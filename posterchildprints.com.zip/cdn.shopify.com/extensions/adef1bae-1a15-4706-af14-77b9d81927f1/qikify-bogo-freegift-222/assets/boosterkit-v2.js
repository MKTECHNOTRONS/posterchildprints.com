(function(fn) {
    typeof define == "function" && define.amd ? define(fn) : fn()
})(function() {
    "use strict";
    var fn = document.createElement("style");
    fn.textContent = `.vm-backdrop{position:fixed;top:0;right:0;bottom:0;left:0;background-color:#00000080}.vm-wrapper{position:fixed;top:0;right:0;bottom:0;left:0;overflow-x:hidden;overflow-y:auto;outline:0}.vm{position:relative;margin:0 auto;width:calc(100% - 20px);min-width:110px;max-width:500px;background-color:#fff;top:30px;cursor:default;box-shadow:0 5px 15px #00000080}.vm-titlebar{padding:10px 15px;overflow:auto;border-bottom:1px solid #e5e5e5}.vm-title{margin-top:2px;margin-bottom:0;display:inline-block;font-size:18px;font-weight:400}.vm-btn-close{color:#ccc;padding:0;cursor:pointer;background:0 0;border:0;float:right;font-size:24px;line-height:1em}.vm-btn-close:before{content:"×";font-family:Arial}.vm-btn-close:hover,.vm-btn-close:focus,.vm-btn-close:focus:hover{color:#bbb;border-color:transparent;background-color:transparent}.vm-content{padding:10px 15px 15px}.vm-content .full-hr{width:auto;border:0;border-top:1px solid #e5e5e5;margin:15px -14px}.vm-fadeIn{animation-name:vm-fadeIn}@keyframes vm-fadeIn{0%{opacity:0}to{opacity:1}}.vm-fadeOut{animation-name:vm-fadeOut}@keyframes vm-fadeOut{0%{opacity:1}to{opacity:0}}.vm-fadeIn,.vm-fadeOut{animation-duration:.25s;animation-fill-mode:both}#qikify-boosterkit,#qikify-boosterkit *,#qikify-boosterkit *:before,#qikify-boosterkit *:after,.qikify-boosterkit-app,.qikify-boosterkit-app *,.qikify-boosterkit-app *:before,.qikify-boosterkit-app *:after,html,html *,html *:before,html *:after{box-sizing:border-box;-webkit-font-smoothing:antialiased}.qikify-boosterkit-app,.qbk-offer-box{font-size:var(--qbk-font-size, inherit);font-family:var(--qbk-font-family, inherit)}.qbk-product-offer{display:flex;flex-flow:column}.qbk-basic{margin:0;padding:0;background-color:transparent;border:none;-webkit-appearance:none;-moz-appearance:none;appearance:none;box-shadow:none;outline:none}.qbk-basicinput[type=radio]{-webkit-appearance:none;-moz-appearance:none;appearance:none;width:auto;margin:0;border:none;min-height:auto}.qbk-basicinput[type=radio]:focus,.qbk-basicinput[type=radio]:hover{border:none;box-shadow:none;outline:none}.qbk-basicinput[type=radio]:after,.qbk-basicinput[type=radio]:checked:after{width:auto;height:auto;border:none}option.qbk-basic{color:#000}.qbk-input-control{min-height:var(--qbk-form-field-height)!important;height:inherit!important;margin:0!important;padding:var(--qbk-space-025) var(--qbk-space-05)!important;line-height:normal!important;font-family:inherit;font-size:.875em!important;color:inherit;text-overflow:ellipsis!important;text-indent:inherit!important;letter-spacing:normal!important;outline:0!important;box-shadow:none!important;background-color:transparent!important;border:0!important}.qbk-input-control[type=number]{-webkit-appearance:textfield!important;-moz-appearance:textfield!important;appearance:textfield!important}.qbk-select-indicator{position:absolute;top:50%;right:var(--qbk-space-05);opacity:.8;transform:translateY(-50%);pointer-events:none}.qbk-input-selector{font-size:inherit!important;margin:0!important;padding:0!important}.qbk-input-wrapper{display:flex;position:relative;justify-content:center;align-items:center}.qbk-input-wrapper:before{content:"";display:block;pointer-events:none;position:absolute;top:0;left:0;width:100%;height:100%;opacity:.15;border:1.5px solid currentColor!important;border-radius:4px}.qbk-input__quantity input{width:var(--qbk-quantity-input-size)!important;color:currentColor;padding-left:0!important;padding-right:0!important;text-align:center!important}.qbk-quantity__control{flex:0 0 var(--qbk-quantity-control-size);width:var(--qbk-quantity-control-size);height:var(--qbk-quantity-control-size);cursor:pointer;-webkit-user-select:none;user-select:none}.qbk-quantity__control svg{fill:currentColor}.qbk-quantity__control.qbk-quantity__control--disabled{opacity:.5;cursor:not-allowed}.qbk-title{margin-bottom:var(--qbk-space-025);font-size:1.25em;line-height:1.3em;font-weight:700;color:currentColor}.qbk-description{font-size:.875em;line-height:1.4em;color:var(--qbk-text-description)}.qbk-count-down__wrapper{display:flex;justify-content:space-between;align-items:center}.qbk-count-down__wrapper--popup{display:flex;justify-content:center;align-items:center}.qbk-bundle-action .qbk-badge{display:none}.qbk-badge.qbk-badge--static .qbk-badge__label{animation:none}.qbk-badge__label{font-size:.75em;font-weight:700;line-height:1.1em;color:var(--qbk-badge-text-color, var(--qbk-button-primary-text-color));transform:scale(1)}.qbk-badge__label:before{display:block;content:"";position:absolute;z-index:-1;top:0;left:0;width:100%;height:100%;border-radius:3px;background-color:var(--qbk-badge-bg-color, var(--qbk-button-primary-bg-color))}.qbk-design-mode__empty-offer{width:100%;height:100%}.qbk-mr-1{margin-right:10px}.qbk-mb-1{margin-bottom:10px}.qbk-toast{position:fixed;left:50%;transform:translate(-50%);height:var(--qbk-toast-height);padding:0 2.5em;border-radius:calc(var(--qbk-toast-height) / 2);background-color:var(--qbk-toast-background-color);border-radius:5px;display:flex;justify-content:center;align-items:center;z-index:999999;bottom:30px}.qbk-toast__content{color:var(--qbk-toast-color);font-size:1em}.toast-enter-active{animation:qbk-slide-up .3s}.toast-leave-active{animation:qbk-fade-out .2s}:root{--qbk-popup-background-color: #fff;--qbk-popup-text-primary-color: #000;--qbk-highlight-color: #0f3ad5;--qbk-button-primary-bg-color: #3847D1;--qbk-button-primary-text-color: #FFFFFF;--qbk-button-secondary-bg-color: #FDE991;--qbk-button-secondary-text-color: #000000;--qbk-button-subdued-text-color: #333;--qbk-font-size: 16px;--qbk-space-025: .25em;--qbk-space-05: .5em;--qbk-space-1: 1em;--qbk-space-2: 1.25em;--qbk-gap: .75em;--qbk-subdued-bg-color: #f1f1f1;--qbk-subdued-text-color: #8E8E8E;--qbk-checkmark-size: 18px;--qbk-border-neutral-subdued: rgba(186, 191, 195, 1);--qbk-error-banner: #ffddd4;--qbk-text-required: #da3b0f;--qbk-text-color-inverse: #fff;--qbk-subdued-highlight: color-mix(in srgb, var(--qbk-highlight-color) 10%, #fff);--qbk-lighten-highlight: color-mix(in srgb, var(--qbk-highlight-color) 25%, #fff);--qbk-success-color: #29805F;--qbk-form-field-height: 28px;--qbk-form-radius: 3px;--qbk-form-field-thickness: 1px;--qbk-quantity-control-size: 20px;--qbk-quantity-input-size: 24px;--qbk-text-primary: var(--qbk-popup-text-primary-color);--qbk-text-description: color-mix(in srgb, currentColor, transparent 25%);--qbk-cart-widget-discount-badge-bg-color: var(--qbk-subdued-bg-color);--qbk-cart-widget-discount-badge-text-color: var(--qbk-subdued-text-color);--qbk-order-goal-bar-size: 7px;--qbk-order-goal-icon-size: 2.1em;--qbk-order-goal-subdued: var(--qbk-subdued-highlight, var(--qbk-subdued-bg-color));--qbk-order-goal-bar-empty-color: var(--qbk-order-goal-subdued);--qbk-order-goal-bar-progress-color: var(--qbk-highlight-color);--qbk-order-goal-bar-milestone-bg-color: var(--qbk-order-goal-subdued);--qbk-order-goal-bar-milestone-color: var(--qbk-highlight-color);--qbk-order-goal-bar-milestone-done-bg-color: var(--qbk-highlight-color);--qbk-order-goal-bar-milestone-done-color: var(--qbk-button-primary-text-color);--qbk-tooltip-max-width: 200px;--qbk-tooltip-arrow-width: 6px;--qbk-tooltip-background: #3D3D3D;--qbk-tooltip-color: #fff;--qbk-action-button-width: 7em;--qbk-action-border-radius: 10px;--qbk-button-shadow: none;--qbk-button-radius: 4px;--qbk-button-bg-color: #fff;--qbk-button-text-color: var(--qbk-text-primary);--qbk-button-border-color: var(--qbk-border-neutral-subdued);--qbk-button-danger-bg-color: #cb4f27;--qbk-button-disable-bg-color: var(--qbk-subdued-bg-color);--qbk-button-disable-text-color: var(--qbk-subdued-text-color);--qbk-button-subdued-bg-color: var(--qbk-subdued-bg-color);--qbk-button-bundle-font-size: .9375em;--qbk-offer-image-size: 68px;--qbk-offer-shadow: 0px 1px 5px rgba(124, 124, 124, .1);--qbk-offer-background-color: var(--qbk-popup-background-color);--qbk-offer-checkbox-size: 18px;--qbk-offer-checkbox-thickness: 1.5px;--qbk-offer-checkbox-border-color: var(--qbk-highlight-color);--qbk-offer-checkbox-bg-color: var(--qbk-highlight-color);--qbk-offer-checkbox-svg-color: var(--qbk-text-color-inverse);--qbk-offer-price-color: var(--qbk-highlight-color);--qbk-offer-quantity-bg-color: #a3a3a3;--qbk-offer-background-img: none;--qbk-popup-zindex: 9999999;--qbk-popup-backdrop-color: rgba(10, 10, 10, .6);--qbk-popup-scrollbar-bg-color: #aaa;--qbk-popup-total-value-color: var(--qbk-highlight-color);--qbk-recommendation-offer-gap: 16px;--qbk-truncate-max-lines: 1;--qbk-truncate-line-height: 1.5em;--qbk-bundle-horizontal-offer-width: 180px;--qbk-bundle-horizontal-gap: 1.2rem;--qbk-free-gift-promote-banner-bg-color: var(--qbk-button-secondary-bg-color);--qbk-free-gift-promote-banner-color: var(--qbk-button-secondary-text-color);--qbk-gift-goal-completed-color: #f64325;--qbk-gift-goal-added-color: #7AC143;--qbk-today-offer-z-index: 999999;--qbk-today-offer-bg-color: #fff;--qbk-today-offer-text-color: #000;--qbk-today-offer-header-bg-color: var(--qbk-subdued-highlight);--qbk-today-offer-border-color: var(--qbk-lighten-highlight);--qbk-today-offer-claimed-bg-color: var(--qbk-subdued-highlight);--qbk-today-offer-claimed-header-bg-color: var(--qbk-highlight-color);--qbk-today-offer-claimed-border-color: var(--qbk-highlight-color);--qbk-today-offer-offer-img-size: 50px;--qbk-today-offer-counter-size: 18px;--qbk-today-offer-counter-position: calc(var(--qbk-today-offer-counter-size) / 2 * -1 + 1px);--qbk-today-offer-counter-bg-color: #E65F5A;--qbk-toast-background-color: #23945d;--qbk-toast-color: white;--qbk-toast-height: 40px;--qbk-promotion-badge-color: var(--qbk-button-primary-text-color);--qbk-promotion-badge-bg-color: var(--qbk-button-primary-bg-color)}.qbk-spinner{width:16px;height:16px;margin:0 auto;border-radius:100%;border-width:2px;border-style:solid;border-color:rgb(55,55,55) rgb(255,255,255) rgb(255,255,255);border-image:initial;transition:all .3s linear;animation:qbk-spinner--spin .8s linear 0s infinite}.qbk-checkmark{display:none;position:absolute;top:var(--qbk-space-05);left:var(--qbk-space-05);width:var(--qbk-checkmark-size);height:var(--qbk-checkmark-size);border-radius:50%;box-shadow:inset 0 0 #7ac142;stroke-width:5;stroke:#fff;stroke-miterlimit:10;animation:qbk--fill .4s ease-in-out .4s forwards,qbk--scale .3s ease-in-out .9s both}.qbk-checkmark .qbk-checkmark__circle{stroke-dasharray:166;stroke-dashoffset:166;stroke-width:2;stroke-miterlimit:10;stroke:#7ac142;fill:none;animation:qbk--stroke .6s cubic-bezier(.65,0,.45,1) forwards}.qbk-checkmark .qbk-checkmark__check{transform-origin:50% 50%;stroke-dasharray:48;stroke-dashoffset:48;animation:qbk--stroke .3s cubic-bezier(.65,0,.45,1) .8s forwards}.qbk-offer__body--added .qbk-checkmark{display:block;z-index:1000}.qbk-tooltip{display:none;position:absolute;bottom:100%;left:50%;width:max-content;max-width:var(--qbk-tooltip-max-width);padding:var(--qbk-space-025) var(--qbk-space-05);text-align:center;text-transform:none;font-weight:400;font-size:.875em;color:var(--qbk-tooltip-color);line-height:1.4em;border-radius:5px;background-color:var(--qbk-tooltip-background);transform:translate(-50%,-50%)}.qbk-tooltip:after{content:"";position:absolute;top:100%;left:50%;width:0;height:0;border-width:var(--qbk-tooltip-arrow-width);border-style:solid;border-color:var(--qbk-tooltip-background) transparent transparent transparent;transform:translate(-50%)}.qbk-watermark{height:30px!important;justify-content:center!important;opacity:.8!important}.qbk-watermark.qbk-watermark--dark{opacity:.4!important}.qbk-watermark:hover{opacity:1!important}.qbk-watermark:hover.qbk-watermark--dark{opacity:.7!important}.qbk-watermark .qbk-logo{width:15px!important;height:18px!important;position:relative;margin-right:5px!important;overflow:hidden}.qbk-watermark .qbk-logo>svg{transform:scale(.044982699)!important;transform-origin:0 0!important}.qbk-watermark>span>strong{text-decoration:underline!important}.qbk-truncate{display:block;display:-webkit-box;overflow:hidden;text-overflow:ellipsis;word-wrap:break-word;max-height:calc(var(--qbk-truncate-line-height) * var(--qbk-truncate-max-lines));line-height:var(--qbk-truncate-line-height);-webkit-line-clamp:var(--qbk-truncate-max-lines);-webkit-box-orient:vertical}.qbk-navigate{display:flex;gap:6px;justify-content:flex-end;margin-bottom:10px}.qbk-navigate .qbk-navigate__prev,.qbk-navigate .qbk-navigate__next{display:flex;justify-content:center;align-items:center;width:1.5em;height:1.5em;color:#000;background-color:#0003;border-radius:6px;opacity:.7}.qbk-navigate .qbk-navigate__prev svg,.qbk-navigate .qbk-navigate__next svg{width:.6em;height:.6em}.qbk-navigate .qbk-navigate__prev:hover,.qbk-navigate .qbk-navigate__next:hover{opacity:1}.qbk-navigate .qbk-navigate__prev[disabled=true],.qbk-navigate .qbk-navigate__next[disabled=true]{opacity:.4;cursor:not-allowed}.qbk-bogo__main-content .qbk-navigate,.qbk-bundle-action .qbk-navigate,.qbk-upsurge-action .qbk-navigate{margin-top:-5px}.qbk-bundle__main-content .qbk-navigate{display:none}@keyframes qbk--stroke{to{stroke-dashoffset:0}}@keyframes qbk--scale{0%,to{transform:none}50%{transform:scale3d(1.1,1.1,1)}}@keyframes qbk--fill{to{box-shadow:inset 0 0 0 30px #7ac142}}@keyframes qbk-spinner--spin{0%{transform:rotate(0)}to{transform:rotate(1turn)}}@keyframes qbk-shake{0%,to{-webkit-transform:translateZ(0);transform:translateZ(0)}10%,30%,50%,70%,90%{-webkit-transform:translate3d(0,-10px,0);transform:translate3d(0,-10px,0)}20%,40%,60%,80%{-webkit-transform:translate3d(0,10px,0);transform:translate3d(0,10px,0)}}@keyframes qbk-progress-bar-stripes{0%{background-position-x:1rem}}@keyframes qbk-badge-scale{0%{transform:scale(1)}50%{transform:scale(.92)}to{transform:scale(1)}}@keyframes qbk-gift-goal-scale{0%{transform:scale(1.1)}50%{transform:scale(.9)}to{transform:scale(1.1)}}@keyframes qbk-slide-up{0%{bottom:0}to{bottom:30px}}@keyframes qbk-fade-out{0%{opacity:1}to{opacity:0}}.qbk--offer-enter-active{opacity:1;transform:scale(1);transition:opacity linear .3s,transform ease-in-out .4s}.qbk--offer-enter{opacity:0;transform:scale(.95)}.qbk--offer-leave-active{display:none!important}.qbk-offer-list--carousel{min-height:86px}.qbk-offer-list--carousel .qbk-offer__body,.qbk-offer-list--carousel .qbk-offer-list__body{position:absolute;top:0;left:0;width:100%;height:100%}.qbk-fade-enter-active,.qbk-fade-leave-active{transition:opacity .5s ease}.qbk-fade-enter-from,.qbk-fade-leave-to{opacity:0}@keyframes qbk-online-dot{0%{opacity:.8;transform:scale(.5)}to{opacity:0;transform:scale(2)}}.vm-titlebar{display:none}.vm-content{padding:0;background-color:#6f6d7a}.vm-wrapper{display:flex;align-items:center}.vm-wrapper .vm{top:auto}.qbk-popup,.qbk-popup-added-gift,.qbk-popup-gift-goal{z-index:var(--qbk-popup-zindex)!important;background-color:var(--qbk-popup-backdrop-color);font-size:var(--qbk-font-size, inherit);font-family:var(--qbk-font-family, inherit);--qbk-text-primary: var(--qbk-popup-text-primary-color) }.qbk-popup-wrapper{position:relative;width:500px;margin:0 auto;line-height:1.3em;font-size:1em;color:var(--qbk-text-primary);background-color:var(--qbk-popup-background-color);border-radius:6px;box-shadow:0 20px 60px -2px #1b213a4d}.qbk-popup-wrapper .qbk-bundle-action,.qbk-popup-wrapper .qbk-upsurge-action{display:none}@media (max-width: 575px){.qbk-popup-wrapper{width:95%;margin-left:auto;margin-right:auto}}.qbk-popup__header-silent{position:absolute;z-index:1;top:-40px;left:0;right:0;height:40px}.qbk-popup__footer-silent{display:flex;justify-content:center;align-items:center;width:100%;position:absolute;z-index:1;bottom:-50px;right:50%;height:40px;gap:10px;transform:translate(50%)}.qbk-popup__header{position:relative;overflow:hidden;padding:20px;text-align:center}.qbk-popup__header .qbk-popup__title{font-size:1.38em}.qbk-popup__header .qbk-badge{position:absolute;top:36px;left:36px;text-align:center;transform:translate(-50%,-50%) rotate(-45deg)}.qbk-popup__header .qbk-badge__label{padding:4px 5px}.qbk-popup__header .qbk-badge__label:before{left:-50px;width:calc(100% + 100px)}.qbk-popup__body{max-height:400px;overflow:auto;padding-bottom:var(--qbk-space-05);padding:0 var(--qbk-space-1) var(--qbk-space-05) var(--qbk-space-1);color:transparent;transition:color ease .2s}.qbk-popup__body::-webkit-scrollbar,.qbk-popup__body::-webkit-scrollbar-thumb{width:8px;border-radius:5px;background-clip:padding-box;border:2px solid transparent}.qbk-popup__body::-webkit-scrollbar-thumb{box-shadow:inset 0 0 0 3px}.qbk-popup__body:hover{color:var(--qbk-popup-scrollbar-bg-color)}.qbk-popup__footer{position:relative;display:flex;justify-content:space-between;align-items:center;padding:var(--qbk-space-05) var(--qbk-space-1)}.qbk-popup__footer:before{content:"";display:block;position:absolute;top:0;left:0;right:0;height:1px;opacity:.2;background-color:var(--qbk-button-primary-bg-color)}.qbk-popup__footer.qbk-popup__footer--free-gift{justify-content:flex-end}.qbk-popup__total{display:flex;align-items:flex-start}.qbk-popup__total-value{padding:0 10px}.qbk-popup__total-value .qbk-offer__price--offer{color:var(--qbk-popup-total-value-color);font-weight:700}.qbk-popup__total-title{font-size:.85em;font-weight:700;opacity:.7;color:var(--qbk-text-primary)}.qbk-popup__outside-btn{display:flex;align-items:center;justify-content:center;z-index:100;width:35px;height:35px;color:#fff!important;background-color:#000000b3;opacity:.7;transition:opacity .25s ease-out;cursor:pointer}.qbk-popup__outside-btn:hover{opacity:1;color:#fff!important}.qbk-popup__outside-btn svg{width:.6em;height:.6em}.qbk-popup__footer-silent .qbk-popup__outside-btn{color:var(--qbk-text-primary)!important;background-color:var(--qbk-popup-background-color);opacity:.9}.qbk-popup__close{position:absolute;top:0;right:0;border-radius:50%}.qbk-popup__next,.qbk-popup__prev{border-radius:6px}.qbk-popup__next[disabled=true],.qbk-popup__prev[disabled=true]{opacity:.4;cursor:not-allowed}.qbk-popup__action-btn{display:flex;align-items:flex-start;flex-shrink:0}@media (max-width: 359px){.qbk-popup__action-btn{flex-shrink:1}}.qbk-popup__action-btn .qbk-popup__skip{margin-right:var(--qbk-space-1);font-weight:400;opacity:.7;transition:opacity .1s ease-out}.qbk-popup__action-btn .qbk-popup__skip:hover{opacity:1}.qbk-popup__action-btn .qbk-popup__add-more{margin-left:10px}.qbk-popup__action-btn:has(.qbk-btn--error):hover .qbk-tooltip{display:block}.qbk-offer{position:relative;margin-bottom:var(--qbk-space-1);color:var(--qbk-text-primary)}.qbk-offer .qbk-offer--loading{display:flex;justify-content:center;align-items:center;min-height:105px}.qbk-offer__variant{display:block;width:100%;min-width:56px;-webkit-appearance:none;-moz-appearance:none;appearance:none;border:0;cursor:pointer;padding-right:calc(var(--qbk-space-1) + 18px)!important;background-image:none!important;color:currentColor;font-style:normal!important}.qbk-offer__body{display:flex;position:relative;overflow:hidden;padding-left:var(--qbk-gap);max-width:100%;background-color:var(--qbk-offer-background-color);background-image:var(--qbk-offer-background-img);background-size:contain;border-radius:4px;box-shadow:var(--qbk-offer-shadow)}.qbk-offer__body:before{content:"";display:block;pointer-events:none;position:absolute;top:0;left:0;width:100%;height:100%;border:1px solid var(--qbk-border-neutral-subdued);opacity:.3;border-radius:4px}.qbk-offer__body.qbk-offer__body--added:before{border-color:var(--qbk-highlight-color);opacity:.4}.qbk-offer__image{display:block;position:relative;align-self:center;height:var(--qbk-offer-image-size);width:var(--qbk-offer-image-size);flex:0 0 var(--qbk-offer-image-size);margin:var(--qbk-gap) var(--qbk-gap) var(--qbk-gap) 0;background-size:contain;background-repeat:no-repeat;background-position:50%;background-color:#f1f1f1;overflow:hidden;border-radius:4px}.qbk-offer__title{--qbk-truncate-max-lines: 2;font-weight:700;font-size:.875em;line-height:1.2em;text-decoration:none;color:currentColor}.qbk-offer__title:hover{color:currentColor}.qbk-offer__sub-body{flex-grow:1;overflow:hidden}.qbk-offer__contents{display:flex;flex-direction:column;padding:var(--qbk-gap);padding-left:0;margin-left:var(--qbk-space-025)}.qbk-offer__content{display:flex;align-items:center;margin-bottom:var(--qbk-space-025)}@media (max-width: 359px){.qbk-offer__content{flex-wrap:wrap}}.qbk-offer__content-actions{gap:5px}.qbk-offer__content-actions .qbk-offer__variants{display:block;position:relative;max-width:calc(100% - 2.5em)}.qbk-offer__description{font-size:.875em}.qbk-offer__checkbox{display:flex;align-items:center;margin-right:var(--qbk-gap)}.qbk-offer__checkbox-label{display:flex;cursor:pointer;justify-content:center;align-items:center;font-size:inherit;-webkit-user-select:none;user-select:none}.qbk-offer__checkbox-tick{display:flex;position:relative;top:1px;width:var(--qbk-offer-checkbox-size);height:var(--qbk-offer-checkbox-size);justify-content:center;opacity:.4;border:var(--qbk-offer-checkbox-thickness) solid var(--qbk-offer-checkbox-border-color);border-radius:var(--qbk-form-radius);background-color:transparent}.qbk-offer__checkbox-tick .qbk-svg-icon{display:block;opacity:0;fill:var(--qbk-offer-checkbox-svg-color)}input.qbk-offer__checkbox-input[type=checkbox]{display:none}input.qbk-offer__checkbox-input[type=checkbox][disabled]+label,.qbk-offer--limited input.qbk-offer__checkbox-input[type=checkbox]+label{cursor:not-allowed}.qbk-offer--limited .qbk-offer__checkbox-tick{border-color:var(--qbk-border-neutral-subdued)}.qbk-offer__body--added .qbk-offer__checkbox-tick{opacity:1;background-color:var(--qbk-offer-checkbox-bg-color)}.qbk-offer__body--added .qbk-offer__checkbox-tick .qbk-svg-icon{opacity:1}.qbk-bundle__offers--original .qbk-offer__body--added .qbk-offer__checkbox-tick{background-color:transparent}.qbk-offer__price{display:flex;line-height:1.3em;margin-bottom:var(--qbk-space-05)}.qbk-offer__price--offer{display:inline-block;color:var(--qbk-offer-price-color);font-weight:700;font-size:.9375em}.qbk-offer__price--bundle .qbk-offer__price--offer,.qbk-bundle--not-valid .qbk-offer__price--offer{display:none}.qbk-offer__price--origin{display:inline-block;position:relative;margin:0 var(--qbk-space-05);opacity:.7;color:currentColor;font-size:.875em}.qbk-offer__price--origin.qbk-offer__price--no-space{display:block;margin:0}.qbk-offer__price--bundle .qbk-offer__price--origin{margin:0}.qbk-bundle--not-valid .qbk-offer__price--origin,.qbk-offer__price--bundle-children .qbk-offer__price--origin{margin:0;display:block!important}.qbk-offer__price--origin:before{content:"";display:block;position:absolute;top:50%;left:0;height:1.5px;width:100%;margin-top:-1px;opacity:.5;background-color:currentColor}.qbk-offer__price--bundle .qbk-offer__price--origin:before,.qbk-bundle--not-valid .qbk-offer__price--origin:before{display:none}.qbk-offer__content .qbk-offer__action-btn{width:auto;height:var(--qbk-form-field-height)!important;padding:var(--qbk-space-025) var(--qbk-space-1)!important;margin-left:auto;border-radius:10px!important;font-size:.65em!important;font-weight:700!important;text-transform:uppercase}.qbk-offer__action-name{position:relative;top:1px}.qbk-offer__quantity{margin-right:calc(var(--qbk-space-1) - 5px)}.qbk-offer__quantity input::-webkit-outer-spin-button,.qbk-offer__quantity input::-webkit-inner-spin-button{-webkit-appearance:none}.qbk-offer__quantity-label{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;width:var(--qbk-form-field-height);height:var(--qbk-form-field-height);font-size:.85em;font-weight:700}.qbk-offer__quantity-label:before{content:"";display:block;position:absolute;z-index:-1;top:0;left:0;width:100%;height:100%;opacity:.3;border-radius:50%;background-color:var(--qbk-offer-quantity-bg-color)}.qbk-offer__selected-items-counter{margin-bottom:var(--qbk-space-1);font-weight:700}.qbk-popup .qbk-offer__selected-items-counter{color:var(--qbk-text-primary)}.qbk-cart-widget{display:flex;flex-direction:column;gap:4px;margin-bottom:5px;min-height:2em}.qbk-cart-widget__summary-line{display:flex;align-items:baseline;justify-content:space-between;gap:2rem}.qbk-cart-widget__summary-line-subtotal{font-weight:700}.qbk-cart-widget__discount-section{margin:5px 0 0;display:flex;flex-wrap:wrap;gap:10px}.qbk-cart-widget__discount-code{display:flex;font-size:.8em;padding:6px 10px 3px;background:var(--qbk-cart-widget-discount-badge-bg-color);color:var(--qbk-cart-widget-discount-badge-text-color);border-radius:5px}.qbk-cart-widget__info-section{margin-top:10px;display:flex;flex-direction:column;gap:15px}.qbk-cart-widget__info-text{align-self:flex-end;font-size:.8em}.qbk-cart-widget__summary-line-subtotal__value{font-size:1.1em}.qbk-cart-widget-divider{line-height:0;font-size:0;margin:15px 0}.qbk-cart-widget-divider:before{content:"";display:block;height:1px;width:100%;background:currentColor;opacity:.1}.qbk-svg-icon{display:block;fill:currentColor;height:auto}.qbk-select-indicator .qbk-svg-icon{width:18px;fill:currentColor}.qbk-svg-icon--xs{width:12px}.qbk-svg-icon--sm{width:16px}.qbk-svg-icon--md{width:20px}.qbk-svg-icon--lg{width:24px}.qbk-svg-icon--xl{width:28px}.qbk-btn{display:inline-flex;justify-content:center;align-items:center;min-width:auto;padding:0 var(--qbk-space-1)!important;color:var(--qbk-button-text-color);background-color:var(--qbk-button-bg-color);font:inherit;font-size:.875em!important;font-weight:700;line-height:1.3em;border:.0625rem solid var(--qbk-button-border-color);border-radius:var(--qbk-button-radius)!important;box-shadow:var(--qbk-button-shadow);transform:scale(1);transition:transform .1s ease-in-out,opacity .1s linear}.qbk-btn:disabled,.qbk-btn[disabled]{color:var(--qbk-button-disable-text-color);border-color:var(--qbk-button-disable-bg-color);background-color:var(--qbk-button-disable-bg-color);pointer-events:none;outline:0}.qbk-btn:hover{cursor:pointer;opacity:.9;transform:scale(1.05)}.qbk-btn.qbk-btn--uppercase{text-transform:uppercase}.qbk-btn.qbk-btn--normal{padding:var(--qbk-space-05) var(--qbk-space-2)!important;color:initial}.qbk-btn.qbk-btn--primary{--qbk-button-border-color: var(--qbk-button-primary-bg-color);--qbk-button-bg-color: var(--qbk-button-primary-bg-color);--qbk-button-text-color: var(--qbk-button-primary-text-color);padding:var(--qbk-space-05) var(--qbk-space-2)!important}.qbk-btn.qbk-btn--primary.qbk-btn--loading:after{border-color:var(--qbk-button-primary-bg-color) var(--qbk-button-primary-text-color)!important}.qbk-btn.qbk-btn--secondary{--qbk-button-border-color: var(--qbk-button-secondary-bg-color);--qbk-button-bg-color: var(--qbk-button-secondary-bg-color);--qbk-button-text-color: var(--qbk-button-secondary-text-color)}.qbk-btn.qbk-btn--secondary.qbk-btn--loading:after{border-color:#000 var(--qbk-button-secondary-bg-color)}.qbk-btn.qbk-btn--subdued{--qbk-button-border-color: var(--qbk-button-subdued-bg-color);--qbk-button-bg-color: var(--qbk-button-subdued-bg-color);--qbk-button-text-color: var(--qbk-button-subdued-text-color)}.qbk-btn.qbk-btn--subdued.qbk-btn--loading:after{border-color:#000 var(--qbk-button-subdued-bg-color)}.qbk-btn.qbk-btn--danger{--qbk-button-border-color: var(--qbk-button-danger-bg-color);--qbk-button-bg: var(--qbk-button-danger-bg-color);--qbk-button-color: var(--qbk-text-color-inverse)}.qbk-btn.qbk-btn--danger.qbk-btn--loading:after{border-color:#000 var(--qbk-button-danger-bg-color)}.qbk-btn.qbk-btn--outline{--qbk-button-bg: transparent;outline:none}.qbk-btn.qbk-btn--outline.qbk-btn--danger{--qbk-button-color: var(--qbk-button-danger-bg-color)}.qbk-btn.qbk-btn--outline.qbk-btn--primary{--qbk-button-color: var(--qbk-button-primary-bg-color)}.qbk-btn.qbk-btn--outline.qbk-btn--loading:after{border-color:#000 #fff}.qbk-btn.qbk-btn--plain{border:none!important;background-color:transparent!important;outline:none;box-shadow:none;padding:var(--qbk-space-05)!important}.qbk-btn.qbk-btn--plain:hover{text-decoration:underline}.qbk-btn.qbk-btn--loading{display:flex;justify-content:center;align-items:center;pointer-events:none}.qbk-btn.qbk-btn--loading span{opacity:0}.qbk-btn.qbk-btn--loading:after{content:"";position:absolute;width:16px;height:16px;margin:0 auto;border-radius:100%;border-width:1.5px;border-style:solid;border-color:var(--qbk-popup-background-color) var(--qbk-popup-text-primary-color);border-image:initial;transition:all .3s linear;animation:qbk-spinner--spin .8s linear 0s infinite}.qbk-btn.qbk-btn--error .qbk-btn__error{position:absolute;top:50%;left:50%;pointer-events:auto;transform:translate(-50%,-50%)}.qbk-btn.qbk-btn--error:not(.qbk-btn--error-hidden)>span{opacity:0}.qbk-btn.qbk-btn--error .qbk-svg-icon{fill:var(--qbk-button-danger-bg-color)}.qbk-btn.qbk-btn--error:hover .qbk-tooltip{display:block}.qbk-bogo.qbk-bogo--added .qbk-bogo__offers{background-color:#eee}.qbk-bogo.qbk-bogo--added .qbk-bogo__offers .qbk-offer__checkbox-label{pointer-events:none}.qbk-bogo .qbk-bogo_description{display:flex;margin-bottom:var(--qbk-space-1);font-weight:700}.qbk-popup .qbk-bogo .qbk-bogo_description{color:var(--qbk-text-primary)}.qbk-bogo .qbk-bogo_navigate{display:flex;justify-content:end}.qbk-offer-box .qbk-badge{flex:0 0 auto;margin-top:2px;margin-left:var(--qbk-space-025)}.qbk-offer-box .qbk-badge__label{padding:3px 6px;animation:qbk-badge-scale 1.5s ease-in-out infinite}@media (min-width: 768px){.qbk-product-offer--has-nav .qbk-offer-box.qbk-offer-box-bundle--one-column.qbk-offer-box--bundle-horizontal .qbk-description{max-width:30%}}.qbk-offer-box__header{position:relative;margin-bottom:var(--qbk-space-1)}.qbk-offer-box__header__heading{display:flex}.qbk-offer-box__header__heading .qbk-title{flex-grow:1}.qbk-product-offer .qbk-offer-box,.bk-embed-mode .qbk-offer-box{position:relative;margin:var(--qbk-space-1) 0;border-radius:5px}.qbk-product-offer .qbk-offer-box:nth-child(n+2):before,.bk-embed-mode .qbk-offer-box:nth-child(n+2):before{content:"";display:block;height:1.5px;width:100%;margin-bottom:var(--qbk-space-2);opacity:.5;background-color:var(--qbk-border-neutral-subdued)}.qbk-bundle__total{display:flex;justify-content:space-between;align-items:center}.qbk-bundle__total-title{font-size:1em;font-weight:700}.qbk-bundle__total-title,.qbk-bundle__total-value{margin-bottom:var(--qbk-space-025)}.qbk-bundle__action-btn.qbk-btn--primary{padding:var(--qbk-space-05) var(--qbk-space-1)!important;font-size:var(--qbk-button-bundle-font-size)!important}.qbk-bundle__actions{display:flex;flex-direction:column;justify-content:center;align-items:center}.qbk-bundle__actions .qbk-bundle__skip-btn{margin:0 0 var(--qbk-space-05);font-weight:400;color:currentColor;opacity:.7;transition:opacity .1s ease-out}.qbk-bundle__actions .qbk-bundle__skip-btn:hover{opacity:1}.qbk-bundle__actions .qbk-bundle__action-btn{width:100%;margin:var(--qbk-space-05) 0}.qbk-bundle__offers--original .qbk-offer__checkbox-tick{background-color:transparent;border-color:transparent}.qbk-bundle__offers--original .qbk-offer__checkbox-tick .qbk-svg-icon{width:16px;fill:var(--qbk-highlight-color)}.qbk-bundle__offers--original .qbk-bundle__plus-icon{width:30px;margin:0 auto var(--qbk-space-1);fill:currentColor;opacity:.5}.qbk-popup__body .qbk-bundle__offers--original .qbk-bundle__plus-icon{display:none}@media (min-width: 768px){.qbk-offer-box--bundle-horizontal{--qbk-offer-image-size: calc(var(--qbk-bundle-horizontal-offer-width) - var(--qbk-gap) * 2);--qbk-offer-shadow: none;--qbk-button-bundle-font-size: 1em}.qbk-offer-box--bundle-horizontal .qbk-bundle{display:flex;gap:var(--qbk-bundle-horizontal-gap);align-items:center;max-width:100%;overflow:auto}.qbk-product-offer--has-nav .qbk-offer-box--bundle-horizontal .qbk-bundle{position:relative;top:-2.5em}.qbk-offer-box--bundle-horizontal .qbk-bundle__main-content .qbk-navigate{display:flex}.qbk-offer-box--bundle-horizontal .qbk-offer-list--transition{display:flex;gap:var(--qbk-bundle-horizontal-gap)}.qbk-offer-box--bundle-horizontal .qbk-offer-box__header .qbk-badge{display:none}.qbk-offer-box--bundle-horizontal .qbk-offer__body{flex-direction:column}.qbk-offer-box--bundle-horizontal .qbk-bundle__offers .qbk-offer{width:var(--qbk-bundle-horizontal-offer-width);margin-bottom:0}.qbk-offer-box--bundle-horizontal .qbk-offer__contents{padding:0 var(--qbk-gap) var(--qbk-gap) 0;margin-left:0;text-align:center}.qbk-offer-box--bundle-horizontal .qbk-offer__content{justify-content:center}.qbk-offer-box--bundle-horizontal .qbk-offer__price{flex-direction:column;align-items:center}.qbk-offer-box--bundle-horizontal .qbk-bundle__total-title{display:none}.qbk-offer-box--bundle-horizontal .qbk-bundle-action{margin-left:var(--qbk-space-1)}.qbk-offer-box--bundle-horizontal .qbk-bundle-action .qbk-badge{display:block;margin:var(--qbk-space-1) auto;width:fit-content}.qbk-offer-box--bundle-horizontal .qbk-bundle-action .qbk-navigate{display:none}.qbk-offer-box--bundle-horizontal .qbk-bundle__action-btn{white-space:nowrap}.qbk-offer-box--bundle-horizontal .qbk-bundle__total{justify-content:center}.qbk-offer-box--bundle-horizontal .qbk-bundle__total .qbk-bundle__total-value{flex-direction:column-reverse}.qbk-offer-box--bundle-horizontal .qbk-bundle__total .qbk-offer__price--origin{font-size:1em}.qbk-offer-box--bundle-horizontal .qbk-bundle__total .qbk-offer__price--offer{font-size:1.2em}.qbk-offer-box--bundle-horizontal .qbk-offer__price--offer{font-size:1em}.qbk-offer-box--bundle-horizontal .qbk-offer__quantity{position:absolute;top:calc(var(--qbk-gap) + var(--qbk-space-025));right:calc(var(--qbk-gap) + var(--qbk-space-025));margin:0}.qbk-offer-box--bundle-horizontal .qbk-offer__checkbox{position:absolute;z-index:100;top:calc(var(--qbk-gap) + var(--qbk-space-025));left:calc(var(--qbk-gap) + var(--qbk-space-025))}.qbk-offer-box--bundle-horizontal .qbk-offer__content-actions{display:block;gap:0}.qbk-offer-box--bundle-horizontal .qbk-offer__content-actions .qbk-offer__variants{max-width:none}.qbk-offer-box--bundle-horizontal .qbk-bundle__offers--original{display:flex;gap:var(--qbk-bundle-horizontal-gap)}.qbk-offer-box--bundle-horizontal .qbk-bundle__plus-icon{width:40px;margin:0 var(--qbk-space-05)}.qbk-offer-box--bundle-horizontal .qbk-watermark{justify-content:flex-start!important;width:fit-content;margin-top:var(--qbk-space-05)}}.qbk-error-banner{padding:var(--qbk-space-025) var(--qbk-space-1);margin-top:var(--qbk-space-05);color:var(--qbk-text-required);font-size:.9em;border-radius:3px;text-align:center;background-color:var(--qbk-error-banner)}.qbk-order-goal{max-width:760px;min-width:360px;margin:var(--qbk-space-1) auto;padding:0 var(--qbk-space-1)}.qbk-order-goal.qbk-order-goal--done .qbk-order-goal__message,.qbk-order-goal.qbk-order-goal--done .qbk-order-goal__bar{transition:all .3s;animation-name:qbk-shake;animation-duration:1s;animation-fill-mode:both;animation-delay:.6s}@media (max-width: 767px){.qbk-order-goal{max-width:95%}}@media (max-width: 359px){.qbk-order-goal{min-width:auto}}@media (max-width: 359px){.qbk-order-goal.qbk-order-goal--hide-title .qbk-order-goal__title{display:none}}.qbk-order-goal__design-mode{display:flex;justify-content:center;align-items:center;margin:10px 0}.qbk-order-goal__design-mode .qbk-design-mode__empty-offer{width:60%;height:auto}.qbk-order-goal__message{margin-bottom:var(--qbk-space-05)}.qbk-order-goal--gift .qbk-order-goal__message{display:flex;justify-content:space-around;align-items:center}.qbk-order-goal__message .qbk-order-goal__promote-message{text-align:center;font-size:1.25em;line-height:1.4em;padding:var(--qbk-space-05)}.qbk-order-goal__message .qbk-order-goal__message--highlight{color:var(--qbk-highlight-color);font-weight:700}.qbk-relative-teleport .qbk-order-goal__message{min-width:100%;font-size:.7em;margin-top:0}.qsc2-drawer .qbk-relative-teleport .qbk-order-goal__message{margin-top:10px}.qbk-order-goal__bar{position:relative;padding-top:calc((var(--qbk-order-goal-icon-size) - var(--qbk-order-goal-bar-size)) * .5);padding-bottom:calc(var(--qbk-order-goal-icon-size) * .5 + 32px);margin-right:calc(var(--qbk-order-goal-icon-size) * .5)}.qbk-order-goal__progress{position:relative;height:var(--qbk-order-goal-bar-size);background-color:var(--qbk-order-goal-bar-empty-color);border-radius:10px}.qbk-order-goal__progress:before{display:block;content:"";position:absolute;top:0;left:0;bottom:0;width:var(--qbk-order-goal-process);border-radius:10px 0 0 10px;background-color:var(--qbk-order-goal-bar-progress-color);transition:width .35s ease-in-out}.qbk-order-goal__milestone{position:absolute;top:0;display:flex;flex-flow:column;align-items:center;justify-content:center;max-width:100px;transform:translate(-50%)}.qbk-order-goal__milestone.qbk-order-goal__milestone--hidden{display:none}.qbk-order-goal__milestone.qbk-order-goal__milestone--gift{cursor:pointer}.qbk-order-goal__milestone.qbk-order-goal__milestone--gift .qbk-svg-icon{animation:qbk-gift-goal-scale 1s ease-in-out infinite}.qbk-order-goal__milestone.qbk-order-goal__milestone--gift-done{animation:none}.qbk-order-goal__milestone.qbk-order-goal__milestone--gift-done .qbk-order-goal__icon:before{content:"";display:block;position:absolute;top:-4px;right:-6px;width:.9em;height:.9em;border-radius:50%;background-color:var(--qbk-gift-goal-added-color);background-image:url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' stroke='%23fff' stroke-width='5' fill='none' stroke-linecap='round' stroke-linejoin='round' class='css-i6dzq1' viewBox='0 0 24 24'%3E%3Cpath d='M20 6L9 17l-5-5'/%3E%3C/svg%3E");background-size:8px;background-position:center;background-repeat:no-repeat}.qbk-order-goal__milestone.qbk-order-goal__milestone--gift-pending .qbk-order-goal__icon:before{content:"";display:block;position:absolute;top:-3px;right:-1px;width:.6em;height:.6em;border-radius:50%;background-color:var(--qbk-gift-goal-completed-color);animation:qbk-gift-goal-scale 1s ease-in-out infinite}.qbk-order-goal__icon{display:flex;position:relative;align-items:center;justify-content:center;width:var(--qbk-order-goal-icon-size);height:var(--qbk-order-goal-icon-size);margin-bottom:var(--qbk-space-025);color:var(--qbk-order-goal-bar-milestone-color);border-radius:50%;background:var(--qbk-order-goal-bar-milestone-bg-color)}.qbk-order-goal__icon .qbk-svg-icon{width:calc(var(--qbk-order-goal-icon-size) * .5);height:calc(var(--qbk-order-goal-icon-size) * .5)}.qbk-order-goal__milestone--done .qbk-order-goal__icon{color:var(--qbk-order-goal-bar-milestone-done-color);background-color:var(--qbk-order-goal-bar-milestone-done-bg-color)}.qbk-order-goal__title{width:max-content;max-width:100px;text-align:center;font-size:.8em}.qbk-relative-teleport .qbk-order-goal{min-width:100%;font-size:.9em;margin-top:0}.qbk-relative-teleport .qbk-order-goal.qbk-order-goal--hide-title .qbk-order-goal__title{display:none}.qbk-relative-teleport .qbk-order-goal.qbk-order-goal--hide-title .qbk-order-goal__milestone:hover .qbk-order-goal__title{display:block}.qbk-relative-teleport .qbk-order-goal.qbk-order-goal--cart-empty{margin-top:4em}.qbk-relative-teleport .qbk-order-goal__message{font-size:1em;padding:0}.qbk-relative-teleport .qbk-order-goal__bar{padding-left:var(--qbk-space-05);padding-right:var(--qbk-space-05)}.qbk-relative-teleport .qbk-recommendation-box{margin-top:0}.qbk-volume{position:relative;margin-bottom:var(--qbk-space-1);color:var(--qbk-text-primary)}.qbk-volume .qbk-volume--loading{display:flex;justify-content:center;align-items:center;height:80px}.qbk-volume-tier{display:flex;overflow:hidden;flex-direction:column;gap:.5em;position:relative;max-width:100%;padding:12px 15px 15px;margin-bottom:var(--qbk-space-1);background-color:var(--qbk-offer-background-color);background-image:var(--qbk-offer-background-img);background-size:100%;border-radius:4px}.qbk-volume-tier:before{box-shadow:0 1px 5px #7c7c7c1a;content:"";display:block;pointer-events:none;position:absolute;top:0;left:0;width:100%;height:100%;border:1px solid var(--qbk-border-neutral-subdued);opacity:.3;border-radius:4px}.qbk-volume-tier.qbk-volume-tier--selected:before{border-color:var(--qbk-highlight-color);opacity:.4}.qbk-volume-tier.qbk-volume-tier--unavailable .qbk-volume-tier__title{cursor:default}.qbk-volume-tier .qbk-badge{position:absolute;top:0;left:30px;margin:0;text-align:center}.qbk-volume-tier .qbk-badge__label{padding:5px 5px 5px 0}.qbk-volume-tier .qbk-badge__label:before{left:-45px;width:calc(100% + 70px);border-radius:0 0 3px 3px}.qbk-volume-tier__extra-section__content{margin-top:20px;display:flex;flex-direction:column;gap:var(--qbk-gap)}.qbk-volume-tier__extra-section__label{font-size:.875em}.qbk-volume-tier__variant-select{display:flex;align-items:center;gap:var(--qbk-gap)}.qbk-volume-tier__main-section,.qbk-volume-tier__info{display:flex;justify-content:space-between;align-items:center;flex-grow:1;overflow:hidden}.qbk-volume-tier__radio{display:flex;align-items:center;margin-right:var(--qbk-gap)}.qbk-volume-tier__radio__label{display:flex;cursor:pointer;justify-content:center;align-items:center;font-size:inherit;-webkit-user-select:none;user-select:none}.qbk-volume-tier__title{--qbk-truncate-max-lines: 2;font-size:1em;line-height:1.2em;cursor:pointer;font-weight:700;color:currentColor;position:relative;top:1px;margin-right:15px}.qbk-volume-tier__item-label{font-size:.875em;width:55px!important}.qbk-volume-tier__radio-tick{display:flex;position:relative;top:1px;width:var(--qbk-offer-checkbox-size);height:var(--qbk-offer-checkbox-size);justify-content:center;opacity:.4;border:var(--qbk-offer-checkbox-thickness) solid var(--qbk-offer-checkbox-border-color);border-radius:100px;background-color:transparent}.qbk-volume-tier__radio-tick .qbk-svg-icon{display:block;opacity:0;fill:var(--qbk-offer-checkbox-svg-color)}input.qbk-volume-tier__radio__input{display:none}input.qbk-volume-tier__radio__input.qbk-volume-tier__radio__input--checked+.qbk-volume-tier__radio__label .qbk-volume-tier__radio-tick{opacity:1;background-color:var(--qbk-offer-checkbox-bg-color)}input.qbk-volume-tier__radio__input.qbk-volume-tier__radio__input--checked+.qbk-volume-tier__radio__label .qbk-volume-tier__radio-tick .qbk-svg-icon{opacity:1}input.qbk-volume-tier__radio__input[disabled]+label{cursor:not-allowed}.qbk-volume__action-btn{width:100%;margin:var(--qbk-space-05) 0}.qbk-volume-tier__price-info{display:flex;flex-direction:column;gap:5px;flex-shrink:0;text-align:end}.qbk-volume-tier__price_section{display:flex;flex-direction:row-reverse;gap:5px}.qbk-volume-tier__price--offer{display:flex;gap:10px;justify-content:end;color:var(--qbk-offer-price-color);font-weight:700;font-size:.9375em}.qbk-volume-tier__price--origin{display:inline-block;position:relative;opacity:.7;color:currentColor;font-size:.875em;margin:0}.qbk-volume-tier__price--origin.strike-through:before{content:"";display:block;position:absolute;top:50%;left:0;height:1.5px;width:100%;margin-top:-1px;opacity:.5;background-color:currentColor}.qbk-divider{display:block!important;border-bottom:1px solid var(--qbk-border-neutral-subdued);opacity:.4}.qbk-recommendation-box{position:relative;display:flex;justify-content:center;align-items:center;width:100%;margin-top:var(--qbk-space-1);margin-bottom:var(--qbk-space-05);padding:0 20px}.qbk-recommendation-box.qbk-recommendation-box--full{padding:0}.qbk-recommendation-box-empty-state{display:flex;justify-content:center;align-items:center;height:9em}.qbk-recommendation-box__container{display:flex;align-items:center;height:100%;min-width:100%;overflow-x:auto;scroll-behavior:smooth}.qbk-recommendation-box__container::-webkit-scrollbar{display:none}.qbk-recommendation-box__container .qbk-offer{flex:0 0 calc(100% / var(--qbk-recommend-box-column));width:calc(100% / var(--qbk-recommend-box-column));padding:0 var(--qbk-space-05);margin:0 auto;max-width:100%}.qbk-recommendation-box__container .qbk-offer--loading{min-height:138px}.qbk-recommendation-box__container .qbk-offer__body{height:100%}.qbk-recommendation-box__container .qbk-offer__body .qbk-btn--error{pointer-events:none}.qbk-recommendation-box__container .qbk-offer__content{align-items:flex-start}.qbk-recommendation-box__container .qbk-offer__content-actions{position:relative;flex-wrap:wrap}.qbk-recommendation-box__container .qbk-offer__quantity-action{display:none;padding-bottom:var(--qbk-space-05)}.qbk-recommendation-box__container .qbk-offer__variants{flex:1 0 50%;max-width:300px}.qbk-recommendation-box__container .qbk-offer__quantity{margin-right:var(--qbk-space-05)}.qbk-recommendation-box__container .qbk-offer__action-btn{margin-left:0;padding-left:3em;padding-right:3em}.qbk-recommendation-box__container .qbk-offer__title{--qbk-truncate-max-lines: 1}.qbk-recommendation__nav{cursor:pointer;position:absolute;top:50%;padding:var(--qbk-space-05);color:var(--qbk-order-goal-bar-milestone-color);background-color:transparent!important;outline:none!important;box-shadow:none!important;border:none!important;-webkit-user-select:none;user-select:none;opacity:.7;transform:translateY(-50%);transition:opacity linear .1s;min-width:auto}.qbk-recommendation__nav:hover{opacity:1;transform:translateY(-50%)}.qbk-recommendation__nav[disabled]{opacity:.4;cursor:not-allowed}.qbk-recommendation__nav--next{right:0;padding-right:0}.qbk-recommendation__nav--prev{left:0;padding-left:0}.qbk-popup .qbk-free-gift .qbk-error-banner{margin-top:0}.qbk-free-gift--auto .qbk-offer__checkbox-tick{background-color:transparent;border-color:transparent}.qbk-free-gift--auto .qbk-offer__checkbox-tick .qbk-svg-icon{width:16px;fill:var(--qbk-highlight-color)}.qbk-free-gift__promote-banner{display:flex;align-items:center;gap:10px;padding:1.5em 1em;margin-bottom:1em;background-color:var(--qbk-free-gift-promote-banner-bg-color);color:var(--qbk-free-gift-promote-banner-color);border-radius:var(--qbk-form-radius)}.qbk-free-gift__promote-banner .qbk-free-gift__promote-icon{flex-shrink:0}.qbk-popup-wrapper .qbk-free-gift__promote-banner,.qbk-promote-free-gift__content .qbk-free-gift__offers{display:none}.qbk-added-gift .qbk-popup__header{display:flex;gap:10px;font-weight:700;padding:30px 20px}.qbk-added-gift .qbk-popup__header .qbk-ag-popup__header-icon{flex-shrink:0;fill:var(--qbk-success-color)}.qbk-added-gift .qbk-popup__body .qbk-offer__title{font-weight:400}.qbk-added-gift .qbk-popup__footer{justify-content:flex-end}.qbk-free-gift_description{margin-bottom:var(--qbk-space-1);font-weight:700}.qbk-popup-wrapper .qbk-free-gift_description{color:var(--qbk-text-primary)}.qbk-upsurge__total{display:flex;justify-content:space-between;align-items:center}.qbk-upsurge__total-title{font-size:1em;font-weight:700}.qbk-upsurge__total-title,.qbk-upsurge__total-value{margin-bottom:var(--qbk-space-025)}.qbk-upsurge__action-btn.qbk-btn--primary{padding:var(--qbk-space-05) var(--qbk-space-1)!important;font-size:var(--qbk-button-upsurge-font-size)!important}.qbk-upsurge__actions{display:flex;flex-direction:column;justify-content:center;align-items:center}.qbk-upsurge__actions .qbk-upsurge__skip-btn{margin:0 0 var(--qbk-space-05);font-weight:400;color:currentColor;opacity:.7;transition:opacity .1s ease-out}.qbk-upsurge__actions .qbk-upsurge__skip-btn:hover{opacity:1}.qbk-upsurge__actions .qbk-upsurge__action-btn{width:100%;margin:var(--qbk-space-05) 0}.qbk-gift-goal .qbk-popup__footer{justify-content:flex-end}.qbk-gift-goal__tiers{display:flex;flex-direction:column;gap:8px}.qbk-gift-goal__tier{color:var(--qbk-text-primary);border-radius:8px;cursor:pointer}.qbk-gift-goal__tier.qbk-gift-goal__tier--active .qbk-gift-goal__tier-body{height:100%;opacity:1;padding:5px}.qbk-gift-goal__tier.qbk-gift-goal__tier--active .qbk-gift-goal__tier-indicator{transform:rotate(180deg)}.qbk-gift-goal__tier-header{display:flex;justify-content:space-between;align-items:center;width:100%;background-color:transparent;padding:8px;border:none}.qbk-gift-goal__tier-header span{max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.qbk-gift-goal__tier-header .qbk-gift-goal__tier-indicator{transition:transform .2s linear}.qbk-gift-goal__info{display:flex;flex-direction:column;gap:5px}.qbk-gift-goal__info.qbk-gift-goal__info--has-description .qbk-gift-goal__tier-title .qbk-gift-goal__tier-label:after{display:inline-block}.qbk-gift-goal__info.qbk-gift-goal__info--has-description .qbk-gift-goal__tier-description{display:inline-block}.qbk-gift-goal__tier-title{position:relative;font-size:.9em;font-weight:700;display:flex;align-items:center}.qbk-gift-goal__tier-title:before{content:"";display:inline-block;left:0;position:absolute;width:.5em;height:.5em;background-color:var(--qbk-subdued-text-color);opacity:.5;border-radius:50%;vertical-align:middle}.qbk-gift-goal__tier-title.qbk-gift-goal__tier-title--completed:before{background-color:var(--qbk-gift-goal-completed-color);opacity:1}.qbk-gift-goal__tier-title.qbk-gift-goal__tier-title--added:before{background-color:var(--qbk-gift-goal-added-color);opacity:1}.qbk-gift-goal__tier-title .qbk-gift-goal__tier-label{margin-left:1em}.qbk-gift-goal__tier-title .qbk-gift-goal__tier-label:after{content:"";display:none;opacity:.2;width:30px;height:1px;background-color:var(--qbk-text-primary);margin:0 10px;vertical-align:middle}.qbk-gift-goal__tier-description{display:none;font-size:.9em;opacity:.6;font-weight:400}.qbk-gift-goal__tier-body{opacity:0;height:0;overflow:hidden;transition:opacity .3s}.qbk-today-offers{position:fixed;bottom:0;left:0;z-index:var(--qbk-today-offer-z-index);color:var(--qbk-today-offer-text-color)}.qbk-today-offers__body__offers--loading{display:flex;justify-content:center;align-items:center}.qbk-today-offers__body__offers--loading .qbk-spinner{margin:2em}.qbk-today-offers__activator{position:relative;margin:1em;background-color:var(--qbk-today-offer-bg-color);border-radius:6px;padding:10px 15px;border:1px solid #eee;box-shadow:0 20px 60px -2px #1b213a4d;z-index:var(--qbk-today-offer-z-index);transition:transform .1s ease-in-out}.qbk-today-offers__activator:hover{cursor:pointer;transform:scale(1.05)}.qbk-today-offers__offer-close{position:absolute;right:-20px;top:-15px;display:flex;justify-content:center;width:var(--qbk-today-offer-counter-size);height:var(--qbk-today-offer-counter-size);background:rgba(23,23,23,.456);color:#fff;border-radius:100%;opacity:.6}.qbk-today-offers__offer-close .qbk-svg-icon{width:8px;fill:#f8f8f8}.qbk-today-offers__offer-close:hover{opacity:1}.qbk-today-offers__offer-count{position:absolute;right:var(--qbk-today-offer-counter-position);top:var(--qbk-today-offer-counter-position);display:flex;justify-content:center;align-items:center;width:var(--qbk-today-offer-counter-size);height:var(--qbk-today-offer-counter-size);background:var(--qbk-today-offer-counter-bg-color);color:#fff;border-radius:100%;font-size:.75em;line-height:var(--qbk-today-offer-counter-size);letter-spacing:normal}.qbk-today-offers__offer-count span{height:100%}.qbk-today-offers__offer-count:before,.qbk-today-offers__offer-count:after{content:"";display:block;position:absolute;z-index:-1;top:0;left:0;width:100%;height:100%;background-color:inherit;border-radius:50%;opacity:1;will-change:auto;transform:translate(0) scale(.5);animation:qbk-online-dot linear 1.5s infinite}.qbk-today-offers__offer-count:after{animation-delay:.6s}.qbk-today-offers__body{position:absolute;top:0;left:0;width:500px;height:auto;max-height:600px;overflow:auto;background-color:var(--qbk-today-offer-bg-color);transform:translate(1em,-100%);border-radius:10px;box-shadow:0 20px 60px -2px #1b213a4d;padding:0 1.5em 1em}@media (max-width: 575px){.qbk-today-offers__body{max-width:calc(100vw - 2em)}}.qbk-today-offers__body-header{position:relative}.qbk-today-offers__body-header .qbk-today-offers__close{position:absolute;top:10px;right:0;cursor:pointer}.qbk-today-offers__body__title{font-size:1.6em;font-weight:700;color:var(--qbk-today-offer-text-color)!important}.qbk-today-offers__body__description{margin-bottom:1.5em;margin-top:-.5em}.qbk-today-offers__body__offer-description{line-height:1.4em;font-size:.9em}.qbk-today-offers__body__offer-description strong{color:var(--qbk-today-offer-claimed-header-bg-color)}.qbk-today-offers__body__offer-contents{display:flex;flex-direction:column;gap:1em;margin:1em 0}.qbk-today-offers__body__offer-wrapper{overflow:hidden;border-radius:6px}.qbk-today-offers__body__offer{display:flex;border:1px solid var(--qbk-today-offer-border-color);justify-content:stretch;align-items:stretch;position:relative;border-radius:6px;background-color:var(--qbk-today-offer-bg-color)}.qbk-today-offers__body__offer:before,.qbk-today-offers__body__offer:after{content:"";width:.8em;height:.8em;border:1px solid var(--qbk-today-offer-border-color);background:#fff;border-radius:50%;position:absolute;top:0;left:2.6em;transform:translateY(-50%);z-index:2}.qbk-today-offers__body__offer:after{top:100%}.qbk-today-offers__body__offer.qbk-today-offers--claimed{background-color:var(--qbk-today-offer-claimed-bg-color);border-color:var(--qbk-today-offer-claimed-border-color)}.qbk-today-offers__body__offer.qbk-today-offers--claimed:before,.qbk-today-offers__body__offer.qbk-today-offers--claimed:after{border-color:var(--qbk-today-offer-claimed-border-color)}.qbk-today-offers__body__offer-header{display:flex;justify-content:center;min-width:3em;border-right:1.5px dashed var(--qbk-today-offer-border-color);background-color:var(--qbk-today-offer-header-bg-color);border-radius:6px}.qbk-today-offers--claimed .qbk-today-offers__body__offer-header{border-right:1.5px dashed var(--qbk-today-offer-claimed-border-color)}.qbk-today-offers__body__offer-header .qbk-svg-icon{fill:var(--qbk-highlight-color)}.qbk-today-offers__body__offer-info{display:flex;justify-content:space-between;align-items:center;width:100%;gap:10px;padding:.8em}.qbk-today-offers__body__offer-content{display:flex;align-items:center;gap:10px}.qbk-today-offers__body__offer-img{width:var(--qbk-today-offer-offer-img-size);height:var(--qbk-today-offer-offer-img-size);flex:0 0 var(--qbk-today-offer-offer-img-size);margin:0}.qbk-today-offers__body__offer-action .qbk-btn{height:22px;font-size:12px!important;padding:1px 10px 0!important;color:var(--qbk-today-offer-claimed-header-bg-color);border-color:var(--qbk-today-offer-claimed-header-bg-color);transition:background-color linear .1s}.qbk-today-offers__body__offer-action .qbk-btn:hover{transform:none!important;background-color:var(--qbk-subdued-highlight)}.qbk-today-offers__body__offer-action svg.qbk-svg-icon{fill:var(--qbk-today-offer-claimed-header-bg-color)}.qbk-promotion-badge{width:fit-content}[qbk-badge-attach] .qbk-promotion-badge{margin:8px}.qbk-promotion-badge__label.qbk-badge__label{padding:3px 8px 4px;color:var(--qbk-promotion-badge-color)}.qbk-promotion-badge__label.qbk-badge__label:before{background-color:var(--qbk-promotion-badge-bg-color)}.qbk-promote-wrapper{z-index:99;position:absolute;top:0;left:0}.qbk-count-down-board{display:inline-flex;justify-content:center;align-items:center;color:var(--qbk-offer-price-color)}.qbk-count-down-item{display:inline-block;min-width:2em;padding:.0625em .25em;border-radius:3px;text-align:center}.qbk-count-down-separate{padding:0 3px;font-size:.875em}.qbk-count-down-digit{display:block;font-weight:700;opacity:1}.qbk-count-down-unit{display:block;position:relative;top:-1px;font-size:.625em;line-height:1em;font-weight:400;opacity:1}.qbk-custom-description__content:has(.qbk-count-down){display:flex;align-items:center;flex-wrap:wrap}.qbk-popup-wrapper .qbk-custom-description__content:has(.qbk-count-down){justify-content:center}
`, document.head.appendChild(fn);

    function uo(e, t) {
        const o = Object.create(null),
            n = e.split(",");
        for (let r = 0; r < n.length; r++) o[n[r]] = !0;
        return t ? r => !!o[r.toLowerCase()] : r => !!o[r]
    }
    const Qe = {}.NODE_ENV !== "production" ? Object.freeze({}) : {},
        Qo = {}.NODE_ENV !== "production" ? Object.freeze([]) : [],
        _t = () => {},
        Ca = () => !1,
        wc = /^on[^a-z]/,
        pn = e => wc.test(e),
        Yn = e => e.startsWith("onUpdate:"),
        Ze = Object.assign,
        ii = (e, t) => {
            const o = e.indexOf(t);
            o > -1 && e.splice(o, 1)
        },
        xc = Object.prototype.hasOwnProperty,
        Re = (e, t) => xc.call(e, t),
        qe = Array.isArray,
        No = e => _n(e) === "[object Map]",
        Wn = e => _n(e) === "[object Set]",
        Ta = e => _n(e) === "[object Date]",
        Ne = e => typeof e == "function",
        Xe = e => typeof e == "string",
        bn = e => typeof e == "symbol",
        je = e => e !== null && typeof e == "object",
        ai = e => je(e) && Ne(e.then) && Ne(e.catch),
        Oa = Object.prototype.toString,
        _n = e => Oa.call(e),
        si = e => _n(e).slice(8, -1),
        Na = e => _n(e) === "[object Object]",
        li = e => Xe(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
        Qn = uo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
        Cc = uo("bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo"),
        Zn = e => {
            const t = Object.create(null);
            return o => t[o] || (t[o] = e(o))
        },
        Tc = /-(\w)/g,
        Pt = Zn(e => e.replace(Tc, (t, o) => o ? o.toUpperCase() : "")),
        Oc = /\B([A-Z])/g,
        At = Zn(e => e.replace(Oc, "-$1").toLowerCase()),
        Po = Zn(e => e.charAt(0).toUpperCase() + e.slice(1)),
        Ao = Zn(e => e ? `on${Po(e)}` : ""),
        mn = (e, t) => !Object.is(e, t),
        Zo = (e, t) => {
            for (let o = 0; o < e.length; o++) e[o](t)
        },
        Jn = (e, t, o) => {
            Object.defineProperty(e, t, {
                configurable: !0,
                enumerable: !1,
                value: o
            })
        },
        Xn = e => {
            const t = parseFloat(e);
            return isNaN(t) ? e : t
        },
        ci = e => {
            const t = Xe(e) ? Number(e) : NaN;
            return isNaN(t) ? e : t
        };
    let Pa;
    const er = () => Pa || (Pa = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});

    function mt(e) {
        if (qe(e)) {
            const t = {};
            for (let o = 0; o < e.length; o++) {
                const n = e[o],
                    r = Xe(n) ? Ic(n) : mt(n);
                if (r)
                    for (const i in r) t[i] = r[i]
            }
            return t
        } else {
            if (Xe(e)) return e;
            if (je(e)) return e
        }
    }
    const Nc = /;(?![^(]*\))/g,
        Pc = /:([^]+)/,
        Ac = /\/\*[^]*?\*\//g;

    function Ic(e) {
        const t = {};
        return e.replace(Ac, "").split(Nc).forEach(o => {
            if (o) {
                const n = o.split(Pc);
                n.length > 1 && (t[n[0].trim()] = n[1].trim())
            }
        }), t
    }

    function Le(e) {
        let t = "";
        if (Xe(e)) t = e;
        else if (qe(e))
            for (let o = 0; o < e.length; o++) {
                const n = Le(e[o]);
                n && (t += n + " ")
            } else if (je(e))
                for (const o in e) e[o] && (t += o + " ");
        return t.trim()
    }
    const Dc = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot",
        Sc = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistantLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view",
        $c = uo(Dc),
        Rc = uo(Sc),
        Fc = uo("itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly");

    function Aa(e) {
        return !!e || e === ""
    }

    function Vc(e, t) {
        if (e.length !== t.length) return !1;
        let o = !0;
        for (let n = 0; o && n < e.length; n++) o = tr(e[n], t[n]);
        return o
    }

    function tr(e, t) {
        if (e === t) return !0;
        let o = Ta(e),
            n = Ta(t);
        if (o || n) return o && n ? e.getTime() === t.getTime() : !1;
        if (o = bn(e), n = bn(t), o || n) return e === t;
        if (o = qe(e), n = qe(t), o || n) return o && n ? Vc(e, t) : !1;
        if (o = je(e), n = je(t), o || n) {
            if (!o || !n) return !1;
            const r = Object.keys(e).length,
                i = Object.keys(t).length;
            if (r !== i) return !1;
            for (const a in e) {
                const s = e.hasOwnProperty(a),
                    c = t.hasOwnProperty(a);
                if (s && !c || !s && c || !tr(e[a], t[a])) return !1
            }
        }
        return String(e) === String(t)
    }

    function Lc(e, t) {
        return e.findIndex(o => tr(o, t))
    }
    const Te = e => Xe(e) ? e : e == null ? "" : qe(e) || je(e) && (e.toString === Oa || !Ne(e.toString)) ? JSON.stringify(e, Ia, 2) : String(e),
        Ia = (e, t) => t && t.__v_isRef ? Ia(e, t.value) : No(t) ? {
            [`Map(${t.size})`]: [...t.entries()].reduce((o, [n, r]) => (o[`${n} =>`] = r, o), {})
        } : Wn(t) ? {
            [`Set(${t.size})`]: [...t.values()]
        } : je(t) && !qe(t) && !Na(t) ? String(t) : t;

    function ui(e, ...t) {
        console.warn(`[Vue warn] ${e}`, ...t)
    }
    let jt;
    class Gc {
        constructor(t = !1) {
            this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this.parent = jt, !t && jt && (this.index = (jt.scopes || (jt.scopes = [])).push(this) - 1)
        }
        get active() {
            return this._active
        }
        run(t) {
            if (this._active) {
                const o = jt;
                try {
                    return jt = this, t()
                } finally {
                    jt = o
                }
            } else({}).NODE_ENV !== "production" && ui("cannot run an inactive effect scope.")
        }
        on() {
            jt = this
        }
        off() {
            jt = this.parent
        }
        stop(t) {
            if (this._active) {
                let o, n;
                for (o = 0, n = this.effects.length; o < n; o++) this.effects[o].stop();
                for (o = 0, n = this.cleanups.length; o < n; o++) this.cleanups[o]();
                if (this.scopes)
                    for (o = 0, n = this.scopes.length; o < n; o++) this.scopes[o].stop(!0);
                if (!this.detached && this.parent && !t) {
                    const r = this.parent.scopes.pop();
                    r && r !== this && (this.parent.scopes[this.index] = r, r.index = this.index)
                }
                this.parent = void 0, this._active = !1
            }
        }
    }

    function Mc(e, t = jt) {
        t && t.active && t.effects.push(e)
    }

    function Bc() {
        return jt
    }
    const gn = e => {
            const t = new Set(e);
            return t.w = 0, t.n = 0, t
        },
        Da = e => (e.w & fo) > 0,
        Sa = e => (e.n & fo) > 0,
        Uc = ({
            deps: e
        }) => {
            if (e.length)
                for (let t = 0; t < e.length; t++) e[t].w |= fo
        },
        jc = e => {
            const {
                deps: t
            } = e;
            if (t.length) {
                let o = 0;
                for (let n = 0; n < t.length; n++) {
                    const r = t[n];
                    Da(r) && !Sa(r) ? r.delete(e) : t[o++] = r, r.w &= ~fo, r.n &= ~fo
                }
                t.length = o
            }
        },
        di = new WeakMap;
    let hn = 0,
        fo = 1;
    const fi = 30;
    let qt;
    const Io = Symbol({}.NODE_ENV !== "production" ? "iterate" : ""),
        pi = Symbol({}.NODE_ENV !== "production" ? "Map key iterate" : "");
    class bi {
        constructor(t, o = null, n) {
            this.fn = t, this.scheduler = o, this.active = !0, this.deps = [], this.parent = void 0, Mc(this, n)
        }
        run() {
            if (!this.active) return this.fn();
            let t = qt,
                o = po;
            for (; t;) {
                if (t === this) return;
                t = t.parent
            }
            try {
                return this.parent = qt, qt = this, po = !0, fo = 1 << ++hn, hn <= fi ? Uc(this) : $a(this), this.fn()
            } finally {
                hn <= fi && jc(this), fo = 1 << --hn, qt = this.parent, po = o, this.parent = void 0, this.deferStop && this.stop()
            }
        }
        stop() {
            qt === this ? this.deferStop = !0 : this.active && ($a(this), this.onStop && this.onStop(), this.active = !1)
        }
    }

    function $a(e) {
        const {
            deps: t
        } = e;
        if (t.length) {
            for (let o = 0; o < t.length; o++) t[o].delete(e);
            t.length = 0
        }
    }
    let po = !0;
    const Ra = [];

    function Do() {
        Ra.push(po), po = !1
    }

    function So() {
        const e = Ra.pop();
        po = e === void 0 ? !0 : e
    }

    function gt(e, t, o) {
        if (po && qt) {
            let n = di.get(e);
            n || di.set(e, n = new Map);
            let r = n.get(o);
            r || n.set(o, r = gn());
            const i = {}.NODE_ENV !== "production" ? {
                effect: qt,
                target: e,
                type: t,
                key: o
            } : void 0;
            _i(r, i)
        }
    }

    function _i(e, t) {
        let o = !1;
        hn <= fi ? Sa(e) || (e.n |= fo, o = !Da(e)) : o = !e.has(qt), o && (e.add(qt), qt.deps.push(e), {}.NODE_ENV !== "production" && qt.onTrack && qt.onTrack(Ze({
            effect: qt
        }, t)))
    }

    function Wt(e, t, o, n, r, i) {
        const a = di.get(e);
        if (!a) return;
        let s = [];
        if (t === "clear") s = [...a.values()];
        else if (o === "length" && qe(e)) {
            const l = Number(n);
            a.forEach((f, u) => {
                (u === "length" || u >= l) && s.push(f)
            })
        } else switch (o !== void 0 && s.push(a.get(o)), t) {
            case "add":
                qe(e) ? li(o) && s.push(a.get("length")) : (s.push(a.get(Io)), No(e) && s.push(a.get(pi)));
                break;
            case "delete":
                qe(e) || (s.push(a.get(Io)), No(e) && s.push(a.get(pi)));
                break;
            case "set":
                No(e) && s.push(a.get(Io));
                break
        }
        const c = {}.NODE_ENV !== "production" ? {
            target: e,
            type: t,
            key: o,
            newValue: n,
            oldValue: r,
            oldTarget: i
        } : void 0;
        if (s.length === 1) s[0] && ({}.NODE_ENV !== "production" ? Jo(s[0], c) : Jo(s[0]));
        else {
            const l = [];
            for (const f of s) f && l.push(...f);
            ({}).NODE_ENV !== "production" ? Jo(gn(l), c) : Jo(gn(l))
        }
    }

    function Jo(e, t) {
        const o = qe(e) ? e : [...e];
        for (const n of o) n.computed && Fa(n, t);
        for (const n of o) n.computed || Fa(n, t)
    }

    function Fa(e, t) {
        (e !== qt || e.allowRecurse) && ({}.NODE_ENV !== "production" && e.onTrigger && e.onTrigger(Ze({
            effect: e
        }, t)), e.scheduler ? e.scheduler() : e.run())
    }
    const zc = uo("__proto__,__v_isRef,__isVue"),
        Va = new Set(Object.getOwnPropertyNames(Symbol).filter(e => e !== "arguments" && e !== "caller").map(e => Symbol[e]).filter(bn)),
        Hc = or(),
        Kc = or(!1, !0),
        Yc = or(!0),
        Wc = or(!0, !0),
        La = Qc();

    function Qc() {
        const e = {};
        return ["includes", "indexOf", "lastIndexOf"].forEach(t => {
            e[t] = function(...o) {
                const n = Ie(this);
                for (let i = 0, a = this.length; i < a; i++) gt(n, "get", i + "");
                const r = n[t](...o);
                return r === -1 || r === !1 ? n[t](...o.map(Ie)) : r
            }
        }), ["push", "pop", "shift", "unshift", "splice"].forEach(t => {
            e[t] = function(...o) {
                Do();
                const n = Ie(this)[t].apply(this, o);
                return So(), n
            }
        }), e
    }

    function Zc(e) {
        const t = Ie(this);
        return gt(t, "has", e), t.hasOwnProperty(e)
    }

    function or(e = !1, t = !1) {
        return function(n, r, i) {
            if (r === "__v_isReactive") return !e;
            if (r === "__v_isReadonly") return e;
            if (r === "__v_isShallow") return t;
            if (r === "__v_raw" && i === (e ? t ? Za : Qa : t ? Wa : Ya).get(n)) return n;
            const a = qe(n);
            if (!e) {
                if (a && Re(La, r)) return Reflect.get(La, r, i);
                if (r === "hasOwnProperty") return Zc
            }
            const s = Reflect.get(n, r, i);
            return (bn(r) ? Va.has(r) : zc(r)) || (e || gt(n, "get", r), t) ? s : at(s) ? a && li(r) ? s : s.value : je(s) ? e ? Ja(s) : ur(s) : s
        }
    }
    const Jc = Ga(),
        Xc = Ga(!0);

    function Ga(e = !1) {
        return function(o, n, r, i) {
            let a = o[n];
            if (_o(a) && at(a) && !at(r)) return !1;
            if (!e && (!fr(r) && !_o(r) && (a = Ie(a), r = Ie(r)), !qe(o) && at(a) && !at(r))) return a.value = r, !0;
            const s = qe(o) && li(n) ? Number(n) < o.length : Re(o, n),
                c = Reflect.set(o, n, r, i);
            return o === Ie(i) && (s ? mn(r, a) && Wt(o, "set", n, r, a) : Wt(o, "add", n, r)), c
        }
    }

    function eu(e, t) {
        const o = Re(e, t),
            n = e[t],
            r = Reflect.deleteProperty(e, t);
        return r && o && Wt(e, "delete", t, void 0, n), r
    }

    function tu(e, t) {
        const o = Reflect.has(e, t);
        return (!bn(t) || !Va.has(t)) && gt(e, "has", t), o
    }

    function ou(e) {
        return gt(e, "iterate", qe(e) ? "length" : Io), Reflect.ownKeys(e)
    }
    const Ma = {
            get: Hc,
            set: Jc,
            deleteProperty: eu,
            has: tu,
            ownKeys: ou
        },
        Ba = {
            get: Yc,
            set(e, t) {
                return {}.NODE_ENV !== "production" && ui(`Set operation on key "${String(t)}" failed: target is readonly.`, e), !0
            },
            deleteProperty(e, t) {
                return {}.NODE_ENV !== "production" && ui(`Delete operation on key "${String(t)}" failed: target is readonly.`, e), !0
            }
        },
        nu = Ze({}, Ma, {
            get: Kc,
            set: Xc
        }),
        ru = Ze({}, Ba, {
            get: Wc
        }),
        mi = e => e,
        nr = e => Reflect.getPrototypeOf(e);

    function rr(e, t, o = !1, n = !1) {
        e = e.__v_raw;
        const r = Ie(e),
            i = Ie(t);
        o || (t !== i && gt(r, "get", t), gt(r, "get", i));
        const {
            has: a
        } = nr(r), s = n ? mi : o ? hi : kn;
        if (a.call(r, t)) return s(e.get(t));
        if (a.call(r, i)) return s(e.get(i));
        e !== r && e.get(t)
    }

    function ir(e, t = !1) {
        const o = this.__v_raw,
            n = Ie(o),
            r = Ie(e);
        return t || (e !== r && gt(n, "has", e), gt(n, "has", r)), e === r ? o.has(e) : o.has(e) || o.has(r)
    }

    function ar(e, t = !1) {
        return e = e.__v_raw, !t && gt(Ie(e), "iterate", Io), Reflect.get(e, "size", e)
    }

    function Ua(e) {
        e = Ie(e);
        const t = Ie(this);
        return nr(t).has.call(t, e) || (t.add(e), Wt(t, "add", e, e)), this
    }

    function ja(e, t) {
        t = Ie(t);
        const o = Ie(this),
            {
                has: n,
                get: r
            } = nr(o);
        let i = n.call(o, e);
        i ? {}.NODE_ENV !== "production" && Ka(o, n, e) : (e = Ie(e), i = n.call(o, e));
        const a = r.call(o, e);
        return o.set(e, t), i ? mn(t, a) && Wt(o, "set", e, t, a) : Wt(o, "add", e, t), this
    }

    function za(e) {
        const t = Ie(this),
            {
                has: o,
                get: n
            } = nr(t);
        let r = o.call(t, e);
        r ? {}.NODE_ENV !== "production" && Ka(t, o, e) : (e = Ie(e), r = o.call(t, e));
        const i = n ? n.call(t, e) : void 0,
            a = t.delete(e);
        return r && Wt(t, "delete", e, void 0, i), a
    }

    function Ha() {
        const e = Ie(this),
            t = e.size !== 0,
            o = {}.NODE_ENV !== "production" ? No(e) ? new Map(e) : new Set(e) : void 0,
            n = e.clear();
        return t && Wt(e, "clear", void 0, void 0, o), n
    }

    function sr(e, t) {
        return function(n, r) {
            const i = this,
                a = i.__v_raw,
                s = Ie(a),
                c = t ? mi : e ? hi : kn;
            return !e && gt(s, "iterate", Io), a.forEach((l, f) => n.call(r, c(l), c(f), i))
        }
    }

    function lr(e, t, o) {
        return function(...n) {
            const r = this.__v_raw,
                i = Ie(r),
                a = No(i),
                s = e === "entries" || e === Symbol.iterator && a,
                c = e === "keys" && a,
                l = r[e](...n),
                f = o ? mi : t ? hi : kn;
            return !t && gt(i, "iterate", c ? pi : Io), {
                next() {
                    const {
                        value: u,
                        done: d
                    } = l.next();
                    return d ? {
                        value: u,
                        done: d
                    } : {
                        value: s ? [f(u[0]), f(u[1])] : f(u),
                        done: d
                    }
                },
                [Symbol.iterator]() {
                    return this
                }
            }
        }
    }

    function bo(e) {
        return function(...t) {
            if ({}.NODE_ENV !== "production") {
                const o = t[0] ? `on key "${t[0]}" ` : "";
                console.warn(`${Po(e)} operation ${o}failed: target is readonly.`, Ie(this))
            }
            return e === "delete" ? !1 : this
        }
    }

    function iu() {
        const e = {
                get(i) {
                    return rr(this, i)
                },
                get size() {
                    return ar(this)
                },
                has: ir,
                add: Ua,
                set: ja,
                delete: za,
                clear: Ha,
                forEach: sr(!1, !1)
            },
            t = {
                get(i) {
                    return rr(this, i, !1, !0)
                },
                get size() {
                    return ar(this)
                },
                has: ir,
                add: Ua,
                set: ja,
                delete: za,
                clear: Ha,
                forEach: sr(!1, !0)
            },
            o = {
                get(i) {
                    return rr(this, i, !0)
                },
                get size() {
                    return ar(this, !0)
                },
                has(i) {
                    return ir.call(this, i, !0)
                },
                add: bo("add"),
                set: bo("set"),
                delete: bo("delete"),
                clear: bo("clear"),
                forEach: sr(!0, !1)
            },
            n = {
                get(i) {
                    return rr(this, i, !0, !0)
                },
                get size() {
                    return ar(this, !0)
                },
                has(i) {
                    return ir.call(this, i, !0)
                },
                add: bo("add"),
                set: bo("set"),
                delete: bo("delete"),
                clear: bo("clear"),
                forEach: sr(!0, !0)
            };
        return ["keys", "values", "entries", Symbol.iterator].forEach(i => {
            e[i] = lr(i, !1, !1), o[i] = lr(i, !0, !1), t[i] = lr(i, !1, !0), n[i] = lr(i, !0, !0)
        }), [e, o, t, n]
    }
    const [au, su, lu, cu] = iu();

    function cr(e, t) {
        const o = t ? e ? cu : lu : e ? su : au;
        return (n, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? n : Reflect.get(Re(o, r) && r in n ? o : n, r, i)
    }
    const uu = {
            get: cr(!1, !1)
        },
        du = {
            get: cr(!1, !0)
        },
        fu = {
            get: cr(!0, !1)
        },
        pu = {
            get: cr(!0, !0)
        };

    function Ka(e, t, o) {
        const n = Ie(o);
        if (n !== o && t.call(e, n)) {
            const r = si(e);
            console.warn(`Reactive ${r} contains both the raw and reactive versions of the same object${r==="Map"?" as keys":""}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`)
        }
    }
    const Ya = new WeakMap,
        Wa = new WeakMap,
        Qa = new WeakMap,
        Za = new WeakMap;

    function bu(e) {
        switch (e) {
            case "Object":
            case "Array":
                return 1;
            case "Map":
            case "Set":
            case "WeakMap":
            case "WeakSet":
                return 2;
            default:
                return 0
        }
    }

    function _u(e) {
        return e.__v_skip || !Object.isExtensible(e) ? 0 : bu(si(e))
    }

    function ur(e) {
        return _o(e) ? e : dr(e, !1, Ma, uu, Ya)
    }

    function mu(e) {
        return dr(e, !1, nu, du, Wa)
    }

    function Ja(e) {
        return dr(e, !0, Ba, fu, Qa)
    }

    function vn(e) {
        return dr(e, !0, ru, pu, Za)
    }

    function dr(e, t, o, n, r) {
        if (!je(e)) return {}.NODE_ENV !== "production" && console.warn(`value cannot be made reactive: ${String(e)}`), e;
        if (e.__v_raw && !(t && e.__v_isReactive)) return e;
        const i = r.get(e);
        if (i) return i;
        const a = _u(e);
        if (a === 0) return e;
        const s = new Proxy(e, a === 2 ? n : o);
        return r.set(e, s), s
    }

    function $o(e) {
        return _o(e) ? $o(e.__v_raw) : !!(e && e.__v_isReactive)
    }

    function _o(e) {
        return !!(e && e.__v_isReadonly)
    }

    function fr(e) {
        return !!(e && e.__v_isShallow)
    }

    function gi(e) {
        return $o(e) || _o(e)
    }

    function Ie(e) {
        const t = e && e.__v_raw;
        return t ? Ie(t) : e
    }

    function Xa(e) {
        return Jn(e, "__v_skip", !0), e
    }
    const kn = e => je(e) ? ur(e) : e,
        hi = e => je(e) ? Ja(e) : e;

    function es(e) {
        po && qt && (e = Ie(e), {}.NODE_ENV !== "production" ? _i(e.dep || (e.dep = gn()), {
            target: e,
            type: "get",
            key: "value"
        }) : _i(e.dep || (e.dep = gn())))
    }

    function ts(e, t) {
        e = Ie(e);
        const o = e.dep;
        o && ({}.NODE_ENV !== "production" ? Jo(o, {
            target: e,
            type: "set",
            key: "value",
            newValue: t
        }) : Jo(o))
    }

    function at(e) {
        return !!(e && e.__v_isRef === !0)
    }

    function J(e) {
        return gu(e, !1)
    }

    function gu(e, t) {
        return at(e) ? e : new hu(e, t)
    }
    class hu {
        constructor(t, o) {
            this.__v_isShallow = o, this.dep = void 0, this.__v_isRef = !0, this._rawValue = o ? t : Ie(t), this._value = o ? t : kn(t)
        }
        get value() {
            return es(this), this._value
        }
        set value(t) {
            const o = this.__v_isShallow || fr(t) || _o(t);
            t = o ? t : Ie(t), mn(t, this._rawValue) && (this._rawValue = t, this._value = o ? t : kn(t), ts(this, t))
        }
    }

    function T(e) {
        return at(e) ? e.value : e
    }
    const vu = {
        get: (e, t, o) => T(Reflect.get(e, t, o)),
        set: (e, t, o, n) => {
            const r = e[t];
            return at(r) && !at(o) ? (r.value = o, !0) : Reflect.set(e, t, o, n)
        }
    };

    function os(e) {
        return $o(e) ? e : new Proxy(e, vu)
    }
    class ku {
        constructor(t, o, n, r) {
            this._setter = o, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this._dirty = !0, this.effect = new bi(t, () => {
                this._dirty || (this._dirty = !0, ts(this))
            }), this.effect.computed = this, this.effect.active = this._cacheable = !r, this.__v_isReadonly = n
        }
        get value() {
            const t = Ie(this);
            return es(t), (t._dirty || !t._cacheable) && (t._dirty = !1, t._value = t.effect.run()), t._value
        }
        set value(t) {
            this._setter(t)
        }
    }

    function yu(e, t, o = !1) {
        let n, r;
        const i = Ne(e);
        i ? (n = e, r = {}.NODE_ENV !== "production" ? () => {
            console.warn("Write operation failed: computed value is readonly")
        } : _t) : (n = e.get, r = e.set);
        const a = new ku(n, r, i || !r, o);
        return {}.NODE_ENV !== "production" && t && !o && (a.effect.onTrack = t.onTrack, a.effect.onTrigger = t.onTrigger), a
    }
    const Ro = [];

    function pr(e) {
        Ro.push(e)
    }

    function br() {
        Ro.pop()
    }

    function le(e, ...t) {
        if ({}.NODE_ENV === "production") return;
        Do();
        const o = Ro.length ? Ro[Ro.length - 1].component : null,
            n = o && o.appContext.config.warnHandler,
            r = qu();
        if (n) no(n, o, 11, [e + t.join(""), o && o.proxy, r.map(({
            vnode: i
        }) => `at <${Ir(o,i.type)}>`).join(`
`), r]);
        else {
            const i = [`[Vue warn]: ${e}`, ...t];
            r.length && i.push(`
`, ...Eu(r)), console.warn(...i)
        }
        So()
    }

    function qu() {
        let e = Ro[Ro.length - 1];
        if (!e) return [];
        const t = [];
        for (; e;) {
            const o = t[0];
            o && o.vnode === e ? o.recurseCount++ : t.push({
                vnode: e,
                recurseCount: 0
            });
            const n = e.component && e.component.parent;
            e = n && n.vnode
        }
        return t
    }

    function Eu(e) {
        const t = [];
        return e.forEach((o, n) => {
            t.push(...n === 0 ? [] : [`
`], ...wu(o))
        }), t
    }

    function wu({
        vnode: e,
        recurseCount: t
    }) {
        const o = t > 0 ? `... (${t} recursive calls)` : "",
            n = e.component ? e.component.parent == null : !1,
            r = ` at <${Ir(e.component,e.type,n)}`,
            i = ">" + o;
        return e.props ? [r, ...xu(e.props), i] : [r + i]
    }

    function xu(e) {
        const t = [],
            o = Object.keys(e);
        return o.slice(0, 3).forEach(n => {
            t.push(...ns(n, e[n]))
        }), o.length > 3 && t.push(" ..."), t
    }

    function ns(e, t, o) {
        return Xe(t) ? (t = JSON.stringify(t), o ? t : [`${e}=${t}`]) : typeof t == "number" || typeof t == "boolean" || t == null ? o ? t : [`${e}=${t}`] : at(t) ? (t = ns(e, Ie(t.value), !0), o ? t : [`${e}=Ref<`, t, ">"]) : Ne(t) ? [`${e}=fn${t.name?`<${t.name}>`:""}`] : (t = Ie(t), o ? t : [`${e}=`, t])
    }

    function Cu(e, t) {
        ({}).NODE_ENV !== "production" && e !== void 0 && (typeof e != "number" ? le(`${t} is not a valid number - got ${JSON.stringify(e)}.`) : isNaN(e) && le(`${t} is NaN - the duration expression might be incorrect.`))
    }
    const vi = {
        sp: "serverPrefetch hook",
        bc: "beforeCreate hook",
        c: "created hook",
        bm: "beforeMount hook",
        m: "mounted hook",
        bu: "beforeUpdate hook",
        u: "updated",
        bum: "beforeUnmount hook",
        um: "unmounted hook",
        a: "activated hook",
        da: "deactivated hook",
        ec: "errorCaptured hook",
        rtc: "renderTracked hook",
        rtg: "renderTriggered hook",
        0: "setup function",
        1: "render function",
        2: "watcher getter",
        3: "watcher callback",
        4: "watcher cleanup function",
        5: "native event handler",
        6: "component event handler",
        7: "vnode hook",
        8: "directive hook",
        9: "transition hook",
        10: "app errorHandler",
        11: "app warnHandler",
        12: "ref function",
        13: "async component loader",
        14: "scheduler flush. This is likely a Vue internals bug. Please open an issue at https://new-issue.vuejs.org/?repo=vuejs/core"
    };

    function no(e, t, o, n) {
        let r;
        try {
            r = n ? e(...n) : e()
        } catch (i) {
            _r(i, t, o)
        }
        return r
    }

    function Dt(e, t, o, n) {
        if (Ne(e)) {
            const i = no(e, t, o, n);
            return i && ai(i) && i.catch(a => {
                _r(a, t, o)
            }), i
        }
        const r = [];
        for (let i = 0; i < e.length; i++) r.push(Dt(e[i], t, o, n));
        return r
    }

    function _r(e, t, o, n = !0) {
        const r = t ? t.vnode : null;
        if (t) {
            let i = t.parent;
            const a = t.proxy,
                s = {}.NODE_ENV !== "production" ? vi[o] : o;
            for (; i;) {
                const l = i.ec;
                if (l) {
                    for (let f = 0; f < l.length; f++)
                        if (l[f](e, a, s) === !1) return
                }
                i = i.parent
            }
            const c = t.appContext.config.errorHandler;
            if (c) {
                no(c, null, 10, [e, a, s]);
                return
            }
        }
        Tu(e, o, r, n)
    }

    function Tu(e, t, o, n = !0) {
        if ({}.NODE_ENV !== "production") {
            const r = vi[t];
            if (o && pr(o), le(`Unhandled error${r?` during execution of ${r}`:""}`), o && br(), n) throw e;
            console.error(e)
        } else console.error(e)
    }
    let yn = !1,
        ki = !1;
    const vt = [];
    let Qt = 0;
    const Xo = [];
    let Zt = null,
        mo = 0;
    const rs = Promise.resolve();
    let yi = null;
    const Ou = 100;

    function is(e) {
        const t = yi || rs;
        return e ? t.then(this ? e.bind(this) : e) : t
    }

    function Nu(e) {
        let t = Qt + 1,
            o = vt.length;
        for (; t < o;) {
            const n = t + o >>> 1;
            qn(vt[n]) < e ? t = n + 1 : o = n
        }
        return t
    }

    function mr(e) {
        (!vt.length || !vt.includes(e, yn && e.allowRecurse ? Qt + 1 : Qt)) && (e.id == null ? vt.push(e) : vt.splice(Nu(e.id), 0, e), as())
    }

    function as() {
        !yn && !ki && (ki = !0, yi = rs.then(us))
    }

    function Pu(e) {
        const t = vt.indexOf(e);
        t > Qt && vt.splice(t, 1)
    }

    function ss(e) {
        qe(e) ? Xo.push(...e) : (!Zt || !Zt.includes(e, e.allowRecurse ? mo + 1 : mo)) && Xo.push(e), as()
    }

    function ls(e, t = yn ? Qt + 1 : 0) {
        for ({}.NODE_ENV !== "production" && (e = e || new Map); t < vt.length; t++) {
            const o = vt[t];
            if (o && o.pre) {
                if ({}.NODE_ENV !== "production" && qi(e, o)) continue;
                vt.splice(t, 1), t--, o()
            }
        }
    }

    function cs(e) {
        if (Xo.length) {
            const t = [...new Set(Xo)];
            if (Xo.length = 0, Zt) {
                Zt.push(...t);
                return
            }
            for (Zt = t, {}.NODE_ENV !== "production" && (e = e || new Map), Zt.sort((o, n) => qn(o) - qn(n)), mo = 0; mo < Zt.length; mo++)({}).NODE_ENV !== "production" && qi(e, Zt[mo]) || Zt[mo]();
            Zt = null, mo = 0
        }
    }
    const qn = e => e.id == null ? 1 / 0 : e.id,
        Au = (e, t) => {
            const o = qn(e) - qn(t);
            if (o === 0) {
                if (e.pre && !t.pre) return -1;
                if (t.pre && !e.pre) return 1
            }
            return o
        };

    function us(e) {
        ki = !1, yn = !0, {}.NODE_ENV !== "production" && (e = e || new Map), vt.sort(Au);
        const t = {}.NODE_ENV !== "production" ? o => qi(e, o) : _t;
        try {
            for (Qt = 0; Qt < vt.length; Qt++) {
                const o = vt[Qt];
                if (o && o.active !== !1) {
                    if ({}.NODE_ENV !== "production" && t(o)) continue;
                    no(o, null, 14)
                }
            }
        } finally {
            Qt = 0, vt.length = 0, cs(e), yn = !1, yi = null, (vt.length || Xo.length) && us(e)
        }
    }

    function qi(e, t) {
        if (!e.has(t)) e.set(t, 1);
        else {
            const o = e.get(t);
            if (o > Ou) {
                const n = t.ownerInstance,
                    r = n && Yi(n.type);
                return le(`Maximum recursive updates exceeded${r?` in component <${r}>`:""}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`), !0
            } else e.set(t, o + 1)
        }
    }
    let go = !1;
    const en = new Set;
    ({}).NODE_ENV !== "production" && (er().__VUE_HMR_RUNTIME__ = {
        createRecord: Ei(ds),
        rerender: Ei(Su),
        reload: Ei($u)
    });
    const Fo = new Map;

    function Iu(e) {
        const t = e.type.__hmrId;
        let o = Fo.get(t);
        o || (ds(t, e.type), o = Fo.get(t)), o.instances.add(e)
    }

    function Du(e) {
        Fo.get(e.type.__hmrId).instances.delete(e)
    }

    function ds(e, t) {
        return Fo.has(e) ? !1 : (Fo.set(e, {
            initialDef: En(t),
            instances: new Set
        }), !0)
    }

    function En(e) {
        return pl(e) ? e.__vccOpts : e
    }

    function Su(e, t) {
        const o = Fo.get(e);
        o && (o.initialDef.render = t, [...o.instances].forEach(n => {
            t && (n.render = t, En(n.type).render = t), n.renderCache = [], go = !0, n.update(), go = !1
        }))
    }

    function $u(e, t) {
        const o = Fo.get(e);
        if (!o) return;
        t = En(t), fs(o.initialDef, t);
        const n = [...o.instances];
        for (const r of n) {
            const i = En(r.type);
            en.has(i) || (i !== o.initialDef && fs(i, t), en.add(i)), r.appContext.propsCache.delete(r.type), r.appContext.emitsCache.delete(r.type), r.appContext.optionsCache.delete(r.type), r.ceReload ? (en.add(i), r.ceReload(t.styles), en.delete(i)) : r.parent ? mr(r.parent.update) : r.appContext.reload ? r.appContext.reload() : typeof window < "u" ? window.location.reload() : console.warn("[HMR] Root or manually mounted instance modified. Full reload required.")
        }
        ss(() => {
            for (const r of n) en.delete(En(r.type))
        })
    }

    function fs(e, t) {
        Ze(e, t);
        for (const o in e) o !== "__file" && !(o in t) && delete e[o]
    }

    function Ei(e) {
        return (t, o) => {
            try {
                return e(t, o)
            } catch (n) {
                console.error(n), console.warn("[HMR] Something went wrong during Vue component hot-reload. Full reload required.")
            }
        }
    }
    let Jt, wn = [],
        wi = !1;

    function xn(e, ...t) {
        Jt ? Jt.emit(e, ...t) : wi || wn.push({
            event: e,
            args: t
        })
    }

    function ps(e, t) {
        var o, n;
        Jt = e, Jt ? (Jt.enabled = !0, wn.forEach(({
            event: r,
            args: i
        }) => Jt.emit(r, ...i)), wn = []) : typeof window < "u" && window.HTMLElement && !((n = (o = window.navigator) == null ? void 0 : o.userAgent) != null && n.includes("jsdom")) ? ((t.__VUE_DEVTOOLS_HOOK_REPLAY__ = t.__VUE_DEVTOOLS_HOOK_REPLAY__ || []).push(i => {
            ps(i, t)
        }), setTimeout(() => {
            Jt || (t.__VUE_DEVTOOLS_HOOK_REPLAY__ = null, wi = !0, wn = [])
        }, 3e3)) : (wi = !0, wn = [])
    }

    function Ru(e, t) {
        xn("app:init", e, t, {
            Fragment: Be,
            Text: Dn,
            Comment: ft,
            Static: Sn
        })
    }

    function Fu(e) {
        xn("app:unmount", e)
    }
    const Vu = xi("component:added"),
        bs = xi("component:updated"),
        Lu = xi("component:removed"),
        Gu = e => {
            Jt && typeof Jt.cleanupBuffer == "function" && !Jt.cleanupBuffer(e) && Lu(e)
        };

    function xi(e) {
        return t => {
            xn(e, t.appContext.app, t.uid, t.parent ? t.parent.uid : void 0, t)
        }
    }
    const Mu = _s("perf:start"),
        Bu = _s("perf:end");

    function _s(e) {
        return (t, o, n) => {
            xn(e, t.appContext.app, t.uid, t, o, n)
        }
    }

    function Uu(e, t, o) {
        xn("component:emit", e.appContext.app, e, t, o)
    }

    function ju(e, t, ...o) {
        if (e.isUnmounted) return;
        const n = e.vnode.props || Qe;
        if ({}.NODE_ENV !== "production") {
            const {
                emitsOptions: f,
                propsOptions: [u]
            } = e;
            if (f)
                if (!(t in f))(!u || !(Ao(t) in u)) && le(`Component emitted event "${t}" but it is neither declared in the emits option nor as an "${Ao(t)}" prop.`);
                else {
                    const d = f[t];
                    Ne(d) && (d(...o) || le(`Invalid event arguments: event validation failed for event "${t}".`))
                }
        }
        let r = o;
        const i = t.startsWith("update:"),
            a = i && t.slice(7);
        if (a && a in n) {
            const f = `${a==="modelValue"?"model":a}Modifiers`,
                {
                    number: u,
                    trim: d
                } = n[f] || Qe;
            d && (r = o.map(_ => Xe(_) ? _.trim() : _)), u && (r = o.map(Xn))
        }
        if ({}.NODE_ENV !== "production" && Uu(e, t, r), {}.NODE_ENV !== "production") {
            const f = t.toLowerCase();
            f !== t && n[Ao(f)] && le(`Event "${f}" is emitted in component ${Ir(e,e.type)} but the handler is registered for "${t}". Note that HTML attributes are case-insensitive and you cannot use v-on to listen to camelCase events when using in-DOM templates. You should probably use "${At(t)}" instead of "${t}".`)
        }
        let s, c = n[s = Ao(t)] || n[s = Ao(Pt(t))];
        !c && i && (c = n[s = Ao(At(t))]), c && Dt(c, e, 6, r);
        const l = n[s + "Once"];
        if (l) {
            if (!e.emitted) e.emitted = {};
            else if (e.emitted[s]) return;
            e.emitted[s] = !0, Dt(l, e, 6, r)
        }
    }

    function ms(e, t, o = !1) {
        const n = t.emitsCache,
            r = n.get(e);
        if (r !== void 0) return r;
        const i = e.emits;
        let a = {},
            s = !1;
        if (!Ne(e)) {
            const c = l => {
                const f = ms(l, t, !0);
                f && (s = !0, Ze(a, f))
            };
            !o && t.mixins.length && t.mixins.forEach(c), e.extends && c(e.extends), e.mixins && e.mixins.forEach(c)
        }
        return !i && !s ? (je(e) && n.set(e, null), null) : (qe(i) ? i.forEach(c => a[c] = null) : Ze(a, i), je(e) && n.set(e, a), a)
    }

    function gr(e, t) {
        return !e || !pn(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), Re(e, t[0].toLowerCase() + t.slice(1)) || Re(e, At(t)) || Re(e, t))
    }
    let st = null,
        hr = null;

    function vr(e) {
        const t = st;
        return st = e, hr = e && e.type.__scopeId || null, t
    }

    function gs(e) {
        hr = e
    }

    function hs() {
        hr = null
    }

    function Ge(e, t = st, o) {
        if (!t || e._n) return e;
        const n = (...r) => {
            n._d && tl(-1);
            const i = vr(t);
            let a;
            try {
                a = e(...r)
            } finally {
                vr(i), n._d && tl(1)
            }
            return {}.NODE_ENV !== "production" && bs(t), a
        };
        return n._n = !0, n._c = !0, n._d = !0, n
    }
    let Ci = !1;

    function kr() {
        Ci = !0
    }

    function Ti(e) {
        const {
            type: t,
            vnode: o,
            proxy: n,
            withProxy: r,
            props: i,
            propsOptions: [a],
            slots: s,
            attrs: c,
            emit: l,
            render: f,
            renderCache: u,
            data: d,
            setupState: _,
            ctx: g,
            inheritAttrs: h
        } = e;
        let O, b;
        const C = vr(e);
        ({}).NODE_ENV !== "production" && (Ci = !1);
        try {
            if (o.shapeFlag & 4) {
                const N = r || n;
                O = Kt(f.call(N, N, u, i, _, d, g)), b = c
            } else {
                const N = t;
                ({}).NODE_ENV !== "production" && c === i && kr(), O = Kt(N.length > 1 ? N(i, {}.NODE_ENV !== "production" ? {
                    get attrs() {
                        return kr(), c
                    },
                    slots: s,
                    emit: l
                } : {
                    attrs: c,
                    slots: s,
                    emit: l
                }) : N(i, null)), b = t.props ? c : Hu(c)
            }
        } catch (N) {
            $n.length = 0, _r(N, e, 1), O = pe(ft)
        }
        let E = O,
            x;
        if ({}.NODE_ENV !== "production" && O.patchFlag > 0 && O.patchFlag & 2048 && ([E, x] = zu(O)), b && h !== !1) {
            const N = Object.keys(b),
                {
                    shapeFlag: w
                } = E;
            if (N.length) {
                if (w & 7) a && N.some(Yn) && (b = Ku(b, a)), E = Xt(E, b);
                else if ({}.NODE_ENV !== "production" && !Ci && E.type !== ft) {
                    const D = Object.keys(c),
                        P = [],
                        I = [];
                    for (let $ = 0, oe = D.length; $ < oe; $++) {
                        const A = D[$];
                        pn(A) ? Yn(A) || P.push(A[2].toLowerCase() + A.slice(3)) : I.push(A)
                    }
                    I.length && le(`Extraneous non-props attributes (${I.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes.`), P.length && le(`Extraneous non-emits event listeners (${P.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes. If the listener is intended to be a component custom event listener only, declare it using the "emits" option.`)
                }
            }
        }
        return o.dirs && ({}.NODE_ENV !== "production" && !ks(E) && le("Runtime directive used on component with non-element root node. The directives will not function as intended."), E = Xt(E), E.dirs = E.dirs ? E.dirs.concat(o.dirs) : o.dirs), o.transition && ({}.NODE_ENV !== "production" && !ks(E) && le("Component inside <Transition> renders non-element root node that cannot be animated."), E.transition = o.transition), {}.NODE_ENV !== "production" && x ? x(E) : O = E, vr(C), O
    }
    const zu = e => {
        const t = e.children,
            o = e.dynamicChildren,
            n = vs(t);
        if (!n) return [e, void 0];
        const r = t.indexOf(n),
            i = o ? o.indexOf(n) : -1,
            a = s => {
                t[r] = s, o && (i > -1 ? o[i] = s : s.patchFlag > 0 && (e.dynamicChildren = [...o, s]))
            };
        return [Kt(n), a]
    };

    function vs(e) {
        let t;
        for (let o = 0; o < e.length; o++) {
            const n = e[o];
            if (on(n)) {
                if (n.type !== ft || n.children === "v-if") {
                    if (t) return;
                    t = n
                }
            } else return
        }
        return t
    }
    const Hu = e => {
            let t;
            for (const o in e)(o === "class" || o === "style" || pn(o)) && ((t || (t = {}))[o] = e[o]);
            return t
        },
        Ku = (e, t) => {
            const o = {};
            for (const n in e)(!Yn(n) || !(n.slice(9) in t)) && (o[n] = e[n]);
            return o
        },
        ks = e => e.shapeFlag & 7 || e.type === ft;

    function Yu(e, t, o) {
        const {
            props: n,
            children: r,
            component: i
        } = e, {
            props: a,
            children: s,
            patchFlag: c
        } = t, l = i.emitsOptions;
        if ({}.NODE_ENV !== "production" && (r || s) && go || t.dirs || t.transition) return !0;
        if (o && c >= 0) {
            if (c & 1024) return !0;
            if (c & 16) return n ? ys(n, a, l) : !!a;
            if (c & 8) {
                const f = t.dynamicProps;
                for (let u = 0; u < f.length; u++) {
                    const d = f[u];
                    if (a[d] !== n[d] && !gr(l, d)) return !0
                }
            }
        } else return (r || s) && (!s || !s.$stable) ? !0 : n === a ? !1 : n ? a ? ys(n, a, l) : !0 : !!a;
        return !1
    }

    function ys(e, t, o) {
        const n = Object.keys(t);
        if (n.length !== Object.keys(e).length) return !0;
        for (let r = 0; r < n.length; r++) {
            const i = n[r];
            if (t[i] !== e[i] && !gr(o, i)) return !0
        }
        return !1
    }

    function Wu({
        vnode: e,
        parent: t
    }, o) {
        for (; t && t.subTree === e;)(e = t.vnode).el = o, t = t.parent
    }
    const Qu = e => e.__isSuspense;

    function Zu(e, t) {
        t && t.pendingBranch ? qe(e) ? t.effects.push(...e) : t.effects.push(e) : ss(e)
    }
    const yr = {};

    function ot(e, t, o) {
        return {}.NODE_ENV !== "production" && !Ne(t) && le("`watch(fn, options?)` signature has been moved to a separate API. Use `watchEffect(fn, options?)` instead. `watch` now only supports `watch(source, cb, options?) signature."), qs(e, t, o)
    }

    function qs(e, t, {
        immediate: o,
        deep: n,
        flush: r,
        onTrack: i,
        onTrigger: a
    } = Qe) {
        var s;
        ({}).NODE_ENV !== "production" && !t && (o !== void 0 && le('watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.'), n !== void 0 && le('watch() "deep" option is only respected when using the watch(source, callback, options?) signature.'));
        const c = N => {
                le("Invalid watch source: ", N, "A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types.")
            },
            l = Bc() === ((s = lt) == null ? void 0 : s.scope) ? lt : null;
        let f, u = !1,
            d = !1;
        if (at(e) ? (f = () => e.value, u = fr(e)) : $o(e) ? (f = () => e, n = !0) : qe(e) ? (d = !0, u = e.some(N => $o(N) || fr(N)), f = () => e.map(N => {
                if (at(N)) return N.value;
                if ($o(N)) return Vo(N);
                if (Ne(N)) return no(N, l, 2);
                ({}).NODE_ENV !== "production" && c(N)
            })) : Ne(e) ? t ? f = () => no(e, l, 2) : f = () => {
                if (!(l && l.isUnmounted)) return _ && _(), Dt(e, l, 3, [g])
            } : (f = _t, {}.NODE_ENV !== "production" && c(e)), t && n) {
            const N = f;
            f = () => Vo(N())
        }
        let _, g = N => {
                _ = E.onStop = () => {
                    no(N, l, 4)
                }
            },
            h;
        if (Fn)
            if (g = _t, t ? o && Dt(t, l, 3, [f(), d ? [] : void 0, g]) : f(), r === "sync") {
                const N = of ();
                h = N.__watcherHandles || (N.__watcherHandles = [])
            } else return _t;
        let O = d ? new Array(e.length).fill(yr) : yr;
        const b = () => {
            if (E.active)
                if (t) {
                    const N = E.run();
                    (n || u || (d ? N.some((w, D) => mn(w, O[D])) : mn(N, O))) && (_ && _(), Dt(t, l, 3, [N, O === yr ? void 0 : d && O[0] === yr ? [] : O, g]), O = N)
                } else E.run()
        };
        b.allowRecurse = !!t;
        let C;
        r === "sync" ? C = b : r === "post" ? C = () => xt(b, l && l.suspense) : (b.pre = !0, l && (b.id = l.uid), C = () => mr(b));
        const E = new bi(f, C);
        ({}).NODE_ENV !== "production" && (E.onTrack = i, E.onTrigger = a), t ? o ? b() : O = E.run() : r === "post" ? xt(E.run.bind(E), l && l.suspense) : E.run();
        const x = () => {
            E.stop(), l && l.scope && ii(l.scope.effects, E)
        };
        return h && h.push(x), x
    }

    function Ju(e, t, o) {
        const n = this.proxy,
            r = Xe(e) ? e.includes(".") ? Es(n, e) : () => n[e] : e.bind(n, n);
        let i;
        Ne(t) ? i = t : (i = t.handler, o = t);
        const a = lt;
        rn(this);
        const s = qs(r, i.bind(n), o);
        return a ? rn(a) : Uo(), s
    }

    function Es(e, t) {
        const o = t.split(".");
        return () => {
            let n = e;
            for (let r = 0; r < o.length && n; r++) n = n[o[r]];
            return n
        }
    }

    function Vo(e, t) {
        if (!je(e) || e.__v_skip || (t = t || new Set, t.has(e))) return e;
        if (t.add(e), at(e)) Vo(e.value, t);
        else if (qe(e))
            for (let o = 0; o < e.length; o++) Vo(e[o], t);
        else if (Wn(e) || No(e)) e.forEach(o => {
            Vo(o, t)
        });
        else if (Na(e))
            for (const o in e) Vo(e[o], t);
        return e
    }

    function ws(e) {
        Cc(e) && le("Do not use built-in directive ids as custom directive id: " + e)
    }

    function ht(e, t) {
        const o = st;
        if (o === null) return {}.NODE_ENV !== "production" && le("withDirectives can only be used inside render functions."), e;
        const n = Ar(o) || o.proxy,
            r = e.dirs || (e.dirs = []);
        for (let i = 0; i < t.length; i++) {
            let [a, s, c, l = Qe] = t[i];
            a && (Ne(a) && (a = {
                mounted: a,
                updated: a
            }), a.deep && Vo(s), r.push({
                dir: a,
                instance: n,
                value: s,
                oldValue: void 0,
                arg: c,
                modifiers: l
            }))
        }
        return e
    }

    function Lo(e, t, o, n) {
        const r = e.dirs,
            i = t && t.dirs;
        for (let a = 0; a < r.length; a++) {
            const s = r[a];
            i && (s.oldValue = i[a].value);
            let c = s.dir[n];
            c && (Do(), Dt(c, o, 8, [e.el, s, e, t]), So())
        }
    }

    function xs() {
        const e = {
            isMounted: !1,
            isLeaving: !1,
            isUnmounting: !1,
            leavingVNodes: new Map
        };
        return nt(() => {
            e.isMounted = !0
        }), io(() => {
            e.isUnmounting = !0
        }), e
    }
    const St = [Function, Array],
        Cs = {
            mode: String,
            appear: Boolean,
            persisted: Boolean,
            onBeforeEnter: St,
            onEnter: St,
            onAfterEnter: St,
            onEnterCancelled: St,
            onBeforeLeave: St,
            onLeave: St,
            onAfterLeave: St,
            onLeaveCancelled: St,
            onBeforeAppear: St,
            onAppear: St,
            onAfterAppear: St,
            onAppearCancelled: St
        },
        Xu = {
            name: "BaseTransition",
            props: Cs,
            setup(e, {
                slots: t
            }) {
                const o = ji(),
                    n = xs();
                let r;
                return () => {
                    const i = t.default && Ni(t.default(), !0);
                    if (!i || !i.length) return;
                    let a = i[0];
                    if (i.length > 1) {
                        let h = !1;
                        for (const O of i)
                            if (O.type !== ft) {
                                if ({}.NODE_ENV !== "production" && h) {
                                    le("<transition> can only be used on a single element or component. Use <transition-group> for lists.");
                                    break
                                }
                                if (a = O, h = !0, {}.NODE_ENV === "production") break
                            }
                    }
                    const s = Ie(e),
                        {
                            mode: c
                        } = s;
                    if ({}.NODE_ENV !== "production" && c && c !== "in-out" && c !== "out-in" && c !== "default" && le(`invalid <transition> mode: ${c}`), n.isLeaving) return Oi(a);
                    const l = Os(a);
                    if (!l) return Oi(a);
                    const f = Cn(l, s, n, o);
                    Tn(l, f);
                    const u = o.subTree,
                        d = u && Os(u);
                    let _ = !1;
                    const {
                        getTransitionKey: g
                    } = l.type;
                    if (g) {
                        const h = g();
                        r === void 0 ? r = h : h !== r && (r = h, _ = !0)
                    }
                    if (d && d.type !== ft && (!Bo(l, d) || _)) {
                        const h = Cn(d, s, n, o);
                        if (Tn(d, h), c === "out-in") return n.isLeaving = !0, h.afterLeave = () => {
                            n.isLeaving = !1, o.update.active !== !1 && o.update()
                        }, Oi(a);
                        c === "in-out" && l.type !== ft && (h.delayLeave = (O, b, C) => {
                            const E = Ts(n, d);
                            E[String(d.key)] = d, O._leaveCb = () => {
                                b(), O._leaveCb = void 0, delete f.delayedLeave
                            }, f.delayedLeave = C
                        })
                    }
                    return a
                }
            }
        };

    function Ts(e, t) {
        const {
            leavingVNodes: o
        } = e;
        let n = o.get(t.type);
        return n || (n = Object.create(null), o.set(t.type, n)), n
    }

    function Cn(e, t, o, n) {
        const {
            appear: r,
            mode: i,
            persisted: a = !1,
            onBeforeEnter: s,
            onEnter: c,
            onAfterEnter: l,
            onEnterCancelled: f,
            onBeforeLeave: u,
            onLeave: d,
            onAfterLeave: _,
            onLeaveCancelled: g,
            onBeforeAppear: h,
            onAppear: O,
            onAfterAppear: b,
            onAppearCancelled: C
        } = t, E = String(e.key), x = Ts(o, e), N = (P, I) => {
            P && Dt(P, n, 9, I)
        }, w = (P, I) => {
            const $ = I[1];
            N(P, I), qe(P) ? P.every(oe => oe.length <= 1) && $() : P.length <= 1 && $()
        }, D = {
            mode: i,
            persisted: a,
            beforeEnter(P) {
                let I = s;
                if (!o.isMounted)
                    if (r) I = h || s;
                    else return;
                P._leaveCb && P._leaveCb(!0);
                const $ = x[E];
                $ && Bo(e, $) && $.el._leaveCb && $.el._leaveCb(), N(I, [P])
            },
            enter(P) {
                let I = c,
                    $ = l,
                    oe = f;
                if (!o.isMounted)
                    if (r) I = O || c, $ = b || l, oe = C || f;
                    else return;
                let A = !1;
                const K = P._enterCb = ae => {
                    A || (A = !0, ae ? N(oe, [P]) : N($, [P]), D.delayedLeave && D.delayedLeave(), P._enterCb = void 0)
                };
                I ? w(I, [P, K]) : K()
            },
            leave(P, I) {
                const $ = String(e.key);
                if (P._enterCb && P._enterCb(!0), o.isUnmounting) return I();
                N(u, [P]);
                let oe = !1;
                const A = P._leaveCb = K => {
                    oe || (oe = !0, I(), K ? N(g, [P]) : N(_, [P]), P._leaveCb = void 0, x[$] === e && delete x[$])
                };
                x[$] = e, d ? w(d, [P, A]) : A()
            },
            clone(P) {
                return Cn(P, t, o, n)
            }
        };
        return D
    }

    function Oi(e) {
        if (Nn(e)) return e = Xt(e), e.children = null, e
    }

    function Os(e) {
        return Nn(e) ? e.children ? e.children[0] : void 0 : e
    }

    function Tn(e, t) {
        e.shapeFlag & 6 && e.component ? Tn(e.component.subTree, t) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
    }

    function Ni(e, t = !1, o) {
        let n = [],
            r = 0;
        for (let i = 0; i < e.length; i++) {
            let a = e[i];
            const s = o == null ? a.key : String(o) + String(a.key != null ? a.key : i);
            a.type === Be ? (a.patchFlag & 128 && r++, n = n.concat(Ni(a.children, t, s))) : (t || a.type !== ft) && n.push(s != null ? Xt(a, {
                key: s
            }) : a)
        }
        if (r > 1)
            for (let i = 0; i < n.length; i++) n[i].patchFlag = -2;
        return n
    }

    function Fe(e, t) {
        return Ne(e) ? (() => Ze({
            name: e.name
        }, t, {
            setup: e
        }))() : e
    }
    const On = e => !!e.type.__asyncLoader,
        Nn = e => e.type.__isKeepAlive;

    function ed(e, t) {
        Ns(e, "a", t)
    }

    function td(e, t) {
        Ns(e, "da", t)
    }

    function Ns(e, t, o = lt) {
        const n = e.__wdc || (e.__wdc = () => {
            let r = o;
            for (; r;) {
                if (r.isDeactivated) return;
                r = r.parent
            }
            return e()
        });
        if (qr(t, n, o), o) {
            let r = o.parent;
            for (; r && r.parent;) Nn(r.parent.vnode) && od(n, t, o, r), r = r.parent
        }
    }

    function od(e, t, o, n) {
        const r = qr(t, e, n, !0);
        As(() => {
            ii(n[t], r)
        }, o)
    }

    function qr(e, t, o = lt, n = !1) {
        if (o) {
            const r = o[e] || (o[e] = []),
                i = t.__weh || (t.__weh = (...a) => {
                    if (o.isUnmounted) return;
                    Do(), rn(o);
                    const s = Dt(t, o, e, a);
                    return Uo(), So(), s
                });
            return n ? r.unshift(i) : r.push(i), i
        } else if ({}.NODE_ENV !== "production") {
            const r = Ao(vi[e].replace(/ hook$/, ""));
            le(`${r} is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup(). If you are using async setup(), make sure to register lifecycle hooks before the first await statement.`)
        }
    }
    const ro = e => (t, o = lt) => (!Fn || e === "sp") && qr(e, (...n) => t(...n), o),
        Er = ro("bm"),
        nt = ro("m"),
        nd = ro("bu"),
        Ps = ro("u"),
        io = ro("bum"),
        As = ro("um"),
        rd = ro("sp"),
        id = ro("rtg"),
        ad = ro("rtc");

    function sd(e, t = lt) {
        qr("ec", e, t)
    }
    const Pi = "components",
        Is = Symbol.for("v-ndc");

    function Ai(e) {
        return Xe(e) ? ld(Pi, e, !1) || e : e || Is
    }

    function ld(e, t, o = !0, n = !1) {
        const r = st || lt;
        if (r) {
            const i = r.type;
            if (e === Pi) {
                const s = Yi(i, !1);
                if (s && (s === t || s === Pt(t) || s === Po(Pt(t)))) return i
            }
            const a = Ds(r[e] || i[e], t) || Ds(r.appContext[e], t);
            if (!a && n) return i;
            if ({}.NODE_ENV !== "production" && o && !a) {
                const s = e === Pi ? `
If this is a native custom element, make sure to exclude it from component resolution via compilerOptions.isCustomElement.` : "";
                le(`Failed to resolve ${e.slice(0,-1)}: ${t}${s}`)
            }
            return a
        } else({}).NODE_ENV !== "production" && le(`resolve${Po(e.slice(0,-1))} can only be used in render() or setup().`)
    }

    function Ds(e, t) {
        return e && (e[t] || e[Pt(t)] || e[Po(Pt(t))])
    }

    function dt(e, t, o, n) {
        let r;
        const i = o && o[n];
        if (qe(e) || Xe(e)) {
            r = new Array(e.length);
            for (let a = 0, s = e.length; a < s; a++) r[a] = t(e[a], a, void 0, i && i[a])
        } else if (typeof e == "number") {
            ({}).NODE_ENV !== "production" && !Number.isInteger(e) && le(`The v-for range expect an integer value but got ${e}.`), r = new Array(e);
            for (let a = 0; a < e; a++) r[a] = t(a + 1, a, void 0, i && i[a])
        } else if (je(e))
            if (e[Symbol.iterator]) r = Array.from(e, (a, s) => t(a, s, void 0, i && i[s]));
            else {
                const a = Object.keys(e);
                r = new Array(a.length);
                for (let s = 0, c = a.length; s < c; s++) {
                    const l = a[s];
                    r[s] = t(e[l], l, s, i && i[s])
                }
            }
        else r = [];
        return o && (o[n] = r), r
    }

    function zt(e, t, o = {}, n, r) {
        if (st.isCE || st.parent && On(st.parent) && st.parent.isCE) return t !== "default" && (o.name = t), pe("slot", o, n && n());
        let i = e[t];
        ({}).NODE_ENV !== "production" && i && i.length > 1 && (le("SSR-optimized slot function detected in a non-SSR-optimized render function. You need to mark this component with $dynamic-slots in the parent template."), i = () => []), i && i._c && (i._d = !1), H();
        const a = i && Ss(i(o)),
            s = Se(Be, {
                key: o.key || a && a.key || `_${t}`
            }, a || (n ? n() : []), a && e._ === 1 ? 64 : -2);
        return !r && s.scopeId && (s.slotScopeIds = [s.scopeId + "-s"]), i && i._c && (i._d = !0), s
    }

    function Ss(e) {
        return e.some(t => on(t) ? !(t.type === ft || t.type === Be && !Ss(t.children)) : !0) ? e : null
    }
    const Ii = e => e ? ll(e) ? Ar(e) || e.proxy : Ii(e.parent) : null,
        Go = Ze(Object.create(null), {
            $: e => e,
            $el: e => e.vnode.el,
            $data: e => e.data,
            $props: e => ({}).NODE_ENV !== "production" ? vn(e.props) : e.props,
            $attrs: e => ({}).NODE_ENV !== "production" ? vn(e.attrs) : e.attrs,
            $slots: e => ({}).NODE_ENV !== "production" ? vn(e.slots) : e.slots,
            $refs: e => ({}).NODE_ENV !== "production" ? vn(e.refs) : e.refs,
            $parent: e => Ii(e.parent),
            $root: e => Ii(e.root),
            $emit: e => e.emit,
            $options: e => Ri(e),
            $forceUpdate: e => e.f || (e.f = () => mr(e.update)),
            $nextTick: e => e.n || (e.n = is.bind(e.proxy)),
            $watch: e => Ju.bind(e)
        }),
        Di = e => e === "_" || e === "$",
        Si = (e, t) => e !== Qe && !e.__isScriptSetup && Re(e, t),
        $s = {
            get({
                _: e
            }, t) {
                const {
                    ctx: o,
                    setupState: n,
                    data: r,
                    props: i,
                    accessCache: a,
                    type: s,
                    appContext: c
                } = e;
                if ({}.NODE_ENV !== "production" && t === "__isVue") return !0;
                let l;
                if (t[0] !== "$") {
                    const _ = a[t];
                    if (_ !== void 0) switch (_) {
                        case 1:
                            return n[t];
                        case 2:
                            return r[t];
                        case 4:
                            return o[t];
                        case 3:
                            return i[t]
                    } else {
                        if (Si(n, t)) return a[t] = 1, n[t];
                        if (r !== Qe && Re(r, t)) return a[t] = 2, r[t];
                        if ((l = e.propsOptions[0]) && Re(l, t)) return a[t] = 3, i[t];
                        if (o !== Qe && Re(o, t)) return a[t] = 4, o[t];
                        $i && (a[t] = 0)
                    }
                }
                const f = Go[t];
                let u, d;
                if (f) return t === "$attrs" ? (gt(e, "get", t), {}.NODE_ENV !== "production" && kr()) : {}.NODE_ENV !== "production" && t === "$slots" && gt(e, "get", t), f(e);
                if ((u = s.__cssModules) && (u = u[t])) return u;
                if (o !== Qe && Re(o, t)) return a[t] = 4, o[t];
                if (d = c.config.globalProperties, Re(d, t)) return d[t];
                ({}).NODE_ENV !== "production" && st && (!Xe(t) || t.indexOf("__v") !== 0) && (r !== Qe && Di(t[0]) && Re(r, t) ? le(`Property ${JSON.stringify(t)} must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`) : e === st && le(`Property ${JSON.stringify(t)} was accessed during render but is not defined on instance.`))
            },
            set({
                _: e
            }, t, o) {
                const {
                    data: n,
                    setupState: r,
                    ctx: i
                } = e;
                return Si(r, t) ? (r[t] = o, !0) : {}.NODE_ENV !== "production" && r.__isScriptSetup && Re(r, t) ? (le(`Cannot mutate <script setup> binding "${t}" from Options API.`), !1) : n !== Qe && Re(n, t) ? (n[t] = o, !0) : Re(e.props, t) ? ({}.NODE_ENV !== "production" && le(`Attempting to mutate prop "${t}". Props are readonly.`), !1) : t[0] === "$" && t.slice(1) in e ? ({}.NODE_ENV !== "production" && le(`Attempting to mutate public property "${t}". Properties starting with $ are reserved and readonly.`), !1) : ({}.NODE_ENV !== "production" && t in e.appContext.config.globalProperties ? Object.defineProperty(i, t, {
                    enumerable: !0,
                    configurable: !0,
                    value: o
                }) : i[t] = o, !0)
            },
            has({
                _: {
                    data: e,
                    setupState: t,
                    accessCache: o,
                    ctx: n,
                    appContext: r,
                    propsOptions: i
                }
            }, a) {
                let s;
                return !!o[a] || e !== Qe && Re(e, a) || Si(t, a) || (s = i[0]) && Re(s, a) || Re(n, a) || Re(Go, a) || Re(r.config.globalProperties, a)
            },
            defineProperty(e, t, o) {
                return o.get != null ? e._.accessCache[t] = 0 : Re(o, "value") && this.set(e, t, o.value, null), Reflect.defineProperty(e, t, o)
            }
        };
    ({}).NODE_ENV !== "production" && ($s.ownKeys = e => (le("Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead."), Reflect.ownKeys(e)));

    function cd(e) {
        const t = {};
        return Object.defineProperty(t, "_", {
            configurable: !0,
            enumerable: !1,
            get: () => e
        }), Object.keys(Go).forEach(o => {
            Object.defineProperty(t, o, {
                configurable: !0,
                enumerable: !1,
                get: () => Go[o](e),
                set: _t
            })
        }), t
    }

    function ud(e) {
        const {
            ctx: t,
            propsOptions: [o]
        } = e;
        o && Object.keys(o).forEach(n => {
            Object.defineProperty(t, n, {
                enumerable: !0,
                configurable: !0,
                get: () => e.props[n],
                set: _t
            })
        })
    }

    function dd(e) {
        const {
            ctx: t,
            setupState: o
        } = e;
        Object.keys(Ie(o)).forEach(n => {
            if (!o.__isScriptSetup) {
                if (Di(n[0])) {
                    le(`setup() return property ${JSON.stringify(n)} should not start with "$" or "_" which are reserved prefixes for Vue internals.`);
                    return
                }
                Object.defineProperty(t, n, {
                    enumerable: !0,
                    configurable: !0,
                    get: () => o[n],
                    set: _t
                })
            }
        })
    }

    function wr() {
        return fd().attrs
    }

    function fd() {
        const e = ji();
        return {}.NODE_ENV !== "production" && !e && le("useContext() called without active instance."), e.setupContext || (e.setupContext = fl(e))
    }

    function Rs(e) {
        return qe(e) ? e.reduce((t, o) => (t[o] = null, t), {}) : e
    }

    function pd() {
        const e = Object.create(null);
        return (t, o) => {
            e[o] ? le(`${t} property "${o}" is already defined in ${e[o]}.`) : e[o] = t
        }
    }
    let $i = !0;

    function bd(e) {
        const t = Ri(e),
            o = e.proxy,
            n = e.ctx;
        $i = !1, t.beforeCreate && Fs(t.beforeCreate, e, "bc");
        const {
            data: r,
            computed: i,
            methods: a,
            watch: s,
            provide: c,
            inject: l,
            created: f,
            beforeMount: u,
            mounted: d,
            beforeUpdate: _,
            updated: g,
            activated: h,
            deactivated: O,
            beforeDestroy: b,
            beforeUnmount: C,
            destroyed: E,
            unmounted: x,
            render: N,
            renderTracked: w,
            renderTriggered: D,
            errorCaptured: P,
            serverPrefetch: I,
            expose: $,
            inheritAttrs: oe,
            components: A,
            directives: K,
            filters: ae
        } = t, B = {}.NODE_ENV !== "production" ? pd() : null;
        if ({}.NODE_ENV !== "production") {
            const [R] = e.propsOptions;
            if (R)
                for (const U in R) B("Props", U)
        }
        if (l && _d(l, n, B), a)
            for (const R in a) {
                const U = a[R];
                Ne(U) ? ({}.NODE_ENV !== "production" ? Object.defineProperty(n, R, {
                    value: U.bind(o),
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                }) : n[R] = U.bind(o), {}.NODE_ENV !== "production" && B("Methods", R)) : {}.NODE_ENV !== "production" && le(`Method "${R}" has type "${typeof U}" in the component definition. Did you reference the function correctly?`)
            }
        if (r) {
            ({}).NODE_ENV !== "production" && !Ne(r) && le("The data option must be a function. Plain object usage is no longer supported.");
            const R = r.call(o, o);
            if ({}.NODE_ENV !== "production" && ai(R) && le("data() returned a Promise - note data() cannot be async; If you intend to perform data fetching before component renders, use async setup() + <Suspense>."), !je(R))({}).NODE_ENV !== "production" && le("data() should return an object.");
            else if (e.data = ur(R), {}.NODE_ENV !== "production")
                for (const U in R) B("Data", U), Di(U[0]) || Object.defineProperty(n, U, {
                    configurable: !0,
                    enumerable: !0,
                    get: () => R[U],
                    set: _t
                })
        }
        if ($i = !0, i)
            for (const R in i) {
                const U = i[R],
                    ie = Ne(U) ? U.bind(o, o) : Ne(U.get) ? U.get.bind(o, o) : _t;
                ({}).NODE_ENV !== "production" && ie === _t && le(`Computed property "${R}" has no getter.`);
                const _e = !Ne(U) && Ne(U.set) ? U.set.bind(o) : {}.NODE_ENV !== "production" ? () => {
                        le(`Write operation failed: computed property "${R}" is readonly.`)
                    } : _t,
                    he = q({
                        get: ie,
                        set: _e
                    });
                Object.defineProperty(n, R, {
                    enumerable: !0,
                    configurable: !0,
                    get: () => he.value,
                    set: Ce => he.value = Ce
                }), {}.NODE_ENV !== "production" && B("Computed", R)
            }
        if (s)
            for (const R in s) Vs(s[R], n, o, R);
        if (c) {
            const R = Ne(c) ? c.call(o) : c;
            Reflect.ownKeys(R).forEach(U => {
                $t(U, R[U])
            })
        }
        f && Fs(f, e, "c");

        function re(R, U) {
            qe(U) ? U.forEach(ie => R(ie.bind(o))) : U && R(U.bind(o))
        }
        if (re(Er, u), re(nt, d), re(nd, _), re(Ps, g), re(ed, h), re(td, O), re(sd, P), re(ad, w), re(id, D), re(io, C), re(As, x), re(rd, I), qe($))
            if ($.length) {
                const R = e.exposed || (e.exposed = {});
                $.forEach(U => {
                    Object.defineProperty(R, U, {
                        get: () => o[U],
                        set: ie => o[U] = ie
                    })
                })
            } else e.exposed || (e.exposed = {});
        N && e.render === _t && (e.render = N), oe != null && (e.inheritAttrs = oe), A && (e.components = A), K && (e.directives = K)
    }

    function _d(e, t, o = _t) {
        qe(e) && (e = Fi(e));
        for (const n in e) {
            const r = e[n];
            let i;
            je(r) ? "default" in r ? i = rt(r.from || n, r.default, !0) : i = rt(r.from || n) : i = rt(r), at(i) ? Object.defineProperty(t, n, {
                enumerable: !0,
                configurable: !0,
                get: () => i.value,
                set: a => i.value = a
            }) : t[n] = i, {}.NODE_ENV !== "production" && o("Inject", n)
        }
    }

    function Fs(e, t, o) {
        Dt(qe(e) ? e.map(n => n.bind(t.proxy)) : e.bind(t.proxy), t, o)
    }

    function Vs(e, t, o, n) {
        const r = n.includes(".") ? Es(o, n) : () => o[n];
        if (Xe(e)) {
            const i = t[e];
            Ne(i) ? ot(r, i) : {}.NODE_ENV !== "production" && le(`Invalid watch handler specified by key "${e}"`, i)
        } else if (Ne(e)) ot(r, e.bind(o));
        else if (je(e))
            if (qe(e)) e.forEach(i => Vs(i, t, o, n));
            else {
                const i = Ne(e.handler) ? e.handler.bind(o) : t[e.handler];
                Ne(i) ? ot(r, i, e) : {}.NODE_ENV !== "production" && le(`Invalid watch handler specified by key "${e.handler}"`, i)
            }
        else({}).NODE_ENV !== "production" && le(`Invalid watch option: "${n}"`, e)
    }

    function Ri(e) {
        const t = e.type,
            {
                mixins: o,
                extends: n
            } = t,
            {
                mixins: r,
                optionsCache: i,
                config: {
                    optionMergeStrategies: a
                }
            } = e.appContext,
            s = i.get(t);
        let c;
        return s ? c = s : !r.length && !o && !n ? c = t : (c = {}, r.length && r.forEach(l => xr(c, l, a, !0)), xr(c, t, a)), je(t) && i.set(t, c), c
    }

    function xr(e, t, o, n = !1) {
        const {
            mixins: r,
            extends: i
        } = t;
        i && xr(e, i, o, !0), r && r.forEach(a => xr(e, a, o, !0));
        for (const a in t)
            if (n && a === "expose")({}).NODE_ENV !== "production" && le('"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.');
            else {
                const s = md[a] || o && o[a];
                e[a] = s ? s(e[a], t[a]) : t[a]
            }
        return e
    }
    const md = {
        data: Ls,
        props: Gs,
        emits: Gs,
        methods: Pn,
        computed: Pn,
        beforeCreate: Et,
        created: Et,
        beforeMount: Et,
        mounted: Et,
        beforeUpdate: Et,
        updated: Et,
        beforeDestroy: Et,
        beforeUnmount: Et,
        destroyed: Et,
        unmounted: Et,
        activated: Et,
        deactivated: Et,
        errorCaptured: Et,
        serverPrefetch: Et,
        components: Pn,
        directives: Pn,
        watch: hd,
        provide: Ls,
        inject: gd
    };

    function Ls(e, t) {
        return t ? e ? function() {
            return Ze(Ne(e) ? e.call(this, this) : e, Ne(t) ? t.call(this, this) : t)
        } : t : e
    }

    function gd(e, t) {
        return Pn(Fi(e), Fi(t))
    }

    function Fi(e) {
        if (qe(e)) {
            const t = {};
            for (let o = 0; o < e.length; o++) t[e[o]] = e[o];
            return t
        }
        return e
    }

    function Et(e, t) {
        return e ? [...new Set([].concat(e, t))] : t
    }

    function Pn(e, t) {
        return e ? Ze(Object.create(null), e, t) : t
    }

    function Gs(e, t) {
        return e ? qe(e) && qe(t) ? [...new Set([...e, ...t])] : Ze(Object.create(null), Rs(e), Rs(t ? ? {})) : t
    }

    function hd(e, t) {
        if (!e) return t;
        if (!t) return e;
        const o = Ze(Object.create(null), e);
        for (const n in t) o[n] = Et(e[n], t[n]);
        return o
    }

    function Ms() {
        return {
            app: null,
            config: {
                isNativeTag: Ca,
                performance: !1,
                globalProperties: {},
                optionMergeStrategies: {},
                errorHandler: void 0,
                warnHandler: void 0,
                compilerOptions: {}
            },
            mixins: [],
            components: {},
            directives: {},
            provides: Object.create(null),
            optionsCache: new WeakMap,
            propsCache: new WeakMap,
            emitsCache: new WeakMap
        }
    }
    let vd = 0;

    function kd(e, t) {
        return function(n, r = null) {
            Ne(n) || (n = Ze({}, n)), r != null && !je(r) && ({}.NODE_ENV !== "production" && le("root props passed to app.mount() must be an object."), r = null);
            const i = Ms();
            ({}).NODE_ENV !== "production" && Object.defineProperty(i.config, "unwrapInjectedRef", {
                get() {
                    return !0
                },
                set() {
                    le("app.config.unwrapInjectedRef has been deprecated. 3.3 now alawys unwraps injected refs in Options API.")
                }
            });
            const a = new Set;
            let s = !1;
            const c = i.app = {
                _uid: vd++,
                _component: n,
                _props: r,
                _container: null,
                _context: i,
                _instance: null,
                version: _l,
                get config() {
                    return i.config
                },
                set config(l) {
                    ({}).NODE_ENV !== "production" && le("app.config cannot be replaced. Modify individual options instead.")
                },
                use(l, ...f) {
                    return a.has(l) ? {}.NODE_ENV !== "production" && le("Plugin has already been applied to target app.") : l && Ne(l.install) ? (a.add(l), l.install(c, ...f)) : Ne(l) ? (a.add(l), l(c, ...f)) : {}.NODE_ENV !== "production" && le('A plugin must either be a function or an object with an "install" function.'), c
                },
                mixin(l) {
                    return i.mixins.includes(l) ? {}.NODE_ENV !== "production" && le("Mixin has already been applied to target app" + (l.name ? `: ${l.name}` : "")) : i.mixins.push(l), c
                },
                component(l, f) {
                    return {}.NODE_ENV !== "production" && Hi(l, i.config), f ? ({}.NODE_ENV !== "production" && i.components[l] && le(`Component "${l}" has already been registered in target app.`), i.components[l] = f, c) : i.components[l]
                },
                directive(l, f) {
                    return {}.NODE_ENV !== "production" && ws(l), f ? ({}.NODE_ENV !== "production" && i.directives[l] && le(`Directive "${l}" has already been registered in target app.`), i.directives[l] = f, c) : i.directives[l]
                },
                mount(l, f, u) {
                    if (s)({}).NODE_ENV !== "production" && le("App has already been mounted.\nIf you want to remount the same app, move your app creation logic into a factory function and create fresh app instances for each mount - e.g. `const createMyApp = () => createApp(App)`");
                    else {
                        ({}).NODE_ENV !== "production" && l.__vue_app__ && le("There is already an app instance mounted on the host container.\n If you want to mount another app on the same host container, you need to unmount the previous app by calling `app.unmount()` first.");
                        const d = pe(n, r);
                        return d.appContext = i, {}.NODE_ENV !== "production" && (i.reload = () => {
                            e(Xt(d), l, u)
                        }), f && t ? t(d, l) : e(d, l, u), s = !0, c._container = l, l.__vue_app__ = c, {}.NODE_ENV !== "production" && (c._instance = d.component, Ru(c, _l)), Ar(d.component) || d.component.proxy
                    }
                },
                unmount() {
                    s ? (e(null, c._container), {}.NODE_ENV !== "production" && (c._instance = null, Fu(c)), delete c._container.__vue_app__) : {}.NODE_ENV !== "production" && le("Cannot unmount an app that is not mounted.")
                },
                provide(l, f) {
                    return {}.NODE_ENV !== "production" && l in i.provides && le(`App already provides property with key "${String(l)}". It will be overwritten with the new value.`), i.provides[l] = f, c
                },
                runWithContext(l) {
                    Cr = c;
                    try {
                        return l()
                    } finally {
                        Cr = null
                    }
                }
            };
            return c
        }
    }
    let Cr = null;

    function $t(e, t) {
        if (!lt)({}).NODE_ENV !== "production" && le("provide() can only be used inside setup().");
        else {
            let o = lt.provides;
            const n = lt.parent && lt.parent.provides;
            n === o && (o = lt.provides = Object.create(n)), o[e] = t
        }
    }

    function rt(e, t, o = !1) {
        const n = lt || st;
        if (n || Cr) {
            const r = n ? n.parent == null ? n.vnode.appContext && n.vnode.appContext.provides : n.parent.provides : Cr._context.provides;
            if (r && e in r) return r[e];
            if (arguments.length > 1) return o && Ne(t) ? t.call(n && n.proxy) : t;
            ({}).NODE_ENV !== "production" && le(`injection "${String(e)}" not found.`)
        } else({}).NODE_ENV !== "production" && le("inject() can only be used inside setup() or functional components.")
    }

    function yd(e, t, o, n = !1) {
        const r = {},
            i = {};
        Jn(i, Nr, 1), e.propsDefaults = Object.create(null), Bs(e, t, r, i);
        for (const a in e.propsOptions[0]) a in r || (r[a] = void 0);
        ({}).NODE_ENV !== "production" && Ks(t || {}, r, e), o ? e.props = n ? r : mu(r) : e.type.props ? e.props = r : e.props = i, e.attrs = i
    }

    function qd(e) {
        for (; e;) {
            if (e.type.__hmrId) return !0;
            e = e.parent
        }
    }

    function Ed(e, t, o, n) {
        const {
            props: r,
            attrs: i,
            vnode: {
                patchFlag: a
            }
        } = e, s = Ie(r), [c] = e.propsOptions;
        let l = !1;
        if (!({}.NODE_ENV !== "production" && qd(e)) && (n || a > 0) && !(a & 16)) {
            if (a & 8) {
                const f = e.vnode.dynamicProps;
                for (let u = 0; u < f.length; u++) {
                    let d = f[u];
                    if (gr(e.emitsOptions, d)) continue;
                    const _ = t[d];
                    if (c)
                        if (Re(i, d)) _ !== i[d] && (i[d] = _, l = !0);
                        else {
                            const g = Pt(d);
                            r[g] = Vi(c, s, g, _, e, !1)
                        }
                    else _ !== i[d] && (i[d] = _, l = !0)
                }
            }
        } else {
            Bs(e, t, r, i) && (l = !0);
            let f;
            for (const u in s)(!t || !Re(t, u) && ((f = At(u)) === u || !Re(t, f))) && (c ? o && (o[u] !== void 0 || o[f] !== void 0) && (r[u] = Vi(c, s, u, void 0, e, !0)) : delete r[u]);
            if (i !== s)
                for (const u in i)(!t || !Re(t, u)) && (delete i[u], l = !0)
        }
        l && Wt(e, "set", "$attrs"), {}.NODE_ENV !== "production" && Ks(t || {}, r, e)
    }

    function Bs(e, t, o, n) {
        const [r, i] = e.propsOptions;
        let a = !1,
            s;
        if (t)
            for (let c in t) {
                if (Qn(c)) continue;
                const l = t[c];
                let f;
                r && Re(r, f = Pt(c)) ? !i || !i.includes(f) ? o[f] = l : (s || (s = {}))[f] = l : gr(e.emitsOptions, c) || (!(c in n) || l !== n[c]) && (n[c] = l, a = !0)
            }
        if (i) {
            const c = Ie(o),
                l = s || Qe;
            for (let f = 0; f < i.length; f++) {
                const u = i[f];
                o[u] = Vi(r, c, u, l[u], e, !Re(l, u))
            }
        }
        return a
    }

    function Vi(e, t, o, n, r, i) {
        const a = e[o];
        if (a != null) {
            const s = Re(a, "default");
            if (s && n === void 0) {
                const c = a.default;
                if (a.type !== Function && !a.skipFactory && Ne(c)) {
                    const {
                        propsDefaults: l
                    } = r;
                    o in l ? n = l[o] : (rn(r), n = l[o] = c.call(null, t), Uo())
                } else n = c
            }
            a[0] && (i && !s ? n = !1 : a[1] && (n === "" || n === At(o)) && (n = !0))
        }
        return n
    }

    function Us(e, t, o = !1) {
        const n = t.propsCache,
            r = n.get(e);
        if (r) return r;
        const i = e.props,
            a = {},
            s = [];
        let c = !1;
        if (!Ne(e)) {
            const f = u => {
                c = !0;
                const [d, _] = Us(u, t, !0);
                Ze(a, d), _ && s.push(..._)
            };
            !o && t.mixins.length && t.mixins.forEach(f), e.extends && f(e.extends), e.mixins && e.mixins.forEach(f)
        }
        if (!i && !c) return je(e) && n.set(e, Qo), Qo;
        if (qe(i))
            for (let f = 0; f < i.length; f++) {
                ({}).NODE_ENV !== "production" && !Xe(i[f]) && le("props must be strings when using array syntax.", i[f]);
                const u = Pt(i[f]);
                js(u) && (a[u] = Qe)
            } else if (i) {
                ({}).NODE_ENV !== "production" && !je(i) && le("invalid props options", i);
                for (const f in i) {
                    const u = Pt(f);
                    if (js(u)) {
                        const d = i[f],
                            _ = a[u] = qe(d) || Ne(d) ? {
                                type: d
                            } : Ze({}, d);
                        if (_) {
                            const g = Hs(Boolean, _.type),
                                h = Hs(String, _.type);
                            _[0] = g > -1, _[1] = h < 0 || g < h, (g > -1 || Re(_, "default")) && s.push(u)
                        }
                    }
                }
            }
        const l = [a, s];
        return je(e) && n.set(e, l), l
    }

    function js(e) {
        return e[0] !== "$" ? !0 : ({}.NODE_ENV !== "production" && le(`Invalid prop name: "${e}" is a reserved property.`), !1)
    }

    function Li(e) {
        const t = e && e.toString().match(/^\s*(function|class) (\w+)/);
        return t ? t[2] : e === null ? "null" : ""
    }

    function zs(e, t) {
        return Li(e) === Li(t)
    }

    function Hs(e, t) {
        return qe(t) ? t.findIndex(o => zs(o, e)) : Ne(t) && zs(t, e) ? 0 : -1
    }

    function Ks(e, t, o) {
        const n = Ie(t),
            r = o.propsOptions[0];
        for (const i in r) {
            let a = r[i];
            a != null && wd(i, n[i], a, !Re(e, i) && !Re(e, At(i)))
        }
    }

    function wd(e, t, o, n) {
        const {
            type: r,
            required: i,
            validator: a,
            skipCheck: s
        } = o;
        if (i && n) {
            le('Missing required prop: "' + e + '"');
            return
        }
        if (!(t == null && !i)) {
            if (r != null && r !== !0 && !s) {
                let c = !1;
                const l = qe(r) ? r : [r],
                    f = [];
                for (let u = 0; u < l.length && !c; u++) {
                    const {
                        valid: d,
                        expectedType: _
                    } = Cd(t, l[u]);
                    f.push(_ || ""), c = d
                }
                if (!c) {
                    le(Td(e, t, f));
                    return
                }
            }
            a && !a(t) && le('Invalid prop: custom validator check failed for prop "' + e + '".')
        }
    }
    const xd = uo("String,Number,Boolean,Function,Symbol,BigInt");

    function Cd(e, t) {
        let o;
        const n = Li(t);
        if (xd(n)) {
            const r = typeof e;
            o = r === n.toLowerCase(), !o && r === "object" && (o = e instanceof t)
        } else n === "Object" ? o = je(e) : n === "Array" ? o = qe(e) : n === "null" ? o = e === null : o = e instanceof t;
        return {
            valid: o,
            expectedType: n
        }
    }

    function Td(e, t, o) {
        let n = `Invalid prop: type check failed for prop "${e}". Expected ${o.map(Po).join(" | ")}`;
        const r = o[0],
            i = si(t),
            a = Ys(t, r),
            s = Ys(t, i);
        return o.length === 1 && Ws(r) && !Od(r, i) && (n += ` with value ${a}`), n += `, got ${i} `, Ws(i) && (n += `with value ${s}.`), n
    }

    function Ys(e, t) {
        return t === "String" ? `"${e}"` : t === "Number" ? `${Number(e)}` : `${e}`
    }

    function Ws(e) {
        return ["string", "number", "boolean"].some(o => e.toLowerCase() === o)
    }

    function Od(...e) {
        return e.some(t => t.toLowerCase() === "boolean")
    }
    const Qs = e => e[0] === "_" || e === "$stable",
        Gi = e => qe(e) ? e.map(Kt) : [Kt(e)],
        Nd = (e, t, o) => {
            if (t._n) return t;
            const n = Ge((...r) => ({}.NODE_ENV !== "production" && lt && le(`Slot "${e}" invoked outside of the render function: this will not track dependencies used in the slot. Invoke the slot function inside the render function instead.`), Gi(t(...r))), o);
            return n._c = !1, n
        },
        Zs = (e, t, o) => {
            const n = e._ctx;
            for (const r in e) {
                if (Qs(r)) continue;
                const i = e[r];
                if (Ne(i)) t[r] = Nd(r, i, n);
                else if (i != null) {
                    ({}).NODE_ENV !== "production" && le(`Non-function value encountered for slot "${r}". Prefer function slots for better performance.`);
                    const a = Gi(i);
                    t[r] = () => a
                }
            }
        },
        Js = (e, t) => {
            ({}).NODE_ENV !== "production" && !Nn(e.vnode) && le("Non-function value encountered for default slot. Prefer function slots for better performance.");
            const o = Gi(t);
            e.slots.default = () => o
        },
        Pd = (e, t) => {
            if (e.vnode.shapeFlag & 32) {
                const o = t._;
                o ? (e.slots = Ie(t), Jn(t, "_", o)) : Zs(t, e.slots = {})
            } else e.slots = {}, t && Js(e, t);
            Jn(e.slots, Nr, 1)
        },
        Ad = (e, t, o) => {
            const {
                vnode: n,
                slots: r
            } = e;
            let i = !0,
                a = Qe;
            if (n.shapeFlag & 32) {
                const s = t._;
                s ? {}.NODE_ENV !== "production" && go ? (Ze(r, t), Wt(e, "set", "$slots")) : o && s === 1 ? i = !1 : (Ze(r, t), !o && s === 1 && delete r._) : (i = !t.$stable, Zs(t, r)), a = t
            } else t && (Js(e, t), a = {
                default: 1
            });
            if (i)
                for (const s in r) !Qs(s) && !(s in a) && delete r[s]
        };

    function Mi(e, t, o, n, r = !1) {
        if (qe(e)) {
            e.forEach((d, _) => Mi(d, t && (qe(t) ? t[_] : t), o, n, r));
            return
        }
        if (On(n) && !r) return;
        const i = n.shapeFlag & 4 ? Ar(n.component) || n.component.proxy : n.el,
            a = r ? null : i,
            {
                i: s,
                r: c
            } = e;
        if ({}.NODE_ENV !== "production" && !s) {
            le("Missing ref owner context. ref cannot be used on hoisted vnodes. A vnode with ref must be created inside the render function.");
            return
        }
        const l = t && t.r,
            f = s.refs === Qe ? s.refs = {} : s.refs,
            u = s.setupState;
        if (l != null && l !== c && (Xe(l) ? (f[l] = null, Re(u, l) && (u[l] = null)) : at(l) && (l.value = null)), Ne(c)) no(c, s, 12, [a, f]);
        else {
            const d = Xe(c),
                _ = at(c);
            if (d || _) {
                const g = () => {
                    if (e.f) {
                        const h = d ? Re(u, c) ? u[c] : f[c] : c.value;
                        r ? qe(h) && ii(h, i) : qe(h) ? h.includes(i) || h.push(i) : d ? (f[c] = [i], Re(u, c) && (u[c] = f[c])) : (c.value = [i], e.k && (f[e.k] = c.value))
                    } else d ? (f[c] = a, Re(u, c) && (u[c] = a)) : _ ? (c.value = a, e.k && (f[e.k] = a)) : {}.NODE_ENV !== "production" && le("Invalid template ref type:", c, `(${typeof c})`)
                };
                a ? (g.id = -1, xt(g, o)) : g()
            } else({}).NODE_ENV !== "production" && le("Invalid template ref type:", c, `(${typeof c})`)
        }
    }
    let An, ho;

    function ao(e, t) {
        e.appContext.config.performance && Tr() && ho.mark(`vue-${t}-${e.uid}`), {}.NODE_ENV !== "production" && Mu(e, t, Tr() ? ho.now() : Date.now())
    }

    function so(e, t) {
        if (e.appContext.config.performance && Tr()) {
            const o = `vue-${t}-${e.uid}`,
                n = o + ":end";
            ho.mark(n), ho.measure(`<${Ir(e,e.type)}> ${t}`, o, n), ho.clearMarks(o), ho.clearMarks(n)
        }({}).NODE_ENV !== "production" && Bu(e, t, Tr() ? ho.now() : Date.now())
    }

    function Tr() {
        return An !== void 0 || (typeof window < "u" && window.performance ? (An = !0, ho = window.performance) : An = !1), An
    }

    function Id() {
        const e = [];
        if ({}.NODE_ENV !== "production" && e.length) {
            const t = e.length > 1;
            console.warn(`Feature flag${t?"s":""} ${e.join(", ")} ${t?"are":"is"} not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.

For more details, see https://link.vuejs.org/feature-flags.`)
        }
    }
    const xt = Zu;

    function Dd(e) {
        return Sd(e)
    }

    function Sd(e, t) {
        Id();
        const o = er();
        o.__VUE__ = !0, {}.NODE_ENV !== "production" && ps(o.__VUE_DEVTOOLS_GLOBAL_HOOK__, o);
        const {
            insert: n,
            remove: r,
            patchProp: i,
            createElement: a,
            createText: s,
            createComment: c,
            setText: l,
            setElementText: f,
            parentNode: u,
            nextSibling: d,
            setScopeId: _ = _t,
            insertStaticContent: g
        } = e, h = (m, y, V, Z = null, Q = null, ee = null, j = !1, M = null, te = {}.NODE_ENV !== "production" && go ? !1 : !!y.dynamicChildren) => {
            if (m === y) return;
            m && !Bo(m, y) && (Z = We(m), we(m, Q, ee, !0), m = null), y.patchFlag === -2 && (te = !1, y.dynamicChildren = null);
            const {
                type: W,
                ref: de,
                shapeFlag: fe
            } = y;
            switch (W) {
                case Dn:
                    O(m, y, V, Z);
                    break;
                case ft:
                    b(m, y, V, Z);
                    break;
                case Sn:
                    m == null ? C(y, V, Z, j) : {}.NODE_ENV !== "production" && E(m, y, V, j);
                    break;
                case Be:
                    K(m, y, V, Z, Q, ee, j, M, te);
                    break;
                default:
                    fe & 1 ? w(m, y, V, Z, Q, ee, j, M, te) : fe & 6 ? ae(m, y, V, Z, Q, ee, j, M, te) : fe & 64 || fe & 128 ? W.process(m, y, V, Z, Q, ee, j, M, te, De) : {}.NODE_ENV !== "production" && le("Invalid VNode type:", W, `(${typeof W})`)
            }
            de != null && Q && Mi(de, m && m.ref, ee, y || m, !y)
        }, O = (m, y, V, Z) => {
            if (m == null) n(y.el = s(y.children), V, Z);
            else {
                const Q = y.el = m.el;
                y.children !== m.children && l(Q, y.children)
            }
        }, b = (m, y, V, Z) => {
            m == null ? n(y.el = c(y.children || ""), V, Z) : y.el = m.el
        }, C = (m, y, V, Z) => {
            [m.el, m.anchor] = g(m.children, y, V, Z, m.el, m.anchor)
        }, E = (m, y, V, Z) => {
            if (y.children !== m.children) {
                const Q = d(m.anchor);
                N(m), [y.el, y.anchor] = g(y.children, V, Q, Z)
            } else y.el = m.el, y.anchor = m.anchor
        }, x = ({
            el: m,
            anchor: y
        }, V, Z) => {
            let Q;
            for (; m && m !== y;) Q = d(m), n(m, V, Z), m = Q;
            n(y, V, Z)
        }, N = ({
            el: m,
            anchor: y
        }) => {
            let V;
            for (; m && m !== y;) V = d(m), r(m), m = V;
            r(y)
        }, w = (m, y, V, Z, Q, ee, j, M, te) => {
            j = j || y.type === "svg", m == null ? D(y, V, Z, Q, ee, j, M, te) : $(m, y, Q, ee, j, M, te)
        }, D = (m, y, V, Z, Q, ee, j, M) => {
            let te, W;
            const {
                type: de,
                props: fe,
                shapeFlag: ge,
                transition: ye,
                dirs: z
            } = m;
            if (te = m.el = a(m.type, ee, fe && fe.is, fe), ge & 8 ? f(te, m.children) : ge & 16 && I(m.children, te, null, Z, Q, ee && de !== "foreignObject", j, M), z && Lo(m, null, Z, "created"), P(te, m, m.scopeId, j, Z), fe) {
                for (const ce in fe) ce !== "value" && !Qn(ce) && i(te, ce, null, fe[ce], ee, m.children, Z, Q, Ae);
                "value" in fe && i(te, "value", null, fe.value), (W = fe.onVnodeBeforeMount) && eo(W, Z, m)
            }({}).NODE_ENV !== "production" && (Object.defineProperty(te, "__vnode", {
                value: m,
                enumerable: !1
            }), Object.defineProperty(te, "__vueParentComponent", {
                value: Z,
                enumerable: !1
            })), z && Lo(m, null, Z, "beforeMount");
            const se = (!Q || Q && !Q.pendingBranch) && ye && !ye.persisted;
            se && ye.beforeEnter(te), n(te, y, V), ((W = fe && fe.onVnodeMounted) || se || z) && xt(() => {
                W && eo(W, Z, m), se && ye.enter(te), z && Lo(m, null, Z, "mounted")
            }, Q)
        }, P = (m, y, V, Z, Q) => {
            if (V && _(m, V), Z)
                for (let ee = 0; ee < Z.length; ee++) _(m, Z[ee]);
            if (Q) {
                let ee = Q.subTree;
                if ({}.NODE_ENV !== "production" && ee.patchFlag > 0 && ee.patchFlag & 2048 && (ee = vs(ee.children) || ee), y === ee) {
                    const j = Q.vnode;
                    P(m, j, j.scopeId, j.slotScopeIds, Q.parent)
                }
            }
        }, I = (m, y, V, Z, Q, ee, j, M, te = 0) => {
            for (let W = te; W < m.length; W++) {
                const de = m[W] = M ? vo(m[W]) : Kt(m[W]);
                h(null, de, y, V, Z, Q, ee, j, M)
            }
        }, $ = (m, y, V, Z, Q, ee, j) => {
            const M = y.el = m.el;
            let {
                patchFlag: te,
                dynamicChildren: W,
                dirs: de
            } = y;
            te |= m.patchFlag & 16;
            const fe = m.props || Qe,
                ge = y.props || Qe;
            let ye;
            V && Mo(V, !1), (ye = ge.onVnodeBeforeUpdate) && eo(ye, V, y, m), de && Lo(y, m, V, "beforeUpdate"), V && Mo(V, !0), {}.NODE_ENV !== "production" && go && (te = 0, j = !1, W = null);
            const z = Q && y.type !== "foreignObject";
            if (W ? (oe(m.dynamicChildren, W, M, V, Z, z, ee), {}.NODE_ENV !== "production" && In(m, y)) : j || ie(m, y, M, null, V, Z, z, ee, !1), te > 0) {
                if (te & 16) A(M, y, fe, ge, V, Z, Q);
                else if (te & 2 && fe.class !== ge.class && i(M, "class", null, ge.class, Q), te & 4 && i(M, "style", fe.style, ge.style, Q), te & 8) {
                    const se = y.dynamicProps;
                    for (let ce = 0; ce < se.length; ce++) {
                        const ue = se[ce],
                            me = fe[ue],
                            p = ge[ue];
                        (p !== me || ue === "value") && i(M, ue, me, p, Q, m.children, V, Z, Ae)
                    }
                }
                te & 1 && m.children !== y.children && f(M, y.children)
            } else !j && W == null && A(M, y, fe, ge, V, Z, Q);
            ((ye = ge.onVnodeUpdated) || de) && xt(() => {
                ye && eo(ye, V, y, m), de && Lo(y, m, V, "updated")
            }, Z)
        }, oe = (m, y, V, Z, Q, ee, j) => {
            for (let M = 0; M < y.length; M++) {
                const te = m[M],
                    W = y[M],
                    de = te.el && (te.type === Be || !Bo(te, W) || te.shapeFlag & 70) ? u(te.el) : V;
                h(te, W, de, null, Z, Q, ee, j, !0)
            }
        }, A = (m, y, V, Z, Q, ee, j) => {
            if (V !== Z) {
                if (V !== Qe)
                    for (const M in V) !Qn(M) && !(M in Z) && i(m, M, V[M], null, j, y.children, Q, ee, Ae);
                for (const M in Z) {
                    if (Qn(M)) continue;
                    const te = Z[M],
                        W = V[M];
                    te !== W && M !== "value" && i(m, M, W, te, j, y.children, Q, ee, Ae)
                }
                "value" in Z && i(m, "value", V.value, Z.value)
            }
        }, K = (m, y, V, Z, Q, ee, j, M, te) => {
            const W = y.el = m ? m.el : s(""),
                de = y.anchor = m ? m.anchor : s("");
            let {
                patchFlag: fe,
                dynamicChildren: ge,
                slotScopeIds: ye
            } = y;
            ({}).NODE_ENV !== "production" && (go || fe & 2048) && (fe = 0, te = !1, ge = null), ye && (M = M ? M.concat(ye) : ye), m == null ? (n(W, V, Z), n(de, V, Z), I(y.children, V, de, Q, ee, j, M, te)) : fe > 0 && fe & 64 && ge && m.dynamicChildren ? (oe(m.dynamicChildren, ge, V, Q, ee, j, M), {}.NODE_ENV !== "production" ? In(m, y) : (y.key != null || Q && y === Q.subTree) && In(m, y, !0)) : ie(m, y, V, de, Q, ee, j, M, te)
        }, ae = (m, y, V, Z, Q, ee, j, M, te) => {
            y.slotScopeIds = M, m == null ? y.shapeFlag & 512 ? Q.ctx.activate(y, V, Z, j, te) : B(y, V, Z, Q, ee, j, te) : re(m, y, te)
        }, B = (m, y, V, Z, Q, ee, j) => {
            const M = m.component = Kd(m, Z, Q);
            if ({}.NODE_ENV !== "production" && M.type.__hmrId && Iu(M), {}.NODE_ENV !== "production" && (pr(m), ao(M, "mount")), Nn(m) && (M.ctx.renderer = De), {}.NODE_ENV !== "production" && ao(M, "init"), Wd(M), {}.NODE_ENV !== "production" && so(M, "init"), M.asyncDep) {
                if (Q && Q.registerDep(M, R), !m.el) {
                    const te = M.subTree = pe(ft);
                    b(null, te, y, V)
                }
                return
            }
            R(M, m, y, V, Q, ee, j), {}.NODE_ENV !== "production" && (br(), so(M, "mount"))
        }, re = (m, y, V) => {
            const Z = y.component = m.component;
            if (Yu(m, y, V))
                if (Z.asyncDep && !Z.asyncResolved) {
                    ({}).NODE_ENV !== "production" && pr(y), U(Z, y, V), {}.NODE_ENV !== "production" && br();
                    return
                } else Z.next = y, Pu(Z.update), Z.update();
            else y.el = m.el, Z.vnode = y
        }, R = (m, y, V, Z, Q, ee, j) => {
            const M = () => {
                    if (m.isMounted) {
                        let {
                            next: de,
                            bu: fe,
                            u: ge,
                            parent: ye,
                            vnode: z
                        } = m, se = de, ce;
                        ({}).NODE_ENV !== "production" && pr(de || m.vnode), Mo(m, !1), de ? (de.el = z.el, U(m, de, j)) : de = z, fe && Zo(fe), (ce = de.props && de.props.onVnodeBeforeUpdate) && eo(ce, ye, de, z), Mo(m, !0), {}.NODE_ENV !== "production" && ao(m, "render");
                        const ue = Ti(m);
                        ({}).NODE_ENV !== "production" && so(m, "render");
                        const me = m.subTree;
                        m.subTree = ue, {}.NODE_ENV !== "production" && ao(m, "patch"), h(me, ue, u(me.el), We(me), m, Q, ee), {}.NODE_ENV !== "production" && so(m, "patch"), de.el = ue.el, se === null && Wu(m, ue.el), ge && xt(ge, Q), (ce = de.props && de.props.onVnodeUpdated) && xt(() => eo(ce, ye, de, z), Q), {}.NODE_ENV !== "production" && bs(m), {}.NODE_ENV !== "production" && br()
                    } else {
                        let de;
                        const {
                            el: fe,
                            props: ge
                        } = y, {
                            bm: ye,
                            m: z,
                            parent: se
                        } = m, ce = On(y);
                        if (Mo(m, !1), ye && Zo(ye), !ce && (de = ge && ge.onVnodeBeforeMount) && eo(de, se, y), Mo(m, !0), fe && He) {
                            const ue = () => {
                                ({}).NODE_ENV !== "production" && ao(m, "render"), m.subTree = Ti(m), {}.NODE_ENV !== "production" && so(m, "render"), {}.NODE_ENV !== "production" && ao(m, "hydrate"), He(fe, m.subTree, m, Q, null), {}.NODE_ENV !== "production" && so(m, "hydrate")
                            };
                            ce ? y.type.__asyncLoader().then(() => !m.isUnmounted && ue()) : ue()
                        } else {
                            ({}).NODE_ENV !== "production" && ao(m, "render");
                            const ue = m.subTree = Ti(m);
                            ({}).NODE_ENV !== "production" && so(m, "render"), {}.NODE_ENV !== "production" && ao(m, "patch"), h(null, ue, V, Z, m, Q, ee), {}.NODE_ENV !== "production" && so(m, "patch"), y.el = ue.el
                        }
                        if (z && xt(z, Q), !ce && (de = ge && ge.onVnodeMounted)) {
                            const ue = y;
                            xt(() => eo(de, se, ue), Q)
                        }(y.shapeFlag & 256 || se && On(se.vnode) && se.vnode.shapeFlag & 256) && m.a && xt(m.a, Q), m.isMounted = !0, {}.NODE_ENV !== "production" && Vu(m), y = V = Z = null
                    }
                },
                te = m.effect = new bi(M, () => mr(W), m.scope),
                W = m.update = () => te.run();
            W.id = m.uid, Mo(m, !0), {}.NODE_ENV !== "production" && (te.onTrack = m.rtc ? de => Zo(m.rtc, de) : void 0, te.onTrigger = m.rtg ? de => Zo(m.rtg, de) : void 0, W.ownerInstance = m), W()
        }, U = (m, y, V) => {
            y.component = m;
            const Z = m.vnode.props;
            m.vnode = y, m.next = null, Ed(m, y.props, Z, V), Ad(m, y.children, V), Do(), ls(), So()
        }, ie = (m, y, V, Z, Q, ee, j, M, te = !1) => {
            const W = m && m.children,
                de = m ? m.shapeFlag : 0,
                fe = y.children,
                {
                    patchFlag: ge,
                    shapeFlag: ye
                } = y;
            if (ge > 0) {
                if (ge & 128) {
                    he(W, fe, V, Z, Q, ee, j, M, te);
                    return
                } else if (ge & 256) {
                    _e(W, fe, V, Z, Q, ee, j, M, te);
                    return
                }
            }
            ye & 8 ? (de & 16 && Ae(W, Q, ee), fe !== W && f(V, fe)) : de & 16 ? ye & 16 ? he(W, fe, V, Z, Q, ee, j, M, te) : Ae(W, Q, ee, !0) : (de & 8 && f(V, ""), ye & 16 && I(fe, V, Z, Q, ee, j, M, te))
        }, _e = (m, y, V, Z, Q, ee, j, M, te) => {
            m = m || Qo, y = y || Qo;
            const W = m.length,
                de = y.length,
                fe = Math.min(W, de);
            let ge;
            for (ge = 0; ge < fe; ge++) {
                const ye = y[ge] = te ? vo(y[ge]) : Kt(y[ge]);
                h(m[ge], ye, V, null, Q, ee, j, M, te)
            }
            W > de ? Ae(m, Q, ee, !0, !1, fe) : I(y, V, Z, Q, ee, j, M, te, fe)
        }, he = (m, y, V, Z, Q, ee, j, M, te) => {
            let W = 0;
            const de = y.length;
            let fe = m.length - 1,
                ge = de - 1;
            for (; W <= fe && W <= ge;) {
                const ye = m[W],
                    z = y[W] = te ? vo(y[W]) : Kt(y[W]);
                if (Bo(ye, z)) h(ye, z, V, null, Q, ee, j, M, te);
                else break;
                W++
            }
            for (; W <= fe && W <= ge;) {
                const ye = m[fe],
                    z = y[ge] = te ? vo(y[ge]) : Kt(y[ge]);
                if (Bo(ye, z)) h(ye, z, V, null, Q, ee, j, M, te);
                else break;
                fe--, ge--
            }
            if (W > fe) {
                if (W <= ge) {
                    const ye = ge + 1,
                        z = ye < de ? y[ye].el : Z;
                    for (; W <= ge;) h(null, y[W] = te ? vo(y[W]) : Kt(y[W]), V, z, Q, ee, j, M, te), W++
                }
            } else if (W > ge)
                for (; W <= fe;) we(m[W], Q, ee, !0), W++;
            else {
                const ye = W,
                    z = W,
                    se = new Map;
                for (W = z; W <= ge; W++) {
                    const X = y[W] = te ? vo(y[W]) : Kt(y[W]);
                    X.key != null && ({}.NODE_ENV !== "production" && se.has(X.key) && le("Duplicate keys found during update:", JSON.stringify(X.key), "Make sure keys are unique."), se.set(X.key, W))
                }
                let ce, ue = 0;
                const me = ge - z + 1;
                let p = !1,
                    k = 0;
                const G = new Array(me);
                for (W = 0; W < me; W++) G[W] = 0;
                for (W = ye; W <= fe; W++) {
                    const X = m[W];
                    if (ue >= me) {
                        we(X, Q, ee, !0);
                        continue
                    }
                    let be;
                    if (X.key != null) be = se.get(X.key);
                    else
                        for (ce = z; ce <= ge; ce++)
                            if (G[ce - z] === 0 && Bo(X, y[ce])) {
                                be = ce;
                                break
                            }
                    be === void 0 ? we(X, Q, ee, !0) : (G[be - z] = W + 1, be >= k ? k = be : p = !0, h(X, y[be], V, null, Q, ee, j, M, te), ue++)
                }
                const Y = p ? $d(G) : Qo;
                for (ce = Y.length - 1, W = me - 1; W >= 0; W--) {
                    const X = z + W,
                        be = y[X],
                        Ee = X + 1 < de ? y[X + 1].el : Z;
                    G[W] === 0 ? h(null, be, V, Ee, Q, ee, j, M, te) : p && (ce < 0 || W !== Y[ce] ? Ce(be, V, Ee, 2) : ce--)
                }
            }
        }, Ce = (m, y, V, Z, Q = null) => {
            const {
                el: ee,
                type: j,
                transition: M,
                children: te,
                shapeFlag: W
            } = m;
            if (W & 6) {
                Ce(m.component.subTree, y, V, Z);
                return
            }
            if (W & 128) {
                m.suspense.move(y, V, Z);
                return
            }
            if (W & 64) {
                j.move(m, y, V, De);
                return
            }
            if (j === Be) {
                n(ee, y, V);
                for (let fe = 0; fe < te.length; fe++) Ce(te[fe], y, V, Z);
                n(m.anchor, y, V);
                return
            }
            if (j === Sn) {
                x(m, y, V);
                return
            }
            if (Z !== 2 && W & 1 && M)
                if (Z === 0) M.beforeEnter(ee), n(ee, y, V), xt(() => M.enter(ee), Q);
                else {
                    const {
                        leave: fe,
                        delayLeave: ge,
                        afterLeave: ye
                    } = M, z = () => n(ee, y, V), se = () => {
                        fe(ee, () => {
                            z(), ye && ye()
                        })
                    };
                    ge ? ge(ee, z, se) : se()
                }
            else n(ee, y, V)
        }, we = (m, y, V, Z = !1, Q = !1) => {
            const {
                type: ee,
                props: j,
                ref: M,
                children: te,
                dynamicChildren: W,
                shapeFlag: de,
                patchFlag: fe,
                dirs: ge
            } = m;
            if (M != null && Mi(M, null, V, m, !0), de & 256) {
                y.ctx.deactivate(m);
                return
            }
            const ye = de & 1 && ge,
                z = !On(m);
            let se;
            if (z && (se = j && j.onVnodeBeforeUnmount) && eo(se, y, m), de & 6) Ve(m.component, V, Z);
            else {
                if (de & 128) {
                    m.suspense.unmount(V, Z);
                    return
                }
                ye && Lo(m, null, y, "beforeUnmount"), de & 64 ? m.type.remove(m, y, V, Q, De, Z) : W && (ee !== Be || fe > 0 && fe & 64) ? Ae(W, y, V, !1, !0) : (ee === Be && fe & 384 || !Q && de & 16) && Ae(te, y, V), Z && ke(m)
            }(z && (se = j && j.onVnodeUnmounted) || ye) && xt(() => {
                se && eo(se, y, m), ye && Lo(m, null, y, "unmounted")
            }, V)
        }, ke = m => {
            const {
                type: y,
                el: V,
                anchor: Z,
                transition: Q
            } = m;
            if (y === Be) {
                ({}).NODE_ENV !== "production" && m.patchFlag > 0 && m.patchFlag & 2048 && Q && !Q.persisted ? m.children.forEach(j => {
                    j.type === ft ? r(j.el) : ke(j)
                }) : Oe(V, Z);
                return
            }
            if (y === Sn) {
                N(m);
                return
            }
            const ee = () => {
                r(V), Q && !Q.persisted && Q.afterLeave && Q.afterLeave()
            };
            if (m.shapeFlag & 1 && Q && !Q.persisted) {
                const {
                    leave: j,
                    delayLeave: M
                } = Q, te = () => j(V, ee);
                M ? M(m.el, ee, te) : te()
            } else ee()
        }, Oe = (m, y) => {
            let V;
            for (; m !== y;) V = d(m), r(m), m = V;
            r(y)
        }, Ve = (m, y, V) => {
            ({}).NODE_ENV !== "production" && m.type.__hmrId && Du(m);
            const {
                bum: Z,
                scope: Q,
                update: ee,
                subTree: j,
                um: M
            } = m;
            Z && Zo(Z), Q.stop(), ee && (ee.active = !1, we(j, m, y, V)), M && xt(M, y), xt(() => {
                m.isUnmounted = !0
            }, y), y && y.pendingBranch && !y.isUnmounted && m.asyncDep && !m.asyncResolved && m.suspenseId === y.pendingId && (y.deps--, y.deps === 0 && y.resolve()), {}.NODE_ENV !== "production" && Gu(m)
        }, Ae = (m, y, V, Z = !1, Q = !1, ee = 0) => {
            for (let j = ee; j < m.length; j++) we(m[j], y, V, Z, Q)
        }, We = m => m.shapeFlag & 6 ? We(m.component.subTree) : m.shapeFlag & 128 ? m.suspense.next() : d(m.anchor || m.el), Je = (m, y, V) => {
            m == null ? y._vnode && we(y._vnode, null, null, !0) : h(y._vnode || null, m, y, null, null, null, V), ls(), cs(), y._vnode = m
        }, De = {
            p: h,
            um: we,
            m: Ce,
            r: ke,
            mt: B,
            mc: I,
            pc: ie,
            pbc: oe,
            n: We,
            o: e
        };
        let Ye, He;
        return t && ([Ye, He] = t(De)), {
            render: Je,
            hydrate: Ye,
            createApp: kd(Je, Ye)
        }
    }

    function Mo({
        effect: e,
        update: t
    }, o) {
        e.allowRecurse = t.allowRecurse = o
    }

    function In(e, t, o = !1) {
        const n = e.children,
            r = t.children;
        if (qe(n) && qe(r))
            for (let i = 0; i < n.length; i++) {
                const a = n[i];
                let s = r[i];
                s.shapeFlag & 1 && !s.dynamicChildren && ((s.patchFlag <= 0 || s.patchFlag === 32) && (s = r[i] = vo(r[i]), s.el = a.el), o || In(a, s)), s.type === Dn && (s.el = a.el), {}.NODE_ENV !== "production" && s.type === ft && !s.el && (s.el = a.el)
            }
    }

    function $d(e) {
        const t = e.slice(),
            o = [0];
        let n, r, i, a, s;
        const c = e.length;
        for (n = 0; n < c; n++) {
            const l = e[n];
            if (l !== 0) {
                if (r = o[o.length - 1], e[r] < l) {
                    t[n] = r, o.push(n);
                    continue
                }
                for (i = 0, a = o.length - 1; i < a;) s = i + a >> 1, e[o[s]] < l ? i = s + 1 : a = s;
                l < e[o[i]] && (i > 0 && (t[n] = o[i - 1]), o[i] = n)
            }
        }
        for (i = o.length, a = o[i - 1]; i-- > 0;) o[i] = a, a = t[a];
        return o
    }
    const Rd = e => e.__isTeleport,
        tn = e => e && (e.disabled || e.disabled === ""),
        Xs = e => typeof SVGElement < "u" && e instanceof SVGElement,
        Bi = (e, t) => {
            const o = e && e.to;
            if (Xe(o))
                if (t) {
                    const n = t(o);
                    return n || {}.NODE_ENV !== "production" && le(`Failed to locate Teleport target with selector "${o}". Note the target element must exist before the component is mounted - i.e. the target cannot be rendered by the component itself, and ideally should be outside of the entire Vue component tree.`), n
                } else return {}.NODE_ENV !== "production" && le("Current renderer does not support string target for Teleports. (missing querySelector renderer option)"), null;
            else return {}.NODE_ENV !== "production" && !o && !tn(e) && le(`Invalid Teleport target: ${o}`), o
        },
        Fd = {
            __isTeleport: !0,
            process(e, t, o, n, r, i, a, s, c, l) {
                const {
                    mc: f,
                    pc: u,
                    pbc: d,
                    o: {
                        insert: _,
                        querySelector: g,
                        createText: h,
                        createComment: O
                    }
                } = l, b = tn(t.props);
                let {
                    shapeFlag: C,
                    children: E,
                    dynamicChildren: x
                } = t;
                if ({}.NODE_ENV !== "production" && go && (c = !1, x = null), e == null) {
                    const N = t.el = {}.NODE_ENV !== "production" ? O("teleport start") : h(""),
                        w = t.anchor = {}.NODE_ENV !== "production" ? O("teleport end") : h("");
                    _(N, o, n), _(w, o, n);
                    const D = t.target = Bi(t.props, g),
                        P = t.targetAnchor = h("");
                    D ? (_(P, D), a = a || Xs(D)) : {}.NODE_ENV !== "production" && !b && le("Invalid Teleport target on mount:", D, `(${typeof D})`);
                    const I = ($, oe) => {
                        C & 16 && f(E, $, oe, r, i, a, s, c)
                    };
                    b ? I(o, w) : D && I(D, P)
                } else {
                    t.el = e.el;
                    const N = t.anchor = e.anchor,
                        w = t.target = e.target,
                        D = t.targetAnchor = e.targetAnchor,
                        P = tn(e.props),
                        I = P ? o : w,
                        $ = P ? N : D;
                    if (a = a || Xs(w), x ? (d(e.dynamicChildren, x, I, r, i, a, s), In(e, t, !0)) : c || u(e, t, I, $, r, i, a, s, !1), b) P || Or(t, o, N, l, 1);
                    else if ((t.props && t.props.to) !== (e.props && e.props.to)) {
                        const oe = t.target = Bi(t.props, g);
                        oe ? Or(t, oe, null, l, 0) : {}.NODE_ENV !== "production" && le("Invalid Teleport target on update:", w, `(${typeof w})`)
                    } else P && Or(t, w, D, l, 1)
                }
                el(t)
            },
            remove(e, t, o, n, {
                um: r,
                o: {
                    remove: i
                }
            }, a) {
                const {
                    shapeFlag: s,
                    children: c,
                    anchor: l,
                    targetAnchor: f,
                    target: u,
                    props: d
                } = e;
                if (u && i(f), (a || !tn(d)) && (i(l), s & 16))
                    for (let _ = 0; _ < c.length; _++) {
                        const g = c[_];
                        r(g, t, o, !0, !!g.dynamicChildren)
                    }
            },
            move: Or,
            hydrate: Vd
        };

    function Or(e, t, o, {
        o: {
            insert: n
        },
        m: r
    }, i = 2) {
        i === 0 && n(e.targetAnchor, t, o);
        const {
            el: a,
            anchor: s,
            shapeFlag: c,
            children: l,
            props: f
        } = e, u = i === 2;
        if (u && n(a, t, o), (!u || tn(f)) && c & 16)
            for (let d = 0; d < l.length; d++) r(l[d], t, o, 2);
        u && n(s, t, o)
    }

    function Vd(e, t, o, n, r, i, {
        o: {
            nextSibling: a,
            parentNode: s,
            querySelector: c
        }
    }, l) {
        const f = t.target = Bi(t.props, c);
        if (f) {
            const u = f._lpa || f.firstChild;
            if (t.shapeFlag & 16)
                if (tn(t.props)) t.anchor = l(a(e), t, s(e), o, n, r, i), t.targetAnchor = u;
                else {
                    t.anchor = a(e);
                    let d = u;
                    for (; d;)
                        if (d = a(d), d && d.nodeType === 8 && d.data === "teleport anchor") {
                            t.targetAnchor = d, f._lpa = t.targetAnchor && a(t.targetAnchor);
                            break
                        }
                    l(u, t, f, o, n, r, i)
                }
            el(t)
        }
        return t.anchor && a(t.anchor)
    }
    const Ld = Fd;

    function el(e) {
        const t = e.ctx;
        if (t && t.ut) {
            let o = e.children[0].el;
            for (; o !== e.targetAnchor;) o.nodeType === 1 && o.setAttribute("data-v-owner", t.uid), o = o.nextSibling;
            t.ut()
        }
    }
    const Be = Symbol.for("v-fgt"),
        Dn = Symbol.for("v-txt"),
        ft = Symbol.for("v-cmt"),
        Sn = Symbol.for("v-stc"),
        $n = [];
    let Ht = null;

    function H(e = !1) {
        $n.push(Ht = e ? null : [])
    }

    function Gd() {
        $n.pop(), Ht = $n[$n.length - 1] || null
    }
    let Rn = 1;

    function tl(e) {
        Rn += e
    }

    function ol(e) {
        return e.dynamicChildren = Rn > 0 ? Ht || Qo : null, Gd(), Rn > 0 && Ht && Ht.push(e), e
    }

    function ne(e, t, o, n, r, i) {
        return ol(v(e, t, o, n, r, i, !0))
    }

    function Se(e, t, o, n, r) {
        return ol(pe(e, t, o, n, r, !0))
    }

    function on(e) {
        return e ? e.__v_isVNode === !0 : !1
    }

    function Bo(e, t) {
        return {}.NODE_ENV !== "production" && t.shapeFlag & 6 && en.has(t.type) ? (e.shapeFlag &= -257, t.shapeFlag &= -513, !1) : e.type === t.type && e.key === t.key
    }
    const Md = (...e) => rl(...e),
        Nr = "__vInternal",
        nl = ({
            key: e
        }) => e ? ? null,
        Pr = ({
            ref: e,
            ref_key: t,
            ref_for: o
        }) => (typeof e == "number" && (e = "" + e), e != null ? Xe(e) || at(e) || Ne(e) ? {
            i: st,
            r: e,
            k: t,
            f: !!o
        } : e : null);

    function v(e, t = null, o = null, n = 0, r = null, i = e === Be ? 0 : 1, a = !1, s = !1) {
        const c = {
            __v_isVNode: !0,
            __v_skip: !0,
            type: e,
            props: t,
            key: t && nl(t),
            ref: t && Pr(t),
            scopeId: hr,
            slotScopeIds: null,
            children: o,
            component: null,
            suspense: null,
            ssContent: null,
            ssFallback: null,
            dirs: null,
            transition: null,
            el: null,
            anchor: null,
            target: null,
            targetAnchor: null,
            staticCount: 0,
            shapeFlag: i,
            patchFlag: n,
            dynamicProps: r,
            dynamicChildren: null,
            appContext: null,
            ctx: st
        };
        return s ? (Ui(c, o), i & 128 && e.normalize(c)) : o && (c.shapeFlag |= Xe(o) ? 8 : 16), {}.NODE_ENV !== "production" && c.key !== c.key && le("VNode created with invalid key (NaN). VNode type:", c.type), Rn > 0 && !a && Ht && (c.patchFlag > 0 || i & 6) && c.patchFlag !== 32 && Ht.push(c), c
    }
    const pe = {}.NODE_ENV !== "production" ? Md : rl;

    function rl(e, t = null, o = null, n = 0, r = null, i = !1) {
        if ((!e || e === Is) && ({}.NODE_ENV !== "production" && !e && le(`Invalid vnode type when creating vnode: ${e}.`), e = ft), on(e)) {
            const s = Xt(e, t, !0);
            return o && Ui(s, o), Rn > 0 && !i && Ht && (s.shapeFlag & 6 ? Ht[Ht.indexOf(e)] = s : Ht.push(s)), s.patchFlag |= -2, s
        }
        if (pl(e) && (e = e.__vccOpts), t) {
            t = Bd(t);
            let {
                class: s,
                style: c
            } = t;
            s && !Xe(s) && (t.class = Le(s)), je(c) && (gi(c) && !qe(c) && (c = Ze({}, c)), t.style = mt(c))
        }
        const a = Xe(e) ? 1 : Qu(e) ? 128 : Rd(e) ? 64 : je(e) ? 4 : Ne(e) ? 2 : 0;
        return {}.NODE_ENV !== "production" && a & 4 && gi(e) && (e = Ie(e), le("Vue received a Component which was made a reactive object. This can lead to unnecessary performance overhead, and should be avoided by marking the component with `markRaw` or using `shallowRef` instead of `ref`.", `
Component that was made reactive: `, e)), v(e, t, o, n, r, a, i, !0)
    }

    function Bd(e) {
        return e ? gi(e) || Nr in e ? Ze({}, e) : e : null
    }

    function Xt(e, t, o = !1) {
        const {
            props: n,
            ref: r,
            patchFlag: i,
            children: a
        } = e, s = t ? jd(n || {}, t) : n;
        return {
            __v_isVNode: !0,
            __v_skip: !0,
            type: e.type,
            props: s,
            key: s && nl(s),
            ref: t && t.ref ? o && r ? qe(r) ? r.concat(Pr(t)) : [r, Pr(t)] : Pr(t) : r,
            scopeId: e.scopeId,
            slotScopeIds: e.slotScopeIds,
            children: {}.NODE_ENV !== "production" && i === -1 && qe(a) ? a.map(il) : a,
            target: e.target,
            targetAnchor: e.targetAnchor,
            staticCount: e.staticCount,
            shapeFlag: e.shapeFlag,
            patchFlag: t && e.type !== Be ? i === -1 ? 16 : i | 16 : i,
            dynamicProps: e.dynamicProps,
            dynamicChildren: e.dynamicChildren,
            appContext: e.appContext,
            dirs: e.dirs,
            transition: e.transition,
            component: e.component,
            suspense: e.suspense,
            ssContent: e.ssContent && Xt(e.ssContent),
            ssFallback: e.ssFallback && Xt(e.ssFallback),
            el: e.el,
            anchor: e.anchor,
            ctx: e.ctx,
            ce: e.ce
        }
    }

    function il(e) {
        const t = Xt(e);
        return qe(e.children) && (t.children = e.children.map(il)), t
    }

    function al(e = " ", t = 0) {
        return pe(Dn, null, e, t)
    }

    function Ud(e, t) {
        const o = pe(Sn, null, e);
        return o.staticCount = t, o
    }

    function ve(e = "", t = !1) {
        return t ? (H(), Se(ft, null, e)) : pe(ft, null, e)
    }

    function Kt(e) {
        return e == null || typeof e == "boolean" ? pe(ft) : qe(e) ? pe(Be, null, e.slice()) : typeof e == "object" ? vo(e) : pe(Dn, null, String(e))
    }

    function vo(e) {
        return e.el === null && e.patchFlag !== -1 || e.memo ? e : Xt(e)
    }

    function Ui(e, t) {
        let o = 0;
        const {
            shapeFlag: n
        } = e;
        if (t == null) t = null;
        else if (qe(t)) o = 16;
        else if (typeof t == "object")
            if (n & 65) {
                const r = t.default;
                r && (r._c && (r._d = !1), Ui(e, r()), r._c && (r._d = !0));
                return
            } else {
                o = 32;
                const r = t._;
                !r && !(Nr in t) ? t._ctx = st : r === 3 && st && (st.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024))
            }
        else Ne(t) ? (t = {
            default: t,
            _ctx: st
        }, o = 32) : (t = String(t), n & 64 ? (o = 16, t = [al(t)]) : o = 8);
        e.children = t, e.shapeFlag |= o
    }

    function jd(...e) {
        const t = {};
        for (let o = 0; o < e.length; o++) {
            const n = e[o];
            for (const r in n)
                if (r === "class") t.class !== n.class && (t.class = Le([t.class, n.class]));
                else if (r === "style") t.style = mt([t.style, n.style]);
            else if (pn(r)) {
                const i = t[r],
                    a = n[r];
                a && i !== a && !(qe(i) && i.includes(a)) && (t[r] = i ? [].concat(i, a) : a)
            } else r !== "" && (t[r] = n[r])
        }
        return t
    }

    function eo(e, t, o, n = null) {
        Dt(e, t, 7, [o, n])
    }
    const zd = Ms();
    let Hd = 0;

    function Kd(e, t, o) {
        const n = e.type,
            r = (t ? t.appContext : e.appContext) || zd,
            i = {
                uid: Hd++,
                vnode: e,
                type: n,
                parent: t,
                appContext: r,
                root: null,
                next: null,
                subTree: null,
                effect: null,
                update: null,
                scope: new Gc(!0),
                render: null,
                proxy: null,
                exposed: null,
                exposeProxy: null,
                withProxy: null,
                provides: t ? t.provides : Object.create(r.provides),
                accessCache: null,
                renderCache: [],
                components: null,
                directives: null,
                propsOptions: Us(n, r),
                emitsOptions: ms(n, r),
                emit: null,
                emitted: null,
                propsDefaults: Qe,
                inheritAttrs: n.inheritAttrs,
                ctx: Qe,
                data: Qe,
                props: Qe,
                attrs: Qe,
                slots: Qe,
                refs: Qe,
                setupState: Qe,
                setupContext: null,
                attrsProxy: null,
                slotsProxy: null,
                suspense: o,
                suspenseId: o ? o.pendingId : 0,
                asyncDep: null,
                asyncResolved: !1,
                isMounted: !1,
                isUnmounted: !1,
                isDeactivated: !1,
                bc: null,
                c: null,
                bm: null,
                m: null,
                bu: null,
                u: null,
                um: null,
                bum: null,
                da: null,
                a: null,
                rtg: null,
                rtc: null,
                ec: null,
                sp: null
            };
        return {}.NODE_ENV !== "production" ? i.ctx = cd(i) : i.ctx = {
            _: i
        }, i.root = t ? t.root : i, i.emit = ju.bind(null, i), e.ce && e.ce(i), i
    }
    let lt = null;
    const ji = () => lt || st;
    let zi, nn, sl = "__VUE_INSTANCE_SETTERS__";
    (nn = er()[sl]) || (nn = er()[sl] = []), nn.push(e => lt = e), zi = e => {
        nn.length > 1 ? nn.forEach(t => t(e)) : nn[0](e)
    };
    const rn = e => {
            zi(e), e.scope.on()
        },
        Uo = () => {
            lt && lt.scope.off(), zi(null)
        },
        Yd = uo("slot,component");

    function Hi(e, t) {
        const o = t.isNativeTag || Ca;
        (Yd(e) || o(e)) && le("Do not use built-in or reserved HTML elements as component id: " + e)
    }

    function ll(e) {
        return e.vnode.shapeFlag & 4
    }
    let Fn = !1;

    function Wd(e, t = !1) {
        Fn = t;
        const {
            props: o,
            children: n
        } = e.vnode, r = ll(e);
        yd(e, o, r, t), Pd(e, n);
        const i = r ? Qd(e, t) : void 0;
        return Fn = !1, i
    }

    function Qd(e, t) {
        var o;
        const n = e.type;
        if ({}.NODE_ENV !== "production") {
            if (n.name && Hi(n.name, e.appContext.config), n.components) {
                const i = Object.keys(n.components);
                for (let a = 0; a < i.length; a++) Hi(i[a], e.appContext.config)
            }
            if (n.directives) {
                const i = Object.keys(n.directives);
                for (let a = 0; a < i.length; a++) ws(i[a])
            }
            n.compilerOptions && Zd() && le('"compilerOptions" is only supported when using a build of Vue that includes the runtime compiler. Since you are using a runtime-only build, the options should be passed via your build tool config instead.')
        }
        e.accessCache = Object.create(null), e.proxy = Xa(new Proxy(e.ctx, $s)), {}.NODE_ENV !== "production" && ud(e);
        const {
            setup: r
        } = n;
        if (r) {
            const i = e.setupContext = r.length > 1 ? fl(e) : null;
            rn(e), Do();
            const a = no(r, e, 0, [{}.NODE_ENV !== "production" ? vn(e.props) : e.props, i]);
            if (So(), Uo(), ai(a)) {
                if (a.then(Uo, Uo), t) return a.then(s => {
                    cl(e, s, t)
                }).catch(s => {
                    _r(s, e, 0)
                });
                if (e.asyncDep = a, {}.NODE_ENV !== "production" && !e.suspense) {
                    const s = (o = n.name) != null ? o : "Anonymous";
                    le(`Component <${s}>: setup function returned a promise, but no <Suspense> boundary was found in the parent component tree. A component with async setup() must be nested in a <Suspense> in order to be rendered.`)
                }
            } else cl(e, a, t)
        } else ul(e, t)
    }

    function cl(e, t, o) {
        Ne(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : je(t) ? ({}.NODE_ENV !== "production" && on(t) && le("setup() should not return VNodes directly - return a render function instead."), {}.NODE_ENV !== "production" && (e.devtoolsRawSetupState = t), e.setupState = os(t), {}.NODE_ENV !== "production" && dd(e)) : {}.NODE_ENV !== "production" && t !== void 0 && le(`setup() should return an object. Received: ${t===null?"null":typeof t}`), ul(e, o)
    }
    let Ki;
    const Zd = () => !Ki;

    function ul(e, t, o) {
        const n = e.type;
        if (!e.render) {
            if (!t && Ki && !n.render) {
                const r = n.template || Ri(e).template;
                if (r) {
                    ({}).NODE_ENV !== "production" && ao(e, "compile");
                    const {
                        isCustomElement: i,
                        compilerOptions: a
                    } = e.appContext.config, {
                        delimiters: s,
                        compilerOptions: c
                    } = n, l = Ze(Ze({
                        isCustomElement: i,
                        delimiters: s
                    }, a), c);
                    n.render = Ki(r, l), {}.NODE_ENV !== "production" && so(e, "compile")
                }
            }
            e.render = n.render || _t
        }
        rn(e), Do(), bd(e), So(), Uo(), {}.NODE_ENV !== "production" && !n.render && e.render === _t && !t && (n.template ? le('Component provided template option but runtime compilation is not supported in this build of Vue. Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".') : le("Component is missing template or render function."))
    }

    function dl(e) {
        return e.attrsProxy || (e.attrsProxy = new Proxy(e.attrs, {}.NODE_ENV !== "production" ? {
            get(t, o) {
                return kr(), gt(e, "get", "$attrs"), t[o]
            },
            set() {
                return le("setupContext.attrs is readonly."), !1
            },
            deleteProperty() {
                return le("setupContext.attrs is readonly."), !1
            }
        } : {
            get(t, o) {
                return gt(e, "get", "$attrs"), t[o]
            }
        }))
    }

    function Jd(e) {
        return e.slotsProxy || (e.slotsProxy = new Proxy(e.slots, {
            get(t, o) {
                return gt(e, "get", "$slots"), t[o]
            }
        }))
    }

    function fl(e) {
        const t = o => {
            if ({}.NODE_ENV !== "production" && (e.exposed && le("expose() should be called only once per setup()."), o != null)) {
                let n = typeof o;
                n === "object" && (qe(o) ? n = "array" : at(o) && (n = "ref")), n !== "object" && le(`expose() should be passed a plain object, received ${n}.`)
            }
            e.exposed = o || {}
        };
        return {}.NODE_ENV !== "production" ? Object.freeze({
            get attrs() {
                return dl(e)
            },
            get slots() {
                return Jd(e)
            },
            get emit() {
                return (o, ...n) => e.emit(o, ...n)
            },
            expose: t
        }) : {
            get attrs() {
                return dl(e)
            },
            slots: e.slots,
            emit: e.emit,
            expose: t
        }
    }

    function Ar(e) {
        if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy(os(Xa(e.exposed)), {
            get(t, o) {
                if (o in t) return t[o];
                if (o in Go) return Go[o](e)
            },
            has(t, o) {
                return o in t || o in Go
            }
        }))
    }
    const Xd = /(?:^|[-_])(\w)/g,
        ef = e => e.replace(Xd, t => t.toUpperCase()).replace(/[-_]/g, "");

    function Yi(e, t = !0) {
        return Ne(e) ? e.displayName || e.name : e.name || t && e.__name
    }

    function Ir(e, t, o = !1) {
        let n = Yi(t);
        if (!n && t.__file) {
            const r = t.__file.match(/([^/\\]+)\.\w+$/);
            r && (n = r[1])
        }
        if (!n && e && e.parent) {
            const r = i => {
                for (const a in i)
                    if (i[a] === t) return a
            };
            n = r(e.components || e.parent.type.components) || r(e.appContext.components)
        }
        return n ? ef(n) : o ? "App" : "Anonymous"
    }

    function pl(e) {
        return Ne(e) && "__vccOpts" in e
    }
    const q = (e, t) => yu(e, t, Fn);

    function bl(e, t, o) {
        const n = arguments.length;
        return n === 2 ? je(t) && !qe(t) ? on(t) ? pe(e, null, [t]) : pe(e, t) : pe(e, null, t) : (n > 3 ? o = Array.prototype.slice.call(arguments, 2) : n === 3 && on(o) && (o = [o]), pe(e, t, o))
    }
    const tf = Symbol.for("v-scx"),
        of = () => {
            {
                const e = rt(tf);
                return e || {}.NODE_ENV !== "production" && le("Server rendering context not provided. Make sure to only call useSSRContext() conditionally in the server build."), e
            }
        };

    function Wi(e) {
        return !!(e && e.__v_isShallow)
    }

    function nf() {
        if ({}.NODE_ENV === "production" || typeof window > "u") return;
        const e = {
                style: "color:#3ba776"
            },
            t = {
                style: "color:#0b1bc9"
            },
            o = {
                style: "color:#b62e24"
            },
            n = {
                style: "color:#9d288c"
            },
            r = {
                header(u) {
                    return je(u) ? u.__isVue ? ["div", e, "VueInstance"] : at(u) ? ["div", {},
                        ["span", e, f(u)], "<", s(u.value), ">"
                    ] : $o(u) ? ["div", {},
                        ["span", e, Wi(u) ? "ShallowReactive" : "Reactive"], "<", s(u), `>${_o(u)?" (readonly)":""}`
                    ] : _o(u) ? ["div", {},
                        ["span", e, Wi(u) ? "ShallowReadonly" : "Readonly"], "<", s(u), ">"
                    ] : null : null
                },
                hasBody(u) {
                    return u && u.__isVue
                },
                body(u) {
                    if (u && u.__isVue) return ["div", {}, ...i(u.$)]
                }
            };

        function i(u) {
            const d = [];
            u.type.props && u.props && d.push(a("props", Ie(u.props))), u.setupState !== Qe && d.push(a("setup", u.setupState)), u.data !== Qe && d.push(a("data", Ie(u.data)));
            const _ = c(u, "computed");
            _ && d.push(a("computed", _));
            const g = c(u, "inject");
            return g && d.push(a("injected", g)), d.push(["div", {},
                ["span", {
                    style: n.style + ";opacity:0.66"
                }, "$ (internal): "],
                ["object", {
                    object: u
                }]
            ]), d
        }

        function a(u, d) {
            return d = Ze({}, d), Object.keys(d).length ? ["div", {
                    style: "line-height:1.25em;margin-bottom:0.6em"
                },
                ["div", {
                    style: "color:#476582"
                }, u],
                ["div", {
                    style: "padding-left:1.25em"
                }, ...Object.keys(d).map(_ => ["div", {},
                    ["span", n, _ + ": "], s(d[_], !1)
                ])]
            ] : ["span", {}]
        }

        function s(u, d = !0) {
            return typeof u == "number" ? ["span", t, u] : typeof u == "string" ? ["span", o, JSON.stringify(u)] : typeof u == "boolean" ? ["span", n, u] : je(u) ? ["object", {
                object: d ? Ie(u) : u
            }] : ["span", o, String(u)]
        }

        function c(u, d) {
            const _ = u.type;
            if (Ne(_)) return;
            const g = {};
            for (const h in u.ctx) l(_, h, d) && (g[h] = u.ctx[h]);
            return g
        }

        function l(u, d, _) {
            const g = u[_];
            if (qe(g) && g.includes(d) || je(g) && d in g || u.extends && l(u.extends, d, _) || u.mixins && u.mixins.some(h => l(h, d, _))) return !0
        }

        function f(u) {
            return Wi(u) ? "ShallowRef" : u.effect ? "ComputedRef" : "Ref"
        }
        window.devtoolsFormatters ? window.devtoolsFormatters.push(r) : window.devtoolsFormatters = [r]
    }
    const _l = "3.3.4",
        rf = "http://www.w3.org/2000/svg",
        jo = typeof document < "u" ? document : null,
        ml = jo && jo.createElement("template"),
        af = {
            insert: (e, t, o) => {
                t.insertBefore(e, o || null)
            },
            remove: e => {
                const t = e.parentNode;
                t && t.removeChild(e)
            },
            createElement: (e, t, o, n) => {
                const r = t ? jo.createElementNS(rf, e) : jo.createElement(e, o ? {
                    is: o
                } : void 0);
                return e === "select" && n && n.multiple != null && r.setAttribute("multiple", n.multiple), r
            },
            createText: e => jo.createTextNode(e),
            createComment: e => jo.createComment(e),
            setText: (e, t) => {
                e.nodeValue = t
            },
            setElementText: (e, t) => {
                e.textContent = t
            },
            parentNode: e => e.parentNode,
            nextSibling: e => e.nextSibling,
            querySelector: e => jo.querySelector(e),
            setScopeId(e, t) {
                e.setAttribute(t, "")
            },
            insertStaticContent(e, t, o, n, r, i) {
                const a = o ? o.previousSibling : t.lastChild;
                if (r && (r === i || r.nextSibling))
                    for (; t.insertBefore(r.cloneNode(!0), o), !(r === i || !(r = r.nextSibling)););
                else {
                    ml.innerHTML = n ? `<svg>${e}</svg>` : e;
                    const s = ml.content;
                    if (n) {
                        const c = s.firstChild;
                        for (; c.firstChild;) s.appendChild(c.firstChild);
                        s.removeChild(c)
                    }
                    t.insertBefore(s, o)
                }
                return [a ? a.nextSibling : t.firstChild, o ? o.previousSibling : t.lastChild]
            }
        };

    function sf(e, t, o) {
        const n = e._vtc;
        n && (t = (t ? [t, ...n] : [...n]).join(" ")), t == null ? e.removeAttribute("class") : o ? e.setAttribute("class", t) : e.className = t
    }

    function lf(e, t, o) {
        const n = e.style,
            r = Xe(o);
        if (o && !r) {
            if (t && !Xe(t))
                for (const i in t) o[i] == null && Qi(n, i, "");
            for (const i in o) Qi(n, i, o[i])
        } else {
            const i = n.display;
            r ? t !== o && (n.cssText = o) : t && e.removeAttribute("style"), "_vod" in e && (n.display = i)
        }
    }
    const cf = /[^\\];\s*$/,
        gl = /\s*!important$/;

    function Qi(e, t, o) {
        if (qe(o)) o.forEach(n => Qi(e, t, n));
        else if (o == null && (o = ""), {}.NODE_ENV !== "production" && cf.test(o) && le(`Unexpected semicolon at the end of '${t}' style value: '${o}'`), t.startsWith("--")) e.setProperty(t, o);
        else {
            const n = uf(e, t);
            gl.test(o) ? e.setProperty(At(n), o.replace(gl, ""), "important") : e[n] = o
        }
    }
    const hl = ["Webkit", "Moz", "ms"],
        Zi = {};

    function uf(e, t) {
        const o = Zi[t];
        if (o) return o;
        let n = Pt(t);
        if (n !== "filter" && n in e) return Zi[t] = n;
        n = Po(n);
        for (let r = 0; r < hl.length; r++) {
            const i = hl[r] + n;
            if (i in e) return Zi[t] = i
        }
        return t
    }
    const vl = "http://www.w3.org/1999/xlink";

    function df(e, t, o, n, r) {
        if (n && t.startsWith("xlink:")) o == null ? e.removeAttributeNS(vl, t.slice(6, t.length)) : e.setAttributeNS(vl, t, o);
        else {
            const i = Fc(t);
            o == null || i && !Aa(o) ? e.removeAttribute(t) : e.setAttribute(t, i ? "" : o)
        }
    }

    function ff(e, t, o, n, r, i, a) {
        if (t === "innerHTML" || t === "textContent") {
            n && a(n, r, i), e[t] = o ? ? "";
            return
        }
        const s = e.tagName;
        if (t === "value" && s !== "PROGRESS" && !s.includes("-")) {
            e._value = o;
            const l = s === "OPTION" ? e.getAttribute("value") : e.value,
                f = o ? ? "";
            l !== f && (e.value = f), o == null && e.removeAttribute(t);
            return
        }
        let c = !1;
        if (o === "" || o == null) {
            const l = typeof e[t];
            l === "boolean" ? o = Aa(o) : o == null && l === "string" ? (o = "", c = !0) : l === "number" && (o = 0, c = !0)
        }
        try {
            e[t] = o
        } catch (l) {
            ({}).NODE_ENV !== "production" && !c && le(`Failed setting prop "${t}" on <${s.toLowerCase()}>: value ${o} is invalid.`, l)
        }
        c && e.removeAttribute(t)
    }

    function zo(e, t, o, n) {
        e.addEventListener(t, o, n)
    }

    function pf(e, t, o, n) {
        e.removeEventListener(t, o, n)
    }

    function bf(e, t, o, n, r = null) {
        const i = e._vei || (e._vei = {}),
            a = i[t];
        if (n && a) a.value = n;
        else {
            const [s, c] = _f(t);
            if (n) {
                const l = i[t] = hf(n, r);
                zo(e, s, l, c)
            } else a && (pf(e, s, a, c), i[t] = void 0)
        }
    }
    const kl = /(?:Once|Passive|Capture)$/;

    function _f(e) {
        let t;
        if (kl.test(e)) {
            t = {};
            let n;
            for (; n = e.match(kl);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
        }
        return [e[2] === ":" ? e.slice(3) : At(e.slice(2)), t]
    }
    let Ji = 0;
    const mf = Promise.resolve(),
        gf = () => Ji || (mf.then(() => Ji = 0), Ji = Date.now());

    function hf(e, t) {
        const o = n => {
            if (!n._vts) n._vts = Date.now();
            else if (n._vts <= o.attached) return;
            Dt(vf(n, o.value), t, 5, [n])
        };
        return o.value = e, o.attached = gf(), o
    }

    function vf(e, t) {
        if (qe(t)) {
            const o = e.stopImmediatePropagation;
            return e.stopImmediatePropagation = () => {
                o.call(e), e._stopped = !0
            }, t.map(n => r => !r._stopped && n && n(r))
        } else return t
    }
    const yl = /^on[a-z]/,
        kf = (e, t, o, n, r = !1, i, a, s, c) => {
            t === "class" ? sf(e, n, r) : t === "style" ? lf(e, o, n) : pn(t) ? Yn(t) || bf(e, t, o, n, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : yf(e, t, n, r)) ? ff(e, t, n, i, a, s, c) : (t === "true-value" ? e._trueValue = n : t === "false-value" && (e._falseValue = n), df(e, t, n, r))
        };

    function yf(e, t, o, n) {
        return n ? !!(t === "innerHTML" || t === "textContent" || t in e && yl.test(t) && Ne(o)) : t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA" || yl.test(t) && Xe(o) ? !1 : t in e
    }

    function Dr(e, t) {
        const o = Fe(e);
        class n extends Xi {
            constructor(i) {
                super(o, i, t)
            }
        }
        return n.def = o, n
    }
    const qf = typeof HTMLElement < "u" ? HTMLElement : class {};
    class Xi extends qf {
        constructor(t, o = {}, n) {
            super(), this._def = t, this._props = o, this._instance = null, this._connected = !1, this._resolved = !1, this._numberProps = null, this.shadowRoot && n ? n(this._createVNode(), this.shadowRoot) : ({}.NODE_ENV !== "production" && this.shadowRoot && le("Custom element has pre-rendered declarative shadow root but is not defined as hydratable. Use `defineSSRCustomElement`."), this.attachShadow({
                mode: "open"
            }), this._def.__asyncLoader || this._resolveProps(this._def))
        }
        connectedCallback() {
            this._connected = !0, this._instance || (this._resolved ? this._update() : this._resolveDef())
        }
        disconnectedCallback() {
            this._connected = !1, is(() => {
                this._connected || (Ll(null, this.shadowRoot), this._instance = null)
            })
        }
        _resolveDef() {
            this._resolved = !0;
            for (let n = 0; n < this.attributes.length; n++) this._setAttr(this.attributes[n].name);
            new MutationObserver(n => {
                for (const r of n) this._setAttr(r.attributeName)
            }).observe(this, {
                attributes: !0
            });
            const t = (n, r = !1) => {
                    const {
                        props: i,
                        styles: a
                    } = n;
                    let s;
                    if (i && !qe(i))
                        for (const c in i) {
                            const l = i[c];
                            (l === Number || l && l.type === Number) && (c in this._props && (this._props[c] = ci(this._props[c])), (s || (s = Object.create(null)))[Pt(c)] = !0)
                        }
                    this._numberProps = s, r && this._resolveProps(n), this._applyStyles(a), this._update()
                },
                o = this._def.__asyncLoader;
            o ? o().then(n => t(n, !0)) : t(this._def)
        }
        _resolveProps(t) {
            const {
                props: o
            } = t, n = qe(o) ? o : Object.keys(o || {});
            for (const r of Object.keys(this)) r[0] !== "_" && n.includes(r) && this._setProp(r, this[r], !0, !1);
            for (const r of n.map(Pt)) Object.defineProperty(this, r, {
                get() {
                    return this._getProp(r)
                },
                set(i) {
                    this._setProp(r, i)
                }
            })
        }
        _setAttr(t) {
            let o = this.getAttribute(t);
            const n = Pt(t);
            this._numberProps && this._numberProps[n] && (o = ci(o)), this._setProp(n, o, !1)
        }
        _getProp(t) {
            return this._props[t]
        }
        _setProp(t, o, n = !0, r = !0) {
            o !== this._props[t] && (this._props[t] = o, r && this._instance && this._update(), n && (o === !0 ? this.setAttribute(At(t), "") : typeof o == "string" || typeof o == "number" ? this.setAttribute(At(t), o + "") : o || this.removeAttribute(At(t))))
        }
        _update() {
            Ll(this._createVNode(), this.shadowRoot)
        }
        _createVNode() {
            const t = pe(this._def, Ze({}, this._props));
            return this._instance || (t.ce = o => {
                this._instance = o, o.isCE = !0, {}.NODE_ENV !== "production" && (o.ceReload = i => {
                    this._styles && (this._styles.forEach(a => this.shadowRoot.removeChild(a)), this._styles.length = 0), this._applyStyles(i), this._instance = null, this._update()
                });
                const n = (i, a) => {
                    this.dispatchEvent(new CustomEvent(i, {
                        detail: a
                    }))
                };
                o.emit = (i, ...a) => {
                    n(i, a), At(i) !== i && n(At(i), a)
                };
                let r = this;
                for (; r = r && (r.parentNode || r.host);)
                    if (r instanceof Xi) {
                        o.parent = r._instance, o.provides = r._instance.provides;
                        break
                    }
            }), t
        }
        _applyStyles(t) {
            t && t.forEach(o => {
                const n = document.createElement("style");
                n.textContent = o, this.shadowRoot.appendChild(n), {}.NODE_ENV !== "production" && (this._styles || (this._styles = [])).push(n)
            })
        }
    }
    const ko = "transition",
        Vn = "animation",
        lo = (e, {
            slots: t
        }) => bl(Xu, wl(e), t);
    lo.displayName = "Transition";
    const ql = {
            name: String,
            type: String,
            css: {
                type: Boolean,
                default: !0
            },
            duration: [String, Number, Object],
            enterFromClass: String,
            enterActiveClass: String,
            enterToClass: String,
            appearFromClass: String,
            appearActiveClass: String,
            appearToClass: String,
            leaveFromClass: String,
            leaveActiveClass: String,
            leaveToClass: String
        },
        Ef = lo.props = Ze({}, Cs, ql),
        Ho = (e, t = []) => {
            qe(e) ? e.forEach(o => o(...t)) : e && e(...t)
        },
        El = e => e ? qe(e) ? e.some(t => t.length > 1) : e.length > 1 : !1;

    function wl(e) {
        const t = {};
        for (const A in e) A in ql || (t[A] = e[A]);
        if (e.css === !1) return t;
        const {
            name: o = "v",
            type: n,
            duration: r,
            enterFromClass: i = `${o}-enter-from`,
            enterActiveClass: a = `${o}-enter-active`,
            enterToClass: s = `${o}-enter-to`,
            appearFromClass: c = i,
            appearActiveClass: l = a,
            appearToClass: f = s,
            leaveFromClass: u = `${o}-leave-from`,
            leaveActiveClass: d = `${o}-leave-active`,
            leaveToClass: _ = `${o}-leave-to`
        } = e, g = wf(r), h = g && g[0], O = g && g[1], {
            onBeforeEnter: b,
            onEnter: C,
            onEnterCancelled: E,
            onLeave: x,
            onLeaveCancelled: N,
            onBeforeAppear: w = b,
            onAppear: D = C,
            onAppearCancelled: P = E
        } = t, I = (A, K, ae) => {
            yo(A, K ? f : s), yo(A, K ? l : a), ae && ae()
        }, $ = (A, K) => {
            A._isLeaving = !1, yo(A, u), yo(A, _), yo(A, d), K && K()
        }, oe = A => (K, ae) => {
            const B = A ? D : C,
                re = () => I(K, A, ae);
            Ho(B, [K, re]), xl(() => {
                yo(K, A ? c : i), co(K, A ? f : s), El(B) || Cl(K, n, h, re)
            })
        };
        return Ze(t, {
            onBeforeEnter(A) {
                Ho(b, [A]), co(A, i), co(A, a)
            },
            onBeforeAppear(A) {
                Ho(w, [A]), co(A, c), co(A, l)
            },
            onEnter: oe(!1),
            onAppear: oe(!0),
            onLeave(A, K) {
                A._isLeaving = !0;
                const ae = () => $(A, K);
                co(A, u), Pl(), co(A, d), xl(() => {
                    A._isLeaving && (yo(A, u), co(A, _), El(x) || Cl(A, n, O, ae))
                }), Ho(x, [A, ae])
            },
            onEnterCancelled(A) {
                I(A, !1), Ho(E, [A])
            },
            onAppearCancelled(A) {
                I(A, !0), Ho(P, [A])
            },
            onLeaveCancelled(A) {
                $(A), Ho(N, [A])
            }
        })
    }

    function wf(e) {
        if (e == null) return null;
        if (je(e)) return [ea(e.enter), ea(e.leave)]; {
            const t = ea(e);
            return [t, t]
        }
    }

    function ea(e) {
        const t = ci(e);
        return {}.NODE_ENV !== "production" && Cu(t, "<transition> explicit duration"), t
    }

    function co(e, t) {
        t.split(/\s+/).forEach(o => o && e.classList.add(o)), (e._vtc || (e._vtc = new Set)).add(t)
    }

    function yo(e, t) {
        t.split(/\s+/).forEach(n => n && e.classList.remove(n));
        const {
            _vtc: o
        } = e;
        o && (o.delete(t), o.size || (e._vtc = void 0))
    }

    function xl(e) {
        requestAnimationFrame(() => {
            requestAnimationFrame(e)
        })
    }
    let xf = 0;

    function Cl(e, t, o, n) {
        const r = e._endId = ++xf,
            i = () => {
                r === e._endId && n()
            };
        if (o) return setTimeout(i, o);
        const {
            type: a,
            timeout: s,
            propCount: c
        } = Tl(e, t);
        if (!a) return n();
        const l = a + "end";
        let f = 0;
        const u = () => {
                e.removeEventListener(l, d), i()
            },
            d = _ => {
                _.target === e && ++f >= c && u()
            };
        setTimeout(() => {
            f < c && u()
        }, s + 1), e.addEventListener(l, d)
    }

    function Tl(e, t) {
        const o = window.getComputedStyle(e),
            n = g => (o[g] || "").split(", "),
            r = n(`${ko}Delay`),
            i = n(`${ko}Duration`),
            a = Ol(r, i),
            s = n(`${Vn}Delay`),
            c = n(`${Vn}Duration`),
            l = Ol(s, c);
        let f = null,
            u = 0,
            d = 0;
        t === ko ? a > 0 && (f = ko, u = a, d = i.length) : t === Vn ? l > 0 && (f = Vn, u = l, d = c.length) : (u = Math.max(a, l), f = u > 0 ? a > l ? ko : Vn : null, d = f ? f === ko ? i.length : c.length : 0);
        const _ = f === ko && /\b(transform|all)(,|$)/.test(n(`${ko}Property`).toString());
        return {
            type: f,
            timeout: u,
            propCount: d,
            hasTransform: _
        }
    }

    function Ol(e, t) {
        for (; e.length < t.length;) e = e.concat(e);
        return Math.max(...t.map((o, n) => Nl(o) + Nl(e[n])))
    }

    function Nl(e) {
        return Number(e.slice(0, -1).replace(",", ".")) * 1e3
    }

    function Pl() {
        return document.body.offsetHeight
    }
    const Al = new WeakMap,
        Il = new WeakMap,
        Dl = {
            name: "TransitionGroup",
            props: Ze({}, Ef, {
                tag: String,
                moveClass: String
            }),
            setup(e, {
                slots: t
            }) {
                const o = ji(),
                    n = xs();
                let r, i;
                return Ps(() => {
                    if (!r.length) return;
                    const a = e.moveClass || `${e.name||"v"}-move`;
                    if (!Pf(r[0].el, o.vnode.el, a)) return;
                    r.forEach(Tf), r.forEach(Of);
                    const s = r.filter(Nf);
                    Pl(), s.forEach(c => {
                        const l = c.el,
                            f = l.style;
                        co(l, a), f.transform = f.webkitTransform = f.transitionDuration = "";
                        const u = l._moveCb = d => {
                            d && d.target !== l || (!d || /transform$/.test(d.propertyName)) && (l.removeEventListener("transitionend", u), l._moveCb = null, yo(l, a))
                        };
                        l.addEventListener("transitionend", u)
                    })
                }), () => {
                    const a = Ie(e),
                        s = wl(a);
                    let c = a.tag || Be;
                    r = i, i = t.default ? Ni(t.default()) : [];
                    for (let l = 0; l < i.length; l++) {
                        const f = i[l];
                        f.key != null ? Tn(f, Cn(f, s, n, o)) : {}.NODE_ENV !== "production" && le("<TransitionGroup> children must be keyed.")
                    }
                    if (r)
                        for (let l = 0; l < r.length; l++) {
                            const f = r[l];
                            Tn(f, Cn(f, s, n, o)), Al.set(f, f.el.getBoundingClientRect())
                        }
                    return pe(c, null, i)
                }
            }
        },
        Cf = e => delete e.mode;
    Dl.props;
    const an = Dl;

    function Tf(e) {
        const t = e.el;
        t._moveCb && t._moveCb(), t._enterCb && t._enterCb()
    }

    function Of(e) {
        Il.set(e, e.el.getBoundingClientRect())
    }

    function Nf(e) {
        const t = Al.get(e),
            o = Il.get(e),
            n = t.left - o.left,
            r = t.top - o.top;
        if (n || r) {
            const i = e.el.style;
            return i.transform = i.webkitTransform = `translate(${n}px,${r}px)`, i.transitionDuration = "0s", e
        }
    }

    function Pf(e, t, o) {
        const n = e.cloneNode();
        e._vtc && e._vtc.forEach(a => {
            a.split(/\s+/).forEach(s => s && n.classList.remove(s))
        }), o.split(/\s+/).forEach(a => a && n.classList.add(a)), n.style.display = "none";
        const r = t.nodeType === 1 ? t : t.parentNode;
        r.appendChild(n);
        const {
            hasTransform: i
        } = Tl(n);
        return r.removeChild(n), i
    }
    const Sr = e => {
        const t = e.props["onUpdate:modelValue"] || !1;
        return qe(t) ? o => Zo(t, o) : t
    };

    function Af(e) {
        e.target.composing = !0
    }

    function Sl(e) {
        const t = e.target;
        t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")))
    }
    const $l = {
            created(e, {
                modifiers: {
                    lazy: t,
                    trim: o,
                    number: n
                }
            }, r) {
                e._assign = Sr(r);
                const i = n || r.props && r.props.type === "number";
                zo(e, t ? "change" : "input", a => {
                    if (a.target.composing) return;
                    let s = e.value;
                    o && (s = s.trim()), i && (s = Xn(s)), e._assign(s)
                }), o && zo(e, "change", () => {
                    e.value = e.value.trim()
                }), t || (zo(e, "compositionstart", Af), zo(e, "compositionend", Sl), zo(e, "change", Sl))
            },
            mounted(e, {
                value: t
            }) {
                e.value = t ? ? ""
            },
            beforeUpdate(e, {
                value: t,
                modifiers: {
                    lazy: o,
                    trim: n,
                    number: r
                }
            }, i) {
                if (e._assign = Sr(i), e.composing || document.activeElement === e && e.type !== "range" && (o || n && e.value.trim() === t || (r || e.type === "number") && Xn(e.value) === t)) return;
                const a = t ? ? "";
                e.value !== a && (e.value = a)
            }
        },
        ta = {
            deep: !0,
            created(e, {
                value: t,
                modifiers: {
                    number: o
                }
            }, n) {
                const r = Wn(t);
                zo(e, "change", () => {
                    const i = Array.prototype.filter.call(e.options, a => a.selected).map(a => o ? Xn($r(a)) : $r(a));
                    e._assign(e.multiple ? r ? new Set(i) : i : i[0])
                }), e._assign = Sr(n)
            },
            mounted(e, {
                value: t
            }) {
                Rl(e, t)
            },
            beforeUpdate(e, t, o) {
                e._assign = Sr(o)
            },
            updated(e, {
                value: t
            }) {
                Rl(e, t)
            }
        };

    function Rl(e, t) {
        const o = e.multiple;
        if (o && !qe(t) && !Wn(t)) {
            ({}).NODE_ENV !== "production" && le(`<select multiple v-model> expects an Array or Set value for its binding, but got ${Object.prototype.toString.call(t).slice(8,-1)}.`);
            return
        }
        for (let n = 0, r = e.options.length; n < r; n++) {
            const i = e.options[n],
                a = $r(i);
            if (o) qe(t) ? i.selected = Lc(t, a) > -1 : i.selected = t.has(a);
            else if (tr($r(i), t)) {
                e.selectedIndex !== n && (e.selectedIndex = n);
                return
            }
        }!o && e.selectedIndex !== -1 && (e.selectedIndex = -1)
    }

    function $r(e) {
        return "_value" in e ? e._value : e.value
    }
    const If = ["ctrl", "shift", "alt", "meta"],
        Df = {
            stop: e => e.stopPropagation(),
            prevent: e => e.preventDefault(),
            self: e => e.target !== e.currentTarget,
            ctrl: e => !e.ctrlKey,
            shift: e => !e.shiftKey,
            alt: e => !e.altKey,
            meta: e => !e.metaKey,
            left: e => "button" in e && e.button !== 0,
            middle: e => "button" in e && e.button !== 1,
            right: e => "button" in e && e.button !== 2,
            exact: (e, t) => If.some(o => e[`${o}Key`] && !t.includes(o))
        },
        oa = (e, t) => (o, ...n) => {
            for (let r = 0; r < t.length; r++) {
                const i = Df[t[r]];
                if (i && i(o, t)) return
            }
            return e(o, ...n)
        },
        Rt = {
            beforeMount(e, {
                value: t
            }, {
                transition: o
            }) {
                e._vod = e.style.display === "none" ? "" : e.style.display, o && t ? o.beforeEnter(e) : Ln(e, t)
            },
            mounted(e, {
                value: t
            }, {
                transition: o
            }) {
                o && t && o.enter(e)
            },
            updated(e, {
                value: t,
                oldValue: o
            }, {
                transition: n
            }) {
                !t != !o && (n ? t ? (n.beforeEnter(e), Ln(e, !0), n.enter(e)) : n.leave(e, () => {
                    Ln(e, !1)
                }) : Ln(e, t))
            },
            beforeUnmount(e, {
                value: t
            }) {
                Ln(e, t)
            }
        };

    function Ln(e, t) {
        e.style.display = t ? e._vod : "none"
    }
    const Sf = Ze({
        patchProp: kf
    }, af);
    let Fl;

    function Vl() {
        return Fl || (Fl = Dd(Sf))
    }
    const Ll = (...e) => {
            Vl().render(...e)
        },
        Ko = (...e) => {
            const t = Vl().createApp(...e);
            ({}).NODE_ENV !== "production" && ($f(t), Rf(t));
            const {
                mount: o
            } = t;
            return t.mount = n => {
                const r = Ff(n);
                if (!r) return;
                const i = t._component;
                !Ne(i) && !i.render && !i.template && (i.template = r.innerHTML), r.innerHTML = "";
                const a = o(r, !1, r instanceof SVGElement);
                return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a
            }, t
        };

    function $f(e) {
        Object.defineProperty(e.config, "isNativeTag", {
            value: t => $c(t) || Rc(t),
            writable: !1
        })
    }

    function Rf(e) {
        {
            const t = e.config.isCustomElement;
            Object.defineProperty(e.config, "isCustomElement", {
                get() {
                    return t
                },
                set() {
                    le("The `isCustomElement` config option is deprecated. Use `compilerOptions.isCustomElement` instead.")
                }
            });
            const o = e.config.compilerOptions,
                n = 'The `compilerOptions` config option is only respected when using a build of Vue.js that includes the runtime compiler (aka "full build"). Since you are using the runtime-only build, `compilerOptions` must be passed to `@vue/compiler-dom` in the build setup instead.\n- For vue-loader: pass it via vue-loader\'s `compilerOptions` loader option.\n- For vue-cli: see https://cli.vuejs.org/guide/webpack.html#modifying-options-of-a-loader\n- For vite: pass it via @vitejs/plugin-vue options. See https://github.com/vitejs/vite-plugin-vue/tree/main/packages/plugin-vue#example-for-passing-options-to-vuecompiler-sfc';
            Object.defineProperty(e.config, "compilerOptions", {
                get() {
                    return le(n), o
                },
                set() {
                    le(n)
                }
            })
        }
    }

    function Ff(e) {
        if (Xe(e)) {
            const t = document.querySelector(e);
            return {}.NODE_ENV !== "production" && !t && le(`Failed to mount app: mount target selector "${e}" returned null.`), t
        }
        return {}.NODE_ENV !== "production" && window.ShadowRoot && e instanceof window.ShadowRoot && e.mode === "closed" && le('mounting on a ShadowRoot with `{mode: "closed"}` may lead to unpredictable bugs'), e
    }

    function Vf() {
        nf()
    }({}).NODE_ENV !== "production" && Vf();
    const Lf = (e, t) => {
            const o = e.__vccOpts || e;
            for (const [n, r] of t) o[n] = r;
            return o
        },
        qo = {
            type: [String, Object, Array],
            default: ""
        },
        Gl = 'a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex]:not([tabindex="-1"])';
    let Rr = 0;
    const Gf = {
            name: "VueModal",
            props: {
                name: {
                    type: String,
                    default: ""
                },
                title: {
                    type: String,
                    default: ""
                },
                baseZindex: {
                    type: Number,
                    default: 1051
                },
                bgClass: qo,
                wrapperClass: qo,
                modalClass: qo,
                modalStyle: qo,
                inClass: Object.assign({}, qo, {
                    default: "vm-fadeIn"
                }),
                outClass: Object.assign({}, qo, {
                    default: "vm-fadeOut"
                }),
                bgInClass: Object.assign({}, qo, {
                    default: "vm-fadeIn"
                }),
                bgOutClass: Object.assign({}, qo, {
                    default: "vm-fadeOut"
                }),
                appendTo: {
                    type: String,
                    default: "body"
                },
                live: {
                    type: Boolean,
                    default: !1
                },
                enableClose: {
                    type: Boolean,
                    default: !0
                },
                modelValue: {
                    type: Boolean,
                    default: !1
                },
                closeLabel: {
                    type: String,
                    default: "Close"
                }
            },
            emits: ["before-open", "opening", "opened", "before-close", "closing", "closed", "update:modelValue"],
            data() {
                return {
                    zIndex: 0,
                    id: null,
                    show: !1,
                    mount: !1,
                    elToFocus: null
                }
            },
            created() {
                this.live && (this.mount = !0)
            },
            mounted() {
                this.id = "vm-" + this.$.uid;
                const e = this.name ? `$modal.state.modals.${this.name}` : "modelValue";
                this.$watch(e, t => {
                    t ? (this.mount = !0, this.$nextTick(() => {
                        this.show = !0
                    })) : this.show = !1
                }, {
                    immediate: !0
                })
            },
            beforeUnmount() {
                this.elToFocus = null, this.name && this.$modal.hide(this.name)
            },
            methods: {
                close() {
                    this.enableClose === !0 && (this.$emit("update:modelValue", !1), this.name && this.$modal.hide(this.name))
                },
                clickOutside(e) {
                    e.target === this.$refs["vm-wrapper"] && this.close()
                },
                keydown(e) {
                    if ((e.which === 27 || e.keyCode === 27) && this.close(), e.which === 9 || e.keyCode === 9) {
                        const t = [].slice.call(this.$refs["vm-wrapper"].querySelectorAll(Gl)).filter(function(o) {
                            return !!(o.offsetWidth || o.offsetHeight || o.getClientRects().length)
                        });
                        e.shiftKey ? (e.target === t[0] || e.target === this.$refs["vm-wrapper"]) && (e.preventDefault(), t[t.length - 1].focus()) : e.target === t[t.length - 1] && (e.preventDefault(), t[0].focus())
                    }
                },
                getAllVisibleWrappers() {
                    return [].slice.call(document.querySelectorAll("[data-vm-wrapper-id]")).filter(e => e.display !== "none")
                },
                getTopZindex() {
                    return this.getAllVisibleWrappers().reduce((e, t) => parseInt(t.style.zIndex) > e ? parseInt(t.style.zIndex) : e, 0)
                },
                handleFocus(e) {
                    const t = e.querySelector("[autofocus]");
                    if (t) t.focus();
                    else {
                        const o = e.querySelectorAll(Gl);
                        o.length ? o[0].focus() : e.focus()
                    }
                },
                beforeOpen() {
                    this.elToFocus = document.activeElement;
                    const e = this.getTopZindex();
                    Rr ? this.zIndex = Rr + 2 : this.zIndex = e === 0 ? this.baseZindex : e + 2, Rr = this.zIndex, this.$emit("before-open")
                },
                opening() {
                    this.$emit("opening")
                },
                opened() {
                    this.handleFocus(this.$refs["vm-wrapper"]), this.$emit("opened")
                },
                beforeClose() {
                    this.$emit("before-close")
                },
                closing() {
                    this.$emit("closing")
                },
                closed() {
                    this.zIndex = 0, this.live || (this.mount = !1), this.$nextTick(() => {
                        window.requestAnimationFrame(() => {
                            const e = this.getTopZindex();
                            if (e > 0) {
                                const t = this.getAllVisibleWrappers();
                                for (let o = 0; o < t.length; o++) {
                                    const n = t[o];
                                    if (parseInt(n.style.zIndex) === e) {
                                        n.contains(this.elToFocus) ? this.elToFocus.focus() : this.handleFocus(n);
                                        break
                                    }
                                }
                            } else document.body.contains(this.elToFocus) && this.elToFocus.focus();
                            Rr = 0, this.$emit("closed")
                        })
                    })
                }
            }
        },
        Mf = ["data-vm-backdrop-id"],
        Bf = ["data-vm-wrapper-id", "aria-label", "aria-describedby", "aria-labelledby"],
        Uf = ["data-vm-id"],
        jf = {
            class: "vm-titlebar"
        },
        zf = ["id"],
        Hf = ["aria-label"],
        Kf = ["id"];

    function Yf(e, t, o, n, r, i) {
        return r.mount ? (H(), Se(Ld, {
            key: 0,
            to: o.appendTo
        }, [pe(lo, {
            name: "vm-backdrop-transition",
            "enter-active-class": o.bgInClass,
            "leave-active-class": o.bgOutClass
        }, {
            default: Ge(() => [ht(v("div", {
                "data-vm-backdrop-id": r.id,
                class: Le(["vm-backdrop", o.bgClass]),
                style: mt({
                    "z-index": r.zIndex - 1
                })
            }, null, 14, Mf), [
                [Rt, r.show]
            ])]),
            _: 1
        }, 8, ["enter-active-class", "leave-active-class"]), pe(lo, {
            name: "vm-transition",
            "enter-active-class": o.inClass,
            "leave-active-class": o.outClass,
            onBeforeEnter: i.beforeOpen,
            onEnter: i.opening,
            onAfterEnter: i.opened,
            onBeforeLeave: i.beforeClose,
            onLeave: i.closing,
            onAfterLeave: i.closed
        }, {
            default: Ge(() => [ht(v("div", {
                ref: "vm-wrapper",
                "data-vm-wrapper-id": r.id,
                tabindex: "-1",
                class: Le(["vm-wrapper", o.wrapperClass]),
                style: mt({
                    "z-index": r.zIndex,
                    cursor: o.enableClose ? "pointer" : "default"
                }),
                role: "dialog",
                "aria-label": o.title,
                "aria-modal": "true",
                "aria-describedby": `${r.id}-content`,
                "aria-labelledby": `${r.id}-title`,
                onClick: t[1] || (t[1] = a => i.clickOutside(a)),
                onKeydown: t[2] || (t[2] = a => i.keydown(a))
            }, [v("div", {
                ref: "vm",
                class: Le(["vm", o.modalClass]),
                "data-vm-id": r.id,
                style: mt(o.modalStyle)
            }, [zt(e.$slots, "titlebar", {}, () => [v("div", jf, [v("h3", {
                id: `${r.id}-title`,
                class: "vm-title"
            }, Te(o.title), 9, zf), o.enableClose ? (H(), ne("button", {
                key: 0,
                type: "button",
                class: "vm-btn-close",
                "aria-label": o.closeLabel,
                onClick: t[0] || (t[0] = oa((...a) => i.close && i.close(...a), ["prevent"]))
            }, null, 8, Hf)) : ve("", !0)])]), zt(e.$slots, "content", {}, () => [v("div", {
                id: `${r.id}-content`,
                class: "vm-content"
            }, [zt(e.$slots, "default")], 8, Kf)])], 14, Uf)], 46, Bf), [
                [Rt, r.show]
            ])]),
            _: 3
        }, 8, ["enter-active-class", "leave-active-class", "onBeforeEnter", "onEnter", "onAfterEnter", "onBeforeLeave", "onLeave", "onAfterLeave"])], 8, ["to"])) : ve("", !0)
    }
    const na = Lf(Gf, [
            ["render", Yf]
        ]),
        Fr = ur({
            modals: {}
        }),
        Vr = () => {
            const e = o => {
                    Fr.modals[o] = !0
                },
                t = o => {
                    delete Fr.modals[o]
                };
            return {
                state: Fr,
                show: e,
                hide: t,
                hideAll: () => {
                    Object.keys(Fr.modals).forEach(o => {
                        t(o)
                    })
                }
            }
        },
        Wf = {
            install(e) {
                e.config.globalProperties.$modal = Vr()
            }
        },
        Vh = "",
        Qf = {
            baseURL: "https://api.qikify.com",
            openURL: "https://open-api.qikify.com"
        },
        F = {
            ELEMENT_ID: "qikify-boosterkit",
            APP_NAME: "boosterkit",
            ENV: "production",
            BUILD_ENV: "production",
            APP_HANDLE: "booster-kit-by-qikify",
            MOBILE_BREAKPOINT: 567,
            POPUP_MODAL_NAME: "qbk-popup-offer",
            POPUP_ADDED_GIFT_NAME: "qbk-popup-added-gift",
            POPUP_GIFT_GOAL_NAME: "qbk-popup-gift-goal",
            EXTENSIONS: ["bogo", "bundle", "volume", "free-gift", "upsurge"],
            ADMIN_BAR_SELECTOR: ".admin-bar",
            LOCALE_WITH_COUNTRY: ["pt", "zh"],
            AKO_SIGNATURE: "Akohub",
            OFFER_ID_PROPERTY: "_qbk-offer-id",
            OFFER_TYPE_PROPERTY: "_qbk-offer-type",
            TRIGGER_ID_PROPERTY: "_qbk-trigger-id",
            ADDED_AT_PROPERTY: "_qbk-added-at",
            TIER_PROPERTY: "_qbk-tier",
            BOGO_LISTENER: "qbk-bogo-listener",
            FREE_GIFT_LISTENER: "qbk-free-gift-listener",
            PROMOTE_FREE_GIFT_LISTENER: "qbk-promote-fg-listener",
            POPUP_LISTENER: "qbk-popup-listener",
            CHECKOUT_LISTENER: "qbk-checkout-listener",
            CHECKOUT_FORM_LISTENER: "qbk-checkout-form-listener",
            CHECKOUT_INPUT_DISCOUNT_CLASS: "qbk-input-discount",
            FORM_LISTENER: "qbk-form-listener",
            FORM_VARIANT_LISTENER: "qbk-form-variant-listener",
            BADGE_ATTACH: "qbk-badge-attach",
            DISCOUNT_STORAGE: "qbk-discount",
            COMPLETED_ORDER_TOKEN: "trackedCompleteOrderSourceId",
            STOREFRONT_TOKEN: "qbk-storefront-token",
            SHOPIFY_SESSION_ANALYTIC_KEY: "_shopify_s",
            SESSION_ANALYTIC_KEY: "qbk_sa",
            POPUP_EXPIRE_TIME: "qbk-expire-time",
            GIFT_GOAL_STORAGE: "qbk-gift-goal",
            TODAY_OFFER_DISMISSED_AT: "qbk-today-offers-dismissed-at",
            EVENT_OPEN_POPUP: "boosterkit-open-popup",
            EVENT_OPEN_ADDED_GIFT_POPUP: "boosterkit-open-added-gift-popup",
            EVENT_CART_CHANGE: "boosterkit-cart-change",
            EVENT_DATA_UPDATED: "boosterkit-data-updated",
            EVENT_CHECKOUT_LISTENER: "boosterkit-checkout-listener",
            EVENT_BOOSTERKIT_MOUNTED: "boosterkit-mounted",
            EVENT_POPUP_BEFORE_CLOSE: "boosterkit-popup-before-close",
            EVENT_POPUP_BEFORE_OPEN: "boosterkit-popup-before-open",
            EVENT_BUNDLE_ADDED: "boosterkit-bundle-added",
            EVENT_BOGO_ADDED: "boosterkit-bogo-added",
            EVENT_VOLUME_ADDED: "boosterkit-volume-added",
            EVENT_UPSURGE_ADDED: "boosterkit-upsurge-added",
            EVENT_VARIANT_CHANGED: "boosterkit-variant-changed",
            EVENT_FREE_GIFT_ADDED: "boosterkit-free-gift-added",
            EVENT_RECOMMENDATION_OFFER_ADDED: "boosterkit-recommendation-offer-added",
            EVENT_FILTER_DISCOUNT: "boosterkit-filter-discount",
            EVENT_OPEN_GIFT_GOAL: "boosterkit-open-gift-goal",
            EVENT_OFFER_MOUNTED: "boosterkit-offer-mounted",
            EVENT_GIFT_GOAL_ADDED: "boosterkit-gift-goal-added",
            EVENT_LINE_ITEMS_CHANGED: "boosterkit-line-items-changed",
            EVENT_GIFT_GOAL_BEFORE_OPEN: "boosterkit-gift-goal-before-open",
            EVENT_GIFT_GOAL_BEFORE_CLOSE: "boosterkit-gift-goal-before-close",
            EVENT_CART_ATTRIBUTE_UPDATED: "boosterkit-cart-attribute-updated",
            EVENT_GIFT_GOAL_REACHED: "boosterkit-gift-goal-reached",
            DISCOUNT_CLEAR_CODE: "QIKIFY-CLEAR",
            TOAST_DURATION: 2e3,
            waitForFormUpdated: 0,
            selectedVariantIdSelector: "[name=id]",
            productIdSelector: "[name=product-id]",
            quantitySelector: "[name=quantity]",
            ignoreCartChangeUrl: ["update.js?", "?qbk-bogo", "?qbk-bundle", "?qbk-ignore", "?qbk-volume", "?qbk-free-gift", "?qbk-upsurge", "?qbk-order-goal", "?qbk-gift-goal"],
            isUseCustomCart: !1,
            orderGoalBreakpoint: 640,
            atcFormSelector: 'form[action*="/cart/add"]',
            atcSubmitSelector: ['[type="submit"]', ".product-buy-buttons--cta", ".buy-buttons__buttons .button-action", ".product-details__add-to-cart-button", ".add_to_cart", ".product-form--add-to-cart", ".add-to-cart-button", ".add-to-cart-btn", "[data-product-atc]", "[data-product-add]", ".product-submit.addtocart-button-active", '[data-pf-type="ProductATC"]', '[data-pf-type="ProductATC2"]', ".gp-button-atc"].join(", "),
            atcFormExcludeSelector: ':not([id*="installment"]):not([id*="instalment"]):not(.installment)',
            checkoutFormSelector: 'form[action*="/cart"]',
            checkoutSubmitSelector: '[name="checkout"],[href$="/checkout"],.qsc2-checkout-button',
            orderGoalDrawerSelector: ["#CartDrawer .drawer__header", ".cart-drawer__header", ".qsc2-drawer-header", ".cart--header", ".cart-drawer__top", "#cart-drawer .drawer__head", "#drawer-cart .drawer__top", "#mini-cart > .grid__wrapper", ".cart-drawer__head", "#CartDrawer .drawer__fixed-header", ".drawer--cart .drawer__header"].join(","),
            orderGoalDrawerPosition: "after",
            orderGoalDrawerEmptyPosition: "prepend",
            orderGoalDrawerEmptySelector: ".drawer__inner-empty",
            waitForDrawerLoadedTimeout: 100,
            triggerDrawerSelector: '[href$="/cart"]',
            waitForCartApiSettle: 200,
            drawerSelector: "cart-drawer",
            bindingEvents: ["click"],
            defaultImageSize: "small",
            ignoreBtnClasses: ["gpo-clone-atc-button"],
            numberOfActiveTiers: 4,
            numberOfTodayOffers: 5,
            productWrapperSelector: [".product-index", ".product-card-wrapper", ".product-block", ".product-grid-item", ".product-item", ".product-rows", ".product-card", ".product-list-item", ".grid-product", ".product--root", "[data-product-title]", "[data-product-available]", "[data-product-item]", ".collection-product", ".collection__grid-item", ".product-wrap", ".thumbnail", "[data-product-grid-item]", ".product-thumbnail__media-wrapper", ".product", ".grid-product"].join(","),
            badgeAttackSelector: ".media,img",
            handleLinkSelector: 'a[href*="/products"]',
            badgePosition: "before",
            lazyLoadTimeout: 100,
            enableResetEventAtc: !1
        },
        Ml = {
            Context: {
                css: `
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Avenue: {
                css: `
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
      .qbk-badge__label {
        font-size: 14px;
      }
    `
            },
            Refresh: {
                css: `
      .qbk-promotion-badge {
        left: 0;
        bottom: 0;
      }
    `
            },
            Broadcast: {
                css: `
      .drawer__inner .qbk-order-goal {
        margin-top: var(--qbk-space-1);
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Story: {
                css: `
      .drawer__content .qbk-order-goal {
        padding: 0 var(--qbk-space-2);
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                badgeAttackSelector: "div.lazy-image",
                badgePosition: "prepend"
            },
            Canopy: {
                css: `
      .cart-summary .qbk-order-goal {
        margin: 1em auto 0 !important;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                orderGoalDrawerSelector: ".cart-summary__inner .cart-form"
            },
            Modular: {
                css: `
      .cart-drawer .qbk-relative-teleport {
        margin: 0 auto var(--qbk-space-2);
      }
      .qbk-popup__body .qbk-bogo .qbk-offer__action-btn {
        margin-right: 0;
      }
      .qbk-promotion-badge {
        left: 0;
        bottom: 0;
      }
    `,
                orderGoalDrawerSelector: ".cart-drawer .cart__title.cart__title--mobile",
                atcSubmitSelector: '[type="submit"][name="add"]'
            },
            "Palo Alto": {
                css: `
     .qbk-promotion-badge {
        left: 0;
        bottom: 0;
      }
    `,
                badgeAttackSelector: ".product__media"
            },
            Icon: {
                css: `
      .qbk-recommendation-box__container .qbk-offer__action-btn {
        margin-bottom: 0;
      }
      .qbk-recommendation__nav {
        width: unset;
      }
      .mini-cart__container .qbk-order-goal {
        padding: 0 var(--qbk-space-2);
      }
    `,
                atcFormSelector: '.product__section-details__inner--product_buttons > form[action*="/cart/add"]'
            },
            Testament: {
                css: `
      .qbk-recommendation-box__container .qbk-offer__action-btn {
        margin-bottom: 0;
      }
      .qbk-recommendation__nav {
        width: unset;
      }
      .qbk-promotion-badge {
        bottom: 0;
        left: 0;
      }
    `,
                atcFormSelector: '.product__section--buttons > form[action*="/cart/add"]'
            },
            Split: {
                css: `
      .qbk-svg-icon * {
        fill: var(--qbk-offer-checkbox-svg-color) !important;
      }
      .qbk-promote-wrapper {
        top: 0.6em;
        left: 0.3em;
      }
    `,
                orderGoalDrawerSelector: "#AjaxCartForm .site-cart-heading"
            },
            Parallax: {
                css: `
      .qbk-btn.qbk-btn--secondary:hover {
        background: var(--qbk-button-secondary-bg-color);
      }
      .qbk-btn.qbk-btn--primary:hover {
        background: var(--qbk-button-primary-bg-color);
      }
      .qbk-popup__continue {
        text-transform: unset;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                orderGoalDrawerSelector: "#mm-1 .mm-subtitle:nth-child(1)"
            },
            Atlantic: {
                css: `
      .sidebar-drawer .qbk-order-goal {
        margin-top: var(--qbk-space-1);
      }
      .qbk-badge__label {
        font-size: 14px;
      }
    `,
                orderGoalDrawerSelector: ".sidebar-drawer__header-container",
                productWrapperSelector: ".product-inner"
            },
            "Mr Parker": {
                css: `
      .qbk-recommendation-box__container .qbk-offer__action-btn {
        margin-bottom: 0;
      }
      .qbk-recommendation__nav {
        margin: 0;
        padding: var(--qbk-space-05) !important;
      }
      .qbk-recommendation__nav--next {
        padding-right: 0 !important;
      }
      .qbk-recommendation__nav--prev {
        padding-left: 0 !important;
      }
      .qbk-recommendation__nav:hover {
        color: var(--qbk-order-goal-bar-milestone-color)
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                atcFormSelector: '.product__section-content__block--buttons > form[action*="/cart/add"]'
            },
            Responsive: {
                css: `
      .qbk-recommendation__nav {
        width: unset;
      }
      .qbk-popup {
        z-index: 99995 !important;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Kingdom: {
                css: `
      .qbk-offer__checkbox input.qbk-offer__checkbox-input[type=checkbox] {
        display: none !important;
      }
      .sidebar__cart .qbk-order-goal {
        margin-top: var(--qbk-space-1);
      }
    `,
                orderGoalDrawerSelector: ".sidebar__cart #AjaxCartForm > div"
            },
            Vantage: {
                css: `
      .qbk-btn.qbk-btn--secondary:hover {
        background: var(--qbk-button-secondary-bg-color);
      }
      .qbk-btn.qbk-btn--primary:hover {
        background: var(--qbk-button-primary-bg-color);
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                atcFormSelector: '.product-blocks__block--buttons > form[action*="/cart/add"]'
            },
            Fashionopolism: {
                css: `
      .qbk-recommendation__nav:hover {
        color: var(--qbk-order-goal-bar-milestone-color) !important;
      }
      .qbk-recommendation-box__container .qbk-offer__action-btn {
        margin-bottom: 0;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                atcFormSelector: '.product__section--buttons > form[action*="/cart/add"]'
            },
            Cascade: {
                css: `
      #right-drawer-slot .qbk-order-goal {
        margin-top: var(--qbk-space-1);
        padding: 0 30px;
      }
    `,
                orderGoalDrawerSelector: "#right-drawer-slot > div.max-h-full.flex.flex-col.h-screen > div:nth-child(1)",
                productWrapperSelector: "[data-cascade-item]"
            },
            Emerge: {
                css: `
      .qbk-recommendation__nav:hover {
        color: var(--qbk-order-goal-bar-milestone-color) !important;
      }
    `
            },
            Symmetry: {
                css: `
      .qbk-btn.qbk-btn--secondary:hover {
        background: var(--qbk-button-secondary-bg-color);
        border-color: var(--qbk-button-secondary-bg-color);
      }
      .qbk-btn.qbk-btn--primary:hover {
        background: var(--qbk-button-primary-bg-color);
        border-color: var(--qbk-button-primary-bg-color);
      }
      .qbk-btn--plain,
      .qbk-btn--primary {
        text-transform: unset;
      }
      .cart-drawer__content .qbk-recommendation__nav {
        background-color: transparent!important;
        color: var(--qbk-order-goal-bar-milestone-color) !important;
      }
      .cart-drawer__content .qbk-recommendation__nav .qbk-svg-icon {
        fill: currentColor !important;
      }
      .qbk-popup {
        z-index: 9999 !important;
      }
    `,
                orderGoalDrawerSelector: ".cart-drawer__header"
            },
            Maker: {
                css: `
      .qbk-btn.qbk-btn--secondary:hover {
        background: var(--qbk-button-secondary-bg-color);
        border-color: var(--qbk-button-secondary-bg-color);
      }
      .qbk-btn.qbk-btn--primary:hover {
        background: var(--qbk-button-primary-bg-color);
        border-color: var(--qbk-button-primary-bg-color);
      }
      .qbk-recommendation__nav:hover {
        color: var(--qbk-order-goal-bar-milestone-color)
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Showcase: {
                css: `
      .qbk-btn.qbk-btn--secondary:hover {
        background: var(--qbk-button-secondary-bg-color) !important;
        border-color: var(--qbk-button-secondary-bg-color) !important;
      }
      .qbk-btn.qbk-btn--primary:hover {
        background: var(--qbk-button-primary-bg-color) !important;
        border-color: var(--qbk-button-primary-bg-color) !important;
        color: var(--qbk-button-primary-text-color) !important;
      }.
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            ShowTime: {
                css: `
      .qbk-order-goal__progress {
        background-color: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__icon {
        background: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__milestone--done .qbk-order-goal__icon {
        background-color: var(--qbk-order-goal-bar-milestone-done-bg-color) !important;
      }
    `,
                productWrapperSelector: "div[class~='#product-card']"
            },
            Capital: {
                css: `
      #cartSlideoutWrapper .qbk-order-goal {
        padding: 0 2em;
      }
    `
            },
            Masonry: {
                css: `
      .qbk-btn.qbk-btn--secondary:hover {
        background: var(--qbk-button-secondary-bg-color);
        border-color: var(--qbk-button-secondary-bg-color);
      }
      .qbk-btn.qbk-btn--primary:hover {
        background: var(--qbk-button-primary-bg-color);
        border-color: var(--qbk-button-primary-bg-color);
      }
      .qbk-btn--plain,
      .qbk-btn--primary {
        text-transform: unset;
      }
      .qbk-btn--plain:hover > span,
      .qbk-offer__action-btn:hover > span {
        color: var(--qbk-button-text-color);
      }
      .qbk-watermark .qbk-logo>svg {
        max-width: unset;
      }
    `
            },
            Pacific: {
                css: `
      .qbk-order-goal {
        font-size: initial;
      }
    `
            },
            Focal: {
                css: `
      #mini-cart .qbk-order-goal {
        margin-top: var(--qbk-space-1);
        padding: 0 var(--qbk-space-2);
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                checkoutSubmitSelector: '[name="checkout"][type="submit"]',
                waitForDrawerLoadedTimeout: 1e3,
                orderGoalDrawerSelector: "#mini-cart > header"
            },
            Lorenza: {
                css: `
      #cart-flyout-drawer .qbk-order-goal {
        margin-top: var(--qbk-space-1);
        padding: 0 var(--qbk-space-2);
      }
    `,
                orderGoalDrawerSelector: "#cart-flyout-drawer .quick-cart__tabs",
                waitForDrawerLoadedTimeout: 500,
                badgeAttackSelector: ".product-item__image",
                badgePosition: "append"
            },
            Spark: {
                css: `
      .quick-cart .qbk-order-goal {
        padding: 0 !important;
      }
      .quick-cart .qbk-watermark .qbk-logo,
      .quick-cart .qbk-watermark > span {
        color: #fff !important;
      }
    `,
                orderGoalDrawerSelector: ".quick-cart__header"
            },
            Baseline: {
                css: `
      #CartContainer .qbk-order-goal {
        margin-top: var(--qbk-space-1);
        padding: 0 var(--qbk-space-2);
      }
      .qbk-order-goal__progress {
        background-color: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__icon {
        background: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__milestone--done .qbk-order-goal__icon {
        background-color: var(--qbk-order-goal-bar-milestone-done-bg-color) !important;
      }
    `,
                orderGoalDrawerSelector: "#CartContainer > div:first-child",
                productWrapperSelector: ".type-product-grid-item"
            },
            Avatar: {
                css: `
      .qbk-order-goal {
        padding: 0 var(--qbk-space-2);
      }
      .qbk-order-goal__progress {
        background-color: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__icon {
        background: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__milestone--done .qbk-order-goal__icon {
        background-color: var(--qbk-order-goal-bar-milestone-done-bg-color) !important;
      }
    `,
                orderGoalDrawerSelector: "[data-slider-cart-header]"
            },
            Prestige: {
                enableResetEventAtc: !0,
                css: `
      #cart-drawer .qbk-order-goal {
        padding: 0;
        margin-top: var(--qbk-space-1);
      }
      .qbk-order-goal__progress {
        background-color: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__icon {
        background: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__milestone--done .qbk-order-goal__icon {
        background-color: var(--qbk-order-goal-bar-milestone-done-bg-color) !important;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                orderGoalDrawerSelector: "#cart-drawer > p"
            },
            Impulse: {
                css: `
      #CartDrawer .qbk-order-goal {
        margin-top: var(--qbk-space-1);
      }
    `
            },
            Warehouse: {
                css: `
      .qbk-order-goal__progress {
        background-color: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__icon {
        background: var(--qbk-button-primary-text-color) !important;
      }
      .qbk-order-goal__milestone--done .qbk-order-goal__icon {
        background-color: var(--qbk-order-goal-bar-milestone-done-bg-color) !important;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Motion: {
                css: `
      #CartDrawer .qbk-order-goal {
        margin-top: var(--qbk-space-1);
      }
    `
            },
            Flow: {
                css: `
      .qbk-popup {
        z-index: 1500 !important;
      }
      input.qbk-offer__checkbox-input[type=checkbox] {
        display: none !important;
      }
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Venue: {
                css: `
    `,
                orderGoalDrawerSelector: ".ajaxcart__head"
            },
            Enterprise: {
                waitForDrawerLoadedTimeout: 1e3
            },
            "Be Yours": {
                drawerSelector: "mini-cart",
                triggerDrawerSelector: "#cart-icon-bubble",
                waitForDrawerLoadedTimeout: 1e3
            },
            Envy: {
                css: `
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `,
                productWrapperSelector: ".indiv-product"
            },
            Galleria: {
                css: `
      .qbk-promote-wrapper {
        top: 0.7em;
      }
    `,
                productWrapperSelector: "div[class~='#product-card']"
            },
            Launch: {
                css: `
      .qbk-badge__label {
        font-size: .75rem;
      }
    `
            },
            Empire: {
                badgeAttackSelector: ".productitem--image",
                badgePosition: "append"
            },
            Blockshop: {
                css: `
      .qbk-promote-wrapper {
        bottom: 0;
        top: unset;
      }
    `
            },
            Alchemy: {
                css: `
      .qbk-promote-wrapper {
        top: unset;
        bottom: 0;
      }
    `,
                productWrapperSelector: ".card"
            },
            Artisan: {
                css: `
      .qbk-promote-wrapper {
        top: unset;
        bottom: 0;
      }
    `
            },
            Vogue: {
                css: `
      .qbk-promote-wrapper {
        left: unset;
        right: 0;
      }
    `
            },
            Editorial: {
                css: `
      .qbk-promote-wrapper {
        top: unset;
        bottom: 0;
      }
    `
            },
            Mobilia: {
                css: `
      .qbk-promote-wrapper {
        top: unset;
        bottom: 0;
      }
    `
            },
            Sunrise: {
                css: `
      .qbk-promote-wrapper {
        left: unset;
        right: 0;
      }
    `,
                productWrapperSelector: ".prod-th"
            },
            Loft: {
                css: `
      .qbk-promote-wrapper {
        left: unset;
        right: 0;
      }
    `,
                productWrapperSelector: ".collection-page__product"
            },
            Retina: {
                css: `
      .qbk-promote-wrapper {
        right: 0;
        left: unset;
      }
    `
            },
            Narrative: {
                productWrapperSelector: ".card"
            },
            Venture: {
                css: `
      .qbk-promote-wrapper {
        right: 0;
        left: unset;
      }
    `
            },
            Minimal: {
                productWrapperSelector: ".grid-link"
            }
        };
    var to = (e => (e.Percentage = "percentage", e.FixedAmount = "fixed-amount", e))(to || {}),
        Lr = (e => (e.Code = "code", e.Auto = "auto", e))(Lr || {}),
        Ct = (e => (e.All = "all", e.Tag = "tags", e.Collection = "collections", e.Specific = "products", e))(Ct || {}),
        Tt = (e => (e.AddToCart = "add-to-cart", e.Checkout = "checkout", e.Payment = "payment", e))(Tt || {}),
        S = (e => (e.Bogo = "bogo", e.Bundle = "bundle", e.CartUpsell = "cart-upsell", e.Volume = "volume", e.FreeGift = "free-gift", e.Upsurge = "upsurge", e.OrderGoal = "order-goal", e.ShippingGoal = "shipping-goal", e.GiftGoal = "gift-goal", e))(S || {}),
        Pe = (e => (e.Added = "added", e.Available = "available", e.Unavailable = "unavailable", e.Error = "error", e.Processing = "processing", e.NotFound = "not-found", e))(Pe || {}),
        Ft = (e => (e.All = "ALL", e))(Ft || {}),
        Gr = (e => (e.Random = "random", e.UpdatedAsc = "updated-asc", e.UpdatedDesc = "updated-desc", e))(Gr || {}),
        Vt = (e => (e.SessionProductOffer = "session_product_offer", e.SessionCartOffer = "session_cart_offer", e.SessionAddToCart = "session_add_to_cart", e))(Vt || {}),
        ct = (e => (e.Auto = "auto", e.Manual = "manual", e))(ct || {}),
        Mr = (e => (e.NotEnoughQuantity = "NOT_ENOUGH_QUANTITY", e))(Mr || {}),
        ra = (e => (e.Random = "random", e.NearestPrice = "nearest-price", e))(ra || {}),
        ia = (e => (e.All = "all", e.Children = "children", e))(ia || {}),
        Lt = (e => (e.Free = "boosterkit-free", e.FreeAll = "boosterkit-free_all", e.FreeBeta = "boosterkit-free_beta", e.Freemium = "boosterkit-freemium", e.Premium = "boosterkit-premium", e.FreeLimitUsage = "boosterkit-free_limit_usage", e))(Lt || {}),
        Gn = (e => (e.PurchaseAmount = "amount", e.PurchaseQuantity = "quantity", e))(Gn || {});
    const Gt = {
            entryName: {
                [S.Bogo]: "Buy X get Y",
                [S.Bundle]: "Bundle",
                [S.Upsurge]: "Upsurge",
                [S.FreeGift]: "Free Gift",
                [S.Volume]: "Volume",
                [S.GiftGoal]: "Gift with purchase",
                [S.OrderGoal]: "Order Goal",
                [S.CartUpsell]: "Cart upsell",
                [S.ShippingGoal]: "Shipping Goal"
            },
            premiumWarning: "{type} is only available for Premium plan.",
            entryByPlan: {
                [Lt.Free]: [S.Bogo, S.Bundle, S.Upsurge, S.FreeGift, S.Volume, S.CartUpsell, S.GiftGoal, S.OrderGoal, S.ShippingGoal],
                [Lt.FreeLimitUsage]: [S.Bogo, S.Bundle, S.Upsurge],
                [Lt.FreeAll]: [S.Bogo, S.Bundle, S.Volume, S.Upsurge, S.OrderGoal, S.CartUpsell],
                [Lt.FreeBeta]: [S.Bogo, S.Bundle, S.Upsurge, S.OrderGoal],
                [Lt.Freemium]: [S.Bogo, S.Bundle, S.Volume, S.Upsurge, S.OrderGoal, S.CartUpsell]
            },
            rewardBarEntries: [S.OrderGoal, S.ShippingGoal, S.GiftGoal]
        },
        L = {
            getOptions() {
                return window.QikifyBoosterKit || {}
            },
            log(...e) {
                const t = this.getOptions(),
                    [o, ...n] = e;
                (F.ENV === "development" || F.BUILD_ENV === "staging" || t.debug) && console.log(`Boosterkit - ${o}`, ...n)
            },
            getThemeName() {
                var e, t;
                return this.getOptions().themeName || ((t = (e = window == null ? void 0 : window.Shopify) == null ? void 0 : e.theme) == null ? void 0 : t.name)
            },
            getActiveLanguageCode() {
                var e, t;
                return ((t = (e = window == null ? void 0 : window.qbkStore) == null ? void 0 : e.shopLocale) == null ? void 0 : t.iso_code) || "en"
            },
            getFormattedLanguageCode() {
                const e = this.getActiveLanguageCode();
                return F.LOCALE_WITH_COUNTRY.some(t => e.includes(t)) ? e.replaceAll("-", "_").toUpperCase() : e.substring(0, 2).toUpperCase()
            },
            getActiveCountryCode() {
                var e;
                return (e = window == null ? void 0 : window.qbkStore) == null ? void 0 : e.country
            },
            isPrimaryLanguage() {
                const {
                    shopLocale: e
                } = window == null ? void 0 : window.qbkStore;
                return !e || e.primary
            },
            getRootUrl() {
                var e, t;
                return ((t = (e = window == null ? void 0 : window.qbkStore) == null ? void 0 : e.shopLocale) == null ? void 0 : t.root_url) || "/"
            },
            insertLocaleToShopLink(e) {
                const t = this.getRootUrl(),
                    o = t && t.split("/")[1];
                return o ? `/${o}${e}` : e
            },
            delay(e) {
                return new Promise(t => setTimeout(t, e))
            },
            gotoCartPage() {
                window.location.href = this.insertLocaleToShopLink("/cart")
            },
            gidProductVariant(e = "") {
                return `gid://shopify/ProductVariant/${e}`
            },
            gidCart(e = "") {
                return `gid://shopify/Cart/${e}`
            },
            mapKeyValueObject(e) {
                return Object.entries(e).map(([t, o]) => ({
                    key: t,
                    value: o.toString()
                }))
            },
            extractId(e) {
                return e.split("/").pop()
            },
            shuffleArray(e) {
                return e.sort(() => .5 - Math.random())
            },
            mapTranslation(e) {
                const t = this.getActiveLanguageCode();
                return (e && e[t] || []).reduce((o, {
                    id: n,
                    data: r
                }) => (o[n] = r, o), {})
            },
            getCookie(e) {
                const t = new RegExp(`(?:(?:^|.*;\\s*)${e}\\s*=\\s*([^;]*).*$)|^.*$`);
                return document.cookie.replace(t, "$1")
            },
            gidProduct(e) {
                return `gid://shopify/Product/${e}`
            },
            isDesignMode() {
                var e;
                return (e = window == null ? void 0 : window.qbkStore) == null ? void 0 : e.designMode
            },
            isProductPage() {
                var e;
                return ((e = window == null ? void 0 : window.qbkStore) == null ? void 0 : e.page) === "product"
            },
            getProductHandleFromUrl(e) {
                const t = e && e.split("/");
                return t && t[t.length - 1].split("?")[0] || ""
            },
            isEmptyObj(e) {
                return !e || Object.keys(e).length === 0
            },
            openPricing() {
                const e = window.location.host.split(".")[0],
                    t = F.APP_HANDLE,
                    o = F.APP_NAME;
                window.open(`https://admin.shopify.com/store/${e}/apps/${t}/${o}/pricing`, "_blank")
            },
            placeElement(e, t, o) {
                if (o) switch (t) {
                    case "before":
                        return e.before(o);
                    case "after":
                        return e.after(o);
                    case "prepend":
                        return e.prepend(o);
                    case "append":
                        return e.append(o)
                }
            },
            checkValidEntry(e) {
                var o, n;
                const t = (((o = window._BK) == null ? void 0 : o.subscriptions) || {}).name || "";
                return t === Lt.Premium ? !0 : (n = Gt.entryByPlan[t]) == null ? void 0 : n.includes(e)
            },
            randomItem(e, t, o) {
                const n = Math.floor(Math.random() * e.length);
                return o ? n : t ? e.splice(n, 1)[0] : e[n]
            },
            reverseArray(e) {
                return [...e].reverse()
            },
            debounce(e, t) {
                let o = null;
                return (n = []) => {
                    clearTimeout(o), o = setTimeout(() => e(...n), t)
                }
            },
            formatAsUTC(e) {
                return e ? `${e==null?void 0:e.replace(" ","T")}Z` : ""
            }
        },
        oo = {
            formatMoney(e, t) {
                var c;
                const o = L.getOptions();
                typeof e == "string" && (e = e.replace(".", ""));
                let n = "",
                    r = /\{\{\s*(\w+)\s*\}\}/,
                    i = t ? ? "${{amount}}";
                const a = o.currencyPrecision || 100;

                function s(l, f, u, d) {
                    if (f = f ? ? 2, u = u ? ? ",", d = d ? ? ".", isNaN(+l)) return "0";
                    l = (+l / a).toFixed(f);
                    const _ = l.split("."),
                        g = _[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1" + u),
                        h = _[1] ? d + _[1] : "";
                    return g + h
                }
                switch ((c = i.match(r)) == null ? void 0 : c[1]) {
                    case "amount":
                        n = s(e, 2);
                        break;
                    case "amount_no_decimals":
                        n = s(e, 0);
                        break;
                    case "amount_with_comma_separator":
                        n = s(e, 2, ".", ",");
                        break;
                    case "amount_no_decimals_with_comma_separator":
                        n = s(e, 0, ".", ",");
                        break;
                    case "amount_no_decimals_with_space_separator":
                        n = s(e, 0, " ");
                        break;
                    case "amount_with_apostrophe_separator":
                        n = s(e, 2, "'");
                        break
                }
                return i.replace(r, n)
            },
            convertMoney(e, t) {
                var a, s;
                const o = L.getOptions(),
                    n = o.currencyPrecision || 100,
                    r = t ? e * n : e,
                    i = ((s = (a = window == null ? void 0 : window.Shopify) == null ? void 0 : a.currency) == null ? void 0 : s.rate) || 1;
                return o.convertMoney ? o.convertMoney(r) : i ? r * i : r
            }
        };

    function Eo(e, t) {
        return F.ENV === "development" || t ? L.delay(1e3).then(() => new Promise((o, n) => {
            !e || e.error ? n(e) : o(e)
        })) : !1
    }

    function Zf(e) {
        const t = {
            statusCode: e.status,
            ok: e.ok
        };
        return new Promise(o => e.text().then(n => o({ ...t,
            json: e.status === 302 ? {} : Jf(n)
        })).catch(n => o({
            json: n
        })))
    }

    function Jf(e) {
        let t = {};
        try {
            t = JSON.parse(e && e.responseText || e)
        } catch (o) {
            t = {
                error: o
            }
        }
        return t
    }

    function sn(e, t, o) {
        const n = {
            "Content-Type": "application/json",
            Accept: "application/json"
        };
        return new Promise((r, i) => {
            const a = { ...t
            };
            a.headers = t && t.headers || n, fetch(e, a).then(Zf).then(s => s.ok || o ? r(s.json) : i(s.json)).catch(s => {
                L.log("Request error", s), i(new Error(s.message))
            })
        })
    }

    function Xf(e, t) {
        return Eo(window.fakeProduct && window.fakeProduct[e], t) || sn(L.insertLocaleToShopLink(`/products/${e}.js`))
    }

    function ep() {
        return Eo(window.fakeCart) || sn(L.insertLocaleToShopLink("/cart.js"))
    }

    function tp() {
        return Eo({}) || sn("/cart/clear.js", {
            method: "POST"
        })
    }

    function Mt(e, t, o) {
        return Eo({}) || sn(e, {
            method: "POST",
            cache: "no-cache",
            credentials: "include",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(t.body)
        }, o)
    }

    function aa(e, t) {
        const o = `/cart/update.js${t?"?qbk-ignore":""}`;
        return Eo({}) || Mt(o, {
            body: {
                attributes: {
                    [F.OFFER_ID_PROPERTY]: e
                }
            }
        })
    }

    function op(e) {
        if (!e) return;
        const t = new FormData;
        return t.append("checkout", ""), new Promise(o => {
            fetch(`/cart?discount=${e}`, {
                method: "POST",
                body: t
            }).finally(() => o({}))
        })
    }

    function ln({
        query: e,
        variables: t
    }) {
        const o = `${window.location.origin}/api/2024-04/graphql.json`;
        return new Promise(n => {
            var r;
            fetch(o, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Shopify-Storefront-Access-Token": ((r = window._BK) == null ? void 0 : r.storeFrontAccessToken) || ""
                },
                body: JSON.stringify({
                    query: e,
                    variables: t
                })
            }).then(i => i.json()).then(i => i.errors || !i || !i.data ? n({
                error: i.errors || "No results found."
            }) : n(i.data)).catch(i => n({
                error: i
            }))
        })
    }

    function np(e) {
        return ln({
            query: `
      mutation createCart($input: CartInput) {
        cartCreate(input: $input) {
          cart {
            id
            checkoutUrl
            discountCodes {
              code
              applicable
            }
            cost {
              subtotalAmount {
                amount
                currencyCode
              }
            }
          }
        }
      }
    `,
            variables: {
                input: e
            }
        })
    }

    function rp(e) {
        const t = `merchant/boosterkit/analytics?shop=${e.shop}`;
        return sn(`${Qf.openURL}/${t}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(e.body)
        })
    }

    function ip(e, t) {
        const o = L.getFormattedLanguageCode(),
            n = L.getActiveCountryCode();
        return Eo({}, t) || ln({
            query: `
      query getProductByHandle($handle: String!) @inContext(language: ${o}, country: ${n}) {
        product(handle: $handle) {
          id
          handle
          tags
          availableForSale
          variants(first: 250) {
            nodes {
              id
              availableForSale
              price {
                amount
                currencyCode
              }
            }
          }
          collections(first: 250) {
            nodes {
              id
              handle
            }
          }
        }
      }
    `,
            variables: {
                handle: e
            }
        })
    }

    function ap(e, t) {
        const o = L.getFormattedLanguageCode(),
            n = L.getActiveCountryCode();
        return Eo({}, t) || ln({
            query: `
      query getProductById($id: ID!) @inContext(language: ${o}, country: ${n}) {
        product(id: $id) {
          id
          handle
          tags
          availableForSale
          variants(first: 250) {
            nodes {
              id
              availableForSale
              price {
                amount
                currencyCode
              }
            }
          }
          collections(first: 250) {
            nodes {
              id
              handle
            }
          }
        }
      }
    `,
            variables: {
                id: L.gidProduct(e)
            }
        })
    }

    function sp(e) {
        const t = L.getFormattedLanguageCode(),
            o = L.getActiveCountryCode();
        return ln({
            query: `
      query getProducts($ids: [ID!]!) @inContext(language: ${t}, country: ${o}) {
        nodes(ids: $ids) {
          ...on Product {
            id
            handle
            tags
            availableForSale
            variants(first: 250) {
              nodes {
                id
                availableForSale
                price {
                  amount
                  currencyCode
                }
              }
            }
            collections(first: 250) {
              nodes {
                id
                handle
              }
            }
          }
        }
      }
    `,
            variables: {
                ids: e.map(n => L.gidProduct(n))
            }
        })
    }

    function lp(e) {
        const t = L.getFormattedLanguageCode(),
            o = L.getActiveCountryCode();
        return ln({
            query: `
      query getProductById($id: ID!) @inContext(language: ${t}, country: ${o}) {
        product(id: $id) {
          id
          handle
        }
      }
    `,
            variables: {
                id: L.gidProduct(e)
            }
        })
    }

    function cp(e) {
        const t = L.getFormattedLanguageCode(),
            o = L.getActiveCountryCode();
        return ln({
            query: `
      query getProducts($ids: [ID!]!) @inContext(language: ${t}, country: ${o}) {
        nodes(ids: $ids) {
          ...on Product {
            id
            title
            handle
            featuredImage {
              url
            }
          }
        }
      }
    `,
            variables: {
                ids: e.map(n => L.gidProduct(n))
            }
        })
    }

    function Bl(e) {
        return new Promise(t => {
            fetch(`?sections=${e.join(",")}`).then(o => o.json()).then(o => t(o)).finally(() => t(null))
        })
    }

    function Ul(e, t) {
        return Eo(window.fakeRecommendation, t) || sn(L.insertLocaleToShopLink(`/recommendations/products.js?product_id=${e}`))
    }
    const Yt = (e, t, o = {}) => {
            var s, c;
            const {
                AdminBarInjector: n
            } = window.Shopify || {}, {
                shop: r
            } = window.qbkStore || {}, i = n || document.querySelector(F.ADMIN_BAR_SELECTOR);
            if (!((s = window._BK) != null && s.version) || i || L.isDesignMode() || F.ENV === "development" || !e) return new Promise(l => l(!0));
            if (t.includes("session")) {
                const l = L.getCookie(F.SHOPIFY_SESSION_ANALYTIC_KEY),
                    [f, u] = (c = localStorage.getItem(F.SESSION_ANALYTIC_KEY) || ";") == null ? void 0 : c.split(";"),
                    d = (u == null ? void 0 : u.split(",")) || [],
                    _ = t.split("_").map(O => O[0]).join(""),
                    g = e + _;
                if (l === f && (d != null && d.includes(g))) return new Promise(O => O(!0));
                const h = l !== f ? g : [...d, g].join(",");
                localStorage.setItem(F.SESSION_ANALYTIC_KEY, l + ";" + h)
            }
            const a = {
                shop: r,
                body: {
                    entry_id: e,
                    type: t,
                    data: JSON.stringify({ ...o
                    })
                }
            };
            return new Promise(l => (rp(a), l(!0)))
        },
        jl = e => {
            if (!e) return [];
            const {
                type: t
            } = e;
            return t === S.GiftGoal ? e.tiers_percentage || [] : (e.discount_type === "fixed-amount" ? e.tiers_fixed : e.tiers_percentage) || []
        },
        sa = (e, t) => {
            const {
                measurement: o,
                rewardBarPriority: n
            } = t, r = n == null ? void 0 : n.split(","), i = e;
            return i.sort((a, s) => {
                if (o === "amount" && Number(a.min_subtotal) !== Number(s.min_subtotal)) return Number(a.min_subtotal) - Number(s.min_subtotal);
                if (o === "quantity" && Number(a.min_quantity) !== Number(s.min_quantity)) return Number(a.min_quantity) - Number(s.min_quantity);
                const c = (r == null ? void 0 : r.indexOf(a.type)) || 0,
                    l = (r == null ? void 0 : r.indexOf(s.type)) || 0;
                return c - l
            }), i
        },
        la = {
            getActiveTiers: jl,
            sortTiers: sa,
            smallestFreePlanTier: (e, t) => {
                const {
                    rewardBarPriority: o,
                    measurement: n
                } = t, r = e.reduce((a, s) => {
                    if (!(s.minimum_purchase_type === n)) return a;
                    const l = jl(s).map(f => ({ ...f,
                        type: s.type
                    }));
                    return l.length && a.push(...l), a
                }, []), i = sa(r, {
                    measurement: n,
                    rewardBarPriority: o
                })[0];
                return i ? {
                    type: i.type,
                    value: n === "amount" ? i.min_subtotal : i.min_quantity
                } : null
            },
            extractMinTiers: (e, t) => {
                const {
                    measurement: o
                } = t, n = e.discount_type, r = sa(la.getActiveTiers(e), {
                    measurement: o
                })[0];
                return {
                    tiers_fixed: n === to.FixedAmount ? [r] : [],
                    tiers_percentage: n === to.Percentage ? [r] : []
                }
            }
        },
        up = {
            remove_button_text: "Remove",
            sold_out_button_text: "Sold out",
            out_of_stock_button_text: "Out of stock",
            pick_button_text: "Pick",
            upgrade_button_text: "Upgrade",
            bundle_button_text: "Choose this bundle",
            volume_button_text: "Grab this deal",
            upsurge_button_text: "Upgrade now",
            grab_offer_button_text: "Continue",
            add_more_button_text: "Add {quantity} more",
            total_text: "Total:",
            item_text: "Item",
            free_offer_text: "Free",
            common_error: "Something went wrong!",
            cart_widget_subtotal_original_text: "Subtotal (original)",
            cart_widget_subtotal_text: "Subtotal",
            cart_widget_discount_text: "Discount",
            cart_widget_info_text: "Taxes and shipping calculated at checkout",
            continue_shopping: "Continue Shopping",
            checkout_button_text: "Checkout",
            not_enough_quantity_error: "Buy {quantity} more to get free gift",
            selected_items_text: "{selected_items} selected items",
            package_deal_reward_message: "You're {amount} away from discounts {discount}",
            package_deal_reward_label: "Package deal",
            package_deal_reward_done_message: "Congratulation! You unlock a discount. Checkout now!",
            buy_more_to_get_gift_text: "Buy <strong>{amount}</strong> more to get",
            today_offer_label: "🔥 Today Offers",
            today_offer_description: "Limited-time savings inside. Don't miss out!",
            claim_button_text: "Claim",
            today_offer_item_description: "Get <b>{offer_title}</b> for <strong>{discount} OFF</strong> with {trigger_title}",
            today_offer_free_gift_description: "Get <b>{offer_title}</b> for <strong> FREE </strong> with {trigger_title}",
            discount_toast_label: "Discount applied!",
            promotion_badge_label: "SPECIAL",
            free_gift_promotion_badge_label: "FREE GIFT",
            day_label: "days",
            hour_label: "hrs",
            minute_label: "mins",
            second_label: "secs",
            co_volume_confirm: "Confirm"
        },
        dp = {
            hide_watermark: !1,
            popup_background_color: "#ffffff",
            popup_text_primary_color: "#000000",
            embed_bundle_layout: "vertical",
            embed_bogo_layout: "vertical",
            highlight_color: "#3847D1",
            button_primary_bg_color: "#3847D1",
            button_primary_text_color: "#FFFFFF",
            button_secondary_bg_color: "#FDE991",
            button_secondary_text_color: "#000000",
            popup_limit_offers: 5,
            popup_offer_priority_type: Gr.Random,
            repeater_value: 30,
            repeat_popup: !1,
            recommended_rules: ra.Random,
            reward_bar_priority: [S.OrderGoal, S.GiftGoal, S.ShippingGoal].join(","),
            reward_bar_measurement_unit: Gn.PurchaseAmount,
            enable_promotion_badge: !1,
            enable_today_offers: !1,
            seasonal_template: ""
        },
        fp = {},
        ca = ["basic", "professional", "unlimited", "shopify_plus"],
        pp = 30 * 24 * 60 * 60 * 1e3,
        bp = "2025-04-01 03:30:00",
        cn = {
            isPricingByShopifyPlan: () => {
                var e, t;
                return /boosterkit-shop_[^_]/.test((t = (e = window._BK) == null ? void 0 : e.subscriptions) == null ? void 0 : t.name)
            },
            checkIfShopifyPlanChange: e => {
                var i, a;
                const t = (((i = window._BK) == null ? void 0 : i.shop) || {}).plan_name || "",
                    o = (((a = window._BK) == null ? void 0 : a.subscriptions) || {}).applied_shopify_plans || [];
                if (!(o != null && o.length) || o.includes(t)) return !1;
                const n = (s, c, l) => {
                        const f = ca.indexOf(s),
                            u = ca.indexOf(c);
                        return l === "upgrade" ? f > u : f < u
                    },
                    r = o == null ? void 0 : o.find(s => ca.includes(s));
                return n(t, r, e)
            },
            isInShopifyPlanUpgradeExtendedTime: () => {
                var n;
                const e = ((n = window._BK) == null ? void 0 : n.shop) || {};
                if (!(e != null && e.plan_updated_at)) return !1;
                const t = new Date,
                    o = new Date(L.formatAsUTC(e.plan_updated_at));
                return t.getTime() - o.getTime() <= pp
            }
        },
        wo = J(dp),
        ua = J(up),
        un = J([]),
        Br = J({}),
        zl = J({}),
        Mn = J({}),
        Ur = J();

    function ze() {
        const {
            setProductData: e
        } = Nt(), t = () => {
            const d = L.getThemeName(),
                _ = Object.keys(Ml).find(g => new RegExp(g, "gi").test(d));
            Br.value = _ && Ml[_] || {}
        }, o = q(() => {
            var d;
            return (d = un.value) == null ? void 0 : d.map(_ => _.discount_code || _.discount_title)
        }), n = q(() => {
            var d;
            return (d = un.value) == null ? void 0 : d.some(_ => _.type === S.FreeGift)
        }), r = q(() => {
            var d, _;
            return !((_ = (d = window == null ? void 0 : window._BK) == null ? void 0 : d.entries) != null && _.length) || a.value
        }), i = q(() => {
            var d;
            return ((d = Mn.value) == null ? void 0 : d.name) === Lt.Premium || cn.isPricingByShopifyPlan()
        }), a = q(() => {
            var C;
            const {
                name: d,
                conversion_revenue_expires_at: _,
                over_capacity: g,
                subscription_status: h
            } = Mn.value || ((C = window == null ? void 0 : window._BK) == null ? void 0 : C.subscriptions) || {};
            if (h === 4) return L.log("Paused subscription"), !0;
            if (![Lt.FreeLimitUsage, Lt.FreeAll].includes(d) || !_) return !1;
            const O = new Date().getTime();
            return new Date(_).getTime() <= O ? !1 : g
        }), s = () => {
            const {
                repeat_popup: d,
                repeater_value: _
            } = wo.value;
            let g = 0;
            d && _ && (g = new Date().getTime() + _ * 6e4), g && localStorage.setItem(F.POPUP_EXPIRE_TIME, g.toString()), u()
        }, c = () => {
            var A, K;
            const d = L.getActiveLanguageCode(),
                {
                    instanceConfig: _,
                    entries: g,
                    generalTranslation: h,
                    bogoTranslation: O,
                    bundleTranslation: b,
                    orderGoalTranslation: C,
                    subscriptions: E,
                    cartUpsellTranslation: x,
                    volumeTranslation: N,
                    freeGiftTranslation: w,
                    upsurgeTranslation: D,
                    shippingGoalTranslation: P,
                    giftGoalTranslation: I
                } = window._BK || {};
            wo.value = { ...wo.value,
                ...(_ == null ? void 0 : _.boosterkit_settings) || {}
            };
            const $ = (g || []).filter(ae => ae.discount_id),
                oe = cn.checkIfShopifyPlanChange("upgrade");
            if (cn.isPricingByShopifyPlan() && oe && !cn.isInShopifyPlanUpgradeExtendedTime() && !L.isDesignMode()) un.value = [];
            else if ((E == null ? void 0 : E.name) === Lt.Free && !L.isDesignMode()) {
                const ae = (A = wo.value) == null ? void 0 : A.free_plan_active_entry;
                let B;
                if (ae) B = ae && $.find(R => ae === "reward-bar" ? Gt.rewardBarEntries.includes(R.type) : R.id === ae);
                else {
                    const R = $.find(ie => Gt.entryByPlan[Lt.Free].includes(ie.type));
                    B = R;
                    const U = ![S.Bogo, S.Bundle, S.Upsurge].includes(R == null ? void 0 : R.type);
                    if (R && U) {
                        const ie = new Date(R.created_at),
                            _e = new Date(bp);
                        if (ie < _e) {
                            const he = $.find(Ce => ["bogo", "bundle", "upsurge"].includes(Ce.type));
                            B = he != null && he.id ? he : null
                        }
                    }
                }
                if (Gt.rewardBarEntries.includes(B == null ? void 0 : B.type)) {
                    const R = wo.value.reward_bar_measurement_unit,
                        U = wo.value.reward_bar_priority,
                        ie = $.filter(Ce => Gt.rewardBarEntries.includes(Ce.type)),
                        _e = la.smallestFreePlanTier(ie, {
                            measurement: R,
                            rewardBarPriority: U
                        }),
                        he = _e && ie.find(Ce => Ce.type === _e.type);
                    if (he) {
                        const Ce = la.extractMinTiers(he, {
                            measurement: R
                        });
                        B = { ...he,
                            ...Ce
                        }
                    }
                }
                un.value = B ? [B] : []
            } else un.value = $;
            u(), e(((K = window == null ? void 0 : window.qbkStore) == null ? void 0 : K.productData) || {}), Mn.value = E || {}, ua.value = { ...ua.value,
                ...h && h.default || {},
                ...h && h[d] || {}
            }, zl.value = { ...L.mapTranslation(O),
                ...L.mapTranslation(b),
                ...L.mapTranslation(C),
                ...L.mapTranslation(x),
                ...L.mapTranslation(N),
                ...L.mapTranslation(w),
                ...L.mapTranslation(D),
                ...L.mapTranslation(P),
                ...L.mapTranslation(I)
            }, t()
        }, l = (d, _) => {
            const g = L.getOptions();
            return _ ? [...F[d] || [], ...Br.value[d] || [], ...g[d] || []] : g[d] ? ? Br.value[d] ? ? F[d]
        }, f = d => {
            var g, h;
            if (i.value || L.isDesignMode()) return !0;
            const _ = ((g = Mn.value) == null ? void 0 : g.name) || "";
            return (h = Gt.entryByPlan[_]) == null ? void 0 : h.includes(d)
        }, u = () => {
            const d = new Date,
                _ = localStorage.getItem(F.POPUP_EXPIRE_TIME) || 0;
            if (_) {
                if (!wo.value.repeat_popup) {
                    localStorage.removeItem(F.POPUP_EXPIRE_TIME), Ur.value = !1;
                    return
                }
                if (parseInt(_) > d.getTime()) {
                    Ur.value = !0;
                    return
                }
                localStorage.removeItem(F.POPUP_EXPIRE_TIME)
            }
            Ur.value = !1
        };
        return {
            init: c,
            settings: wo,
            entries: un,
            getConfig: l,
            contents: ua,
            extensionContents: zl,
            themeSettings: Br,
            subscriptions: Mn,
            isExpired: a,
            isFrozenApp: r,
            setExpireTime: s,
            isShowPopupOneTime: Ur,
            isPremium: i,
            isExtensionAvailableInPlan: f,
            hasActiveFreeGift: n,
            bkCodes: o
        }
    }

    function jr(e) {
        const {
            entries: t,
            getConfig: o,
            isFrozenApp: n,
            isExtensionAvailableInPlan: r
        } = ze(), {
            alreadyInCartVariants: i,
            cart: a,
            isCartEmpty: s
        } = kt(), {
            combineProduct: c,
            isDiscountReady: l,
            appliedEntryIds: f,
            combineRewardBar: u
        } = wt(), {
            isPassConditions: d
        } = jn(), {
            getProductData: _,
            collectProducts: g
        } = Nt(), h = q(() => {
            var w;
            return (w = t.value) == null ? void 0 : w.some(D => [S.OrderGoal, S.ShippingGoal, S.GiftGoal].includes(D.type))
        }), O = q(() => t.value.some(w => w.type === S.GiftGoal)), b = q(() => {
            var w;
            return (w = t.value) == null ? void 0 : w.some(D => D.type === S.CartUpsell || D.type === S.Upsurge)
        }), C = q(() => !e || !e.value.triggerId || !(e.value.productId || e.value.handle) || !e.value.type || n.value || !l.value ? [] : N(e.value, t.value.filter(w => w.type === e.value.type))), E = async () => {
            var D;
            const w = t.value.find(P => P.type === S.GiftGoal && P.mode === ct.Auto);
            if (w) {
                const P = (D = w == null ? void 0 : w.tiers_percentage) == null ? void 0 : D.reduce((I, $) => {
                    var oe;
                    return (oe = $ == null ? void 0 : $.offer_product_data) == null || oe.forEach(A => {
                        I.includes(A.id) || I.push(A.id)
                    }), I
                }, []);
                await g(P)
            }
        }, x = () => {
            const w = (a.value.items || []).filter(P => {
                const {
                    [F.TRIGGER_ID_PROPERTY]: I, [F.TIER_PROPERTY]: $
                } = P.properties || {};
                return !$ && !I && !(i.value[P.id] || []).some(oe => [S.Bogo, S.CartUpsell].includes(oe.type))
            });
            L.log("useOffer: valid trigger items of cart", w);
            const D = t.value.filter(P => u.value.isDiscountApplied ? P.type === S.CartUpsell : [S.CartUpsell, S.Upsurge].includes(P.type));
            return w.reduce((P, I) => {
                var A;
                const $ = {
                        handle: I.handle,
                        productId: I.product_id.toString(),
                        triggerId: I.id.toString(),
                        triggerAction: Tt.Checkout
                    },
                    oe = P.map(K => K.id);
                if (oe.length < D.length) {
                    const K = (A = i.value[I.id]) == null ? void 0 : A.some(B => B.type === S.FreeGift),
                        ae = N($, D.filter(B => B.type === S.Upsurge ? !K : !oe || !oe.includes(B.id)));
                    P.push(...ae.map(B => ({ ...B,
                        triggerHandle: $.handle,
                        triggerId: $.triggerId,
                        triggerKey: I.key
                    })))
                }
                return P
            }, [])
        }, N = ({
            handle: w,
            triggerId: D,
            productId: P,
            triggerAction: I
        }, $) => {
            var ae;
            if (n.value) return L.log("useOffer: frozen app"), [];
            if (!l.value) return L.log("useOffer: discount not ready"), [];
            const oe = _(P, w);
            if (!oe) return L.log("useOffer: no product data"), [];
            const A = (ae = oe.variants) == null ? void 0 : ae.find(B => B.id.toString() === D);
            L.log("useOffer: handle - triggerId", w, D, oe);
            const K = ($ || t.value).filter(B => {
                var j;
                const {
                    id: re,
                    type: R,
                    trigger_type: U,
                    trigger_data_tags: ie,
                    trigger_data_collections: _e,
                    trigger_data_products: he,
                    trigger_data_excludes: Ce,
                    enable_trigger_data_collection_excludes: we,
                    trigger_data_collection_excludes: ke,
                    starts_at: Oe,
                    ends_at: Ve,
                    enable_ends_at: Ae,
                    allow_receive_once: We,
                    discount_usage_limit: Je,
                    enable_discount_usage_limit: De,
                    async_usage_count: Ye
                } = B;
                if (De && Je && Je <= (Ye || 0)) return L.log("useOffer: discount usage limit"), !1;
                if (!r(R)) return L.log(`useOffer: ${R} is not available on current plan`), !1;
                const He = new Date(Oe).getTime(),
                    m = new Date().getTime(),
                    y = Ae && Ve && new Date(Ve).getTime(),
                    V = i.value[+D] || [],
                    Z = f.value.length && f.value.includes(re);
                let Q = !o("allowOfferAlreadyInCart") && Z && V.some(M => M.offerId === re),
                    ee = !d(B, {
                        productPrice: A == null ? void 0 : A.price
                    });
                if (R === S.Volume) {
                    const M = B.trigger_action === Tt.Payment;
                    ee = ee || M, Q = !1
                } else if (R === S.Bogo) {
                    const M = B.trigger_action === Tt.Payment;
                    ee = ee || M, Q = Q || V.some(te => te.type === S.CartUpsell)
                } else if (R === S.FreeGift) {
                    const M = B.enable_once_per_order || o("freeGiftLimitOnePerOrder"),
                        te = u.value.offers || {},
                        W = !s.value && (!c.value.canCombine || c.value.isDiscountApplied && !B.enable_combinations_products || te[S.OrderGoal].isDiscountApplied && !B.enable_combinations_orders || te[S.GiftGoal].isDiscountApplied && !B.enable_combinations_products || te[S.ShippingGoal].isDiscountApplied && !B.enable_combinations_shipping);
                    Q = M && Z || We && Q || !Z && W
                } else if (R === S.Upsurge) {
                    const M = I && ((j = B.trigger_action) == null ? void 0 : j.includes(I));
                    ee = ee || !M
                }
                if (He > m || y && y < m || Q || ee) return L.log("useOffer: Time not right or already got offered", re, R, Q, ee), !1;
                switch (U) {
                    case Ct.All:
                        return !(Ce || []).some(W => W.id === oe.id.toString() && (W.variants === Ft.All || W.variants.includes(D)));
                    case Ct.Tag:
                        return ie && oe.tags.some(te => ie.includes(te));
                    case Ct.Collection:
                        {
                            const te = we && (ke || []).some(W => W.id === oe.id.toString() && (W.variants === Ft.All || W.variants.includes(D)));
                            return _e && oe.collections.some(W => _e.some(de => L.extractId(de) === W.toString())) && !te
                        }
                    case Ct.Specific:
                        const M = R === S.Bundle && o("allowBundleUncheckSpecific");
                        return he && he.some(te => te.id === oe.id.toString() && (M || te.variants === Ft.All || te.variants.includes(D)));
                    default:
                        return !1
                }
            }).map(B => {
                var R;
                let re = B.offer_product_data;
                if (o("filterOfferProductAlreadyInCart") && !s.value && [S.Bogo, S.CartUpsell, S.Upsurge].includes(B.type) && (re = re.filter(U => {
                        var ie;
                        return !((ie = a.value) != null && ie.items.some(_e => +_e.product_id == +U.id))
                    })), [S.CartUpsell, S.FreeGift, S.Upsurge].includes(B.type)) {
                    const U = re.find(ie => ie.id === P || ie.handle === w);
                    U && (oe.variants.length === 1 || ((R = U.variants) == null ? void 0 : R.length) === 1 && U.variants[0] === D) && (re = re.filter(ie => ie.id !== U.id))
                }
                return { ...B,
                    offer_product_data: re
                }
            }).filter(B => !B.offer_product_data || B.offer_product_data.length);
            return L.log("useOffer: mapOffer", K), K
        };
        return {
            offersByType: C,
            getOffers: N,
            hasActiveRewardBar: h,
            getOffersForCart: x,
            hasActiveCheckoutOffer: b,
            hasActiveGiftGoal: O,
            collectAutoGiftData: E
        }
    }
    const Hl = J({}),
        Kl = J(1);

    function da(e, t) {
        const o = J(null),
            n = J(""),
            r = J(null),
            {
                getConfig: i
            } = ze(),
            {
                getVariantInput: a
            } = Ot(),
            s = q(() => Hl.value[n.value] || t || ""),
            c = (g, h) => {
                if (g && (Hl.value[n.value] = g, document.dispatchEvent(new CustomEvent(F.EVENT_VARIANT_CHANGED, {
                        detail: {
                            variantId: g
                        }
                    })), !h)) {
                    const O = document.querySelectorAll(`[${F.POPUP_LISTENER}='false']`);
                    O && O.forEach(b => b.setAttribute(F.POPUP_LISTENER, "true"))
                }
            },
            l = () => r.value && r.value.value,
            f = g => {
                const O = g && g.detail && (g.detail.variant && g.detail.variant.id || g.detail.data && g.detail.data.variantId) || l();
                c(O)
            },
            u = () => {
                var h;
                const g = i("waitForFormUpdated");
                (h = e.value) == null || h.addEventListener("change", () => {
                    setTimeout(f, g)
                })
            },
            d = () => {
                const g = r.value;
                if (g && g.tagName !== "SELECT") {
                    o.value = new MutationObserver(h => {
                        L.log("input variant mutation", h), h.forEach(O => {
                            O.type === "attributes" && O.attributeName === "value" && c(g.value)
                        })
                    }), o.value.observe(g, {
                        attributes: !0
                    });
                    return
                }
                return u()
            };
        return {
            selectedVariantId: s,
            setupVariantChangeListener: () => {
                if (!e.value) return;
                const g = e.value.getAttribute(F.FORM_VARIANT_LISTENER);
                if (g) {
                    n.value = g;
                    return
                }
                const h = `form${Kl.value}`;
                e.value.setAttribute(F.FORM_VARIANT_LISTENER, h), n.value = h, Kl.value += 1;
                const O = i("variantChangeEvent");
                if (O) {
                    const C = i("triggerEventElement") || document,
                        E = i("waitForFormUpdated");
                    C.addEventListener(O, x => {
                        setTimeout(() => f(x), E)
                    });
                    return
                }
                const b = a(e.value);
                b && (r.value = b, d(), c(l(), !0))
            }
        }
    }
    const Bt = J({}),
        fa = J(null);

    function kt() {
        const {
            getConfig: e,
            hasActiveFreeGift: t
        } = ze(), {
            renderCartContents: o
        } = Ot(), n = q(() => Bt.value.original_total_price || 0), r = q(() => Bt.value.items_subtotal_price || 0), i = q(() => (Bt.value.item_count || 0) === 0), a = q(() => {
            var A;
            return (((A = Bt.value) == null ? void 0 : A.items) || []).map(K => {
                const ae = (K.properties || {})[F.OFFER_ID_PROPERTY];
                return ae ? { ...K,
                    properties: { ...K.properties,
                        [F.OFFER_ID_PROPERTY]: +ae
                    }
                } : K
            })
        }), s = q(() => {
            var A, K;
            return ((K = (A = Bt.value) == null ? void 0 : A.attributes) == null ? void 0 : K[F.OFFER_ID_PROPERTY]) || ""
        }), c = q(() => a.value.reduce((A, K) => {
            const {
                [F.TIER_PROPERTY]: ae, [F.OFFER_TYPE_PROPERTY]: B
            } = K.properties || {};
            return (ae || B === S.FreeGift) && (A += K.original_line_price), A
        }, 0)), l = q(() => a.value.reduce((A, K) => {
            const {
                [F.TIER_PROPERTY]: ae, [F.OFFER_TYPE_PROPERTY]: B
            } = K.properties || {};
            return (ae || B === S.FreeGift) && (A += K.quantity), A
        }, 0)), f = q(() => e("isTotalPriceMode") ? r.value : n.value - c.value), u = q(() => Bt.value.item_count - l.value), d = q(() => a.value.reduce((A, K) => {
            const {
                [F.OFFER_ID_PROPERTY]: ae, [F.TRIGGER_ID_PROPERTY]: B, [F.OFFER_TYPE_PROPERTY]: re
            } = K.properties || {};
            if (ae && B) {
                const R = isNaN(+B) ? +B.split("-")[0] : +B;
                A[R] = [...A[R] || [], {
                    offerId: ae,
                    type: re
                }]
            }
            return A
        }, {})), _ = q(() => (Bt.value.items || []).filter(A => {
            var K;
            return (K = A == null ? void 0 : A.properties) == null ? void 0 : K[F.TIER_PROPERTY]
        })), g = q(() => _.value.reduce((A, K) => {
            const ae = K.properties[F.TIER_PROPERTY];
            return A.includes(ae) || A.push(ae), A
        }, [])), h = q(() => {
            const {
                cart_level_discount_applications: A,
                items: K
            } = Bt.value || {}, ae = {
                code: [],
                auto: [],
                all: []
            };
            return [...(K || []).reduce((R, U) => {
                var ie;
                return (ie = U == null ? void 0 : U.line_level_discount_allocations) != null && ie.length && R.push(...U.line_level_discount_allocations.map(_e => _e.discount_application)), R
            }, []), ...A || []].forEach(R => {
                const {
                    title: U,
                    type: ie
                } = R || {};
                ae.all.includes(U) || (ie === "discount_code" ? ae.code.push(U) : ae.auto.push(U), ae.all.push(U))
            }), ae
        }), O = async () => {
            const A = localStorage.getItem(F.COMPLETED_ORDER_TOKEN),
                K = localStorage.getItem(F.STOREFRONT_TOKEN);
            try {
                K && A && A.slice(1, -1) === K && (await tp(), localStorage.removeItem(F.STOREFRONT_TOKEN), window.location.reload())
            } catch (ae) {
                L.log("Cannot clear cart", ae)
            }
        }, b = async () => {
            try {
                const A = await ep();
                return await $(A), Bt.value = A, A
            } catch (A) {
                throw L.log("Cannot fetch cart data", A), new Error("Cannot fetch cart data")
            }
        }, C = () => {
            let A = e("ignoreCartChangeUrl", !0);
            const K = window[F.AKO_SIGNATURE],
                ae = e("debounceCartChangeTimeout") || K && 1e3,
                B = () => document.dispatchEvent(new CustomEvent(F.EVENT_CART_CHANGE)),
                re = ae ? L.debounce(B, ae) : B;
            K && (A = ["update.js", ...A]), new PerformanceObserver(U => {
                U.getEntries().forEach(ie => {
                    const _e = new RegExp(/(\/cart\/(add|change|update|clear)(\.js)?)/),
                        {
                            initiatorType: he,
                            name: Ce
                        } = ie,
                        we = ["xmlhttprequest", "fetch"].includes(he),
                        ke = _e.test(Ce) && !A.some(Oe => Ce.includes(Oe));
                    we && ke && re()
                })
            }).observe({
                entryTypes: ["resource"]
            })
        }, E = async A => {
            const {
                items: K,
                attributes: ae,
                note: B,
                item_count: re
            } = Bt.value;
            if (!re) return;
            const R = {
                note: B,
                lines: K.map(U => ({
                    merchandiseId: L.gidProductVariant(U.id),
                    quantity: U.quantity,
                    ...U.properties && {
                        attributes: L.mapKeyValueObject(U.properties)
                    }
                })),
                discountCodes: A,
                ...ae && {
                    attributes: L.mapKeyValueObject(ae)
                }
            };
            return np(R).then(U => {
                var _e;
                L.log("storeFrontApi cart", {
                    res: U,
                    input: R
                });
                const ie = (_e = U == null ? void 0 : U.cartCreate) == null ? void 0 : _e.cart;
                if (ie) {
                    fa.value = ie;
                    const he = ie.checkoutUrl;
                    localStorage.setItem(F.STOREFRONT_TOKEN, he.split("/").pop())
                }
                return ie
            }).catch(U => L.log("Cant create cart", {
                err: U
            }))
        }, x = () => {
            fa.value = null, localStorage.getItem(F.STOREFRONT_TOKEN) && localStorage.removeItem(F.STOREFRONT_TOKEN)
        }, N = A => {
            var K;
            return A && ((K = (Bt.value.items || []).find(ae => ae.id.toString() === A && (!ae.properties || !ae.properties[F.OFFER_ID_PROPERTY]))) == null ? void 0 : K.quantity) || 0
        }, w = async () => {
            s.value && await aa(null, !0)
        }, D = (A, K) => {
            var ae;
            return (ae = _.value.find(B => +B.id == +A && (B == null ? void 0 : B.properties[F.TIER_PROPERTY]) === K)) == null ? void 0 : ae.key
        }, P = () => {
            const A = JSON.parse(localStorage.getItem(F.GIFT_GOAL_STORAGE) || "{}");
            L.isEmptyObj(A) || (Object.keys(A).forEach(K => {
                if (A[K].isPending || A[K].isRejected) return;
                const ae = A[K].lineItems.reduce((B, re) => (D(re.id, K) && B.push(re), B), []);
                if (!ae.length) {
                    A[K] = {
                        isRejected: !0
                    };
                    return
                }
                A[K].lineItems = ae
            }), localStorage.setItem(F.GIFT_GOAL_STORAGE, JSON.stringify(A)))
        }, I = (A, K, ae) => ae.some(B => {
            const {
                [F.TRIGGER_ID_PROPERTY]: re, [F.OFFER_TYPE_PROPERTY]: R
            } = B.properties || {};
            return A.includes(B.id) && (R === K || [S.CartUpsell].includes(K) && !re || [S.Bogo, S.FreeGift].includes(K) && !R)
        }), $ = async A => {
            if (!A.item_count) return;
            const K = [];
            if (e("enableMissingTriggerChecking") && K.push(S.Bogo, S.Bundle, S.CartUpsell), t.value && K.push(S.FreeGift), !K.length) return;
            const ae = {};
            if (A.items.forEach(B => {
                    const {
                        [F.TRIGGER_ID_PROPERTY]: re, [F.OFFER_TYPE_PROPERTY]: R
                    } = B.properties || {};
                    !K.includes(R) || !re || I(re, R, A.items) || (ae[B.key] = 0)
                }), !L.isEmptyObj(ae)) try {
                L.log("useCart: remove free gift", ae);
                const B = await Mt("/cart/update.js?qbk-free-gift", {
                    body: {
                        updates: ae
                    }
                });
                await o({
                    removeRes: B
                }, () => window.location.reload())
            } catch {
                L.log("useCart: cannot remove free gift")
            }
        };
        return {
            fetchCartData: b,
            cart: Bt,
            cartAttributes: s,
            customCart: fa,
            clearCustomCart: x,
            observeCartChanges: C,
            createCustomCart: E,
            clearCartAfterCheckoutByStorefrontAPI: O,
            alreadyInCartVariants: d,
            subtotal: n,
            totalPrice: r,
            isCartEmpty: i,
            getQuantityInCart: N,
            clearCartAttrs: w,
            currentPrice: f,
            currentQuantity: u,
            giftChecking: P,
            getGiftLineKey: D,
            giftLines: _,
            checkAppliedDiscount: (A, K) => {
                if (!K) return !1;
                switch (A) {
                    case S.ShippingGoal:
                        return !0;
                    default:
                        return h.value.all.includes(K)
                }
            },
            addedGiftTiers: g,
            appliedDiscounts: h,
            cartItems: a
        }
    }
    const xo = J([]),
        Yo = J([]),
        Yl = J([]),
        pa = J({}),
        Wl = J({}),
        Bn = J({}),
        ba = J(!1);

    function wt() {
        const {
            cart: e,
            clearCartAttrs: t,
            checkAppliedDiscount: o,
            isCartEmpty: n,
            appliedDiscounts: r
        } = kt(), {
            entries: i,
            getConfig: a
        } = ze(), {
            isPassConditions: s
        } = jn(), c = async b => {
            var N;
            const C = (N = b.discount) != null && N.length ? b.discount : xo.value,
                E = [...new Set([...r.value.code, ...C, ...Yo.value, ...b.code ? [b.code] : []].sort())].filter(w => !(b.invalidCodes || []).includes(w)).join(","),
                x = d();
            if (L.log("discount", E, x), typeof E == "string" && E !== x) {
                if (Bn.value.isApplied || await t(), await op(E), E === F.DISCOUNT_CLEAR_CODE) {
                    localStorage.setItem(F.DISCOUNT_STORAGE, "");
                    return
                }
                localStorage.setItem(F.DISCOUNT_STORAGE, E)
            }
        }, l = (b, C) => {
            Yo.value = [...new Set([...Yo.value.filter(E => E !== C), ...typeof b == "string" ? [b] : b])]
        }, f = b => {
            Yo.value.length && (Yo.value = Yo.value.filter(C => b ? C !== b : !xo.value.includes(C)))
        }, u = b => {
            b && (xo.value = b, c({
                discount: b
            }))
        }, d = () => localStorage.getItem(F.DISCOUNT_STORAGE) || "", _ = () => {
            var I;
            const {
                items: b,
                attributes: C
            } = e.value;
            if (n.value) {
                u([]), pa.value = {}, ba.value = !0;
                return
            }
            const E = ((I = C[F.OFFER_ID_PROPERTY]) == null ? void 0 : I.split(",").map($ => +$)) || [],
                x = {
                    offers: {
                        [S.OrderGoal]: {
                            id: 0,
                            canCombineProduct: !0,
                            canCombineShipping: !0,
                            code: ""
                        },
                        [S.GiftGoal]: {
                            id: 0,
                            canCombineProduct: !0,
                            canCombineOrder: !0,
                            canCombineShipping: !0,
                            code: ""
                        },
                        [S.ShippingGoal]: {
                            id: 0,
                            canCombineProduct: !0,
                            canCombineOrder: !0,
                            code: ""
                        }
                    },
                    isApplied: !1,
                    activeIds: [],
                    activeCodes: [],
                    isDiscountApplied: !1
                },
                N = {
                    codes: [],
                    variants: {},
                    entryIds: [],
                    canCombineProduct: !0,
                    canCombineOrder: !0,
                    canCombineShipping: !0
                },
                w = x.offers;
            E.length && (E.forEach($ => {
                const oe = i.value.find(B => B.id === $);
                if (!oe || !oe.enable_discount) return;
                const A = oe.discount_method === Lr.Code && oe.discount_code,
                    K = o(oe.type, A || oe.discount_title),
                    ae = w[oe.type];
                ae && (ae.id = $, ae.code = A || "", ae.isDiscountApplied = K, ae.canCombineProduct = !!oe.enable_combinations_products || !K, ae.canCombineOrder = !!oe.enable_combinations_orders || !K, ae.canCombineShipping = !!oe.enable_combinations_shipping || !K, x.isApplied = !0, x.activeIds.push($), A && x.activeCodes.push(A))
            }), x.isDiscountApplied = Object.values(w).some($ => $.isDiscountApplied));
            const D = Object.values(w).every($ => $.canCombineProduct);
            D && (b.reduce(($, oe) => {
                const {
                    [F.OFFER_ID_PROPERTY]: A
                } = oe.properties || {};
                if (!A || !oe.discounts.length) return $;
                const K = i.value.find(B => B.id === +A);
                return !K || Object.keys(w).includes(K.type) ? $ : $.entryIds.some(B => B === K.id) ? ($.variants[oe.id] = [...$.variants[b.id] || [], K.id], $) : (oe.discounts.some(B => B.title === (K.discount_code || K.discount_title)) && (K.discount_code && $.codes.push(K.discount_code), $.variants[oe.id] = [...$.variants[b.id] || [], K.id], $.canCombineProduct = $.canCombineProduct && K.enable_combinations_products, $.canCombineOrder = $.canCombineOrder && K.enable_combinations_orders, $.canCombineShipping = $.canCombineShipping && K.enable_combinations_shipping, $.entryIds.push(K.id)), $)
            }, N), pa.value = N.variants), L.log("collect discounts", {
                rewardBarDiscount: x,
                productDiscounts: N,
                canRewardBarCombineProduct: D
            });
            const P = [...N.codes, ...x.activeCodes];
            Yl.value = [...N.entryIds, ...x.activeIds], Wl.value = { ...N,
                canCombine: D && N.canCombineProduct,
                isDiscountApplied: !!N.entryIds.length
            }, Bn.value = { ...x,
                canCombineProduct: D
            }, u(P), ba.value = !0, f()
        }, g = () => {
            document.querySelectorAll(a("checkoutFormSelector")).forEach(C => {
                let E;
                try {
                    E = new URL(C.action)
                } catch {
                    E = new URL(C.action, window.location.origin)
                }
                E.searchParams.set("discount", xo.value.join(",")), C.action = E
            })
        }, h = async () => {
            const b = {};
            if (e.value.items.forEach(C => {
                    const {
                        [F.TIER_PROPERTY]: E
                    } = C.properties || {};
                    E && (b[C.key] = 0)
                }), !L.isEmptyObj(b)) try {
                L.log("useCart: remove gift goal", b), await Mt("/cart/update.js?qbk-ignore", {
                    body: {
                        updates: b
                    }
                })
            } catch {
                L.log("useCart: cannot remove gift goal")
            }
        };
        return {
            discounts: xo,
            tempDiscounts: Yo,
            collectDiscounts: _,
            getCurrentDiscounts: d,
            alreadyApplyDiscountVariants: pa,
            combineProduct: Wl,
            combineRewardBar: Bn,
            appliedEntryIds: Yl,
            setupDiscounts: g,
            updateDiscount: c,
            removeDiscountByDisplayCondition: async b => {
                const C = xo.value.filter(P => {
                        const I = i.value.find($ => $.discount_code === P);
                        return I && !s(I)
                    }),
                    E = (Bn.value.activeIds || []).filter(P => {
                        const I = i.value.find($ => $.id === P);
                        return I && s(I)
                    }),
                    x = !!C.length,
                    N = E.length !== (Bn.value.activeIds || []).length,
                    w = C.length === xo.value.length;
                if (x && (L.log("update codes by display condition :: ", xo.value, C), await c({
                        discount: w ? [F.DISCOUNT_CLEAR_CODE] : void 0,
                        invalidCodes: C
                    })), N) {
                    L.log("remove codes by display condition :: ", E), await aa(E.length ? E.join(",") : null, !0);
                    const P = i.value.find(I => I.type === S.GiftGoal);
                    P && !E.includes(P.id) && await h()
                }(x || N) && b && b()
            },
            isDiscountReady: ba,
            updateTempDiscounts: l,
            clearTempDiscount: f
        }
    }
    const Un = J({});

    function Ot() {
        const {
            isShowPopupOneTime: e,
            getConfig: t
        } = ze(), {
            collectProductData: o
        } = Nt(), n = (b, C) => {
            !b || !C || (Un.value[b] = [...Un.value[b] || [], C])
        }, r = b => !b || (Un.value[b] || []).length >= F.EXTENSIONS.length, i = (b, C) => {
            var E;
            return b && C && ((E = Un.value[b]) == null ? void 0 : E.includes(C))
        }, a = (b, C) => {
            if (!b) return;
            const E = b.querySelector(C);
            if (!E) {
                const N = `[form="${b.getAttribute("id")}"]${C}`;
                return document.querySelector(N)
            }
            return E
        }, s = b => a(b, t("selectedVariantIdSelector")), c = b => a(b, t("quantitySelector")), l = (b, C, E) => {
            if (b.getAttribute(C)) return;
            const {
                parentNode: x
            } = b, N = t("bindingEvents"), w = t("isTriggerPopupOneTime"), D = t("ignoreBtnClasses");
            b.setAttribute(C, "true"), N.forEach(P => {
                x == null || x.addEventListener(P, function(I) {
                    const $ = I.target,
                        oe = $ === b ? $ : $.closest(`[${C}]`);
                    oe && (D != null && D.length && D.some(A => oe.classList.contains(A)) || e.value || t("ignoreInitPopup") || ((!w || !C.includes("popup")) && I.isTrusted || (oe == null ? void 0 : oe.getAttribute(C)) === "true") && (I.preventDefault(), I.stopImmediatePropagation(), I.stopPropagation(), oe.setAttribute(C, "false"), E(), L.log("useSetup: Our function has been executed", C)))
                }, {
                    once: !1,
                    capture: !0
                })
            })
        }, f = b => {
            let C = null,
                E = null;
            const x = t("atcFormExcludeSelector");
            if (b && (C = document.querySelector(`${b}${x}`)), !C) {
                const N = t("atcFormSelector");
                C = document.querySelector(`${N}${x}`)
            }
            return C && (E = C.querySelector(t("atcSubmitSelector"))), {
                form: C,
                btn: E
            }
        }, u = b => {
            var D;
            const {
                form: C,
                getTriggerId: E,
                getProductId: x,
                getTriggerBtn: N,
                includeFreeGift: w
            } = b || {};
            if (!(C != null && C.getAttribute(F.FORM_LISTENER))) {
                const P = N ? N(C) : C.querySelector(t("atcSubmitSelector"));
                if (!P) return;
                const I = x ? x(C) : (D = C.querySelector(t("productIdSelector"))) == null ? void 0 : D.value;
                L.log("useSetup: all atc form", I), o({
                    id: I
                });
                const $ = () => {
                    var A;
                    const oe = E ? E(C) : (A = C.querySelector(t("selectedVariantIdSelector"))) == null ? void 0 : A.value;
                    L.log("show atc popup", oe), document.dispatchEvent(new CustomEvent(F.EVENT_OPEN_POPUP, {
                        detail: {
                            product: {
                                productId: I,
                                triggerId: oe
                            },
                            action: Tt.AddToCart,
                            element: P,
                            includeFreeGift: w
                        }
                    }))
                };
                l(P, F.POPUP_LISTENER, $), C.setAttribute(F.FORM_LISTENER, "true")
            }
        }, d = b => {
            const C = t("atcFormExcludeSelector"),
                E = t("atcFormSelector"),
                x = document.querySelectorAll(`${E}${C}`);
            x && x.forEach(N => u({
                form: N,
                ...b || {
                    includeFreeGift: !0
                }
            }))
        }, _ = async () => {
            const b = t("updateThemeCart");
            if (b) {
                b();
                return
            }
            const C = document.querySelector("cart-items"),
                E = document.querySelector("cart-drawer");
            if (C || E) {
                const x = [...C ? ["main-cart-items"] : [], ...E ? ["cart-drawer"] : []],
                    N = await Bl(x);
                if (!N) return;
                if (C) {
                    const D = new DOMParser().parseFromString(N["main-cart-items"], "text/html").querySelector("cart-items");
                    D && (C.innerHTML = D.innerHTML)
                }
                if (E) {
                    const w = new DOMParser().parseFromString(N["cart-drawer"], "text/html"),
                        D = "cart-drawer-items",
                        P = document.querySelector(D),
                        I = w.querySelector(D);
                    I && P && P.replaceWith(I)
                }
            }
        }, g = async b => {
            var E, x;
            if (t("bundleStayOnPage")) {
                const N = t("renderCartContents");
                return await (N == null ? void 0 : N(b)), !0
            }
            if (window.QIKIFY_STICKYCART_V2_LOADED) return !0;
            const C = document.querySelector(t("drawerSelector"));
            if (C && C.renderContents) {
                await L.delay(1e3);
                const N = (((E = C.getSectionsToRender) == null ? void 0 : E.call(C)) || []).map(D => D.section || D.id),
                    w = await Bl(N);
                return C.renderContents({ ...b,
                    sections: w
                }), C.classList.contains("is-empty") ? C.classList.remove("is-empty") : ((x = b == null ? void 0 : b.removeRes) == null ? void 0 : x.item_count) === 0 && C.classList.add("is-empty"), !0
            }
            return !1
        };
        return {
            setupListener: l,
            getAtcListener: f,
            renderCartContents: async (b, C) => {
                if (await g(b)) {
                    document.dispatchEvent(new CustomEvent(F.EVENT_CART_CHANGE));
                    return
                }
                if (await L.delay(300), C) {
                    C();
                    return
                }
                L.gotoCartPage()
            },
            updateEmbeddedOffers: n,
            isAllExtensionsEmbedded: r,
            embeddedOffers: Un,
            isOfferEmbed: i,
            setupTriggerDrawerListener: () => {
                const b = t("triggerDrawerSelector"),
                    C = document.querySelectorAll(b);
                C && C.forEach(E => {
                    E.addEventListener("click", () => setTimeout(() => {
                        document.dispatchEvent(new CustomEvent(F.EVENT_CHECKOUT_LISTENER))
                    }, t("waitForDrawerLoadedTimeout")))
                })
            },
            getVariantInput: s,
            getQuantityInput: c,
            updateThemeCart: g,
            updateThemeCartItems: _,
            setupAllAtcListener: d,
            setupAtcListener: u
        }
    }

    function zr(e) {
        const {
            combineProduct: t,
            appliedEntryIds: o,
            combineRewardBar: n
        } = wt(), {
            isCartEmpty: r
        } = kt(), i = q(() => e && a(e.value)), a = c => {
            const {
                id: l,
                enable_discount: f,
                discount_type: u,
                discount_value_percentage: d,
                discount_value_fixed: _,
                enable_combinations_products: g,
                enable_combinations_orders: h,
                enable_combinations_shipping: O
            } = c, b = u === to.FixedAmount ? _ : d, C = o.value.length && o.value.includes(l), E = f && Number(b);
            if (C || r.value) return E;
            const x = n.value.offers || {};
            return !t.value.canCombine || t.value.isDiscountApplied && !g || x[S.OrderGoal].isDiscountApplied && !h || x[S.GiftGoal].isDiscountApplied && !g || x[S.ShippingGoal].isDiscountApplied && !O ? !1 : E
        };
        return {
            haveDiscount: i,
            checkDiscount: a,
            getOfferPrice: (c, l) => {
                var u;
                const f = l && a(l);
                if (((l == null ? void 0 : l.type) || ((u = e == null ? void 0 : e.value) == null ? void 0 : u.type)) === S.GiftGoal) return 0;
                if ((i.value || f) && c) {
                    const {
                        discount_value_fixed: d,
                        discount_value_percentage: _,
                        discount_type: g
                    } = l || e && e.value;
                    let h = oo.convertMoney(d || 0, !0);
                    g === to.Percentage && _ && (h = c * (_ / 100));
                    const O = c - h;
                    return O > 0 ? O : 0
                }
                return c
            }
        }
    }
    const _a = J({}),
        ma = J({}),
        Wo = J({}),
        _p = J({}),
        mp = J({});

    function Nt() {
        const e = (l, f) => {
                if (l) {
                    if (!f) {
                        delete _a.value[l];
                        return
                    }
                    _a.value[l] = f
                }
            },
            t = l => {
                var f;
                return ma.value[l] || ((f = Wo.value[l]) == null ? void 0 : f.handle)
            };
        return {
            handles: ma,
            promoteFreeGift: _a,
            setPromoteFreeGift: e,
            collectProductHandle: async l => {
                if (!l) return;
                const f = t(l);
                if (f) return f;
                const u = await lp(l);
                if (u != null && u.product) {
                    const {
                        id: d,
                        handle: _
                    } = u.product, g = L.extractId(d);
                    if (g) return ma.value[g] = _, _
                }
            },
            setProductData: l => {
                Wo.value = l
            },
            getProductData: (l, f, u) => {
                if (u && f) return window.fakeProduct[f];
                let d = l && Wo.value[l];
                return !d && f ? Object.values(Wo.value).find(_ => _.handle === f) : d
            },
            collectProductData: async ({
                id: l,
                handle: f
            }) => {
                var _, g;
                if (!l && !f) return;
                const u = l || f,
                    d = Wo.value;
                if (!d[u]) {
                    const h = l ? await ap(u) : await ip(u);
                    if (h != null && h.product) {
                        const O = L.extractId(h.product.id);
                        d[u] = { ...h.product,
                            id: O,
                            available: h.product.availableForSale,
                            variants: (((_ = h.product.variants) == null ? void 0 : _.nodes) || []).map(b => {
                                var C;
                                return {
                                    id: L.extractId(b.id),
                                    price: oo.convertMoney((C = b.price) == null ? void 0 : C.amount, !0),
                                    available: b.availableForSale
                                }
                            }),
                            collections: (((g = h.product.collections) == null ? void 0 : g.nodes) || []).map(b => L.extractId(b.id))
                        }
                    }
                }
                return d[u]
            },
            getHandle: t,
            collectProducts: async l => {
                var _;
                if (!(l != null && l.length)) return;
                const f = Wo.value,
                    u = Object.keys(f),
                    d = l.filter(g => !u.includes(g));
                if (d.length) {
                    const g = await sp(d);
                    (_ = g == null ? void 0 : g.nodes) != null && _.length && (g.nodes.forEach(h => {
                        var b, C;
                        if (!h) return;
                        const O = L.extractId(h.id);
                        f[O] = { ...h,
                            available: h.availableForSale,
                            id: O,
                            variants: (((b = h.variants) == null ? void 0 : b.nodes) || []).map(E => {
                                var x;
                                return {
                                    id: L.extractId(E.id),
                                    price: oo.convertMoney((x = E.price) == null ? void 0 : x.amount, !0),
                                    available: E.availableForSale
                                }
                            }),
                            collections: (((C = h.collections) == null ? void 0 : C.nodes) || []).map(E => L.extractId(E.id))
                        }
                    }), Wo.value = f)
                }
            },
            collectRenderedProduct: async (l, f) => {
                if (!l) return;
                const u = _p.value;
                if (u[l]) return u[l];
                try {
                    const d = await Xf(l, f);
                    return u[l] = d, d
                } catch (d) {
                    L.log("Cannot fetch product", d);
                    return
                }
            },
            collectRecommendProduct: async (l, f) => {
                if (f) return await Ul("portal", f);
                if (!l) return;
                const u = mp.value;
                if (u[l]) return u[l];
                try {
                    const d = await Ul(l, f);
                    return u[l] = d, d
                } catch (d) {
                    L.log("Cannot fetch recommendation products", d);
                    return
                }
            }
        }
    }

    function jn() {
        const {
            cart: e,
            currentQuantity: t
        } = kt(), {
            customer: o,
            country: n,
            market: r
        } = (window == null ? void 0 : window.qbkStore) || {}, i = ({
            conditionValue: c,
            operator: l,
            value: f
        }) => l === "greater" ? f > +c : l === "greater-equal" ? f >= +c : l === "lower" ? f < +c : l === "lower-equal" ? f <= +c : !1, a = (c, l) => {
            const {
                type: f,
                operator: u,
                value: d
            } = c;
            if (typeof d != "number" && (!d || !(d != null && d.length))) return !0;
            let _ = !1;
            switch (f) {
                case "product-price":
                    {
                        if (!l) return !0;_ = i({
                            conditionValue: oo.convertMoney(d, !0),
                            operator: u,
                            value: l.productPrice || 0
                        });
                        break
                    }
                case "cart-total":
                    {
                        _ = i({
                            conditionValue: oo.convertMoney(d, !0),
                            operator: u,
                            value: e.value.total_price
                        });
                        break
                    }
                case "cart-quantity":
                    {
                        _ = i({
                            conditionValue: d,
                            operator: u,
                            value: t.value
                        });
                        break
                    }
                case "customer-login":
                    {
                        _ = d === "false" && !o || d === "true" && !!o;
                        break
                    }
                case "customer-tags":
                    {
                        _ = o == null ? void 0 : o.tags.some(g => d.includes(g));
                        break
                    }
                case "customer-new":
                    {
                        _ = d === "false" && (o == null ? void 0 : o.orderCount) > 0 || d === "true" && (!o || o.orderCount === 0);
                        break
                    }
                case "customer-country":
                    {
                        _ = d.map(h => h.toLowerCase()).includes(n == null ? void 0 : n.toLowerCase());
                        break
                    }
                case "markets":
                    {
                        _ = d.some(g => L.extractId(g.id) === r);
                        break
                    }
            }
            return (u === "not-in" || u === "not") && (_ = !_), _
        };
        return {
            isPassConditions: (c, l) => {
                const {
                    enable_display_conditions: f
                } = c, {
                    type: u,
                    conditions: d
                } = c.display_conditions || {};
                return !f || !(d != null && d.length) ? !0 : u === "or" ? d.some(_ => a(_, l)) : d.every(_ => a(_, l))
            }
        }
    }
    let Co = J();
    const {
        getConfig: gp
    } = ze();

    function Hr() {
        const e = q(() => {
            var n;
            return (n = Co == null ? void 0 : Co.value) == null ? void 0 : n.getAttribute("id")
        });
        return {
            setForm: n => {
                Co.value = n
            },
            getCustomProperties: () => {
                if (!(Co != null && Co.value) || !gp("useCustomProperties")) return {};
                const n = `input[form="${e.value}"][name^="properties["]`,
                    r = 'input[name^="properties["]';
                return [...Array.from(document.querySelectorAll(n)), ...Array.from(Co.value.querySelectorAll(r))].reduce((s, c) => {
                    var f;
                    const l = (f = c.name.match(/\[(.*)\]/)) == null ? void 0 : f.pop();
                    return l ? { ...s,
                        [l]: c.value
                    } : s
                }, {})
            }
        }
    }

    function ga(e) {
        const t = J(0),
            o = q(() => t.value),
            n = q(() => t.value < e.value - 1);
        return {
            activeIndex: t,
            prevActive: o,
            nextActive: n,
            navigate: (i, a) => {
                i === "prev" && !o.value || i === "next" && !n.value || (t.value = i === "next" ? t.value + 1 : t.value - 1, a == null || a())
            }
        }
    }

    function ut(e) {
        var r;
        const t = L.getOptions();
        if (t.formatMoney) return t.formatMoney(e);
        const o = t.moneyFormat || ((r = window == null ? void 0 : window.qbkStore) == null ? void 0 : r.moneyFormat);
        let n = oo.formatMoney;
        return window.Currency && window.Currency.formatMoney && (n = window.Currency.formatMoney), n(+e, o)
    }

    function To(e) {
        if (!e) return e;
        const t = document.createElement("span");
        return e.replace(/&[#A-Za-z0-9]+;/gi, o => (t.innerHTML = o, t.innerText))
    }

    function ha(e) {
        return e && e.replace(/<[^>]+>/g, "")
    }

    function Kr(e, t) {
        const o = {
                pico: "16x16",
                icon: "32x32",
                thumb: "50x50",
                small: "100x100",
                compact: "160x160",
                medium: "240x240",
                large: "480x480",
                grande: "600x600",
                original: "1024x",
                master: ""
            },
            n = L.getOptions().defaultImageSize || F.defaultImageSize,
            r = t || n;
        if (r === "master") return e;
        if (e) {
            const i = e.split("."),
                a = i.pop(),
                s = o[r] ? ? t;
            return i.join(".") + "_" + s + "." + a
        }
        return ""
    }

    function yt(e, t) {
        return e && Object.entries(t).reduce((o, [n, r]) => {
            const i = new RegExp(`{${n}}`, "g");
            return o.replace(i, r)
        }, e)
    }

    function hp() {
        const e = J([]),
            t = J({}),
            o = J(!1),
            {
                cartItems: n
            } = kt(),
            {
                appliedEntryIds: r
            } = wt(),
            {
                promotionEntries: i
            } = zn(),
            a = q(() => n.value.reduce((u, d) => (u[d.id] = d.product_id.toString(), u), {})),
            s = q(() => n.value.reduce((u, d) => {
                const {
                    [F.TRIGGER_ID_PROPERTY]: _, [F.OFFER_ID_PROPERTY]: g
                } = d.properties || {};
                if (_ && g) {
                    const h = isNaN(+_) ? _.split("-")[0] : _,
                        O = a.value[h],
                        b = d.product_id;
                    u[`${O}-${g}-${b}`] = 1
                }
                return u
            }, {})),
            c = q(() => i.value.filter(u => u.trigger_type === Ct.Specific));
        return {
            collectTodayOffers: (u = 5) => {
                if (!c.value.length) return [];
                const d = [...c.value],
                    _ = {},
                    g = {};
                for (; !(Object.keys(_).length === u || !d.length);) {
                    const h = L.randomItem(d, !1, !0),
                        O = d[h];
                    if (!g[O.id]) {
                        const N = [];
                        O.offer_product_data.forEach(w => {
                            N.push(...(O.trigger_data_products || []).map(D => `${D.id}-${O.id}-${w.id}`))
                        }), g[O.id] = N
                    }
                    if (!g[O.id].length) {
                        d.splice(h, 1);
                        continue
                    }
                    const b = O.discount_type === to.FixedAmount ? ut(oo.convertMoney(O.discount_value_fixed || 0, !0)) : `${O.discount_value_percentage}%`,
                        C = L.randomItem(g[O.id], !0),
                        E = C.split("-"),
                        x = s.value[C];
                    !x && r.value.includes(O.id) && Object.keys(s.value).some(N => N.includes(`${E[0]}-${E[1]}`)) || (_[C] = {
                        key: C,
                        offerId: E[2],
                        triggerId: E[0],
                        discountValue: b,
                        entryId: O.id,
                        type: O.type,
                        claimed: x
                    })
                }
                e.value = Object.values(_), o.value = !0
            },
            todayOffers: e,
            collectTodayOfferProducts: async () => {
                var h;
                if (!o.value) return;
                const u = [...new Set(e.value.reduce((O, b) => [...O, b.offerId, b.triggerId], []))];
                if (!u.length) return;
                const d = t.value,
                    _ = Object.keys(d);
                if (u.filter(O => !_.includes(O)).length) {
                    const O = await cp(u);
                    (h = O == null ? void 0 : O.nodes) != null && h.length && (O.nodes.forEach(b => {
                        if (!b) return;
                        const C = L.extractId(b.id);
                        d[C] = b
                    }), t.value = { ...d
                    })
                }
                o.value = !1
            },
            products: t
        }
    }
    let Ql = 1;
    const Zl = J([]),
        Jl = J(!1);

    function zn() {
        const {
            getConfig: e,
            entries: t,
            settings: o,
            isPremium: n
        } = ze(), {
            isPassConditions: r
        } = jn(), {
            appliedEntryIds: i
        } = wt(), {
            checkDiscount: a
        } = zr(), s = q(() => (n.value || L.isDesignMode()) && o.value.enable_promotion_badge), c = q(() => {
            if (!(n.value || L.isDesignMode()) || !o.value.enable_today_offers || Jl.value) return !1;
            const d = new Date().getTime(),
                _ = Number(localStorage.getItem(F.TODAY_OFFER_DISMISSED_AT) || "0");
            return d - _ > 30 * 60 * 1e3
        }), l = () => {
            if (!s.value && !c.value) {
                L.log("Promotion badge and today offers not active");
                return
            }
            Zl.value = t.value.filter(d => {
                const {
                    id: _,
                    type: g,
                    enable_discount: h,
                    enable_discount_usage_limit: O,
                    discount_usage_limit: b,
                    async_usage_count: C,
                    starts_at: E,
                    enable_ends_at: x,
                    ends_at: N,
                    enable_once_per_order: w
                } = d, D = d.trigger_action === Tt.Payment;
                if (!h || ![S.Bogo, S.FreeGift].includes(g) || O && b && b <= (C || 0) || D) return !1;
                const P = new Date(E).getTime(),
                    I = new Date().getTime(),
                    $ = x && N && new Date(N).getTime();
                if (P > I || $ && $ < I) return !1;
                let oe = !r(d);
                if (g === S.FreeGift) {
                    const A = i.value.includes(_);
                    oe = !!(w && A)
                }
                return !oe && a(d)
            }).sort((d, _) => _.type.localeCompare(d.type)), setTimeout(f, e("lazyLoadTimeout"))
        }, f = d => {
            if (!s.value) return;
            const _ = document.querySelectorAll((d == null ? void 0 : d.wrapper) || e("productWrapperSelector"));
            L.log("usePromotion: wrappers", _), _ && _.forEach(g => {
                if (g.getAttribute(F.BADGE_ATTACH)) return;
                const h = g.querySelector((d == null ? void 0 : d.attack) || e("badgeAttackSelector"));
                if (!h) return;
                const O = g.querySelector((d == null ? void 0 : d.link) || e("handleLinkSelector")),
                    b = O ? O == null ? void 0 : O.href : g == null ? void 0 : g.href,
                    C = b && L.getProductHandleFromUrl(b);
                if (!C) return;
                const E = `qbk-promote-${Ql}`,
                    x = document.createElement("div");
                x.id = E, x.classList.add("qbk-promote-wrapper"), Ql += 1, L.placeElement(h, (d == null ? void 0 : d.position) || e("badgePosition"), x), Ko(bc, {
                    handle: C
                }).mount(`#${E}`), g.setAttribute(F.BADGE_ATTACH, "true")
            })
        };
        return {
            init: l,
            promotionEntries: Zl,
            setupPromotionBadge: f,
            todayOffersActive: c,
            dismissTodayOffers: () => {
                Jl.value = !0, localStorage.setItem(F.TODAY_OFFER_DISMISSED_AT, new Date().getTime().toString())
            }
        }
    }

    function Xl() {
        const {
            setupAllAtcListener: e,
            setupAtcListener: t
        } = Ot(), {
            setupPromotionBadge: o
        } = zn();
        return {
            setupPublicAPI: () => {
                window._BK_API = { ...window._BK_API || {}
                }, window._BK_API.setupAllAtcListener = i => {
                    e(i)
                }, window._BK_API.setupAtcListener = i => {
                    t(i)
                }, window._BK_API.setupPromotionBadge = i => {
                    o(i)
                }
            },
            setPublicApi: (i, a) => {
                if (!window._BK_API) {
                    window._BK_API = {
                        [i]: a
                    };
                    return
                }
                window._BK_API[i] = a
            }
        }
    }

    function Yr() {
        const {
            settings: e
        } = ze(), t = q(() => {
            var c;
            return ((c = e.value) == null ? void 0 : c.seasonal_template) || ""
        }), o = q(() => fp[t.value] || {}), n = q(() => !L.isEmptyObj(o.value)), r = q(() => n.value ? `qbk-offer-box-seasonal--${t.value}` : ""), i = q(() => n.value ? `qbk-popup-seasonal-wrapper--${t.value}` : ""), a = q(() => n.value ? `qbk-order-goal--${t.value}` : ""), s = q(() => {
            var c;
            return (c = o.value) == null ? void 0 : c.gift_icon_key
        });
        return {
            seasonalTemplate: o,
            offerBoxClassName: r,
            popupClassName: i,
            orderGoalClassName: a,
            giftIconKey: s
        }
    }

    function ec(e, t) {
        const o = J({}),
            n = J(0),
            r = J(""),
            {
                updateDiscount: i,
                discounts: a,
                updateTempDiscounts: s,
                clearTempDiscount: c
            } = wt(),
            l = q(() => {
                const h = o.value[n.value];
                return h && h.lineItems.reduce((O, b) => O + b.price * b.quantity, 0)
            }),
            f = q(() => (t == null ? void 0 : t.value) || S.Bogo),
            u = h => {
                s(h, r.value), r.value = h, i({
                    code: h
                })
            },
            d = (h, O) => {
                if (L.log("useBogo: update discounts", a.value, O), n.value !== h) {
                    O.code && O.haveDiscount && u(O.code), o.value = {
                        [h]: O
                    }, n.value = h;
                    return
                }!r.value && O.haveDiscount && O.code && u(O.code), c(), o.value[h] = O, O.lineItems.every(b => !b.quantity) && c(r.value)
            },
            _ = () => {
                o.value = {}, n.value = 0, r.value = ""
            };
        return {
            updateBogoItems: d,
            bogoItems: o,
            addBogoToCart: async () => {
                const h = o.value[n.value];
                if (!h || !h.lineItems.length) return;
                const O = h.lineItems.map(b => ({
                    id: b.id,
                    quantity: b.quantity,
                    properties: { ...b.haveDiscount && {
                            [F.TRIGGER_ID_PROPERTY]: e == null ? void 0 : e.value
                        },
                        [F.OFFER_ID_PROPERTY]: n.value,
                        [F.OFFER_TYPE_PROPERTY]: f.value
                    }
                }));
                try {
                    await Mt("/cart/add.js?qbk-bogo", {
                        body: {
                            items: O
                        }
                    }), Yt(n.value, Vt.SessionAddToCart, {
                        component: f.value
                    }), _(), document.dispatchEvent(new CustomEvent(F.EVENT_BOGO_ADDED))
                } catch (b) {
                    throw L.log("Cannot add items", b), new Error((b == null ? void 0 : b.description) || (b == null ? void 0 : b.message))
                }
            },
            clearData: _,
            price: l,
            bogoActiveEntryId: n
        }
    }
    const Wr = J([]);

    function tc(e, t) {
        const o = J([]),
            {
                haveDiscount: n,
                getOfferPrice: r
            } = zr(e),
            {
                updateDiscount: i,
                tempDiscounts: a
            } = wt(),
            {
                renderCartContents: s
            } = Ot(),
            {
                getCustomProperties: c
            } = Hr(),
            {
                alreadyInCartVariants: l
            } = kt(),
            f = q(() => t ? Wr.value : o.value),
            u = q(() => f.value.filter(Boolean)),
            d = q(() => u.value.length < e.value.offer_product_data.length + 1),
            _ = q(() => !d.value && f.value.every(w => w.status === Pe.Added)),
            g = q(() => !d.value && f.value.find(w => w.isTrigger && w.status === Pe.Added)),
            h = q(() => e.value.discount_apply === ia.Children),
            O = q(() => {
                var w, D;
                if (h.value) {
                    const P = (D = (w = f.value) == null ? void 0 : w.find(oe => oe == null ? void 0 : oe.isTrigger)) == null ? void 0 : D.id,
                        I = l.value[+(P || 0)];
                    if (I == null ? void 0 : I.some(oe => oe.offerId === e.value.id)) return !1
                }
                return n.value && f.value.every(P => P.haveDiscount || h.value && P.isTrigger)
            }),
            b = q(() => f.value.reduce((w, D) => {
                const P = D.status === Pe.Added ? D.price * D.quantity : 0;
                return w + P
            }, 0)),
            C = q(() => {
                if (!O.value || !_.value) return b.value;
                if (h.value) {
                    const w = f.value.find(I => I.isTrigger),
                        D = w ? w.price * w.quantity : 0,
                        P = f.value.reduce((I, $) => $.isTrigger || $.status !== Pe.Added ? I : I + $.price * $.quantity, 0);
                    return r(P) + D
                }
                return r(b.value)
            });
        return {
            addBundleToCart: async () => {
                if (L.log("Add bundle", f.value), f.value.length) {
                    const w = f.value.find(I => I.isTrigger);
                    if (!w) return;
                    const D = O.value && _.value,
                        P = f.value.filter(I => I.status === Pe.Added).map(I => ({
                            id: I.id,
                            quantity: I.quantity,
                            properties: { ...D && {
                                    [F.TRIGGER_ID_PROPERTY]: w.id
                                },
                                [F.OFFER_ID_PROPERTY]: e.value.id,
                                [F.OFFER_TYPE_PROPERTY]: S.Bundle,
                                ...I.isTrigger && c()
                            }
                        }));
                    try {
                        const I = await Mt("/cart/add.js?qbk-bundle", {
                            body: {
                                items: P
                            }
                        });
                        if (D && await i({
                                code: e.value.discount_code
                            }), Yt(e.value.id, Vt.SessionAddToCart, {
                                component: S.Bundle
                            }), document.dispatchEvent(new CustomEvent(F.EVENT_BUNDLE_ADDED)), t && a.value.length) return {
                            doNormalAction: !0
                        };
                        await s(I)
                    } catch (I) {
                        throw L.log("Cannot add bundle", I), new Error((I == null ? void 0 : I.description) || (I == null ? void 0 : I.message))
                    }
                }
            },
            updateItems: (w, D) => {
                if (t) {
                    Wr.value[w] = { ...Wr.value[w],
                        ...D
                    };
                    return
                }
                o.value[w] = { ...o.value[w],
                    ...D
                }
            },
            price: b,
            offerPrice: C,
            isValidDiscount: O,
            isValidOffer: _,
            hasValidTrigger: g,
            clearData: () => {
                Wr.value = []
            },
            isLoadingItems: d
        }
    }
    const oc = J(null);

    function nc(e, t) {
        const o = t ? oc : J(null),
            {
                updateDiscount: n,
                tempDiscounts: r
            } = wt(),
            {
                renderCartContents: i
            } = Ot(),
            {
                getCustomProperties: a
            } = Hr(),
            s = q(() => !!o.value),
            c = u => {
                o.value = u
            },
            l = () => {
                oc.value = null
            },
            f = async () => {
                var u, d, _;
                try {
                    const g = ((u = o.value) == null ? void 0 : u.selectedVariants) || [];
                    if (g.length <= 0) return;
                    const h = ((d = o.value) == null ? void 0 : d.price) !== ((_ = o.value) == null ? void 0 : _.offerPrice),
                        O = { ...h && {
                                [F.TRIGGER_ID_PROPERTY]: g[0].id
                            },
                            [F.OFFER_ID_PROPERTY]: e.value.id,
                            [F.OFFER_TYPE_PROPERTY]: S.Volume,
                            ...a()
                        },
                        b = g.reduce((E, x) => (E[x.id] ? E[x.id].quantity += 1 : E[x.id] = {
                            id: x.id,
                            quantity: 1,
                            properties: O
                        }, E), {}),
                        C = await Mt("/cart/add.js?qbk-volume", {
                            body: {
                                items: Object.values(b)
                            }
                        });
                    if (h && await n({
                            code: e.value.discount_code
                        }), Yt(e.value.id, Vt.SessionAddToCart, {
                            component: S.Volume
                        }), document.dispatchEvent(new CustomEvent(F.EVENT_VOLUME_ADDED)), t && r.value.length) return {
                        doNormalAction: !0
                    };
                    await i(C)
                } catch (g) {
                    throw L.log("Cannot add volume", g), new Error((g == null ? void 0 : g.description) || (g == null ? void 0 : g.message))
                }
            };
        return {
            offerPrice: q(() => {
                var u;
                return ((u = o.value) == null ? void 0 : u.offerPrice) || 0
            }),
            isValidOffer: s,
            addTier: c,
            addVolumeToCart: f,
            clearData: l
        }
    }

    function va(e) {
        const t = J({}),
            o = J(0),
            n = J(""),
            r = J(0),
            {
                updateDiscount: i,
                discounts: a,
                updateTempDiscounts: s,
                clearTempDiscount: c
            } = wt(),
            {
                getQuantityInCart: l
            } = kt(),
            {
                contents: f
            } = ze(),
            u = q(() => t.value[o.value]),
            d = q(() => {
                var x;
                return (x = u.value) == null ? void 0 : x.lineItems.length
            }),
            _ = q(() => u.value && u.value.lineItems.reduce((x, N) => x + N.price * N.quantity, 0)),
            g = x => {
                s(x, n.value), n.value = x, i({
                    code: x
                })
            },
            h = x => {
                x && (r.value = x)
            },
            O = (x, N) => {
                if (L.log("useFreeGift: update data", a.value, N), o.value !== x) {
                    N.code && N.haveDiscount && g(N.code), t.value = {
                        [x]: N
                    }, o.value = x;
                    return
                }!n.value && N.haveDiscount && N.code && g(N.code), c(), t.value[x] = N, N.lineItems.every(w => !w.quantity) && c(n.value)
            },
            b = () => {
                t.value = {}, o.value = 0, n.value = "", r.value = 0
            },
            C = (x, N) => {
                const {
                    neededQuantity: w
                } = N || u.value || {}, D = N ? N.triggerId : e == null ? void 0 : e.value;
                if (L.log("getInNeedQuantity", x, w), !D || !w) return 0;
                const P = l(D),
                    I = P % w ? w - P % w : w;
                return L.log("getInNeedQuantity", P, I), I > 1 && x < I ? I - x : 0
            };
        return {
            updateFreeGiftItems: O,
            freeGiftItems: t,
            addFreeGiftToCart: async x => {
                if (!u.value || !u.value.lineItems.length) return;
                const {
                    neededQuantity: N,
                    isMultiplier: w
                } = u.value;
                if (!r.value) {
                    const $ = C(+(x || 1));
                    if ($) {
                        const oe = new Error(yt(f.value.not_enough_quantity_error, {
                            quantity: $
                        }));
                        throw oe.name = Mr.NotEnoughQuantity, oe
                    }
                }
                const D = N > 1 || w;
                let P = e == null ? void 0 : e.value;
                D && (P += `-${N}${w?"x":""}`);
                const I = u.value.lineItems.map($ => (P += D && $.quantity > 1 ? `-${$.quantity}` : "", {
                    id: $.id,
                    quantity: $.quantity,
                    properties: { ...$.haveDiscount && {
                            [F.TRIGGER_ID_PROPERTY]: P
                        },
                        [F.OFFER_ID_PROPERTY]: o.value,
                        [F.OFFER_TYPE_PROPERTY]: S.FreeGift
                    }
                }));
                try {
                    const $ = await Mt("/cart/add.js?qbk-free-gift", {
                        body: {
                            items: [...r.value ? [{
                                id: e == null ? void 0 : e.value,
                                quantity: r.value
                            }] : [], ...I]
                        }
                    });
                    return Yt(o.value, Vt.SessionAddToCart, {
                        component: S.FreeGift
                    }), b(), document.dispatchEvent(new CustomEvent(F.EVENT_FREE_GIFT_ADDED)), $
                } catch ($) {
                    throw L.log("Cannot add items", $), new Error(($ == null ? void 0 : $.description) || ($ == null ? void 0 : $.message))
                }
            },
            clearData: b,
            price: _,
            freeGiftActiveEntryId: o,
            isValidOffer: d,
            getInNeedQuantity: C,
            updateTriggerQuantity: h
        }
    }
    const vp = J([]);

    function rc(e, t, o) {
        const n = o ? vp : J([]),
            {
                updateDiscount: r,
                tempDiscounts: i
            } = wt(),
            {
                updateThemeCartItems: a,
                renderCartContents: s
            } = Ot(),
            {
                getCustomProperties: c
            } = Hr(),
            l = q(() => n.value.filter(b => b.status === Pe.Added)),
            f = q(() => l.value.reduce((b, C) => {
                const E = C.originPrice * C.quantity;
                return b + E
            }, 0)),
            u = q(() => l.value.reduce((b, C) => {
                const E = C.price * C.quantity;
                return b + E
            }, 0)),
            d = q(() => n.value.length < t.value.offer_product_data.length);
        return {
            isValidOffer: q(() => n.value.some(b => b.status === Pe.Added || b.status === Pe.Available)),
            isLoadingItems: d,
            addUpsurgeToCart: async b => {
                try {
                    if (!l.value.length) return {
                        doNormalAction: !0
                    };
                    const C = l.value.some(D => D.haveDiscount),
                        E = {
                            [F.OFFER_ID_PROPERTY]: t.value.id,
                            [F.OFFER_TYPE_PROPERTY]: S.Upsurge,
                            ...c()
                        },
                        x = l.value.map(D => ({
                            id: D.id,
                            quantity: D.quantity,
                            properties: { ...D.haveDiscount && {
                                    [F.TRIGGER_ID_PROPERTY]: e.value
                                },
                                ...E
                            }
                        }));
                    L.log("Add upsurge", x);
                    const {
                        triggerKey: N
                    } = t.value;
                    N && await Mt("/cart/change.js?qbk-upsurge", {
                        body: {
                            id: N,
                            quantity: 0
                        }
                    }, !0);
                    const w = await Mt("/cart/add.js?qbk-upsurge", {
                        body: {
                            items: x
                        }
                    }, !0);
                    if (C && await r({
                            code: t.value.discount_code
                        }), Yt(t.value.id, Vt.SessionAddToCart, {
                            component: S.Upsurge
                        }), document.dispatchEvent(new CustomEvent(F.EVENT_UPSURGE_ADDED)), b === Tt.Checkout) return await a(), {
                        doNormalAction: !0
                    };
                    if (o && i.value.length) return {
                        doNormalAction: !0
                    };
                    await s(w)
                } catch (C) {
                    throw L.log("Cannot add upsurge", C), new Error((C == null ? void 0 : C.description) || (C == null ? void 0 : C.message))
                }
            },
            updateItems: b => {
                n.value = b
            },
            price: f,
            offerPrice: u,
            clearData: () => {
                n.value = []
            }
        }
    }
    const Qr = J({});

    function ic() {
        const {
            getGiftLineKey: e,
            giftLines: t
        } = kt(), {
            renderCartContents: o
        } = Ot(), {
            getProductData: n
        } = Nt(), r = (u, d) => {
            L.log("useGiftGoal: update data", d), Qr.value[u] = {
                lineItems: d
            }
        }, i = () => {
            Qr.value = {}
        }, a = async u => {
            const d = Object.values(u).reduce((g, h) => (h.quantity <= 0 || g.push({
                id: h.id,
                quantity: h.quantity,
                properties: {
                    [F.TIER_PROPERTY]: String(h.tier)
                }
            }), g), []);
            return d.length ? await Mt("/cart/add.js?qbk-gift-goal", {
                body: {
                    items: d
                }
            }, !0) : !1
        }, s = async u => L.isEmptyObj(u) ? !1 : await Mt("/cart/update.js?qbk-gift-goal", {
            body: {
                updates: u
            }
        }, !0), c = async () => {
            const u = Qr.value,
                d = {},
                _ = {},
                g = JSON.parse(JSON.stringify(u)),
                h = l();
            if (Object.entries(u).forEach(([O, b]) => {
                    var C;
                    b.isPending || b.isRejected || !((C = b == null ? void 0 : b.lineItems) != null && C.length) || b.lineItems.forEach(E => {
                        const x = `${E.id}-${O}`;
                        d[x] = { ...E,
                            tier: O
                        }
                    })
                }), Object.entries(h).forEach(([O, b]) => {
                    var C, E, x;
                    if (b.isPending || b.isRejected && !((E = (C = u[O]) == null ? void 0 : C.lineItems) != null && E.length)) {
                        g[O] = b;
                        return
                    }(x = b == null ? void 0 : b.lineItems) == null || x.forEach(N => {
                        const w = `${N.id}-${O}`;
                        if (d[w]) d[w].quantity -= N.quantity;
                        else {
                            const D = e(N.id, O);
                            D && (_[D] = 0)
                        }
                    })
                }), !Object.values(d).filter(O => O.quantity).length && L.isEmptyObj(_)) {
                L.log("useGiftGoal: nothing change");
                return
            }
            L.log("useGiftGoal: addData - removeData", d, _);
            try {
                const O = await s(_),
                    b = await a(d);
                return localStorage.setItem(F.GIFT_GOAL_STORAGE, JSON.stringify(g)), O || b ? {
                    removeRes: O,
                    addRes: b
                } : !1
            } catch (O) {
                throw L.log("Cannot add items", O), new Error((O == null ? void 0 : O.description) || (O == null ? void 0 : O.message))
            }
        }, l = () => JSON.parse(localStorage.getItem(F.GIFT_GOAL_STORAGE) || "{}");
        return {
            updateGiftGoalItem: r,
            updateGift: c,
            clearData: i,
            addGift: a,
            removeGift: s,
            giftGoalItems: Qr,
            getStorageData: l,
            giftGoalChecking: async (u, d) => {
                if (!u.length) return;
                const _ = u.filter(b => b.completed && b.haveGiftGoal),
                    g = l(),
                    h = t.value.reduce((b, C) => (_.some(E => E.raw_subtotal === (C == null ? void 0 : C.properties[F.TIER_PROPERTY])) || (b[C.key] = 0), b), {}),
                    O = {};
                if (d && _.forEach(b => {
                        var C;
                        if (!g[b.raw_subtotal]) {
                            const E = {
                                lineItems: []
                            };
                            (C = b.offer_product_data) == null || C.forEach(x => {
                                let N = x.variants;
                                const w = n(x.id);
                                !w || !(w != null && w.available) || (N === Ft.All && (N = (w == null ? void 0 : w.variants.map(D => D.id)) || []), N.length && N.forEach(D => {
                                    const P = w.variants.find($ => String($.id).includes(D));
                                    if (!P || !(P != null && P.available)) return;
                                    const I = {
                                        id: D,
                                        quantity: x.quantity || 1
                                    };
                                    O[`${D}-${b.raw_subtotal}`] = { ...I,
                                        tier: b.raw_subtotal
                                    }, E.lineItems.push(I)
                                }))
                            }), g[b.raw_subtotal] = E
                        }
                    }), L.isEmptyObj(g) || Object.entries(g).forEach(b => {
                        const [C, E] = b, x = _.some(N => N.raw_subtotal === C);
                        if (!E.isRejected) {
                            if (!E.isPending && !x) {
                                E.isPending = !0;
                                return
                            }
                            if (E.isPending && x) {
                                E.lineItems.forEach(N => O[`${N.id}-${C}`] = { ...N,
                                    tier: C
                                }), E.isPending = !1;
                                return
                            }
                        }
                    }), !L.isEmptyObj(O) || !L.isEmptyObj(h)) {
                    L.log("useGiftGoal - Gift goal checking", O, h, g);
                    try {
                        const b = await s(h),
                            C = await a(O);
                        localStorage.setItem(F.GIFT_GOAL_STORAGE, JSON.stringify(g)), await o({
                            addRes: C,
                            removeRes: b
                        }, () => window.location.reload()), document.dispatchEvent(new CustomEvent(F.EVENT_GIFT_GOAL_ADDED))
                    } catch {
                        L.log("Order goal: Cannot update gift")
                    }
                }
            }
        }
    }
    const Zr = J(!1),
        ac = J([]),
        kp = J(!1),
        ka = J("");

    function sc() {
        const {
            cart: e,
            isCartEmpty: t
        } = kt(), {
            collectRecommendProduct: o
        } = Nt();
        return {
            collectRecommendationData: async i => {
                var l;
                let a = 0,
                    s = 0,
                    c = [];
                if (!(t.value || Zr.value)) try {
                    for (Zr.value = !0; s < 10 && a < e.value.item_count && c.length < 10;) {
                        const f = await o((l = e.value.items[a]) == null ? void 0 : l.product_id, i);
                        s += 1, a += 1, f && f.products && (c = [...c, ...f.products.filter(u => !c.some(d => d.id === u.id))])
                    }
                } catch (f) {
                    L.log("Cannot get product", f)
                } finally {
                    ac.value = c, Zr.value = !1
                }
            },
            recommendationData: ac,
            isCollecting: Zr,
            isEventAdded: kp,
            updateOfferIds: async (i, a) => {
                if (!i || ka.value === i) return;
                ka.value = i;
                const s = await aa(i, !0);
                return a || document.dispatchEvent(new CustomEvent(F.EVENT_CART_CHANGE)), ka.value = "", s
            }
        }
    }
    const Jr = J(""),
        yp = F.TOAST_DURATION;

    function lc() {
        return {
            activeMessage: Jr,
            showToast: t => {
                Jr.value || (Jr.value = t, setTimeout(() => {
                    Jr.value = ""
                }, yp))
            }
        }
    }
    const qp = ["innerHTML"],
        Ep = {
            class: "qbk-bogo__main-content"
        },
        wp = {
            key: 0,
            class: "qbk-bogo_navigate"
        },
        xp = {
            key: 0,
            class: "qbk-navigate"
        },
        Cp = ["disabled"],
        Tp = ["disabled"],
        Op = Fe({
            __name: "Bogo",
            props: {
                entry: {},
                triggerId: {}
            },
            setup(e) {
                const t = e,
                    o = rt("update-bogo-items", () => {}),
                    n = rt("bogoActiveEntryId", J(0)),
                    r = rt("isPopup", !1),
                    i = J([]),
                    a = J([]),
                    {
                        promoteFreeGift: s
                    } = Nt(),
                    {
                        contents: c,
                        settings: l
                    } = ze(),
                    f = q(() => ({
                        "qbk-cart-upsell": t.entry.type === S.CartUpsell
                    })),
                    u = q(() => t.entry.offer_product_data.length),
                    {
                        activeIndex: d,
                        prevActive: _,
                        nextActive: g
                    } = ga(u),
                    h = q(() => {
                        const I = s.value[t.triggerId];
                        return I ? !I.enable_combinations_products || !t.entry.enable_combinations_products : !1
                    }),
                    O = q(() => i.value.filter(I => I.quantity).length),
                    b = q(() => +(t.entry.enable_limit_item && t.entry.limit_item || 0)),
                    C = q(() => b.value && O.value >= b.value),
                    E = q(() => !r && l.value.embed_bogo_layout === "horizontal"),
                    x = q(() => {
                        if (b.value && b.value < t.entry.offer_product_data.length) return yt(c.value.selected_items_text, {
                            selected_items: `${O.value}/${b.value}`
                        });
                        if (E.value && O.value) return yt(c.value.selected_items_text, {
                            selected_items: `${O.value}`
                        })
                    }),
                    N = q(() => {
                        let I = 0;
                        return t.entry.offer_product_data.map(oe => {
                            const A = { ...oe
                            };
                            return n.value && n.value !== t.entry.id ? { ...A,
                                enablePreSelected: !1
                            } : b.value && (A.enablePreSelected && I++, I > b.value) ? { ...A,
                                enablePreSelected: !1
                            } : A
                        })
                    });
                ot(() => n.value, I => {
                    I || (i.value = [])
                });
                const w = I => d.value === I,
                    D = (I, $) => {
                        i.value[I] = $;
                        const oe = t.entry.discount_method === Lr.Code && t.entry.discount_code;
                        o(t.entry.id, {
                            lineItems: i.value.filter(A => A && A.quantity),
                            code: oe || "",
                            haveDiscount: $.haveDiscount
                        }), L.log("bogo added", t.entry.id, {
                            index: I,
                            value: $
                        })
                    },
                    P = I => {
                        if (I === "prev" && !_.value || I === "next" && !g.value) return;
                        let $;
                        I === "next" && ($ = a.value.findIndex((oe, A) => oe.status && A > d.value)), I === "prev" && ($ = a.value.findLastIndex((oe, A) => oe.status && A < d.value)), d.value = $
                    };
                return nt(() => {
                    Yt(t.entry.id, Vt.SessionProductOffer, {
                        component: t.entry.type
                    })
                }), (I, $) => (H(), ne("div", {
                    class: Le(["qbk-bogo", f.value])
                }, [x.value ? (H(), ne("div", {
                    key: 0,
                    class: "qbk-bogo_description qbk-description",
                    innerHTML: x.value
                }, null, 8, qp)) : ve("", !0), v("div", Ep, [pe(an, {
                    class: "qbk-offer-list--transition",
                    tag: "div",
                    name: "qbk--offer"
                }, {
                    default: Ge(() => [(H(!0), ne(Be, null, dt(N.value, (oe, A) => ht((H(), ne("div", {
                        class: "qbk-bogo__offers",
                        key: oe.handle
                    }, [pe(T(Hn), {
                        ref_for: !0,
                        ref_key: "offerRefs",
                        ref: a,
                        entry: I.entry,
                        offer: oe,
                        "active-entry-id": T(n),
                        "is-free-gift-take-over": h.value,
                        "is-limited-gift": !!C.value,
                        onUpdateLineItems: K => D(A, K)
                    }, null, 8, ["entry", "offer", "active-entry-id", "is-free-gift-take-over", "is-limited-gift", "onUpdateLineItems"])])), [
                        [Rt, E.value ? w(A) : !0]
                    ])), 128))]),
                    _: 1
                }), zt(I.$slots, "navigate"), E.value && u.value > 1 ? (H(), ne("div", wp, [T(_) || T(g) ? (H(), ne("div", xp, [v("div", {
                    class: "qbk-navigate__prev",
                    disabled: !T(_),
                    onClick: $[0] || ($[0] = () => P("prev"))
                }, [pe(T(Ue), {
                    icon: "prev"
                })], 8, Cp), v("div", {
                    class: "qbk-navigate__next",
                    disabled: !T(g),
                    onClick: $[1] || ($[1] = () => P("next"))
                }, [pe(T(Ue), {
                    icon: "next"
                })], 8, Tp)])) : ve("", !0)])) : ve("", !0)])], 2))
            }
        }),
        Np = ["data-offer-id"],
        Pp = {
            key: 0,
            class: "qbk-offer-box__header"
        },
        Ap = {
            class: "qbk-offer-box__header__heading"
        },
        Ip = ["innerHTML"],
        Dp = {
            class: "qbk-description"
        },
        cc = Fe({
            __name: "OfferBox",
            props: {
                entry: {},
                triggerHandle: {},
                triggerId: {}
            },
            setup(e) {
                const t = e,
                    o = rt("isPopup", !1),
                    {
                        settings: n,
                        extensionContents: r
                    } = ze(),
                    {
                        offerBoxClassName: i
                    } = Yr(),
                    a = q(() => ({ ...t.entry,
                        ...r.value[t.entry.id] || {}
                    })),
                    s = q(() => {
                        const c = [];
                        return !o && t.entry.type === S.Bundle && (c.push(`qbk-offer-box--bundle-${n.value.embed_bundle_layout}`), t.entry.offer_product_data.length === 1 && c.push("qbk-offer-box-bundle--one-column")), c.push(i.value), c
                    });
                return (c, l) => (H(), ne("div", {
                    class: Le(["qbk-offer-box", s.value]),
                    "data-offer-id": c.entry.id
                }, [T(o) ? ve("", !0) : (H(), ne("div", Pp, [v("div", Ap, [v("div", {
                    class: "qbk-title",
                    innerHTML: a.value.title
                }, null, 8, Ip), a.value.badge_label ? (H(), Se(T(ya), {
                    key: 0,
                    label: a.value.badge_label,
                    "background-color": c.entry.badge_background_color,
                    "text-color": c.entry.badge_text_color
                }, null, 8, ["label", "background-color", "text-color"])) : ve("", !0)]), v("div", Dp, [pe(T(dc), {
                    offer: c.entry,
                    "offer-content": a.value
                }, null, 8, ["offer", "offer-content"])])])), c.entry.type === T(S).Bogo || c.entry.type === T(S).CartUpsell ? (H(), Se(T(Op), {
                    key: 1,
                    entry: c.entry,
                    "trigger-id": c.triggerId
                }, {
                    navigate: Ge(() => [zt(c.$slots, "navigate")]),
                    _: 3
                }, 8, ["entry", "trigger-id"])) : c.entry.type === T(S).Bundle ? (H(), Se(T(Yp), {
                    key: 2,
                    entry: c.entry,
                    "trigger-handle": c.triggerHandle,
                    "trigger-id": c.triggerId
                }, {
                    navigate: Ge(() => [zt(c.$slots, "navigate")]),
                    _: 3
                }, 8, ["entry", "trigger-handle", "trigger-id"])) : c.entry.type === T(S).FreeGift ? (H(), Se(T(pc), {
                    key: 3,
                    entry: c.entry,
                    "trigger-id": c.triggerId
                }, null, 8, ["entry", "trigger-id"])) : c.entry.type === T(S).Volume ? (H(), Se(T(Eb), {
                    key: 4,
                    entry: c.entry,
                    "trigger-id": c.triggerId,
                    "trigger-handle": c.triggerHandle
                }, null, 8, ["entry", "trigger-id", "trigger-handle"])) : c.entry.type === T(S).Upsurge ? (H(), Se(T(Z_), {
                    key: 5,
                    entry: c.entry,
                    "trigger-id": c.triggerId,
                    onUpdated: l[0] || (l[0] = f => c.$emit("updated"))
                }, {
                    navigate: Ge(() => [zt(c.$slots, "navigate")]),
                    _: 3
                }, 8, ["entry", "trigger-id"])) : ve("", !0), pe(T(ei), {
                    hide: T(o),
                    mode: "dark"
                }, null, 8, ["hide"])], 10, Np))
            }
        }),
        Sp = {
            key: 0,
            class: "qbk-navigate"
        },
        $p = ["disabled"],
        Rp = ["disabled"],
        Fp = {
            key: 1,
            class: "qbk-design-mode"
        },
        Vp = [v("img", {
            class: "qbk-design-mode__empty-offer",
            src: "https://cdn.qikify.com/portal/v2/boosterkit/entry-not-match.png"
        }, null, -1)],
        Lp = Fe({
            __name: "ProductOffer",
            props: {
                triggerId: {},
                handle: {},
                sectionId: {},
                type: {},
                productId: {}
            },
            setup(e) {
                const t = e,
                    o = J(null),
                    n = J(null),
                    r = J(""),
                    i = J(!1),
                    a = J(0),
                    s = q(() => t.type === S.Bundle),
                    c = q(() => t.type === S.FreeGift),
                    l = q(() => t.type === S.Upsurge),
                    f = q(() => t.type === S.Bogo),
                    u = q(() => {
                        if (!re.value.length) return [];
                        if (s.value && !w("isBundleShowAll") || l.value || f.value && !w("isBogoShowAll") && D.value.embed_bogo_layout !== "horizontal") return [re.value[R.value]];
                        if (c.value) {
                            const we = re.value.find(ke => ke.mode === ct.Auto);
                            return we ? [we] : re.value.filter(ke => ke.mode === ct.Manual)
                        }
                        return re.value
                    }),
                    d = q(() => h.value || t.triggerId),
                    _ = q(() => ({ ...t,
                        triggerId: d.value,
                        triggerAction: Tt.AddToCart
                    })),
                    g = q(() => s.value ? w("isBundleShowAll") ? 0 : re.value.length : f.value ? D.value.embed_bogo_layout === "horizontal" || w("isBogoShowAll") ? 0 : re.value.length : 0),
                    {
                        selectedVariantId: h,
                        setupVariantChangeListener: O
                    } = da(o),
                    {
                        setupListener: b,
                        getAtcListener: C,
                        getQuantityInput: E
                    } = Ot(),
                    {
                        contents: x,
                        isFrozenApp: N,
                        getConfig: w,
                        settings: D
                    } = ze(),
                    {
                        addBogoToCart: P,
                        clearData: I,
                        updateBogoItems: $,
                        bogoActiveEntryId: oe
                    } = ec(d),
                    {
                        addFreeGiftToCart: A,
                        clearData: K,
                        updateFreeGiftItems: ae,
                        freeGiftActiveEntryId: B
                    } = va(d),
                    {
                        offersByType: re
                    } = jr(_),
                    {
                        activeIndex: R,
                        prevActive: U,
                        nextActive: ie,
                        navigate: _e
                    } = ga(g);
                ot(() => h.value, () => {
                    var ke;
                    if (![S.Bogo, S.FreeGift].includes(t.type)) return;
                    let we = "";
                    if (t.type === S.Bogo && (I(), we = F.BOGO_LISTENER), t.type === S.FreeGift && (K(), we = F.FREE_GIFT_LISTENER), w("enableResetEventAtc")) {
                        Ce();
                        return
                    }(ke = n.value) == null || ke.setAttribute(we, "true")
                });
                const he = () => {
                        r.value = ""
                    },
                    Ce = () => {
                        const {
                            form: we,
                            btn: ke
                        } = C(t.sectionId && `form[id*="${t.sectionId}"]`);
                        if (!(!we || !ke)) {
                            if (o.value = we, n.value = ke, O(), t.type === S.Bogo) {
                                const Oe = () => {
                                    he(), ke.style.pointerEvents = "none", P().catch(Ve => {
                                        r.value = (Ve == null ? void 0 : Ve.message) || x.value.common_error
                                    }).finally(() => {
                                        ke.style.pointerEvents = "auto", ke.click()
                                    })
                                };
                                b(ke, F.BOGO_LISTENER, Oe)
                            }
                            if (t.type === S.FreeGift) {
                                const Oe = () => {
                                    he(), ke.style.pointerEvents = "none";
                                    const Ve = E(we);
                                    A(Ve == null ? void 0 : Ve.value).then(() => i.value = !0).catch(Ae => {
                                        Ae.name === Mr.NotEnoughQuantity && setTimeout(() => ke.setAttribute(F.FREE_GIFT_LISTENER, "true"), 100), r.value = (Ae == null ? void 0 : Ae.message) || x.value.common_error
                                    }).finally(() => {
                                        ke.style.pointerEvents = "auto", ke.click(), setTimeout(() => ke.setAttribute(F.FREE_GIFT_LISTENER, "true"), 100)
                                    })
                                };
                                b(ke, F.FREE_GIFT_LISTENER, Oe)
                            }
                        }
                    };
                return nt(() => {
                    if (N.value) return;
                    const we = w("waitForFormUpdated");
                    we ? setTimeout(Ce, we) : Ce(), document.addEventListener(F.EVENT_LINE_ITEMS_CHANGED, () => {
                        i.value && (i.value = !1, a.value += 1)
                    })
                }), $t("update-bogo-items", $), $t("bogoActiveEntryId", oe), $t("update-free-gift-items", ae), $t("freeGiftActiveEntryId", B), (we, ke) => (H(), ne("div", {
                    class: Le(["qbk-product-offer", {
                        "qbk-product-offer--has-nav": g.value > 1
                    }]),
                    key: T(h)
                }, [u.value.length ? (H(!0), ne(Be, {
                    key: 0
                }, dt(u.value, Oe => (H(), Se(T(cc), {
                    key: `${Oe.id}${a.value}`,
                    entry: Oe,
                    "trigger-id": _.value.triggerId,
                    "trigger-handle": we.handle
                }, {
                    navigate: Ge(() => [T(U) || T(ie) ? (H(), ne("div", Sp, [v("div", {
                        class: "qbk-navigate__prev",
                        disabled: !T(U),
                        onClick: ke[0] || (ke[0] = () => T(_e)("prev"))
                    }, [pe(T(Ue), {
                        icon: "prev"
                    })], 8, $p), v("div", {
                        class: "qbk-navigate__next",
                        disabled: !T(ie),
                        onClick: ke[1] || (ke[1] = () => T(_e)("next"))
                    }, [pe(T(Ue), {
                        icon: "next"
                    })], 8, Rp)])) : ve("", !0)]),
                    _: 2
                }, 1032, ["entry", "trigger-id", "trigger-handle"]))), 128)) : T(L).isDesignMode() ? (H(), ne("div", Fp, Vp)) : ve("", !0), u.value.length ? (H(), Se(T(dn), {
                    key: 2,
                    message: r.value,
                    "not-fade": ""
                }, null, 8, ["message"])) : ve("", !0)], 2))
            }
        }),
        Gp = {
            class: "qbk-bundle__main-content"
        },
        Mp = {
            class: "qbk-bundle-action"
        },
        Bp = {
            class: "qbk-bundle__total"
        },
        Up = {
            class: "qbk-bundle__total-title"
        },
        jp = {
            class: "qbk-bundle__total-value qbk-offer__price"
        },
        zp = ["innerHTML"],
        Hp = ["innerHTML"],
        Kp = {
            class: "qbk-bundle__actions"
        },
        Yp = Fe({
            __name: "Bundle",
            props: {
                entry: {},
                triggerHandle: {},
                triggerId: {}
            },
            setup(e) {
                const t = e,
                    o = rt("isPopup", !1),
                    n = J(!1),
                    r = J(""),
                    {
                        updateItems: i,
                        price: a,
                        addBundleToCart: s,
                        isValidDiscount: c,
                        isValidOffer: l,
                        hasValidTrigger: f,
                        offerPrice: u,
                        isLoadingItems: d
                    } = tc(q(() => t.entry), o),
                    {
                        contents: _,
                        extensionContents: g
                    } = ze(),
                    h = q(() => ({ ...t.entry,
                        ...g.value[t.entry.id] || {}
                    })),
                    O = q(() => C.value ? _.value.out_of_stock_button_text : _.value.bundle_button_text),
                    b = q(() => {
                        var N, w;
                        let x = Ft.All;
                        if (t.entry.trigger_type === Ct.Specific) {
                            const D = (w = (N = t.entry.trigger_data_products) == null ? void 0 : N.find(P => P.handle === t.triggerHandle)) == null ? void 0 : w.variants;
                            D && (x = D)
                        }
                        return [{
                            id: "",
                            handle: t.triggerHandle,
                            isTrigger: !0,
                            variants: x,
                            quantity: t.entry.trigger_quantity,
                            triggerId: t.triggerId
                        }, ...t.entry.offer_product_data]
                    }),
                    C = q(() => t.entry.allow_purchase_any_item ? !f.value : !l.value),
                    E = async () => {
                        n.value = !0;
                        try {
                            await s()
                        } catch (x) {
                            r.value = (x == null ? void 0 : x.message) || _.value.common_error
                        } finally {
                            n.value = !1
                        }
                    };
                return nt(() => {
                    L.log("bundle list props", {
                        offerData: b.value
                    }), Yt(t.entry.id, Vt.SessionProductOffer, {
                        component: S.Bundle
                    })
                }), (x, N) => (H(), ne("div", {
                    class: Le(["qbk-bundle", {
                        "qbk-bundle--not-valid": !T(c) || !T(l)
                    }])
                }, [v("div", Gp, [zt(x.$slots, "navigate"), pe(an, {
                    class: "qbk-offer-list--transition",
                    tag: "div",
                    name: "qbk--offer"
                }, {
                    default: Ge(() => [(H(!0), ne(Be, null, dt(b.value, (w, D) => (H(), ne("div", {
                        class: Le(["qbk-bundle__offers", {
                            "qbk-bundle__offers--original": !D
                        }]),
                        key: w.handle
                    }, [pe(T(Hn), {
                        entry: x.entry,
                        offer: w,
                        onUpdateLineItems: P => T(i)(D, P)
                    }, null, 8, ["entry", "offer", "onUpdateLineItems"]), D ? ve("", !0) : (H(), Se(T(Ue), {
                        key: 0,
                        class: "qbk-bundle__plus-icon",
                        icon: "plus"
                    }))], 2))), 128))]),
                    _: 1
                })]), v("div", Mp, [h.value.badge_label ? (H(), Se(T(ya), {
                    key: 0,
                    label: h.value.badge_label,
                    "background-color": x.entry.badge_background_color,
                    "text-color": x.entry.badge_text_color
                }, null, 8, ["label", "background-color", "text-color"])) : ve("", !0), zt(x.$slots, "navigate"), v("div", Bp, [v("div", Up, Te(T(_).total_text), 1), v("div", jp, [ht(v("div", {
                    class: "qbk-offer__price--origin",
                    innerHTML: T(ut)(T(a))
                }, null, 8, zp), [
                    [Rt, T(c) && T(a) !== T(u)]
                ]), v("div", {
                    class: "qbk-offer__price--offer",
                    innerHTML: T(ut)(T(u))
                }, null, 8, Hp)])]), pe(T(dn), {
                    message: r.value
                }, null, 8, ["message"]), v("div", Kp, [pe(T(Ut), {
                    class: "qbk-bundle__action-btn",
                    loading: n.value || T(d),
                    disabled: C.value,
                    error: !!r.value,
                    "hide-error": "",
                    primary: "",
                    type: "button",
                    onClick: E
                }, {
                    default: Ge(() => [v("span", null, Te(O.value), 1)]),
                    _: 1
                }, 8, ["loading", "disabled", "error"])])])], 2))
            }
        }),
        Wp = {
            xmlns: "http://www.w3.org/2000/svg",
            class: "qbk-checkmark",
            viewBox: "0 0 52 52"
        },
        Qp = [v("circle", {
            cx: "26",
            cy: "26",
            r: "25",
            fill: "none",
            class: "qbk-checkmark__circle"
        }, null, -1), v("path", {
            fill: "none",
            d: "m14.1 27.2 7.1 7.2 16.7-16.8",
            class: "qbk-checkmark__check"
        }, null, -1)];

    function Zp(e, t) {
        return H(), ne("svg", Wp, Qp)
    }
    const uc = {
            render: Zp
        },
        Jp = {
            class: "qbk-volume"
        },
        Xp = [v("div", {
            class: "qbk-spinner"
        }, " ", -1)],
        eb = ["onClick"],
        tb = {
            class: "qbk-badge__label"
        },
        ob = {
            key: 0,
            class: "qbk-volume-tier__radio"
        },
        nb = ["checked", "id"],
        rb = ["for", "onClick", "onTouchstart"],
        ib = {
            class: "qbk-volume-tier__radio-tick"
        },
        ab = {
            class: "qbk-volume-tier__info"
        },
        sb = ["onClick", "innerHTML"],
        lb = {
            key: 0,
            class: "qbk-volume-tier__price-info"
        },
        cb = {
            class: "qbk-volume-tier__price_section"
        },
        ub = ["innerHTML"],
        db = {
            key: 0,
            class: "qbk-volume-tier__price_section"
        },
        fb = ["innerHTML"],
        pb = {
            class: "qbk-volume-tier__price--offer"
        },
        bb = {
            key: 1,
            class: "qbk-offer__content"
        },
        _b = {
            class: "qbk-offer__action-name"
        },
        mb = v("div", {
            class: "qbk-divider"
        }, null, -1),
        gb = {
            class: "qbk-volume-tier__extra-section__content"
        },
        hb = {
            class: "qbk-volume-tier__item-label"
        },
        vb = {
            class: "qbk-input-wrapper qbk-input-selector"
        },
        kb = ["onUpdate:modelValue"],
        yb = ["value"],
        qb = {
            class: "qbk-select-indicator"
        },
        Eb = Fe({
            __name: "Volume",
            props: {
                entry: {},
                triggerId: {},
                triggerHandle: {}
            },
            setup(e) {
                const t = e,
                    o = rt("isPopup", !1),
                    n = rt("isPortal", !1),
                    {
                        contents: r,
                        extensionContents: i,
                        getConfig: a
                    } = ze(),
                    {
                        appliedEntryIds: s
                    } = wt(),
                    {
                        getOfferPrice: c
                    } = zr(),
                    {
                        collectRenderedProduct: l
                    } = Nt(),
                    {
                        addTier: f,
                        addVolumeToCart: u
                    } = nc(q(() => t.entry), o),
                    d = J(!0),
                    _ = J(!1),
                    g = J([]),
                    h = J(null),
                    O = J([]),
                    b = J(""),
                    C = q(() => g.value.every(re => re.available) && typeof h.value == "number" && h.value >= 0),
                    E = q(() => {
                        let B = A((t.entry.discount_type === to.FixedAmount ? t.entry.tiers_fixed : t.entry.tiers_percentage) || []);
                        return B = B.map((re, R) => {
                            var U;
                            return { ...re,
                                ...((U = i.value[t.entry.id]) == null ? void 0 : U.tiers[R]) || {}
                            }
                        }).sort((re, R) => re.min_quantity - R.min_quantity), B
                    }),
                    x = q(() => r.value.volume_button_text);
                ot(() => s.value, () => oe(O.value)), ot(() => g.value, () => {
                    if (h.value === null) return;
                    const B = g.value[h.value];
                    if (!B) return;
                    const {
                        price: re,
                        offerPrice: R
                    } = ae(B);
                    B.price = re, B.offerPrice = R
                }, {
                    deep: !0
                });
                const N = (B, re) => {
                        const R = a("displayVolumeUnitPrice") && !t.entry.allow_changing_tier_item_variant ? Math.ceil(B[re] / B.min_quantity) : B[re];
                        return ut(R)
                    },
                    w = (B, re) => {
                        a("allowContainerClick") && D(B, re)
                    },
                    D = async (B, re) => {
                        B.stopPropagation(), B.preventDefault(), P(re)
                    },
                    P = async B => {
                        h.value = B, f(g.value[B])
                    },
                    I = async () => {
                        try {
                            _.value = !0, await u()
                        } catch (B) {
                            b.value = (B == null ? void 0 : B.message) || r.value.common_error
                        } finally {
                            _.value = !1
                        }
                    },
                    $ = B => ({
                        "--qbk-badge-bg-color": B.badge_background_color || "#D96730",
                        "--qbk-badge-text-color": B.badge_text_color || "#ffffff"
                    }),
                    oe = B => {
                        var ie;
                        const re = [];
                        let R = B.find(_e => String(_e.id) === String(t.triggerId));
                        const U = !!R;
                        for (let _e = 0; _e < E.value.length; _e++) {
                            const he = (ie = E.value[_e]) == null ? void 0 : ie.min_quantity,
                                Ce = oo.convertMoney(E.value[_e].value, !0),
                                we = { ...E.value[_e],
                                    title: yt(E.value[_e].title, {
                                        quantity: E.value[_e].min_quantity,
                                        discount_amount: t.entry.discount_type === to.Percentage ? `${E.value[_e].value}%` : `${ut(Ce)}`
                                    }),
                                    available: U,
                                    selectedVariants: U ? Array(he).fill({}).map(() => R) : [],
                                    price: 0,
                                    offerPrice: 0,
                                    convertedValue: Ce
                                },
                                {
                                    price: ke,
                                    offerPrice: Oe
                                } = ae(we);
                            we.price = ke, we.offerPrice = Oe, re.push(we)
                        }
                        if (g.value = re, U) {
                            const he = re.every(Ce => Ce.is_default_selected === void 0) ? 0 : re.findIndex(Ce => Ce.is_default_selected);
                            he > -1 && P(he)
                        }
                    },
                    A = B => B.map(R => ({ ...R,
                        value: Number(R.value) || 0,
                        min_quantity: Number(R.min_quantity) || 0
                    })),
                    K = (B, re) => {
                        var U, ie, _e, he, Ce, we;
                        if (!B.available) return [];
                        const R = B.variants.filter(ke => ke.available);
                        if (n) return R;
                        if (re.trigger_type === Ct.All) {
                            const ke = ((ie = (U = re.trigger_data_excludes) == null ? void 0 : U.find(Oe => Oe.id === B.id.toString())) == null ? void 0 : ie.variants) || [];
                            return ke === Ft.All ? [] : ke.length < 0 ? R : R.filter(Oe => !ke.includes(Oe.id.toString()))
                        }
                        if (re.trigger_type === Ct.Specific) {
                            const ke = ((he = (_e = re.trigger_data_products) == null ? void 0 : _e.find(Oe => Oe.id === B.id.toString())) == null ? void 0 : he.variants) || [];
                            return ke === Ft.All ? R : R.filter(Oe => ke.includes(Oe.id.toString()))
                        }
                        if (re.trigger_type === Ct.Collection && re.enable_trigger_data_collection_excludes) {
                            const ke = ((we = (Ce = re.trigger_data_collection_excludes) == null ? void 0 : Ce.find(Oe => Oe.id === B.id.toString())) == null ? void 0 : we.variants) || [];
                            return ke === Ft.All ? [] : ke.length < 0 ? R : R.filter(Oe => !ke.includes(Oe.id.toString()))
                        }
                        return R
                    },
                    ae = B => {
                        const re = { ...t.entry,
                                discount_value_percentage: B.value || 0,
                                discount_value_fixed: B.value || 0
                            },
                            R = B.selectedVariants || [];
                        let U = 0;
                        R.forEach(_e => {
                            U += _e.price
                        });
                        const ie = c(U, re);
                        return {
                            price: U,
                            offerPrice: ie > 0 ? ie : 0
                        }
                    };
                return nt(async () => {
                    try {
                        const B = await l(t.triggerHandle, n),
                            re = K(B, t.entry);
                        O.value = re, oe(re), Yt(t.entry.id, Vt.SessionProductOffer, {
                            component: S.Volume
                        })
                    } finally {
                        d.value = !1
                    }
                }), (B, re) => (H(), ne("div", Jp, [pe(an, {
                    class: "qbk-offer-list--transition",
                    tag: "div",
                    name: "qbk--offer"
                }, {
                    default: Ge(() => [d.value ? (H(!0), ne(Be, {
                        key: 0
                    }, dt(B.entry.tiers_fixed || B.entry.tiers_percentage, (R, U) => (H(), ne("div", {
                        class: "qbk-volume--loading",
                        key: `${U}-loading`
                    }, Xp))), 128)) : (H(!0), ne(Be, {
                        key: 1
                    }, dt(g.value, (R, U) => (H(), ne("div", {
                        class: Le(["qbk-volume-tier", {
                            "qbk-volume-tier--selected": U === h.value,
                            "qbk-volume-tier--unavailable": !R.available
                        }]),
                        key: U,
                        onClick: ie => R.available && w(ie, U)
                    }, [R.badge_label ? (H(), ne("div", {
                        key: 0,
                        class: "qbk-badge qbk-badge--static",
                        style: mt($(R))
                    }, [v("div", tb, Te(R.badge_label), 1)], 4)) : ve("", !0), v("div", {
                        class: "qbk-volume-tier__main-section",
                        style: mt({
                            "margin-top": R.badge_label ? "20px" : "0px"
                        })
                    }, [pe(T(uc)), R.available ? (H(), ne("div", ob, [v("input", {
                        class: Le(["qbk-volume-tier__radio__input", {
                            "qbk-volume-tier__radio__input--checked": U === h.value
                        }]),
                        checked: U == h.value,
                        name: "volume-tiers",
                        type: "radio",
                        id: `qbk-tier-${U}`
                    }, null, 10, nb), v("label", {
                        class: "qbk-label qbk-volume-tier__radio__label",
                        for: `qbk-tier-${U}`,
                        onClick: ie => D(ie, U),
                        onTouchstart: ie => D(ie, U)
                    }, [v("span", ib, [pe(T(Ue), {
                        icon: "tick",
                        size: "xs"
                    })])], 40, rb)])) : ve("", !0), v("div", ab, [v("div", {
                        class: "qbk-volume-tier__title",
                        onClick: ie => R.available && D(ie, U),
                        innerHTML: R.title
                    }, null, 8, sb), R.available ? (H(), ne("div", lb, [v("div", cb, [v("div", {
                        class: Le(["qbk-volume-tier__price--origin", {
                            "strike-through": R.offerPrice !== R.price
                        }]),
                        innerHTML: N(R, "price")
                    }, null, 10, ub)]), R.offerPrice !== R.price ? (H(), ne("div", db, [v("div", {
                        class: "qbk-volume-tier__price--offer",
                        innerHTML: R.offerPrice ? N(R, "offerPrice") : T(r).free_offer_text
                    }, null, 8, fb), v("div", pb, Te(T(r).total_text), 1)])) : ve("", !0)])) : (H(), ne("div", bb, [pe(T(Ut), {
                        class: "qbk-offer__action-btn",
                        secondary: "",
                        subdued: "",
                        disabled: ""
                    }, {
                        default: Ge(() => [v("span", _b, Te(T(r).sold_out_button_text), 1)]),
                        _: 1
                    })]))])], 4), B.entry.allow_changing_tier_item_variant && U === h.value && O.value.length > 1 ? (H(), ne("div", {
                        key: 1,
                        class: "qbk-volume-tier__extra-section",
                        onClick: re[0] || (re[0] = oa(() => {}, ["stop"]))
                    }, [mb, v("div", gb, [(H(!0), ne(Be, null, dt(R.selectedVariants, (ie, _e) => (H(), ne("div", {
                        class: "qbk-volume-tier__variant-select",
                        key: _e
                    }, [v("span", hb, Te(T(r).item_text) + " " + Te(_e + 1), 1), v("label", vb, [ht(v("select", {
                        class: "qbk-input-control qbk-offer__variant",
                        "onUpdate:modelValue": he => R.selectedVariants[_e] = he
                    }, [(H(!0), ne(Be, null, dt(O.value, he => (H(), ne("option", {
                        class: "qbk-basic",
                        key: he.id,
                        value: he
                    }, Te(he.public_title), 9, yb))), 128))], 8, kb), [
                        [ta, R.selectedVariants[_e]]
                    ]), v("span", qb, [pe(T(Ue), {
                        icon: "arrow-down"
                    })])])]))), 128))])])) : ve("", !0)], 10, eb))), 128))]),
                    _: 1
                }), pe(T(dn), {
                    message: b.value
                }, null, 8, ["message"]), T(o) ? ve("", !0) : (H(), Se(T(Ut), {
                    key: 0,
                    class: "qbk-volume__action-btn",
                    loading: d.value || _.value,
                    disabled: !C.value,
                    error: !!b.value,
                    "hide-error": "",
                    primary: "",
                    type: "button",
                    onClick: I
                }, {
                    default: Ge(() => [v("span", null, Te(x.value), 1)]),
                    _: 1
                }, 8, ["loading", "disabled", "error"]))]))
            }
        }),
        wb = {
            class: "qbk-custom-description"
        },
        xb = ["innerHTML"],
        dc = Fe({
            __name: "CustomDescription",
            props: {
                offer: {},
                offerContent: {}
            },
            setup(e) {
                const t = e,
                    o = rt("isPortal", !1),
                    {
                        isPremium: n
                    } = ze(),
                    r = q(() => t.offer.enable_count_down && t.offer.enable_ends_at),
                    i = q(() => {
                        let s = t.offerContent.description || "";
                        if (r.value) {
                            const c = n.value || L.isDesignMode() || o ? '<span class="qbk-inject-count-down"></span>' : "";
                            s = yt(s, {
                                countdown: c
                            })
                        }
                        return s
                    }),
                    a = async () => {
                        var c, l;
                        await L.delay(100);
                        const s = o ? (l = (c = document.querySelector(".preview-frame")) == null ? void 0 : c.contentWindow) == null ? void 0 : l.document : document;
                        s == null || s.querySelectorAll(".qbk-inject-count-down").forEach(f => {
                            Ko(Ym, {
                                time: t.offer.ends_at
                            }).mount(f)
                        })
                    };
                return nt(() => {
                    r.value && a()
                }), (s, c) => (H(), ne("div", wb, [v("span", {
                    class: "qbk-custom-description__content",
                    innerHTML: i.value
                }, null, 8, xb)]))
            }
        }),
        Cb = {
            class: "qbk-popup__header"
        },
        Tb = ["innerHTML"],
        Ob = {
            class: "qbk-popup__description qbk-description"
        },
        Nb = {
            class: "qbk-popup__body"
        },
        Pb = {
            class: "qbk-popup__total"
        },
        Ab = {
            class: "qbk-popup__total-title"
        },
        Ib = {
            class: "qbk-popup__total-value"
        },
        Db = ["innerHTML"],
        Sb = ["innerHTML"],
        $b = {
            class: "qbk-popup__action-btn"
        },
        Rb = {
            key: 0,
            class: "qbk-popup__footer-silent"
        },
        Fb = ["disabled"],
        Vb = ["disabled"],
        Lb = Fe({
            __name: "Popup",
            props: {
                offer: {}
            },
            emits: ["handle-skip"],
            setup(e, {
                emit: t
            }) {
                const o = e,
                    n = rt("isPortal", !1),
                    r = J([]),
                    i = J(null),
                    a = J(!0),
                    s = J(""),
                    c = J(!1),
                    l = J(0),
                    f = q(() => n ? "div" : na),
                    u = q(() => o.offer || r.value[P.value] || {}),
                    d = q(() => u.value.type === S.Bogo || u.value.type === S.CartUpsell),
                    _ = q(() => u.value.type === S.Bundle),
                    g = q(() => u.value.type === S.Volume),
                    h = q(() => u.value.type === S.FreeGift),
                    O = q(() => u.value.type === S.Upsurge),
                    b = q(() => {
                        let xe = 0;
                        return d.value ? He.value : _.value ? de.value : g.value ? x.value : h.value ? Z.value : O.value ? me.value : xe
                    }),
                    C = q(() => {
                        var xe;
                        return u.value.triggerId || ((xe = i.value) == null ? void 0 : xe.product.triggerId) || ""
                    }),
                    E = q(() => n || +U.value.popup_limit_offers && U.value.popup_limit_offers < r.value.length ? U.value.popup_limit_offers : r.value.length),
                    {
                        offerPrice: x,
                        addVolumeToCart: N,
                        isValidOffer: w,
                        clearData: D
                    } = nc(u, !0),
                    {
                        activeIndex: P,
                        prevActive: I,
                        nextActive: $,
                        navigate: oe
                    } = ga(E),
                    A = q(() => {
                        if (_.value) return ge.value && W.value;
                        if (O.value) return ue.value
                    }),
                    K = q(() => ({ ...u.value,
                        ..._e.value[u.value.id] || {}
                    })),
                    ae = q(() => h.value && l.value),
                    B = q(() => g.value ? !w.value : _.value ? u.value.allow_purchase_any_item ? !z.value : !ye.value : !1),
                    re = q(() => _.value ? B.value ? ie.value.out_of_stock_button_text : ie.value.bundle_button_text : g.value ? ie.value.volume_button_text : ie.value.grab_offer_button_text);
                ot([i, u], () => {
                    var xe, Me;
                    i.value.includeFreeGift && h.value && (l.value = M(((xe = i.product) == null ? void 0 : xe.triggerQuantity) || 1, {
                        neededQuantity: +(u.value.trigger_quantity || 1),
                        triggerId: (Me = i.value.product) == null ? void 0 : Me.triggerId
                    }))
                });
                const {
                    popupClassName: R
                } = Yr(), {
                    settings: U,
                    contents: ie,
                    extensionContents: _e,
                    entries: he,
                    setExpireTime: Ce,
                    isShowPopupOneTime: we
                } = ze(), {
                    hide: ke,
                    show: Oe
                } = Vr(), {
                    getOffers: Ve,
                    getOffersForCart: Ae
                } = jr(), {
                    combineRewardBar: We
                } = wt(), {
                    isAllExtensionsEmbedded: Je,
                    embeddedOffers: De
                } = Ot(), {
                    clearCartAttrs: Ye
                } = kt(), {
                    price: He,
                    addBogoToCart: m,
                    clearData: y,
                    updateBogoItems: V
                } = ec(C, q(() => u.value.type)), {
                    price: Z,
                    addFreeGiftToCart: Q,
                    clearData: ee,
                    updateFreeGiftItems: j,
                    getInNeedQuantity: M,
                    updateTriggerQuantity: te
                } = va(C), {
                    price: W,
                    offerPrice: de,
                    addBundleToCart: fe,
                    isValidDiscount: ge,
                    isValidOffer: ye,
                    hasValidTrigger: z,
                    clearData: se,
                    isLoadingItems: ce
                } = tc(u, !0), {
                    price: ue,
                    offerPrice: me,
                    addUpsurgeToCart: p,
                    clearData: k
                } = rc(C, u, !0), {
                    promoteFreeGift: G,
                    getHandle: Y,
                    collectProductData: X
                } = Nt(), be = xe => {
                    switch (U.value.popup_offer_priority_type) {
                        case Gr.UpdatedAsc:
                            return xe.sort((Me, pt) => new Date(Me.updated_at).getTime() - new Date(pt.updated_at).getTime());
                        case Gr.UpdatedDesc:
                            return xe.sort((Me, pt) => new Date(pt.updated_at).getTime() - new Date(Me.updated_at).getTime());
                        default:
                            return L.shuffleArray(xe)
                    }
                }, Ee = async xe => {
                    var Kn, bt, Ec;
                    if (n) {
                        i.value = xe, Oe(F.POPUP_MODAL_NAME);
                        return
                    }
                    if (we.value) {
                        setTimeout(() => {
                            xe.element.click()
                        }, 0);
                        return
                    }
                    if (!xe) return;
                    xe.isCollectData && await X({
                        id: (Kn = xe.product) == null ? void 0 : Kn.productId
                    });
                    let Me = [],
                        pt = null;
                    if (xe.action === Tt.AddToCart && xe.product)
                        if (xe.product.productId && !xe.product.handle && (xe.product.handle = Y(xe.product.productId)), pt = xe.product && G.value[xe.product.triggerId], pt && pt.mode === ct.Auto) Me = [];
                        else {
                            const wa = xe.includeFreeGift ? [S.OrderGoal, S.CartUpsell] : [S.OrderGoal, S.CartUpsell, S.FreeGift],
                                xa = he.value.filter(ri => !wa.includes(ri.type));
                            if (Me = Ve({ ...xe.product,
                                    triggerAction: xe.action
                                }, xa), !Je(xe.product.handle)) {
                                const ri = De.value[xe.product.handle];
                                ri && (Me = Me.filter($h => !ri.includes($h.type)))
                            }
                        }
                    if (xe.action === Tt.Checkout && (We.value.isDiscountApplied || Ye(), Me = Ae()), Me = be(Me), pt && pt.mode === ct.Manual) {
                        l.value = M(((bt = xe.product) == null ? void 0 : bt.triggerQuantity) || 1, {
                            neededQuantity: +(pt.trigger_quantity || 1),
                            triggerId: (Ec = xe.product) == null ? void 0 : Ec.triggerId
                        });
                        const wa = Me.filter(xa => xa.id !== pt.id);
                        Me = [pt, ...wa]
                    }
                    if (r.value = Me, i.value = xe, L.log("Popup offer", {
                            popupData: xe,
                            offerValues: Me
                        }), Me.length) {
                        document.dispatchEvent(new CustomEvent(F.EVENT_POPUP_BEFORE_OPEN)), Oe(F.POPUP_MODAL_NAME);
                        return
                    }
                    setTimeout(() => {
                        xe.element.click()
                    }, 0)
                }, $e = () => {
                    y(), se(), it(), D(), ee(), k()
                }, Ke = xe => {
                    n && t("handle-skip", xe), oe(xe, $e)
                }, tt = () => {
                    it(), te(l.value), l.value = 0
                }, et = async () => {
                    var xe, Me, pt, Kn;
                    c.value = !0;
                    try {
                        if (d.value && await m(), _.value) {
                            const bt = await fe();
                            a.value = (bt == null ? void 0 : bt.doNormalAction) || !1
                        }
                        if (g.value) {
                            const bt = await N();
                            a.value = (bt == null ? void 0 : bt.doNormalAction) || !1
                        }
                        if (h.value && await Q((Me = (xe = i.value) == null ? void 0 : xe.product) == null ? void 0 : Me.triggerQuantity), O.value) {
                            const bt = await p((pt = i.value) == null ? void 0 : pt.action);
                            ((Kn = i.value) == null ? void 0 : Kn.action) === Tt.AddToCart && (a.value = (bt == null ? void 0 : bt.doNormalAction) || !1)
                        }
                        $e(), Ea()
                    } catch (bt) {
                        a.value = !0, s.value = (bt == null ? void 0 : bt.message) || ie.value.common_error
                    } finally {
                        c.value = !1
                    }
                }, it = () => {
                    s.value = ""
                }, It = (xe, Me) => {
                    it(), V(xe, Me)
                }, Oo = (xe, Me) => {
                    it(), j(xe, Me)
                }, qa = () => {
                    it()
                }, Ea = () => {
                    n || ke(F.POPUP_MODAL_NAME)
                }, Sh = async () => {
                    var xe, Me;
                    document.dispatchEvent(new CustomEvent(F.EVENT_POPUP_BEFORE_CLOSE)), Ce(), i.value.includeFreeGift && h.value && u.value.mode === ct.Auto && await et(), a.value ? ((xe = i.value) == null ? void 0 : xe.action) === Tt.Checkout ? setTimeout(() => {
                        var pt;
                        (pt = i.value) == null || pt.element.click()
                    }, 100) : (Me = i.value) == null || Me.element.click() : window != null && window.QIKIFY_QUICKVIEW_LOADED && document.dispatchEvent(new CustomEvent("qview-close-popup")), it(), a.value = !0, P.value = 0
                };
                return Er(() => {
                    document.addEventListener(F.EVENT_OPEN_POPUP, xe => Ee({ ...xe.detail
                    }))
                }), io(() => {
                    document.removeEventListener(F.EVENT_OPEN_POPUP, xe => Ee({ ...xe.detail
                    }))
                }), $t("isPopup", !0), $t("update-bogo-items", It), $t("update-free-gift-items", Oo), $t("inNeedQuantity", l), (xe, Me) => (H(), Se(Ai(f.value), {
                    name: T(F).POPUP_MODAL_NAME,
                    "wrapper-class": "qbk-popup",
                    onBeforeClose: Sh
                }, {
                    default: Ge(() => [i.value && u.value ? (H(), ne("div", {
                        key: 0,
                        class: Le(["qbk-popup-wrapper", T(R)])
                    }, [v("div", {
                        class: "qbk-popup__header-silent",
                        onClick: Ea
                    }, [v("a", {
                        class: "qbk-popup__outside-btn qbk-popup__close",
                        onClick: Ea
                    }, [pe(T(Ue), {
                        icon: "close"
                    })])]), pe(T(ei), {
                        float: ""
                    }), v("div", Cb, [K.value.badge_label ? (H(), Se(T(ya), {
                        key: 0,
                        label: K.value.badge_label,
                        "background-color": u.value.badge_background_color,
                        "text-color": u.value.badge_text_color
                    }, null, 8, ["label", "background-color", "text-color"])) : ve("", !0), v("div", {
                        class: "qbk-popup__title qbk-title",
                        innerHTML: K.value.title
                    }, null, 8, Tb), v("div", Ob, [pe(dc, {
                        offer: u.value,
                        offerContent: K.value
                    }, null, 8, ["offer", "offerContent"])])]), v("div", Nb, [(H(), Se(T(cc), {
                        key: u.value.id,
                        entry: u.value,
                        "trigger-handle": u.value.triggerHandle || i.value.product.handle,
                        "trigger-id": u.value.triggerId || i.value.product.triggerId,
                        onUpdated: qa
                    }, null, 8, ["entry", "trigger-handle", "trigger-id"]))]), v("div", {
                        class: Le(["qbk-popup__footer", {
                            "qbk-popup__footer--free-gift": h.value
                        }])
                    }, [ht(v("div", Pb, [v("div", Ab, Te(T(ie).total_text), 1), v("div", Ib, [v("div", {
                        class: "qbk-offer__price--offer",
                        innerHTML: T(ut)(b.value)
                    }, null, 8, Db), A.value && A.value !== b.value ? (H(), ne("div", {
                        key: 0,
                        class: "qbk-offer__price--origin",
                        innerHTML: T(ut)(A.value)
                    }, null, 8, Sb)) : ve("", !0)])], 512), [
                        [Rt, !h.value]
                    ]), v("div", $b, [pe(T(Ut), {
                        class: "qbk-popup__continue",
                        normal: !!ae.value,
                        primary: !ae.value,
                        disabled: B.value,
                        loading: c.value || _.value && T(ce),
                        error: s.value,
                        onClick: et
                    }, {
                        default: Ge(() => [v("span", null, Te(re.value), 1)]),
                        _: 1
                    }, 8, ["normal", "primary", "disabled", "loading", "error"]), ae.value ? (H(), Se(T(Ut), {
                        key: 0,
                        class: "qbk-popup__add-more",
                        primary: "",
                        onClick: tt
                    }, {
                        default: Ge(() => [v("span", null, Te(T(yt)(T(ie).add_more_button_text, {
                            quantity: l.value
                        })), 1)]),
                        _: 1
                    })) : ve("", !0)])], 2), E.value > 1 ? (H(), ne("div", Rb, [v("div", {
                        class: "qbk-popup__outside-btn qbk-popup__prev",
                        disabled: T(n) ? d.value : !T(I),
                        onClick: Me[0] || (Me[0] = () => Ke("prev"))
                    }, [pe(T(Ue), {
                        icon: "prev"
                    })], 8, Fb), v("div", {
                        class: "qbk-popup__outside-btn qbk-popup__next",
                        disabled: !T(n) && !T($),
                        onClick: Me[1] || (Me[1] = () => Ke("next"))
                    }, [pe(T(Ue), {
                        icon: "next"
                    })], 8, Vb)])) : ve("", !0)], 2)) : ve("", !0)]),
                    _: 1
                }, 40, ["name"]))
            }
        });

    function Gb(e, t) {
        return null
    }
    const Xr = (e, t) => {
            const o = e.__vccOpts || e;
            for (const [n, r] of t) o[n] = r;
            return o
        },
        ei = Xr({}, [
            ["render", Gb]
        ]),
        Mb = ["data-offer-id"],
        Bb = {
            class: "qbk-order-goal__message"
        },
        Ub = ["innerHTML"],
        jb = {
            class: "qbk-order-goal__bar"
        },
        zb = {
            class: "qbk-order-goal__milestones"
        },
        Hb = ["onClick"],
        Kb = {
            class: "qbk-order-goal__icon"
        },
        Yb = {
            class: "qbk-order-goal__title"
        },
        Wb = {
            key: 1,
            class: "qbk-order-goal__design-mode"
        },
        Qb = [v("img", {
            class: "qbk-design-mode__empty-offer",
            src: "https://cdn.qikify.com/portal/v2/boosterkit/empty-cart.png"
        }, null, -1)],
        fc = Fe({
            __name: "OrderGoal",
            props: {
                offer: {},
                firstKick: {
                    type: Boolean
                }
            },
            setup(e) {
                const t = e,
                    o = rt("isPortal", !1),
                    {
                        cartAttributes: n,
                        currentQuantity: r,
                        currentPrice: i,
                        isCartEmpty: a,
                        addedGiftTiers: s
                    } = kt(),
                    {
                        entries: c,
                        extensionContents: l,
                        settings: f,
                        getConfig: u,
                        isFrozenApp: d,
                        contents: _,
                        isExtensionAvailableInPlan: g
                    } = ze(),
                    {
                        combineProduct: h,
                        isDiscountReady: O
                    } = wt(),
                    {
                        isPassConditions: b
                    } = jn(),
                    {
                        giftGoalChecking: C,
                        getStorageData: E
                    } = ic(),
                    {
                        isEventAdded: x,
                        collectRecommendationData: N,
                        updateOfferIds: w
                    } = sc(),
                    {
                        giftIconKey: D,
                        orderGoalClassName: P
                    } = Yr(),
                    {
                        setPublicApi: I
                    } = Xl(),
                    $ = J(null),
                    oe = J([]),
                    A = q(() => D.value || "gift"),
                    K = q(() => f.value.reward_bar_measurement_unit === Gn.PurchaseAmount),
                    ae = q(() => K.value ? i.value : r.value),
                    B = q(() => {
                        const z = [];
                        return a.value && f.value.enable_empty_cart_reward_bar && z.push("qbk-order-goal--cart-empty"), V.value <= 0 && z.push("qbk-order-goal--done"), Z.value && z.push("qbk-order-goal--gift"), ee.value.tiers.length > 3 && z.push("qbk-order-goal--hide-title"), z.push(P.value), z
                    }),
                    re = q(() => De.value.length),
                    R = q(() => o ? !0 : d.value || !O.value ? !1 : u("allowEmptyCartOffer") || f.value.enable_empty_cart_reward_bar ? !0 : !a.value),
                    U = q(() => t.offer || (R.value ? c.value.filter(z => {
                        const {
                            starts_at: se,
                            ends_at: ce,
                            enable_ends_at: ue,
                            type: me
                        } = z;
                        if (!g(me)) return L.log(`Reward Bar: ${me} is not available on current plan`), !1;
                        if ((z.minimum_purchase_type || Gn.PurchaseAmount) !== f.value.reward_bar_measurement_unit) return L.log(`Reward Bar: ${me} is not available on current measurement setting`), !1;
                        const p = new Date(se).getTime(),
                            k = new Date().getTime(),
                            G = ue && ce && new Date(ce).getTime(),
                            Y = b(z);
                        let X = !0;
                        if (h.value.isDiscountApplied) {
                            const be = me === S.ShippingGoal && h.value.canCombineShipping || me === S.OrderGoal && h.value.canCombineOrder || me === S.GiftGoal && h.value.canCombineProduct;
                            X = !!z.enable_combinations_products && !!be
                        }
                        return !(!Gt.rewardBarEntries.includes(me) || p > k || G && G < k || !Y || !X)
                    }) : [])),
                    ie = q(() => U.value.filter(z => z.type !== S.ShippingGoal).map(z => z.id)),
                    _e = q(() => {
                        const z = U.value.every(me => me.type === S.GiftGoal || me.type === S.ShippingGoal && me.enable_combinations_orders || me.type === S.OrderGoal && me.enable_combinations_shipping),
                            se = U.value.every(me => me.type === S.ShippingGoal || me.type === S.GiftGoal && me.enable_combinations_orders || me.type === S.OrderGoal && me.enable_combinations_products),
                            ce = U.value.every(me => me.type === S.OrderGoal || me.type === S.GiftGoal && me.enable_combinations_shipping || me.type === S.ShippingGoal && me.enable_combinations_products);
                        return {
                            [`${S.GiftGoal}${S.OrderGoal}`]: se,
                            [`${S.OrderGoal}${S.GiftGoal}`]: se,
                            [`${S.GiftGoal}${S.ShippingGoal}`]: ce,
                            [`${S.ShippingGoal}${S.GiftGoal}`]: ce,
                            [`${S.OrderGoal}${S.ShippingGoal}`]: z,
                            [`${S.ShippingGoal}${S.OrderGoal}`]: z,
                            all: ce && z && se
                        }
                    }),
                    he = q(() => U.value.find(z => z.type === S.GiftGoal)),
                    Ce = q(() => {
                        var z;
                        return ((z = he.value) == null ? void 0 : z.mode) === ct.Auto
                    }),
                    we = q(() => U.value.length === 1),
                    ke = q(() => {
                        var se, ce, ue;
                        if (((se = f.value) == null ? void 0 : se.enable_recommendation_box) !== void 0) return (ce = f.value) == null ? void 0 : ce.enable_recommendation_box;
                        const z = (ue = U.value) == null ? void 0 : ue.find(me => me.type === S.OrderGoal);
                        return (z == null ? void 0 : z.enable_recommendation_box) !== void 0 ? z.enable_recommendation_box : !0
                    }),
                    Oe = q(() => {
                        const z = {};
                        let se = {};
                        return U.value.forEach(ce => {
                            const ue = l.value[ce.id] || {};
                            z[ce.id] = { ...ce,
                                ...ue
                            }, se[ce.id] = ue.tiers
                        }), { ...z,
                            tiers: se
                        }
                    }),
                    Ve = q(() => {
                        if (!U.value) return [];
                        let z = [];
                        return U.value.forEach(se => {
                            const ce = (se.discount_type === to.FixedAmount ? se.tiers_fixed : se.tiers_percentage) || [],
                                ue = Oe.value.tiers[se.id],
                                me = ce.map((p, k) => {
                                    const G = K.value ? oo.convertMoney(p.min_subtotal, !0) : +(p.min_quantity || 0),
                                        Y = K.value ? String(p.min_subtotal) : String(p.min_quantity),
                                        X = (ue == null ? void 0 : ue[k]) || {};
                                    return { ...p,
                                        ...X,
                                        raw_subtotal: Y,
                                        min_amount: G,
                                        type: se.type,
                                        offerId: se.id,
                                        completed: G <= ae.value,
                                        neededAmount: G - ae.value,
                                        isGiftAdded: se.type === S.GiftGoal && s.value.includes(Y)
                                    }
                                });
                            z = z.concat(me)
                        }), z.sort((se, ce) => se.min_amount - ce.min_amount)
                    }),
                    Ae = q(() => {
                        var me;
                        if (!Ve.value.length) return 0;
                        const z = u("numberOfActiveTiers"),
                            se = Ve.value.filter(p => p.min_amount > ae.value),
                            ce = se.length ? se.slice(0, z) : [Ve.value[Ve.value.length - 1]];
                        return (me = ce[ce.length - 1]) == null ? void 0 : me.min_amount
                    }),
                    We = q(() => {
                        var k;
                        if (!Ve.value.length) return [];
                        let z = 0,
                            se = [];
                        const ce = Ve.value.map(G => G.min_amount).filter((G, Y, X) => X.indexOf(G) !== Y),
                            ue = Ve.value.reduce((G, Y) => (Y.completed && (G[Y.type] = Y.min_amount, z = Y.min_amount), G), {}),
                            me = Ve.value.map(G => {
                                var be;
                                const Y = ue[G.type],
                                    X = G.min_amount > Ae.value || Y && G.min_amount < Y && (G.type !== S.GiftGoal || !((be = he.value) != null && be.enable_receive_all_tiers));
                                return { ...G,
                                    isHidden: X,
                                    isCombo: !1
                                }
                            });
                        if (!_e.value.all) {
                            z ? se = [...new Set(me.filter(X => X.completed).map(X => X.type).reverse())] : (z = Ve.value[0].min_amount, se = me.filter(X => Ve.value[0].min_amount === X.min_amount).map(X => X.type));
                            const G = (k = f.value.reward_bar_priority) == null ? void 0 : k.split(","),
                                Y = ce.includes(z) && G.find(X => se.includes(X)) || se[0];
                            se = se.reduce((X, be) => (be === Y || X.some(Ee => !_e.value[`${Ee}${be}`]) || X.push(be), X), [Y])
                        }
                        return me.map(G => {
                            if (G.isHidden || _e.value.all || G.min_amount === z && se.includes(G.type)) return G;
                            if (!G.completed) return ce.length && ce.includes(G.min_amount) && !se.includes(G.type) && (G.isHidden = !0), G;
                            for (let Y of se)
                                if (G.type !== Y && !_e.value[`${Y}${G.type}`]) return G.isHidden = !0, G;
                            return G
                        })
                    }),
                    Je = q(() => We.value.filter(z => z.type === S.GiftGoal && !z.isHidden)),
                    De = q(() => {
                        if (!We.value.length) return [];
                        const z = [],
                            se = We.value.filter(ce => !ce.isHidden);
                        for (let ce = 0; ce < se.length; ce++) {
                            const ue = se[ce];
                            let me = z.length;
                            if (me - 1 >= 0 && ue.min_amount === z[me - 1].min_amount) {
                                const k = z[me - 1],
                                    G = k.isCombo ? [...k.type, ue.type] : [k.type, ue.type];
                                z[me - 1] = { ...k,
                                    ...ue,
                                    title: k.isCombo ? [...k.title, ue.title] : [k.title, ue.title],
                                    offerIds: k.isCombo ? [...k.offerIds, ue.offerId] : [k.offerId, ue.offerId],
                                    type: G,
                                    isCombo: !0,
                                    haveGiftGoal: G.includes(S.GiftGoal),
                                    isGiftAdded: k.isGiftAdded || ue.isGiftAdded
                                }, me = me - 1
                            } else z[me] = { ...ue,
                                haveGiftGoal: ue.type === S.GiftGoal
                            }
                        }
                        return z
                    }),
                    Ye = q(() => L.reverseArray(De.value).find(z => z.completed)),
                    He = q(() => {
                        if (a.value || we.value || !De.value.length) return 0;
                        const z = De.value[0].min_amount;
                        return (z <= ae.value && z || 0) * 80 / 100
                    }),
                    m = q(() => De.value.find(z => !z.completed)),
                    y = q(() => {
                        var z, se;
                        return ((z = m.value) == null ? void 0 : z.offerId) || ((se = De.value[De.value.length - 1]) == null ? void 0 : se.offerId)
                    }),
                    V = q(() => {
                        var z;
                        return ((z = m.value) == null ? void 0 : z.neededAmount) || 0
                    }),
                    Z = q(() => Je.value.length),
                    Q = q(() => Ae.value - He.value),
                    ee = q(() => {
                        const z = De.value.map(p => {
                                const k = [];
                                return p.completed && k.push("qbk-order-goal__milestone--done"), p.haveGiftGoal && (k.push("qbk-order-goal__milestone--gift"), p.completed && (p.isGiftAdded ? k.push("qbk-order-goal__milestone--gift-done") : k.push("qbk-order-goal__milestone--gift-pending"))), { ...p,
                                    position: (p.min_amount - He.value) / Q.value * 100,
                                    classes: k
                                }
                            }),
                            se = 1 / z.length * 100;
                        let ce = (ae.value - He.value) / Q.value * 100,
                            ue = 0,
                            me = !1;
                        for (let p = 0; p < z.length - 1; p++) {
                            const k = p ? z[p - 1].position : 0,
                                G = z[p + 1].position,
                                Y = z[p].position,
                                X = G + ue - Y;
                            if (X > se) {
                                ue && (z[p + 1].position += ue), ue && !me && (ce += ue, me = !0), ue = 0;
                                continue
                            }
                            X < 10 && (ue += 10 - X);
                            const be = 100 - 15 * (z.length - (p + 2));
                            if (G + ue > be) {
                                const $e = p !== z.length - 2 ? 5 + ue : 5;
                                if (Y - $e > k) {
                                    z[p].position -= 5 + $e, !me && ce > k && ce <= Y && (ce -= 5 + $e, me = !0), ue = 0;
                                    continue
                                }
                            }!me && G > ce && (z[p].min_amount <= ae.value && (ce += p ? ue : 0), me = !0), z[p + 1].position += ue
                        }
                        return {
                            tiers: z,
                            currentPosition: a.value ? 0 : ce
                        }
                    }),
                    j = q(() => {
                        const z = ee.value.currentPosition;
                        return {
                            "--qbk-order-goal-process": z > 100 ? "100%" : `${Math.floor(z)}%`
                        }
                    }),
                    M = q(() => {
                        var k;
                        if (V.value <= 0 || !m.value) return Ye.value ? Ye.value.isCombo ? _.value.package_deal_reward_done_message : ((k = Oe.value[Ye.value.offerId]) == null ? void 0 : k.done_message) || "" : "";
                        const {
                            offerId: z,
                            title: se,
                            isCombo: ce
                        } = m.value, ue = Oe.value[z], me = ce ? _.value.package_deal_reward_message : (ue == null ? void 0 : ue.title) || "", p = ce ? se.join(", ") : se;
                        return yt(me, {
                            amount: `<span class="qbk-order-goal__message--highlight">${te(V.value)}</span>`,
                            discount: m.value && `<span class="qbk-order-goal__message--highlight">${p}</span>` || ""
                        })
                    }),
                    te = z => K.value ? ut(z) : z;
                ot(() => $.value, () => {
                    var z;
                    ye(), (z = U.value) == null || z.forEach(se => {
                        De.value.some(ue => ue.isCombo ? ue.offerIds.includes(se.id) : ue.offerId === se.id) && Yt(se.id, Vt.SessionCartOffer, {
                            component: se.type
                        })
                    }), L.log("Order goal data", _e.value, De.value)
                });
                const W = async () => {
                        var ce;
                        if (!Je.value.length) return;
                        await L.delay(1e3);
                        const z = E(),
                            se = L.reverseArray(Je.value).find(ue => ue.completed && !z[ue.raw_subtotal] && !oe.value.includes(ue.raw_subtotal));
                        se && !se.isGiftAdded && (oe.value.push(se.raw_subtotal), document.dispatchEvent(new CustomEvent(F.EVENT_GIFT_GOAL_REACHED, {
                            detail: {
                                reachingTier: { ...se,
                                    haveGiftGoal: !0
                                }
                            }
                        })), (ce = he.value) != null && ce.enable_auto_open_gift_popup && ge({ ...se,
                            haveGiftGoal: !0
                        }))
                    },
                    de = async () => {
                        if (o || !re.value) return;
                        const z = De.value.filter(k => k.completed),
                            se = z.some(k => k.type.includes(S.ShippingGoal)),
                            ue = (!z.length || !se && (ie.value.length < 2 || _e.value[`${S.GiftGoal}${S.OrderGoal}`]) ? ie.value : U.value.filter(k => z.some(G => G.type.includes(k.type))).map(k => k.id)).join(","),
                            me = ue !== n.value;
                        let p = !1;
                        me && (await w(ue, a.value), document.dispatchEvent(new CustomEvent(F.EVENT_CART_ATTRIBUTE_UPDATED)), p = !0), p || (await L.delay(u("waitForCartApiSettle")), await C(De.value, Ce.value), W())
                    },
                    fe = z => {
                        var ue;
                        if (z < V.value) return (ue = m.value) == null ? void 0 : ue.offerId;
                        const se = ae.value + z,
                            ce = L.reverseArray(De.value).find(me => me.min_amount <= se);
                        return ce.isCombo ? ce == null ? void 0 : ce.offerIds[0] : ce == null ? void 0 : ce.offerId
                    },
                    ge = z => {
                        Z.value && (z && !z.haveGiftGoal || document.dispatchEvent(new CustomEvent(F.EVENT_OPEN_GIFT_GOAL, {
                            detail: {
                                entry: he,
                                tierData: Je.value,
                                activeTier: z
                            }
                        })))
                    },
                    ye = () => {
                        !re.value || !ke.value || N(o)
                    };
                return nt(() => {
                    x.value || (t.firstKick && de(), I("openGiftGoal", ge), document.addEventListener(F.EVENT_DATA_UPDATED, de), document.addEventListener(F.EVENT_LINE_ITEMS_CHANGED, ye), x.value = !0)
                }), io(() => {
                    x.value && (document.removeEventListener(F.EVENT_DATA_UPDATED, de), document.removeEventListener(F.EVENT_LINE_ITEMS_CHANGED, ye), x.value = !1)
                }), $t("getPassedGoalEntryId", fe), (z, se) => re.value ? (H(), ne("div", {
                    key: 0,
                    class: Le(["qbk-order-goal", B.value]),
                    "data-offer-id": y.value
                }, [v("div", Bb, [v("div", {
                    class: "qbk-order-goal__promote-message",
                    innerHTML: M.value,
                    ref_key: "visibleElement",
                    ref: $
                }, null, 8, Ub)]), v("div", jb, [v("div", {
                    class: "qbk-order-goal__progress",
                    style: mt(j.value)
                }, " ", 4), v("div", zb, [(H(!0), ne(Be, null, dt(ee.value.tiers, (ce, ue) => (H(), ne("div", {
                    class: Le(["qbk-order-goal__milestone", ce.classes]),
                    key: ue,
                    style: mt({
                        left: `${ce.position>100?100:ce.position}%`
                    }),
                    onClick: () => ge(ce)
                }, [v("div", Kb, [ce.isCombo ? (H(), Se(T(Ue), {
                    key: 0,
                    icon: "combo"
                })) : ce.type === T(S).ShippingGoal ? (H(), Se(T(Ue), {
                    key: 1,
                    icon: "shipping"
                })) : ce.type === T(S).GiftGoal ? (H(), Se(T(Ue), {
                    key: 2,
                    icon: A.value
                }, null, 8, ["icon"])) : (H(), Se(T(Ue), {
                    key: 3,
                    icon: "coupon"
                }))]), v("div", Yb, Te(ce.isCombo ? T(_).package_deal_reward_label : ce.title), 1)], 14, Hb))), 128))])]), ke.value ? (H(), Se(T(m_), {
                    key: 0,
                    "needed-amount": K.value ? V.value : 0
                }, null, 8, ["needed-amount"])) : ve("", !0), pe(T(ei), {
                    mode: "dark"
                })], 10, Mb)) : T(L).isDesignMode() ? ht((H(), ne("div", Wb, Qb, 512)), [
                    [Rt, T(a) && !T(f).enable_empty_cart_reward_bar]
                ]) : ve("", !0)
            }
        }),
        Zb = {
            key: 0,
            class: "qbk-cart-widget"
        },
        Jb = {
            key: 0,
            class: "qbk-spinner"
        },
        Xb = {
            class: "qbk-cart-widget__container"
        },
        e_ = {
            key: 0,
            class: "qbk-cart-widget_details"
        },
        t_ = {
            class: "qbk-cart-widget__summary-line"
        },
        o_ = ["innerHTML"],
        n_ = {
            class: "qbk-cart-widget__summary-line"
        },
        r_ = ["innerHTML"],
        i_ = {
            class: "qbk-cart-widget__discount-section"
        },
        a_ = v("div", {
            class: "qbk-cart-widget-divider"
        }, " ", -1),
        s_ = {
            class: "qbk-cart-widget__summary-line-subtotal__label"
        },
        l_ = ["innerHTML"],
        c_ = {
            class: "qbk-cart-widget__info-section"
        },
        u_ = {
            class: "qbk-cart-widget__info-text"
        },
        d_ = Fe({
            __name: "CartWidget",
            setup(e) {
                const {
                    getConfig: t,
                    contents: o
                } = ze(), {
                    cart: n,
                    customCart: r,
                    createCustomCart: i,
                    clearCustomCart: a,
                    isCartEmpty: s,
                    appliedDiscounts: c
                } = kt(), {
                    discounts: l,
                    isDiscountReady: f
                } = wt(), u = t("isUseCustomCart"), d = J(u), _ = async () => {
                    d.value = !0;
                    try {
                        l.value && l.value.length > 1 ? await i(l.value) : a()
                    } catch (x) {
                        L.log("Cart widget cannot update data", x)
                    } finally {
                        d.value = !1
                    }
                }, g = q(() => ({
                    justifyContent: h.value ? "space-between" : "flex-end"
                })), h = q(() => r.value || E.value.length > 0), O = q(() => b.value - C.value), b = q(() => {
                    var N;
                    return (N = n.value) == null ? void 0 : N.original_total_price
                }), C = q(() => {
                    var x, N, w, D;
                    if (r.value) {
                        const P = (x = n.value) == null ? void 0 : x.original_total_price,
                            I = oo.convertMoney(+((w = (N = r.value) == null ? void 0 : N.cost) == null ? void 0 : w.subtotalAmount.amount), !0);
                        return P - I
                    }
                    return (D = n.value) == null ? void 0 : D.total_discount
                }), E = q(() => {
                    var x;
                    return r.value ? ((x = r.value) == null ? void 0 : x.discountCodes.map(N => N.code)) || [] : c.value.all
                });
                return nt(() => {
                    u && document.addEventListener(F.EVENT_DATA_UPDATED, _)
                }), io(() => {
                    u && document.removeEventListener(F.EVENT_DATA_UPDATED, _)
                }), (x, N) => !T(s) && T(f) ? (H(), ne("div", Zb, [d.value ? (H(), ne("div", Jb, " ")) : ve("", !0), v("div", Xb, [h.value ? (H(), ne("div", e_, [v("div", t_, [v("span", null, Te(T(o).cart_widget_subtotal_original_text), 1), v("div", {
                    class: "qbk-cart-widget__summary-line__amount",
                    innerHTML: T(ut)(b.value)
                }, null, 8, o_)]), v("div", n_, [v("span", null, Te(T(o).cart_widget_discount_text), 1), v("div", {
                    class: "qbk-cart-widget__summary-line__amount",
                    innerHTML: T(ut)(C.value)
                }, null, 8, r_)]), v("div", i_, [(H(!0), ne(Be, null, dt(E.value, w => (H(), ne("div", {
                    class: "qbk-cart-widget__discount-code",
                    key: w
                }, [pe(T(Ue), {
                    icon: "discount",
                    size: "lg"
                }), v("span", null, Te(w), 1)]))), 128))]), a_])) : ve("", !0), v("div", {
                    class: "qbk-cart-widget__summary-line qbk-cart-widget__summary-line-subtotal",
                    style: mt(g.value)
                }, [v("span", s_, Te(T(o).cart_widget_subtotal_text), 1), v("div", {
                    class: "qbk-cart-widget__summary-line-subtotal__value",
                    innerHTML: T(ut)(O.value)
                }, null, 8, l_)], 4), v("div", c_, [v("span", u_, Te(T(o).cart_widget_info_text), 1)])])])) : ve("", !0)
            }
        }),
        f_ = {
            key: 0,
            class: "qbk-recommendation-box-empty-state"
        },
        p_ = [v("div", {
            class: "qbk-spinner"
        }, " ", -1)],
        b_ = ["disabled"],
        __ = ["disabled"],
        m_ = Fe({
            __name: "RecommendationBox",
            props: {
                neededAmount: {}
            },
            setup(e) {
                const t = e,
                    o = J(null),
                    n = J(null),
                    r = J(null),
                    {
                        getConfig: i,
                        settings: a
                    } = ze(),
                    {
                        recommendationData: s,
                        isCollecting: c
                    } = sc(),
                    l = q(() => {
                        if (!o.value) return;
                        const {
                            clientWidth: _
                        } = o.value;
                        return _ > i("orderGoalBreakpoint") ? {
                            "--qbk-recommend-box-column": 2
                        } : {
                            "--qbk-recommend-box-column": 1
                        }
                    });
                ot(() => o.value, () => {
                    setTimeout(() => {
                        var _;
                        d(), (_ = o.value) == null || _.addEventListener("scroll", d)
                    }, 100)
                });
                const f = q(() => {
                        if (t.neededAmount > 0 && a.value.recommended_rules === ra.NearestPrice) {
                            const _ = s.value.filter(h => h.price < t.neededAmount).sort((h, O) => O.price - h.price);
                            return [...s.value.filter(h => h.price >= t.neededAmount).sort((h, O) => h.price - O.price), ..._]
                        }
                        return s.value
                    }),
                    u = (_, g) => {
                        if (_.preventDefault(), _.stopPropagation(), !o.value) return;
                        const h = o.value.clientWidth;
                        o.value.scrollBy({
                            left: g === "prev" ? -h : h
                        })
                    };

                function d() {
                    if (!o.value) return;
                    const {
                        scrollWidth: _,
                        scrollLeft: g,
                        clientWidth: h
                    } = o.value;
                    n.value = g > 0, r.value = g + h < _ - 1
                }
                return (_, g) => T(c) ? (H(), ne("div", f_, p_)) : T(s).length ? (H(), ne("div", {
                    key: 1,
                    class: Le(["qbk-recommendation-box", {
                        "qbk-recommendation-box--full": n.value === !1 && r.value === !1
                    }])
                }, [v("div", {
                    class: "qbk-recommendation-box__container",
                    ref_key: "containerRef",
                    ref: o,
                    style: mt(l.value)
                }, [(H(!0), ne(Be, null, dt(f.value, h => (H(), Se(T(Qg), {
                    data: h
                }, null, 8, ["data"]))), 256))], 4), n.value || r.value ? (H(), ne(Be, {
                    key: 0
                }, [v("button", {
                    class: "qbk-recommendation__nav qbk-recommendation__nav--prev",
                    disabled: !n.value,
                    onClick: g[0] || (g[0] = h => u(h, "prev"))
                }, [pe(T(Ue), {
                    icon: "prev"
                })], 8, b_), v("button", {
                    class: "qbk-recommendation__nav qbk-recommendation__nav--next",
                    disabled: !r.value,
                    onClick: g[1] || (g[1] = h => u(h, "next"))
                }, [pe(T(Ue), {
                    icon: "next"
                })], 8, __)], 64)) : ve("", !0)], 2)) : ve("", !0)
            }
        }),
        g_ = ["innerHTML"],
        h_ = {
            key: 1,
            class: "qbk-free-gift__promote-banner"
        },
        v_ = ["innerHTML"],
        pc = Fe({
            __name: "FreeGift",
            props: {
                entry: {},
                triggerId: {},
                isPromote: {
                    type: Boolean
                }
            },
            setup(e) {
                const t = e,
                    {
                        contents: o,
                        extensionContents: n
                    } = ze(),
                    {
                        cart: r
                    } = kt(),
                    i = q(() => ({ ...t.entry,
                        ...n.value[t.entry.id] || {}
                    })),
                    a = rt("update-free-gift-items", () => {}),
                    s = rt("freeGiftActiveEntryId", J(0)),
                    c = rt("inNeedQuantity", q(() => 0)),
                    l = rt("isPopup", !1),
                    f = J([]);
                ot(() => s.value, E => {
                    E !== t.entry.id && (f.value = [])
                });
                const u = q(() => c.value ? yt(o.value.not_enough_quantity_error, {
                        quantity: c.value
                    }) : ""),
                    d = q(() => f.value.filter(E => E.quantity).length),
                    _ = q(() => +(t.entry.mode === ct.Manual && t.entry.enable_limit_gift && t.entry.limit_gift || 0)),
                    g = q(() => _.value && d.value >= _.value),
                    h = q(() => {
                        var E;
                        return yt(((E = i.value) == null ? void 0 : E.initiate_message) || "", {
                            quantity: t.entry.trigger_quantity
                        })
                    }),
                    O = q(() => {
                        let E = t.entry.offer_product_data;
                        if (t.entry.mode === ct.Auto) return E.reduce((N, w) => {
                            var D;
                            if (w.totalVariants === 1 || ((D = w.variants) == null ? void 0 : D.length) === 1) return N.push(w), N;
                            if (w.variants === Ft.All) {
                                const P = [...Array(w.totalVariants || 1).keys()].map(I => ({ ...w,
                                    totalVariants: 1,
                                    variantIndex: I
                                }));
                                N.push(...P)
                            } else if (Array.isArray(w.variants)) {
                                const P = w.variants.map(I => ({ ...w,
                                    totalVariants: 1,
                                    variants: [I]
                                }));
                                N.push(...P)
                            } else N.push(w);
                            return N
                        }, []).map(N => ({ ...N,
                            excludeVariantId: t.triggerId
                        }));
                        if (_.value) {
                            const N = (r.value.items || []).reduce((w, D) => {
                                const {
                                    [F.OFFER_ID_PROPERTY]: P
                                } = D.properties || {};
                                return P === t.entry.id && !w.includes(D.product_id) && w.push(D.product_id), w
                            }, []);
                            if (N.length) {
                                const w = _.value - N.length,
                                    D = E.filter(I => N.includes(+I.id)),
                                    P = w && E.filter(I => !N.includes(+I.id));
                                E = P && P.length ? [...D, ...P.slice(0, w)] : D
                            }
                        }
                        let x = 0;
                        return E.map(N => {
                            const w = { ...N,
                                excludeVariantId: t.triggerId
                            };
                            return _.value ? (w.enablePreSelected && x++, x > _.value ? { ...w,
                                enablePreSelected: !1
                            } : w) : w
                        })
                    }),
                    b = q(() => {
                        if (_.value && _.value < t.entry.offer_product_data.length) return yt(o.value.selected_items_text, {
                            selected_items: `${d.value}/${_.value}`
                        })
                    }),
                    C = (E, x) => {
                        f.value[E] = x;
                        const N = t.entry.discount_method === Lr.Code && t.entry.discount_code;
                        a(t.entry.id, {
                            lineItems: f.value.filter(w => w && w.quantity),
                            code: N || "",
                            haveDiscount: x.haveDiscount,
                            neededQuantity: +(t.entry.trigger_quantity || 1),
                            isMultiplier: !t.entry.allow_receive_once
                        }), L.log("free gift added", t.entry.id, {
                            index: E,
                            value: x
                        })
                    };
                return nt(() => {
                    Yt(t.entry.id, Vt.SessionProductOffer, {
                        component: t.entry.type
                    })
                }), (E, x) => (H(), ne("div", {
                    class: Le(["qbk-free-gift", {
                        "qbk-free-gift--auto": E.entry.mode === T(ct).Auto
                    }])
                }, [!E.isPromote && !T(c) && b.value ? (H(), ne("div", {
                    key: 0,
                    class: "qbk-free-gift_description qbk-description",
                    innerHTML: b.value
                }, null, 8, g_)) : ve("", !0), E.entry.initiate_message ? (H(), ne("div", h_, [pe(T(Ue), {
                    class: "qbk-free-gift__promote-icon",
                    icon: "gift-box",
                    size: "xl"
                }), v("div", {
                    class: "qbk-free-gift__promote-banner__contents",
                    innerHTML: h.value
                }, null, 8, v_)])) : ve("", !0), T(l) ? (H(), Se(T(dn), {
                    key: 2,
                    class: "qbk-mb-1",
                    message: u.value,
                    "not-fade": ""
                }, null, 8, ["message"])) : ve("", !0), pe(an, {
                    class: "qbk-offer-list--transition",
                    tag: "div",
                    name: "qbk--offer"
                }, {
                    default: Ge(() => [!E.isPromote || E.entry.mode === T(ct).Auto ? (H(!0), ne(Be, {
                        key: 0
                    }, dt(O.value, (N, w) => (H(), ne("div", {
                        class: "qbk-free-gift__offers",
                        key: w
                    }, [pe(T(Hn), {
                        entry: E.entry,
                        offer: N,
                        "active-entry-id": T(s),
                        "is-limited-gift": !!g.value,
                        "is-required-trigger": !!T(c),
                        onUpdateLineItems: D => C(w, D)
                    }, null, 8, ["entry", "offer", "active-entry-id", "is-limited-gift", "is-required-trigger", "onUpdateLineItems"])]))), 128)) : ve("", !0)]),
                    _: 1
                })], 2))
            }
        }),
        k_ = {
            key: 0,
            class: "qbk-promote-free-gift"
        },
        y_ = Fe({
            __name: "PromoteFreeGift",
            props: {
                form: {},
                to: {}
            },
            setup(e) {
                const t = e,
                    o = J(null),
                    n = J(null),
                    r = J(""),
                    i = J(1),
                    a = q(() => {
                        var P, I;
                        return {
                            productId: (P = window == null ? void 0 : window.qbkStore) == null ? void 0 : P.productId,
                            handle: ((I = window == null ? void 0 : window.qbkStore) == null ? void 0 : I.handle) || "",
                            triggerId: c.value,
                            type: S.FreeGift
                        }
                    }),
                    s = q(() => {
                        var oe, A;
                        const {
                            productId: P,
                            selectedId: I,
                            productData: $
                        } = (window == null ? void 0 : window.qbkStore) || {};
                        return $ && P && ((A = (oe = $[P]) == null ? void 0 : oe.variants) == null ? void 0 : A.length) === 1 ? I : ""
                    }),
                    {
                        selectedVariantId: c,
                        setupVariantChangeListener: l
                    } = da(q(() => t.form), s.value),
                    {
                        offersByType: f
                    } = jr(a),
                    {
                        addFreeGiftToCart: u,
                        updateFreeGiftItems: d,
                        clearData: _,
                        isValidOffer: g
                    } = va(c),
                    {
                        setupListener: h,
                        getQuantityInput: O
                    } = Ot(),
                    {
                        contents: b,
                        extensionContents: C
                    } = ze(),
                    {
                        setPromoteFreeGift: E
                    } = Nt(),
                    x = q(() => {
                        if (f.value.length) return f.value.find(P => P.mode === ct.Auto) || f.value.find(P => P.mode === ct.Manual)
                    }),
                    N = q(() => x.value ? { ...x.value,
                        ...C.value[x.value.id] || {}
                    } : {}),
                    w = q(() => {
                        var P;
                        return ((P = x.value) == null ? void 0 : P.mode) === ct.Auto && !g.value
                    });
                ot([x, w], () => {
                    var P, I;
                    if (w.value) {
                        E(c.value);
                        return
                    }
                    x.value && (E(c.value, x.value), ((P = x.value) == null ? void 0 : P.mode) === ct.Manual && ((I = n.value) == null ? void 0 : I.getAttribute(F.POPUP_LISTENER)) === "false" && n.value.setAttribute(F.POPUP_LISTENER, "true"))
                }), ot(() => x.value, (P, I) => {
                    var $;
                    P && !I && (($ = n.value) == null ? void 0 : $.getAttribute(F.PROMOTE_FREE_GIFT_LISTENER)) === "false" && n.value.setAttribute(F.PROMOTE_FREE_GIFT_LISTENER, "true")
                }), ot(() => c.value, P => {
                    P && (_(), D(), n.value && n.value.setAttribute(F.PROMOTE_FREE_GIFT_LISTENER, "true"))
                }), ot(() => t.to, P => {
                    if (!P) return;
                    let I = P;
                    typeof P == "string" && (I = document.querySelector(P)), n.value = I;
                    const $ = O(t.form),
                        oe = () => {
                            if (D(), !x.value || x.value.mode === ct.Manual || w.value) {
                                setTimeout(() => {
                                    I.click()
                                }, 0);
                                return
                            }
                            let A = !0;
                            I.style.pointerEvents = "none", u($ == null ? void 0 : $.value).then(K => {
                                var ae;
                                A = !1, document.dispatchEvent(new CustomEvent(F.EVENT_OPEN_ADDED_GIFT_POPUP, {
                                    detail: {
                                        addedGift: K && K.items || [],
                                        message: (ae = N.value) == null ? void 0 : ae.success_message,
                                        element: I,
                                        beforeClose: () => {
                                            I.click(), x.value && I.setAttribute(F.PROMOTE_FREE_GIFT_LISTENER, "true")
                                        }
                                    }
                                }))
                            }).catch(K => {
                                K.name === Mr.NotEnoughQuantity && setTimeout(() => I.setAttribute(F.PROMOTE_FREE_GIFT_LISTENER, "true"), 100), r.value = (K == null ? void 0 : K.message) || b.value.common_error
                            }).finally(() => {
                                I.style.pointerEvents = "auto", A && I.click(), i.value += 1
                            })
                        };
                    h(I, F.PROMOTE_FREE_GIFT_LISTENER, oe), l()
                }), ot([o, n], () => {
                    !n.value || !o.value || n.value.before(o.value)
                });
                const D = () => r.value = "";
                return $t("update-free-gift-items", d), (P, I) => n.value ? (H(), ne("div", k_, [ht(v("div", {
                    class: "qbk-promote-free-gift__content",
                    ref_key: "freeGiftRef",
                    ref: o
                }, [x.value ? (H(), Se(T(pc), {
                    key: `${T(c)}${x.value.id}${i.value}`,
                    entry: x.value,
                    "trigger-id": T(c),
                    "is-promote": ""
                }, null, 8, ["entry", "trigger-id"])) : ve("", !0), pe(T(dn), {
                    class: "qbk-mb-1",
                    message: r.value,
                    "not-fade": ""
                }, null, 8, ["message"])], 512), [
                    [Rt, !w.value]
                ]), pe(T(M_))])) : ve("", !0)
            }
        }),
        q_ = {
            class: "qbk-popup-wrapper qbk-added-gift"
        },
        E_ = {
            class: "qbk-popup__header"
        },
        w_ = ["innerHTML"],
        x_ = {
            key: 0,
            class: "qbk-popup__body"
        },
        C_ = {
            class: "qbk-offer__body"
        },
        T_ = {
            class: "qbk-offer__sub-body"
        },
        O_ = {
            class: "qbk-offer__contents"
        },
        N_ = {
            class: "qbk-offer__content qbk-offer__content-info"
        },
        P_ = ["href", "target", "title"],
        A_ = ["innerHTML"],
        I_ = {
            class: "qbk-offer__price"
        },
        D_ = {
            class: "qbk-offer__price--offer"
        },
        S_ = ["innerHTML"],
        $_ = {
            class: "qbk-offer__content qbk-offer__content-actions"
        },
        R_ = {
            class: "qbk-offer__quantity-action"
        },
        F_ = {
            class: "qbk-offer__quantity"
        },
        V_ = {
            class: "qbk-offer__quantity-label",
            title: "Quantity"
        },
        L_ = {
            class: "qbk-offer__variants"
        },
        G_ = {
            class: "qbk-popup__footer"
        },
        M_ = Fe({
            __name: "AddedGiftPopup",
            setup(e) {
                const t = J(null),
                    o = J(!1),
                    {
                        show: n,
                        hide: r
                    } = Vr(),
                    {
                        contents: i
                    } = ze(),
                    a = f => {
                        t.value = f, n(F.POPUP_ADDED_GIFT_NAME)
                    },
                    s = () => {
                        var f, u;
                        (u = (f = t.value) == null ? void 0 : f.beforeClose) == null || u.call(f)
                    },
                    c = () => {
                        r(F.POPUP_ADDED_GIFT_NAME)
                    },
                    l = async () => {
                        var f;
                        (f = t.value) == null || f.element.click(), o.value = !0, await L.delay(1e3), window.location.href = L.insertLocaleToShopLink("/checkout"), o.value = !1
                    };
                return Er(() => {
                    document.addEventListener(F.EVENT_OPEN_ADDED_GIFT_POPUP, f => a({ ...f.detail
                    }))
                }), io(() => {
                    document.removeEventListener(F.EVENT_OPEN_ADDED_GIFT_POPUP, f => a({ ...f.detail
                    }))
                }), (f, u) => (H(), Se(T(na), {
                    name: T(F).POPUP_ADDED_GIFT_NAME,
                    "wrapper-class": "qbk-popup-added-gift",
                    onBeforeClose: s
                }, {
                    default: Ge(() => {
                        var d, _;
                        return [v("div", q_, [v("div", E_, [pe(T(Ue), {
                            class: "qbk-ag-popup__header-icon",
                            icon: "check-circle"
                        }), v("div", {
                            class: "qbk-ag-popup__header-message",
                            innerHTML: ((d = t.value) == null ? void 0 : d.message) || ""
                        }, null, 8, w_)]), (_ = t.value) != null && _.addedGift.length ? (H(), ne("div", x_, [(H(!0), ne(Be, null, dt(t.value.addedGift, g => (H(), ne("div", {
                            class: "qbk-offer",
                            key: g.handle
                        }, [v("div", C_, [v("span", {
                            class: "qbk-offer__image",
                            style: mt({
                                backgroundImage: `url(${T(Kr)(g.image)})`
                            })
                        }, " ", 4), v("div", T_, [v("div", O_, [v("div", N_, [v("a", {
                            class: "qbk-offer__title qbk-truncate",
                            href: `${g.url}`,
                            target: g.url.includes("javascript") ? "" : "_blank",
                            title: g.title
                        }, [v("span", {
                            innerHTML: T(To)(g.title)
                        }, null, 8, A_)], 8, P_)]), v("div", I_, [v("div", D_, Te(T(i).free_offer_text), 1), v("div", {
                            class: "qbk-offer__price--origin",
                            innerHTML: T(ut)(g.price)
                        }, null, 8, S_)]), v("div", $_, [v("div", R_, [v("div", F_, [v("div", V_, "×" + Te(g.quantity), 1)])]), v("div", L_, [v("span", null, Te(T(ha)(T(To)(g.variant_title || ""))), 1)])])])])])]))), 128))])) : ve("", !0), v("div", G_, [pe(T(Ut), {
                            class: "qbk-mr-1",
                            plain: "",
                            onClick: c
                        }, {
                            default: Ge(() => [v("span", null, Te(T(i).continue_shopping), 1)]),
                            _: 1
                        }), pe(T(Ut), {
                            primary: "",
                            loading: o.value,
                            onClick: l
                        }, {
                            default: Ge(() => [v("span", null, Te(T(i).checkout_button_text), 1)]),
                            _: 1
                        }, 8, ["loading"])])])]
                    }),
                    _: 1
                }, 8, ["name"]))
            }
        }),
        B_ = {
            class: "qbk-upsurge"
        },
        U_ = ["innerHTML"],
        j_ = {
            class: "qbk-upsurge-action"
        },
        z_ = {
            class: "qbk-upsurge__total"
        },
        H_ = {
            class: "qbk-upsurge__total-title"
        },
        K_ = {
            class: "qbk-upsurge__total-value qbk-offer__price"
        },
        Y_ = ["innerHTML"],
        W_ = ["innerHTML"],
        Q_ = {
            class: "qbk-upsurge__actions"
        },
        Z_ = Fe({
            __name: "Upsurge",
            props: {
                entry: {},
                triggerId: {}
            },
            emits: ["updated"],
            setup(e, {
                emit: t
            }) {
                const o = e,
                    n = rt("isPopup", !1),
                    r = J(!1),
                    i = J(""),
                    {
                        isValidOffer: a,
                        isLoadingItems: s,
                        updateItems: c,
                        price: l,
                        addUpsurgeToCart: f,
                        offerPrice: u
                    } = rc(q(() => o.triggerId), q(() => o.entry), n),
                    {
                        contents: d
                    } = ze(),
                    _ = J([]),
                    g = q(() => {
                        let w = 0;
                        return o.entry.offer_product_data.map(D => {
                            const P = { ...D,
                                excludeVariantId: o.triggerId
                            };
                            return P.enablePreSelected && w++, w > O.value ? { ...P,
                                enablePreSelected: !1
                            } : P
                        })
                    }),
                    h = q(() => a.value ? d.value.upsurge_button_text : d.value.out_of_stock_button_text),
                    O = q(() => o.entry.enable_multiple_offer && o.entry.multiple_offer_limit || 1),
                    b = q(() => C.value >= O.value),
                    C = q(() => _.value.filter(w => w.status === Pe.Added).length),
                    E = q(() => {
                        if (O.value < o.entry.offer_product_data.length) return yt(d.value.selected_items_text, {
                            selected_items: `${C.value}/${O.value}`
                        })
                    }),
                    x = async () => {
                        r.value = !0;
                        try {
                            await f()
                        } catch (w) {
                            i.value = (w == null ? void 0 : w.message) || d.value.common_error
                        } finally {
                            r.value = !1
                        }
                    },
                    N = (w, D) => {
                        _.value[w] = D, c(_.value.filter(P => P && P.quantity)), t("updated")
                    };
                return nt(() => {
                    Yt(o.entry.id, Vt.SessionProductOffer, {
                        component: S.Upsurge
                    })
                }), (w, D) => (H(), ne("div", B_, [E.value ? (H(), ne("div", {
                    key: 0,
                    class: "qbk-offer__selected-items-counter qbk-description",
                    innerHTML: E.value
                }, null, 8, U_)) : ve("", !0), pe(an, {
                    class: "qbk-offer-list--transition",
                    tag: "div",
                    name: "qbk--offer"
                }, {
                    default: Ge(() => [(H(!0), ne(Be, null, dt(g.value, (P, I) => (H(), ne("div", {
                        class: "qbk-upsurge__offers",
                        key: P.handle
                    }, [pe(T(Hn), {
                        entry: w.entry,
                        offer: P,
                        "is-limited-gift": !!b.value,
                        onUpdateLineItems: $ => N(I, $)
                    }, null, 8, ["entry", "offer", "is-limited-gift", "onUpdateLineItems"])]))), 128))]),
                    _: 1
                }), v("div", j_, [zt(w.$slots, "navigate"), v("div", z_, [v("div", H_, Te(T(d).total_text), 1), v("div", K_, [ht(v("div", {
                    class: "qbk-offer__price--origin",
                    innerHTML: T(ut)(T(l))
                }, null, 8, Y_), [
                    [Rt, T(l) !== T(u)]
                ]), v("div", {
                    class: "qbk-offer__price--offer",
                    innerHTML: T(ut)(T(u))
                }, null, 8, W_)])]), pe(T(dn), {
                    message: i.value
                }, null, 8, ["message"]), v("div", Q_, [pe(T(Ut), {
                    class: "qbk-upsurge__action-btn",
                    loading: r.value || T(s),
                    disabled: !T(a) || T(s),
                    error: !!i.value,
                    "hide-error": "",
                    primary: "",
                    type: "button",
                    onClick: x
                }, {
                    default: Ge(() => [v("span", null, Te(h.value), 1)]),
                    _: 1
                }, 8, ["loading", "disabled", "error"])])])]))
            }
        }),
        J_ = {
            key: 0,
            class: "qbk-popup-wrapper qbk-gift-goal"
        },
        X_ = {
            class: "qbk-popup__header-silent"
        },
        em = {
            class: "qbk-popup__header"
        },
        tm = ["innerHTML"],
        om = ["innerHTML"],
        nm = {
            class: "qbk-popup__body"
        },
        rm = {
            class: "qbk-gift-goal__tiers"
        },
        im = ["onClick"],
        am = {
            class: "qbk-gift-goal__tier-label"
        },
        sm = ["innerHTML"],
        lm = {
            class: "qbk-gift-goal__tier-body"
        },
        cm = {
            class: "qbk-popup__footer"
        },
        um = {
            class: "qbk-popup__action-btn"
        },
        dm = Fe({
            __name: "GiftGoalPopup",
            props: {
                previewData: {}
            },
            setup(e) {
                const t = e,
                    o = rt("isPortal", !1),
                    n = J(null),
                    r = J(o ? 0 : -1),
                    i = J({}),
                    a = J(!1),
                    s = J(""),
                    c = J(!1),
                    l = J(!0),
                    {
                        show: f,
                        hide: u
                    } = Vr(),
                    {
                        extensionContents: d,
                        settings: _,
                        contents: g
                    } = ze(),
                    {
                        updateGiftGoalItem: h,
                        updateGift: O,
                        getStorageData: b,
                        giftGoalItems: C,
                        clearData: E
                    } = ic(),
                    {
                        renderCartContents: x
                    } = Ot(),
                    {
                        getProductData: N
                    } = Nt(),
                    w = q(() => o ? "div" : na),
                    D = q(() => {
                        var R, U;
                        return ((R = t.previewData) == null ? void 0 : R.entry) || ((U = n.value) == null ? void 0 : U.entry)
                    }),
                    P = q(() => {
                        var R;
                        return ((R = D.value) == null ? void 0 : R.mode) === ct.Auto
                    }),
                    I = q(() => D.value ? { ...D.value,
                        ...d.value[D.value.id] || {}
                    } : {}),
                    $ = q(() => {
                        const {
                            tierData: R
                        } = o ? t.previewData : n.value || {};
                        return R != null && R.length ? R.map(U => {
                            var Je;
                            const ie = C.value[U.raw_subtotal],
                                {
                                    isRejected: _e,
                                    isPending: he,
                                    isSyncStorage: Ce
                                } = ie || {},
                                we = !he && !_e && (ie == null ? void 0 : ie.lineItems),
                                ke = (Je = we || []) == null ? void 0 : Je.length,
                                Oe = !P.value && U.enable_limit_gift && +U.limit_gift || 0,
                                Ve = Oe && ke >= Oe;
                            let Ae = U.offer_product_data || [];
                            if (P.value && (Ae = Ae.reduce((De, Ye) => {
                                    var V;
                                    const He = { ...Ye
                                        },
                                        y = (He.variants === Ft.All ? (((V = N(He.id, He.handle, o)) == null ? void 0 : V.variants) || []).map(Z => String(Z.id)) : He.variants).map(Z => ({ ...He,
                                            variants: [Z],
                                            triggerId: Z
                                        }));
                                    return De.push(...y), De
                                }, [])), Ce && we) Ae = Ae.map(De => {
                                const Ye = we.find(He => P.value ? He.id === De.triggerId : +He.productId == +De.id);
                                return { ...De,
                                    enablePreSelected: !!Ye,
                                    triggerId: Ye == null ? void 0 : Ye.id,
                                    isSync: !!Ye
                                }
                            });
                            else if (!P.value) {
                                let De = 0;
                                Ae = Ae.map(Ye => {
                                    const He = { ...Ye
                                    };
                                    return He.enablePreSelected && De++, Oe && De > Oe || !U.completed || _e ? { ...He,
                                        enablePreSelected: !1
                                    } : He
                                })
                            }
                            const We = _.value.reward_bar_measurement_unit === Gn.PurchaseAmount ? ut(U.neededAmount) : U.neededAmount;
                            return { ...U,
                                offer_product_data: Ae,
                                isLimited: Ve,
                                description: Oe && Oe < Ae.length && yt(g.value.selected_items_text, {
                                    selected_items: `${ke}/${Oe}`
                                }),
                                message: U.completed ? "" : yt(g.value.buy_more_to_get_gift_text, {
                                    amount: We
                                })
                            }
                        }) : []
                    }),
                    oe = () => {
                        s.value = ""
                    },
                    A = () => {
                        oe(), E(), document.dispatchEvent(new CustomEvent(F.EVENT_GIFT_GOAL_BEFORE_CLOSE))
                    },
                    K = () => {
                        var R, U;
                        if (L.log("gift goal popup: close"), o) {
                            (U = (R = t.previewData) == null ? void 0 : R.onClose) == null || U.call(R);
                            return
                        }
                        if (!c.value) {
                            L.log("Gift goal popup: nothing change"), u(F.POPUP_GIFT_GOAL_NAME);
                            return
                        }
                        ae()
                    },
                    ae = async () => {
                        try {
                            a.value = !0;
                            const R = await O();
                            R && (await x(R, () => window.location.reload()), document.dispatchEvent(new CustomEvent(F.EVENT_GIFT_GOAL_ADDED))), u(F.POPUP_GIFT_GOAL_NAME)
                        } catch (R) {
                            s.value = (R == null ? void 0 : R.message) || g.value.common_error, l.value = !0
                        } finally {
                            a.value = !1
                        }
                    },
                    B = (R, U, ie, _e) => {
                        let he = i.value[R];
                        if (he ? he[U] = ie : (he = [], he[U] = ie, i.value[R] = he), _e.isSync) {
                            _e.isSync = !1;
                            return
                        }
                        c.value = !0, l.value = !1, h(R, i.value[R].filter(Ce => Ce && Ce.quantity && Ce.haveDiscount)), oe(), L.log("gift goal added", {
                            minSubtotal: R,
                            lineIndex: U,
                            value: ie
                        })
                    },
                    re = R => {
                        const U = b();
                        L.isEmptyObj(U) || (Object.keys(U).forEach(ie => U[ie].isSyncStorage = !0), C.value = U), n.value = R, R.activeTier ? r.value = $.value.findIndex(ie => {
                            var _e;
                            return ie.raw_subtotal === ((_e = R.activeTier) == null ? void 0 : _e.raw_subtotal)
                        }) : $.value.some((ie, _e) => {
                            var he;
                            return !ie.completed || !((he = U[ie.raw_subtotal]) != null && he.lineItems.length) ? (r.value = _e, !0) : !1
                        }), document.dispatchEvent(new CustomEvent(F.EVENT_GIFT_GOAL_BEFORE_OPEN)), f(F.POPUP_GIFT_GOAL_NAME)
                    };
                return nt(() => {
                    document.addEventListener(F.EVENT_OPEN_GIFT_GOAL, R => re({ ...R.detail
                    }))
                }), io(() => {
                    document.removeEventListener(F.EVENT_OPEN_GIFT_GOAL, R => re({ ...R.detail
                    }))
                }), $t("isPopup", !0), (R, U) => (H(), Se(Ai(w.value), {
                    name: T(F).POPUP_GIFT_GOAL_NAME,
                    "wrapper-class": "qbk-popup-gift-goal",
                    "enable-close": l.value,
                    onBeforeClose: A
                }, {
                    default: Ge(() => [D.value ? (H(), ne("div", J_, [v("div", X_, [v("a", {
                        class: "qbk-popup__outside-btn qbk-popup__close",
                        onClick: K
                    }, [pe(T(Ue), {
                        icon: "close"
                    })])]), pe(T(ei), {
                        float: ""
                    }), v("div", em, [v("div", {
                        class: "qbk-popup__title qbk-title",
                        innerHTML: I.value.popup_title
                    }, null, 8, tm), v("div", {
                        class: "qbk-popup__description qbk-description",
                        innerHTML: I.value.popup_description
                    }, null, 8, om)]), v("div", nm, [v("div", rm, [(H(!0), ne(Be, null, dt($.value, (ie, _e) => (H(), ne("div", {
                        class: Le(["qbk-gift-goal__tier", {
                            "qbk-gift-goal__tier--active": _e === r.value
                        }])
                    }, [v("div", {
                        class: "qbk-gift-goal__tier-header",
                        onClick: he => r.value = r.value === _e ? -1 : _e
                    }, [v("div", {
                        class: Le(["qbk-gift-goal__info", {
                            "qbk-gift-goal__info--has-description": ie.description || ie.message
                        }])
                    }, [v("div", {
                        class: Le(["qbk-gift-goal__tier-title", {
                            "qbk-gift-goal__tier-title--completed": ie.completed,
                            "qbk-gift-goal__tier-title--added": ie.isGiftAdded
                        }])
                    }, [v("div", am, Te(ie.title), 1), v("div", {
                        class: "qbk-gift-goal__tier-description",
                        innerHTML: ie.completed && ie.description || ie.message || ""
                    }, null, 8, sm)], 2)], 2), pe(T(Ue), {
                        class: "qbk-gift-goal__tier-indicator",
                        icon: "arrow-down"
                    })], 8, im), v("div", lm, [pe(an, {
                        class: "qbk-offer-list--transition",
                        tag: "div",
                        name: "qbk--offer"
                    }, {
                        default: Ge(() => [(H(!0), ne(Be, null, dt(ie.offer_product_data, (he, Ce) => (H(), ne("div", {
                            class: "qbk-gift-goal__tier-offers",
                            key: he.handle
                        }, [pe(T(Hn), {
                            entry: D.value,
                            offer: he,
                            "is-active-offer": ie.completed,
                            "is-limited-gift": !!ie.isLimited,
                            onUpdateLineItems: we => B(ie.raw_subtotal, Ce, we, he)
                        }, null, 8, ["entry", "offer", "is-active-offer", "is-limited-gift", "onUpdateLineItems"])]))), 128))]),
                        _: 2
                    }, 1024)])], 2))), 256))])]), v("div", cm, [v("div", um, [pe(T(Ut), {
                        class: "qbk-popup__continue",
                        primary: "",
                        loading: a.value,
                        error: s.value,
                        onClick: K
                    }, {
                        default: Ge(() => [v("span", null, Te(T(g).grab_offer_button_text), 1)]),
                        _: 1
                    }, 8, ["loading", "error"])])])])) : ve("", !0)]),
                    _: 1
                }, 40, ["name", "enable-close"]))
            }
        }),
        fm = {
            key: 0,
            class: "qbk-today-offers"
        },
        pm = {
            class: "qbk-today-offers__activator-label"
        },
        bm = {
            key: 0,
            class: "qbk-today-offers__offer-count"
        },
        _m = {
            class: "qbk-today-offers__body"
        },
        mm = {
            class: "qbk-today-offers__body-header"
        },
        gm = {
            class: "qbk-today-offers__body__title"
        },
        hm = {
            class: "qbk-today-offers__body__description"
        },
        vm = {
            class: "qbk-today-offers__body__offers"
        },
        km = {
            key: 0,
            class: "qbk-today-offers__body__offers--loading"
        },
        ym = [v("div", {
            class: "qbk-spinner"
        }, " ", -1)],
        qm = {
            key: 1,
            class: "qbk-today-offers__body__offer-contents"
        },
        Em = {
            class: "qbk-today-offers__body__offer-header"
        },
        wm = {
            class: "qbk-today-offers__body__offer-info"
        },
        xm = {
            class: "qbk-today-offers__body__offer-content"
        },
        Cm = ["innerHTML"],
        Tm = {
            class: "qbk-today-offers__body__offer-action"
        },
        Om = Fe({
            __name: "TodayOffers",
            setup(e) {
                const t = J(!1),
                    o = J(!1),
                    n = J(!1),
                    {
                        todayOffers: r,
                        collectTodayOffers: i,
                        collectTodayOfferProducts: a,
                        products: s
                    } = hp(),
                    {
                        dismissTodayOffers: c
                    } = zn(),
                    {
                        getConfig: l,
                        contents: f
                    } = ze(),
                    u = q(() => l("numberOfTodayOffers")),
                    d = q(() => r.value.slice(0, u.value)),
                    _ = q(() => d.value.map(h => {
                        var E;
                        const O = s.value[h.offerId],
                            b = s.value[h.triggerId];
                        if (!O || !b) return;
                        const C = Kr((E = O.featuredImage) == null ? void 0 : E.url);
                        return { ...h,
                            claim: () => window.location.href = L.insertLocaleToShopLink(`/products/${b.handle}`),
                            image: `url(${C})`,
                            description: yt(h.type === S.FreeGift ? f.value.today_offer_free_gift_description : f.value.today_offer_item_description, {
                                offer_title: O.title,
                                trigger_title: b.title,
                                discount: h.discountValue
                            })
                        }
                    }).filter(h => h)),
                    g = async () => {
                        n.value = !0, o.value = !o.value, await a(), n.value = !1, t.value = !0
                    };
                return nt(() => {
                    i(u.value)
                }), (h, O) => d.value.length ? (H(), ne("div", fm, [v("div", {
                    class: "qbk-today-offers__activator",
                    onClick: g
                }, [v("span", pm, Te(T(f).today_offer_label), 1), t.value ? ve("", !0) : (H(), ne("div", bm, [v("span", null, Te(d.value.length), 1)])), t.value && !o.value ? (H(), ne("div", {
                    key: 1,
                    class: "qbk-today-offers__offer-close",
                    onClick: O[0] || (O[0] = (...b) => T(c) && T(c)(...b))
                }, [pe(T(Ue), {
                    icon: "close",
                    size: "xs"
                })])) : ve("", !0)]), pe(lo, {
                    name: "qbk-fade"
                }, {
                    default: Ge(() => [ht(v("div", _m, [v("div", mm, [v("div", {
                        class: "qbk-today-offers__close",
                        onClick: g
                    }, [pe(T(Ue), {
                        icon: "close",
                        size: "xs"
                    })]), v("h2", gm, Te(T(f).today_offer_label), 1), v("div", hm, Te(T(f).today_offer_description), 1)]), v("div", vm, [n.value ? (H(), ne("div", km, ym)) : (H(), ne("div", qm, [(H(!0), ne(Be, null, dt(_.value, b => (H(), ne("div", {
                        class: "qbk-today-offers__body__offer-wrapper",
                        key: b.key
                    }, [v("div", {
                        class: Le(["qbk-today-offers__body__offer", {
                            "qbk-today-offers--claimed": b.claimed
                        }])
                    }, [v("div", Em, [pe(T(Ue), {
                        icon: b.type === T(S).FreeGift ? "gift-box" : "percent",
                        size: "lg"
                    }, null, 8, ["icon"])]), v("div", wm, [v("div", xm, [v("span", {
                        class: "qbk-today-offers__body__offer-img qbk-offer__image",
                        style: mt({
                            backgroundImage: b.image
                        })
                    }, " ", 4), v("div", {
                        class: "qbk-today-offers__body__offer-description",
                        innerHTML: b.description
                    }, null, 8, Cm)]), v("div", Tm, [b.claimed ? (H(), Se(T(Ue), {
                        key: 0,
                        icon: "check-circle",
                        size: "md"
                    })) : (H(), Se(T(Ut), {
                        key: 1,
                        outline: "",
                        onClick: b.claim
                    }, {
                        default: Ge(() => [al(Te(T(f).claim_button_text), 1)]),
                        _: 2
                    }, 1032, ["onClick"]))])])], 2)]))), 128))]))])], 512), [
                        [Rt, o.value]
                    ])]),
                    _: 1
                })])) : ve("", !0)
            }
        }),
        Nm = ["innerHTML"],
        bc = Fe({
            __name: "PromotionBadge",
            props: {
                productId: {},
                handle: {}
            },
            setup(e) {
                const t = e,
                    o = J(null),
                    {
                        contents: n
                    } = ze(),
                    {
                        cart: r,
                        isCartEmpty: i
                    } = kt(),
                    {
                        collectProductData: a
                    } = Nt(),
                    {
                        isPassConditions: s
                    } = jn(),
                    {
                        promotionEntries: c
                    } = zn(),
                    l = q(() => (u.value || {}).type === S.FreeGift ? n.value.free_gift_promotion_badge_label : n.value.promotion_badge_label),
                    f = q(() => {
                        var d;
                        return (d = t.productId || t.handle) == null ? void 0 : d.toString()
                    }),
                    u = q(() => {
                        if (!o.value) return !1;
                        const {
                            variants: d,
                            id: _,
                            tags: g,
                            collections: h,
                            available: O
                        } = o.value;
                        return O ? c.value.find(b => {
                            if (!s(b, {
                                    productPrice: d[0].price
                                })) return !1;
                            switch (b.trigger_type) {
                                case Ct.All:
                                    return !(b.trigger_data_excludes || []).some(x => +x.id == +_);
                                case Ct.Tag:
                                    return g.some(E => (b.trigger_data_tags || []).includes(E));
                                case Ct.Collection:
                                    return !(b.enable_trigger_data_collection_excludes && (b.trigger_data_collection_excludes || []).some(x => +x.id == +_)) && h.some(x => (b.trigger_data_collections || []).some(N => N.includes(x.toString())));
                                case Ct.Specific:
                                    return (b.trigger_data_products || []).some(E => +E.id == +_);
                                default:
                                    return !1
                            }
                        }) : !1
                    });
                return nt(async () => {
                    if (!c.value.length) return;
                    const d = r.value.items.some(_ => [_.product_id.toString(), _.handle].includes(f.value));
                    (i.value || !d) && (o.value = await a({
                        id: t.productId,
                        handle: t.handle
                    }))
                }), (d, _) => u.value ? (H(), ne("div", {
                    key: 0,
                    class: Le(["qbk-promotion-badge qbk-badge", `qbk-promotion-badge--${u.value.type}`])
                }, [v("div", {
                    class: "qbk-promotion-badge__label qbk-badge__label",
                    innerHTML: l.value
                }, null, 8, Nm)], 2)) : ve("", !0)
            }
        }); /*! vue-countdown v2.1.0 | (c) 2018-present Chen Fengyuan | MIT */
    const ti = 1e3,
        oi = 60 * ti,
        ni = 60 * oi,
        _c = 24 * ni,
        mc = "abort",
        gc = "end",
        hc = "progress",
        vc = "start",
        kc = "visibilitychange";
    var Pm = Fe({
        name: "VueCountdown",
        props: {
            autoStart: {
                type: Boolean,
                default: !0
            },
            emitEvents: {
                type: Boolean,
                default: !0
            },
            interval: {
                type: Number,
                default: 1e3,
                validator: e => e >= 0
            },
            now: {
                type: Function,
                default: () => Date.now()
            },
            tag: {
                type: String,
                default: "span"
            },
            time: {
                type: Number,
                default: 0,
                validator: e => e >= 0
            },
            transform: {
                type: Function,
                default: e => e
            }
        },
        emits: [mc, gc, hc, vc],
        data() {
            return {
                counting: !1,
                endTime: 0,
                totalMilliseconds: 0,
                requestId: 0
            }
        },
        computed: {
            days() {
                return Math.floor(this.totalMilliseconds / _c)
            },
            hours() {
                return Math.floor(this.totalMilliseconds % _c / ni)
            },
            minutes() {
                return Math.floor(this.totalMilliseconds % ni / oi)
            },
            seconds() {
                return Math.floor(this.totalMilliseconds % oi / ti)
            },
            milliseconds() {
                return Math.floor(this.totalMilliseconds % ti)
            },
            totalDays() {
                return this.days
            },
            totalHours() {
                return Math.floor(this.totalMilliseconds / ni)
            },
            totalMinutes() {
                return Math.floor(this.totalMilliseconds / oi)
            },
            totalSeconds() {
                return Math.floor(this.totalMilliseconds / ti)
            }
        },
        watch: {
            $props: {
                deep: !0,
                immediate: !0,
                handler() {
                    this.totalMilliseconds = this.time, this.endTime = this.now() + this.time, this.autoStart && this.start()
                }
            }
        },
        mounted() {
            document.addEventListener(kc, this.handleVisibilityChange)
        },
        beforeUnmount() {
            document.removeEventListener(kc, this.handleVisibilityChange), this.pause()
        },
        methods: {
            start() {
                this.counting || (this.counting = !0, this.emitEvents && this.$emit(vc), document.visibilityState === "visible" && this.continue())
            },
            continue () {
                if (!this.counting) return;
                const e = Math.min(this.totalMilliseconds, this.interval);
                if (e > 0) {
                    let t, o;
                    const n = r => {
                        t || (t = r), o || (o = r);
                        const i = r - t;
                        i >= e || i + (r - o) / 2 >= e ? this.progress() : this.requestId = requestAnimationFrame(n), o = r
                    };
                    this.requestId = requestAnimationFrame(n)
                } else this.end()
            },
            pause() {
                cancelAnimationFrame(this.requestId)
            },
            progress() {
                this.counting && (this.totalMilliseconds -= this.interval, this.emitEvents && this.totalMilliseconds > 0 && this.$emit(hc, {
                    days: this.days,
                    hours: this.hours,
                    minutes: this.minutes,
                    seconds: this.seconds,
                    milliseconds: this.milliseconds,
                    totalDays: this.totalDays,
                    totalHours: this.totalHours,
                    totalMinutes: this.totalMinutes,
                    totalSeconds: this.totalSeconds,
                    totalMilliseconds: this.totalMilliseconds
                }), this.continue())
            },
            abort() {
                this.counting && (this.pause(), this.counting = !1, this.emitEvents && this.$emit(mc))
            },
            end() {
                this.counting && (this.pause(), this.totalMilliseconds = 0, this.counting = !1, this.emitEvents && this.$emit(gc))
            },
            update() {
                this.counting && (this.totalMilliseconds = Math.max(0, this.endTime - this.now()))
            },
            restart() {
                this.pause(), this.totalMilliseconds = this.time, this.endTime = this.now() + this.time, this.counting = !1, this.start()
            },
            handleVisibilityChange() {
                switch (document.visibilityState) {
                    case "visible":
                        this.update(), this.continue();
                        break;
                    case "hidden":
                        this.pause();
                        break
                }
            }
        },
        render() {
            return bl(this.tag, this.$slots.default ? [this.$slots.default(this.transform({
                days: this.days,
                hours: this.hours,
                minutes: this.minutes,
                seconds: this.seconds,
                milliseconds: this.milliseconds,
                totalDays: this.totalDays,
                totalHours: this.totalHours,
                totalMinutes: this.totalMinutes,
                totalSeconds: this.totalSeconds,
                totalMilliseconds: this.totalMilliseconds
            }))] : void 0)
        }
    });
    const Am = {
            key: 0,
            class: "qbk-count-down"
        },
        Im = {
            class: "qbk-count-down-board"
        },
        Dm = {
            class: "qbk-count-down-item qbk-count-down--day"
        },
        Sm = {
            class: "qbk-count-down-digit"
        },
        $m = {
            class: "qbk-count-down-unit"
        },
        Rm = v("div", {
            class: "qbk-count-down-separate"
        }, [v("span", null, ":")], -1),
        Fm = {
            class: "qbk-count-down-item qbk-count-down--hour"
        },
        Vm = {
            class: "qbk-count-down-digit"
        },
        Lm = {
            class: "qbk-count-down-unit"
        },
        Gm = v("div", {
            class: "qbk-count-down-separate"
        }, [v("span", null, ":")], -1),
        Mm = {
            class: "qbk-count-down-item qbk-count-down--minute"
        },
        Bm = {
            class: "qbk-count-down-digit"
        },
        Um = {
            class: "qbk-count-down-unit"
        },
        jm = v("div", {
            class: "qbk-count-down-separate"
        }, [v("span", null, ":")], -1),
        zm = {
            class: "qbk-count-down-item qbk-count-down--second"
        },
        Hm = {
            class: "qbk-count-down-digit"
        },
        Km = {
            class: "qbk-count-down-unit"
        },
        Ym = Fe({
            __name: "CountDown",
            props: {
                time: {}
            },
            setup(e) {
                const t = e,
                    {
                        contents: o
                    } = ze(),
                    n = q(() => o.value.day_label),
                    r = q(() => o.value.hour_label),
                    i = q(() => o.value.minute_label),
                    a = q(() => o.value.second_label),
                    s = q(() => {
                        const c = new Date(t.time),
                            l = new Date;
                        return c.getTime() - l.getTime()
                    });
                return (c, l) => s.value > 0 ? (H(), ne("span", Am, [pe(T(Pm), {
                    time: s.value
                }, {
                    default: Ge(({
                        days: f,
                        hours: u,
                        minutes: d,
                        seconds: _
                    }) => [v("span", Im, [v("div", Dm, [v("span", Sm, Te(f), 1), v("span", $m, Te(n.value), 1)]), Rm, v("div", Fm, [v("span", Vm, Te(u), 1), v("span", Lm, Te(r.value), 1)]), Gm, v("div", Mm, [v("span", Bm, Te(d), 1), v("span", Um, Te(i.value), 1)]), jm, v("div", zm, [v("span", Hm, Te(_), 1), v("span", Km, Te(a.value), 1)])])]),
                    _: 1
                }, 8, ["time"])])) : ve("", !0)
            }
        }),
        Wm = {
            class: "qbk-badge__label"
        },
        ya = Fe({
            __name: "Badge",
            props: {
                label: {},
                backgroundColor: {},
                textColor: {}
            },
            setup(e) {
                const t = e,
                    o = q(() => ({
                        "--qbk-badge-bg-color": t.backgroundColor || "#6d6d6d",
                        "--qbk-badge-text-color": t.textColor || "#fff"
                    }));
                return (n, r) => (H(), ne("div", {
                    class: "qbk-badge",
                    style: mt(o.value)
                }, [v("div", Wm, Te(n.label), 1)], 4))
            }
        }),
        Qm = ["disabled"],
        Zm = {
            key: 0,
            class: "qbk-btn__error"
        },
        Jm = {
            class: "qbk-tooltip"
        },
        Ut = Fe({
            __name: "Button",
            props: {
                normal: {
                    type: Boolean
                },
                primary: {
                    type: Boolean
                },
                secondary: {
                    type: Boolean
                },
                subdued: {
                    type: Boolean
                },
                danger: {
                    type: Boolean
                },
                plain: {
                    type: Boolean
                },
                outline: {
                    type: Boolean
                },
                disabled: {
                    type: Boolean
                },
                uppercase: {
                    type: Boolean
                },
                loading: {
                    type: Boolean
                },
                error: {
                    type: [String, Boolean]
                },
                hideError: {
                    type: Boolean
                }
            },
            setup(e) {
                const t = e,
                    o = q(() => r(t.normal && "normal", t.primary && "primary", t.secondary && "secondary", t.subdued && "subdued", t.plain && "plain", t.outline && "outline", t.uppercase && "uppercase", t.danger && "danger", t.loading && "loading", t.error && "error", t.hideError && "error-hidden")),
                    n = q(() => t.error && typeof t.error == "string"),
                    r = (...i) => i.filter(Boolean).map(a => `qbk-btn--${a}`).join(" ");
                return (i, a) => (H(), ne("button", {
                    class: Le(["qbk-btn", o.value]),
                    disabled: i.disabled || !!i.error
                }, [n.value ? (H(), ne("div", Zm, [pe(T(Ue), {
                    icon: "error"
                }), v("span", Jm, [v("span", null, Te(i.error), 1)])])) : ve("", !0), zt(i.$slots, "default")], 10, Qm))
            }
        }),
        Xm = {
            key: 0,
            class: "qbk-offer--loading"
        },
        eg = [v("div", {
            class: "qbk-spinner"
        }, " ", -1)],
        tg = {
            key: 1,
            class: "qbk-offer__checkbox"
        },
        og = ["checked", "id", "disabled"],
        ng = ["for"],
        rg = {
            class: "qbk-offer__checkbox-tick"
        },
        ig = {
            class: "qbk-offer__sub-body"
        },
        ag = {
            class: "qbk-offer__contents"
        },
        sg = {
            class: "qbk-offer__content qbk-offer__content-info"
        },
        lg = ["href", "target", "title"],
        cg = ["innerHTML"],
        ug = ["innerHTML"],
        dg = ["innerHTML"],
        fg = {
            class: "qbk-offer__content qbk-offer__content-actions"
        },
        pg = {
            key: 0,
            class: "qbk-offer__quantity-action"
        },
        bg = {
            class: "qbk-offer__quantity"
        },
        _g = {
            key: 0,
            class: "qbk-offer__quantity-label",
            title: "Quantity"
        },
        mg = {
            key: 1,
            class: "qbk-input-wrapper qbk-input__quantity"
        },
        gg = ["disabled", "max"],
        hg = {
            class: "qbk-offer__variants"
        },
        vg = {
            key: 0,
            class: "qbk-input-wrapper qbk-input-selector"
        },
        kg = ["disabled"],
        yg = ["value"],
        qg = {
            class: "qbk-select-indicator"
        },
        Eg = {
            key: 1,
            class: "qbk-offer__description-section"
        },
        wg = ["innerHTML"],
        xg = {
            class: "qbk-offer__action-name"
        },
        Hn = Fe({
            __name: "Offer",
            props: {
                offer: {},
                entry: {},
                activeEntryId: {},
                isLimitedGift: {
                    type: Boolean
                },
                isFreeGiftTakeOver: {
                    type: Boolean
                },
                isRequiredTrigger: {
                    type: Boolean
                },
                isActiveOffer: {
                    type: Boolean
                }
            },
            emits: ["update-line-items"],
            setup(e, {
                expose: t,
                emit: o
            }) {
                const n = e,
                    r = rt("isPopup", !1),
                    i = rt("isPortal", !1),
                    a = J(!1),
                    s = J(!0),
                    c = J(null),
                    l = J(""),
                    f = J(1),
                    u = J({}),
                    d = J([]),
                    _ = J([]),
                    {
                        alreadyApplyDiscountVariants: g
                    } = wt(),
                    {
                        haveDiscount: h,
                        getOfferPrice: O
                    } = zr(q(() => n.entry)),
                    {
                        contents: b,
                        getConfig: C
                    } = ze(),
                    {
                        collectProductHandle: E,
                        collectRenderedProduct: x
                    } = Nt();
                ot(() => l.value, (j, M) => {
                    ($.value || A.value && K.value || n.offer.enablePreSelected) && M === "" && j === Pe.Available && (l.value = Pe.Added)
                }), ot(() => n.activeEntryId, j => {
                    j !== n.entry.id && l.value === Pe.Added && (l.value = Pe.Available)
                }), ot([g, d], ([j, M]) => {
                    const {
                        id: te,
                        enable_discount: W
                    } = n.entry;
                    if ($.value && n.offer.isTrigger && (!W || R.value) || n.offer.triggerId && n.offer.enablePreSelected) {
                        B.value && n.offer.triggerId && (_.value = [n.offer.triggerId]), M.length && (u.value = M.find(de => de.id.toString() === n.offer.triggerId) || M[0]);
                        return
                    }
                    if (W && M.length) {
                        const de = $.value ? M.filter(ge => {
                            var ye;
                            return !((ye = j[ge.id]) != null && ye.includes(te) && n.offer.isTrigger)
                        }) : M;
                        if (A.value && !de.length && (l.value = Pe.Unavailable), !de.length) return;
                        let fe = de[0];
                        n.offer.triggerId && (fe = de.find(ge => ge.id.toString() === n.offer.triggerId) || de[0]), u.value = fe, _.value = de.map(ge => String(ge.id))
                    }
                }), ot(() => f.value, j => {
                    if (j === 0) {
                        f.value = 1;
                        return
                    }
                    const M = Number(n.entry.offer_quantity_limit);
                    M && j > M && (f.value = M)
                });
                const N = q(() => {
                        const j = Number(n.entry.offer_quantity_limit);
                        return j && f.value >= j ? "qbk-quantity__control--disabled" : ""
                    }),
                    w = q(() => {
                        let j = [];
                        return n.entry.discount_type === to.FixedAmount && ($.value && h.value && j.push("qbk-offer__price--bundle"), n.offer.isTrigger && R.value && j.push("qbk-offer__price--bundle-children")), j
                    }),
                    D = q(() => {
                        let j = "";
                        if (B.value && !Ae.value) return b.value.sold_out_button_text;
                        switch (l.value) {
                            case Pe.Added:
                                j = b.value.remove_button_text;
                                break;
                            case Pe.Unavailable:
                                j = b.value.sold_out_button_text;
                                break;
                            case Pe.Error:
                                j = "";
                                break;
                            case Pe.Available:
                                j = ae.value ? b.value.upgrade_button_text : b.value.pick_button_text;
                                break
                        }
                        return j
                    }),
                    P = q(() => l.value === Pe.Unavailable || n.isLimitedGift && l.value !== Pe.Added || n.isRequiredTrigger || B.value && !Ae.value),
                    I = q(() => l.value === Pe.Unavailable),
                    $ = q(() => n.entry.type === S.Bundle),
                    oe = q(() => n.entry.type === S.Bogo || n.entry.type === S.CartUpsell),
                    A = q(() => n.entry.type === S.FreeGift),
                    K = q(() => n.entry.mode === ct.Auto),
                    ae = q(() => n.entry.type === S.Upsurge),
                    B = q(() => n.entry.type === S.GiftGoal),
                    re = q(() => r || C("usePickButton")),
                    R = q(() => n.entry.discount_apply === ia.Children),
                    U = q(() => !$.value && re.value),
                    ie = q(() => l.value === Pe.Unavailable ? !1 : (oe.value || A.value || ae.value) && !re.value || $.value && n.entry.allow_purchase_any_item),
                    _e = q(() => re.value && (oe.value || A.value || ae.value) && !K.value || l.value === Pe.Unavailable || n.isActiveOffer),
                    he = q(() => l.value === Pe.Added),
                    Ce = q(() => (ie.value || _e.value || K.value) && l.value ? `qbk-offer__body--${l.value}` : ""),
                    we = q(() => `qbk-offer__input-${n.entry.id}-${n.offer.handle}`),
                    ke = q(() => {
                        let j = "";
                        const M = u.value && u.value.featured_image && (u.value.featured_image.src || u.value.featured_image.url) || c.value.featured_image;
                        return j = Kr(M), `url(${j})`
                    }),
                    Oe = q(() => c.value.url || "javascript:;"),
                    Ve = q(() => To(c.value.title)),
                    Ae = q(() => {
                        var j;
                        return n.isFreeGiftTakeOver || $.value && n.offer.isTrigger && R.value ? !1 : (B.value || h.value) && _.value.includes(String((j = u.value) == null ? void 0 : j.id))
                    }),
                    We = q(() => {
                        var j;
                        return ((j = u.value) == null ? void 0 : j.price) || c.value.price
                    }),
                    Je = q(() => Ae.value ? O(We.value) : We.value),
                    De = q(() => Je.value <= 0 ? b.value.free_offer_text : ut(Je.value)),
                    Ye = q(() => {
                        const j = To(d.value[0].public_title);
                        return j && j !== "Default Title" ? j : ""
                    });
                ot([u, l, f, Ae], () => {
                    var j, M;
                    if ($.value || ae.value || l.value === Pe.Added) {
                        const te = $.value ? We.value : Je.value,
                            W = {
                                id: (j = u.value.id) == null ? void 0 : j.toString(),
                                quantity: f.value,
                                price: te,
                                originPrice: We.value,
                                haveDiscount: !!Ae.value,
                                isTrigger: n.offer.isTrigger,
                                status: l.value,
                                productId: (M = c.value.id) == null ? void 0 : M.toString()
                            };
                        o("update-line-items", W)
                    }
                });
                const He = j => {
                        l.value === Pe.Unavailable || n.offer.isTrigger || K.value || (j.stopPropagation(), j.preventDefault(), Q())
                    },
                    m = j => {
                        const M = +f.value || 0;
                        j === "minus" && M > 1 && (f.value = M - 1), j === "plus" && M < (Number(n.entry.offer_quantity_limit) || 99) && (f.value = M + 1)
                    },
                    y = () => {
                        l.value = Pe.Available
                    },
                    V = j => {
                        if (!C("allowContainerClick")) return;
                        const M = ["qbk-offer__content", "qbk-offer__price", "qbk-offer__body"].some(te => j.target.className.includes(te));
                        l.value === Pe.Unavailable || n.offer.isTrigger || !M || Q()
                    },
                    Z = () => {
                        l.value === Pe.Unavailable || n.offer.isTrigger || Q()
                    },
                    Q = () => {
                        var W, de;
                        const j = l.value === Pe.Added,
                            M = $.value ? We.value : Je.value;
                        if (!j && n.isLimitedGift || (l.value = j ? Pe.Available : Pe.Added, !j)) return;
                        const te = {
                            id: (W = u.value.id) == null ? void 0 : W.toString(),
                            quantity: j ? 0 : f.value,
                            price: M,
                            originPrice: We.value,
                            haveDiscount: !!Ae.value,
                            status: l.value,
                            productId: (de = c.value.id) == null ? void 0 : de.toString()
                        };
                        o("update-line-items", te)
                    },
                    ee = async () => {
                        var j;
                        try {
                            let M = n.offer.handle;
                            !i && (!L.isPrimaryLanguage() || C("alwaysFetchHandle")) && (M = await E(n.offer.id) || M);
                            const te = await x(M, i),
                                {
                                    variants: W
                                } = te;
                            let de = [];
                            if (c.value = te, f.value = n.offer.quantity || 1, te.available) {
                                const fe = n.offer,
                                    ge = W.filter(z => z.available && fe.excludeVariantId !== z.id.toString()),
                                    ye = fe == null ? void 0 : fe.variantIndex;
                                fe && typeof ye == "number" && (ye >= W.length ? fe.variants = [] : fe.variants = [(j = W[ye]) == null ? void 0 : j.id.toString()]), de = (fe == null ? void 0 : fe.variants) === Ft.All ? ge : ge.filter(z => ((fe == null ? void 0 : fe.variants) || []).includes(z.id.toString()))
                            }
                            de.length ? (l.value = Pe.Available, u.value = de[0]) : l.value = Pe.Unavailable, d.value = de, document.dispatchEvent(new CustomEvent(F.EVENT_OFFER_MOUNTED))
                        } catch {
                            a.value = !0
                        } finally {
                            s.value = !1
                        }
                    };
                return nt(() => {
                    ee()
                }), t({
                    status: l
                }), (j, M) => (H(), ne("div", {
                    class: Le(["qbk-offer", {
                        "qbk-offer--limited": j.isLimitedGift && l.value !== T(Pe).Added
                    }])
                }, [pe(lo, {
                    name: "qbk--offer"
                }, {
                    default: Ge(() => {
                        var te;
                        return [s.value ? (H(), ne("div", Xm, eg)) : c.value ? (H(), ne("div", {
                            key: 1,
                            class: Le(["qbk-offer__body", Ce.value]),
                            onClick: V
                        }, [U.value ? (H(), Se(T(uc), {
                            key: 0
                        })) : ve("", !0), ie.value ? (H(), ne("div", tg, [v("input", {
                            class: Le(["qbk-offer__checkbox-input", {
                                "qbk-offer__checkbox-input--checked": he.value
                            }]),
                            checked: l.value === T(Pe).Added,
                            type: "checkbox",
                            id: we.value,
                            disabled: l.value === T(Pe).Unavailable || j.offer.isTrigger
                        }, null, 10, og), v("label", {
                            class: "qbk-label qbk-offer__checkbox-label",
                            for: we.value,
                            onClick: He,
                            onTouchstart: He
                        }, [v("span", rg, [pe(T(Ue), {
                            icon: "tick",
                            size: "xs"
                        })])], 40, ng)])) : ve("", !0), v("span", {
                            class: "qbk-offer__image",
                            style: mt({
                                backgroundImage: ke.value
                            }),
                            onClick: Z
                        }, " ", 4), v("div", ig, [v("div", ag, [v("div", sg, [v("a", {
                            class: "qbk-offer__title qbk-truncate",
                            href: `${Oe.value}`,
                            target: Oe.value.includes("javascript") ? "" : "_blank",
                            title: c.value.title,
                            onClick: M[0] || (M[0] = oa(() => {}, ["stop"]))
                        }, [v("span", {
                            innerHTML: Ve.value
                        }, null, 8, cg)], 8, lg)]), v("div", {
                            class: Le(["qbk-offer__price", w.value])
                        }, [v("div", {
                            class: "qbk-offer__price--offer",
                            innerHTML: De.value
                        }, null, 8, ug), $.value || Ae.value ? ht((H(), ne("div", {
                            key: 0,
                            class: "qbk-offer__price--origin",
                            innerHTML: T(ut)(We.value)
                        }, null, 8, dg)), [
                            [Rt, We.value !== Je.value]
                        ]) : ve("", !0)], 2), v("div", fg, [$.value || A.value || B.value || j.entry.enable_offer_quantity ? (H(), ne("div", pg, [v("div", bg, [$.value || A.value || B.value ? (H(), ne("div", _g, "×" + Te(f.value), 1)) : j.entry.enable_offer_quantity ? (H(), ne("div", mg, [v("div", {
                            class: Le(["qbk-quantity__control", {
                                "qbk-quantity__control--disabled": f.value <= 1
                            }]),
                            onClick: M[1] || (M[1] = () => m("minus"))
                        }, [pe(T(Ue), {
                            icon: "minus"
                        })], 2), ht(v("input", {
                            class: "qbk-basic qbk-input-control",
                            "onUpdate:modelValue": M[2] || (M[2] = W => f.value = W),
                            type: "number",
                            disabled: I.value,
                            min: "1",
                            max: Number((te = j.entry) == null ? void 0 : te.offer_quantity_limit) || void 0,
                            onChange: y
                        }, null, 40, gg), [
                            [$l, f.value]
                        ]), v("div", {
                            class: Le(["qbk-quantity__control", N.value]),
                            onClick: M[3] || (M[3] = () => m("plus"))
                        }, [pe(T(Ue), {
                            icon: "plus"
                        })], 2)])) : ve("", !0)])])) : ve("", !0), v("div", hg, [d.value.length > 1 ? (H(), ne("label", vg, [ht(v("select", {
                            class: "qbk-input-control qbk-offer__variant",
                            disabled: I.value,
                            "onUpdate:modelValue": M[4] || (M[4] = W => u.value = W)
                        }, [(H(!0), ne(Be, null, dt(d.value, W => (H(), ne("option", {
                            class: "qbk-basic",
                            key: W.id,
                            value: W
                        }, Te(T(ha)(T(To)(W.public_title))), 9, yg))), 128))], 8, kg), [
                            [ta, u.value]
                        ]), v("span", qg, [pe(T(Ue), {
                            icon: "arrow-down"
                        })])])) : d.value.length ? (H(), ne("div", Eg, [v("div", {
                            class: "qbk-offer__description",
                            innerHTML: Ye.value
                        }, null, 8, wg)])) : ve("", !0)]), _e.value ? (H(), Se(T(Ut), {
                            key: 1,
                            class: "qbk-offer__action-btn",
                            secondary: "",
                            subdued: l.value === T(Pe).Added,
                            disabled: P.value,
                            onClick: Q
                        }, {
                            default: Ge(() => [v("span", xg, Te(D.value), 1)]),
                            _: 1
                        }, 8, ["subdued", "disabled"])) : ve("", !0)])])])], 2)) : ve("", !0)]
                    }),
                    _: 1
                })], 2))
            }
        }),
        Cg = ["xlink:href", "href"],
        Ue = Fe({
            __name: "SvgIcon",
            props: {
                icon: {},
                size: {
                    default: "md"
                },
                prefix: {
                    default: "qbk-icon"
                }
            },
            setup(e) {
                const t = e,
                    o = q(() => {
                        let r = ["qbk-svg-icon", `qbk-svg--${t.icon}`];
                        return t.size && r.push(`qbk-svg-icon--${t.size}`), r
                    }),
                    n = q(() => `#${t.prefix?`${t.prefix}-`:""}${t.icon}`);
                return (r, i) => (H(), ne("svg", {
                    class: Le(o.value),
                    viewBox: "0 0 512 512"
                }, [v("use", {
                    "xlink:href": n.value,
                    href: n.value
                }, null, 8, Cg)], 2))
            }
        }),
        dn = Fe({
            __name: "ErrorBanner",
            props: {
                message: {},
                notFade: {
                    type: Boolean
                }
            },
            setup(e) {
                const t = e,
                    o = J(!1);
                return ot(() => t.message, () => {
                    t.message && (o.value = !0, t.notFade || setTimeout(() => o.value = !1, 3e3))
                }, {
                    immediate: !0
                }), (n, r) => (H(), Se(lo, {
                    name: "qbk-fade"
                }, {
                    default: Ge(() => [n.message ? ht((H(), ne("div", {
                        key: 0,
                        class: "qbk-error-banner"
                    }, Te(n.message), 513)), [
                        [Rt, o.value]
                    ]) : ve("", !0)]),
                    _: 1
                }))
            }
        }),
        Tg = {
            class: "qbk-recommendation-offer qbk-offer"
        },
        Og = {
            key: 0,
            class: "qbk-offer__body"
        },
        Ng = {
            class: "qbk-offer__sub-body"
        },
        Pg = {
            class: "qbk-offer__contents"
        },
        Ag = {
            class: "qbk-offer__content qbk-offer__content-info"
        },
        Ig = ["href", "title", "target"],
        Dg = ["innerHTML"],
        Sg = {
            class: "qbk-offer__price"
        },
        $g = ["innerHTML"],
        Rg = ["innerHTML"],
        Fg = {
            class: "qbk-offer__content qbk-offer__content-actions"
        },
        Vg = {
            class: "qbk-offer__quantity-action"
        },
        Lg = {
            class: "qbk-offer__quantity"
        },
        Gg = {
            class: "qbk-input-wrapper qbk-input__quantity"
        },
        Mg = ["disabled"],
        Bg = {
            class: "qbk-offer__variants"
        },
        Ug = {
            key: 0,
            class: "qbk-input-wrapper qbk-input-selector"
        },
        jg = ["disabled"],
        zg = ["value"],
        Hg = {
            class: "qbk-select-indicator"
        },
        Kg = {
            key: 1,
            class: "qbk-offer__description-section"
        },
        Yg = ["innerHTML"],
        Wg = {
            class: "qbk-offer__action-name"
        },
        Qg = Fe({
            __name: "RecommendationOffer",
            props: {
                data: {}
            },
            setup(e) {
                const t = e,
                    o = rt("getPassedGoalEntryId", () => {}),
                    n = J(""),
                    r = J(1),
                    i = J({}),
                    a = J([]),
                    s = J(""),
                    c = J(!1),
                    {
                        contents: l
                    } = ze(),
                    {
                        renderCartContents: f
                    } = Ot(),
                    u = q(() => {
                        let w = "";
                        switch (n.value) {
                            case Pe.Unavailable:
                                w = l.value.sold_out_button_text;
                                break;
                            default:
                                w = l.value.pick_button_text;
                                break
                        }
                        return w
                    }),
                    d = q(() => n.value === Pe.Unavailable || n.value === Pe.Error),
                    _ = q(() => n.value === Pe.Unavailable),
                    g = q(() => {
                        let w = "";
                        const D = i.value && i.value.featured_image && (i.value.featured_image.src || i.value.featured_image.url) || t.data.featured_image;
                        return w = Kr(D), `url(${w})`
                    }),
                    h = q(() => t.data.url || "javascript:;"),
                    O = q(() => To(t.data.title)),
                    b = q(() => {
                        var w;
                        return ((w = i.value) == null ? void 0 : w.price) || t.data.price
                    }),
                    C = q(() => i.value.compare_at_price),
                    E = q(() => {
                        const w = To(a.value[0].public_title);
                        return w && w !== "Default Title" ? w : ""
                    }),
                    x = async w => {
                        w.stopPropagation(), w.preventDefault();
                        const D = r.value * i.value.price,
                            P = o(D),
                            I = [{
                                quantity: r.value,
                                id: i.value.id,
                                properties: { ...P && {
                                        [F.OFFER_ID_PROPERTY]: P
                                    }
                                }
                            }];
                        try {
                            c.value = !0;
                            const $ = await Mt("/cart/add.js?qbk-order-goal", {
                                body: {
                                    items: I
                                }
                            });
                            await f($, () => window.location.reload()), document.dispatchEvent(new CustomEvent(F.EVENT_RECOMMENDATION_OFFER_ADDED))
                        } catch ($) {
                            n.value = Pe.Error, L.log("Cannot add product", $), s.value = ($ == null ? void 0 : $.description) || ($ == null ? void 0 : $.message) || l.value.common_error
                        } finally {
                            c.value = !1
                        }
                    },
                    N = async () => {
                        if (!t.data.available) n.value = Pe.Unavailable;
                        else {
                            const w = t.data.variants.filter(D => D.available);
                            i.value = w[0], a.value = w
                        }
                    };
                return nt(() => {
                    N()
                }), (w, D) => (H(), ne("div", Tg, [pe(lo, {
                    name: "qbk--offer"
                }, {
                    default: Ge(() => [w.data ? (H(), ne("div", Og, [v("span", {
                        class: "qbk-offer__image",
                        style: mt({
                            backgroundImage: g.value
                        })
                    }, " ", 4), v("div", Ng, [v("div", Pg, [v("div", Ag, [v("a", {
                        class: "qbk-offer__title qbk-truncate",
                        href: `${h.value}`,
                        title: w.data.title,
                        target: h.value.includes("javascript") ? "" : "_blank"
                    }, [v("span", {
                        innerHTML: O.value
                    }, null, 8, Dg)], 8, Ig)]), v("div", Sg, [v("div", {
                        class: "qbk-offer__price--offer",
                        innerHTML: T(ut)(b.value)
                    }, null, 8, $g), C.value ? (H(), ne("div", {
                        key: 0,
                        class: "qbk-offer__price--origin",
                        innerHTML: T(ut)(C.value)
                    }, null, 8, Rg)) : ve("", !0)]), v("div", Fg, [v("div", Vg, [v("div", Lg, [v("div", Gg, [v("div", {
                        class: Le(["qbk-quantity__control", {
                            "qbk-quantity__control--disabled": r.value <= 1
                        }]),
                        onClick: D[0] || (D[0] = () => r.value > 1 && (r.value -= 1))
                    }, [pe(T(Ue), {
                        icon: "minus"
                    })], 2), ht(v("input", {
                        class: "qbk-basic qbk-input-control",
                        "onUpdate:modelValue": D[1] || (D[1] = P => r.value = P),
                        type: "number",
                        disabled: _.value,
                        min: "1",
                        max: 99
                    }, null, 8, Mg), [
                        [$l, r.value]
                    ]), v("div", {
                        class: "qbk-quantity__control",
                        onClick: D[2] || (D[2] = () => r.value < 99 && (r.value += 1))
                    }, [pe(T(Ue), {
                        icon: "plus"
                    })])])])]), v("div", Bg, [a.value.length > 1 ? (H(), ne("label", Ug, [ht(v("select", {
                        class: "qbk-input-control qbk-offer__variant",
                        disabled: _.value,
                        "onUpdate:modelValue": D[3] || (D[3] = P => i.value = P)
                    }, [(H(!0), ne(Be, null, dt(a.value, P => (H(), ne("option", {
                        class: "qbk-basic",
                        key: P.id,
                        value: P
                    }, Te(T(ha)(T(To)(P.public_title))), 9, zg))), 128))], 8, jg), [
                        [ta, i.value]
                    ]), v("span", Hg, [pe(T(Ue), {
                        icon: "arrow-down"
                    })])])) : a.value.length ? (H(), ne("div", Kg, [v("div", {
                        class: "qbk-offer__description",
                        innerHTML: E.value
                    }, null, 8, Yg)])) : ve("", !0)]), pe(T(Ut), {
                        class: "qbk-offer__action-btn",
                        secondary: "",
                        loading: c.value,
                        disabled: d.value,
                        error: s.value,
                        onClick: x
                    }, {
                        default: Ge(() => [v("span", Wg, Te(u.value), 1)]),
                        _: 1
                    }, 8, ["loading", "disabled", "error"])])])])])) : ve("", !0)]),
                    _: 1
                })]))
            }
        }),
        Zg = {
            key: 0,
            class: "qbk-toast"
        },
        Jg = {
            class: "qbk-toast__content"
        },
        Xg = Fe({
            __name: "Toast",
            setup(e) {
                const {
                    activeMessage: t
                } = lc();
                return (o, n) => (H(), Se(lo, {
                    name: "toast"
                }, {
                    default: Ge(() => [T(t) ? (H(), ne("div", Zg, [v("div", Jg, Te(T(t)), 1)])) : ve("", !0)]),
                    _: 1
                }))
            }
        }),
        eh = {},
        th = {
            xmlns: "http://www.w3.org/2000/svg",
            style: {
                display: "none"
            }
        },
        oh = [Ud('<symbol id="qbk-icon-arrow-down" viewBox="0 0 24 24"><path d="m12 16a1 1 0 0 1 -.71-.29l-6-6a1 1 0 0 1 1.42-1.42l5.29 5.3 5.29-5.29a1 1 0 0 1 1.41 1.41l-6 6a1 1 0 0 1 -.7.29z"></path></symbol><symbol id="qbk-icon-error" viewBox="0 0 16 16"><path d="M7.99981 10.9651C7.5525 10.9651 7.17755 11.34 7.17755 11.7873C7.17755 12.2347 7.5525 12.6096 7.99981 12.6096C8.43067 12.6096 8.82206 12.2347 8.80233 11.8071C8.82206 11.3368 8.4504 10.9651 7.99981 10.9651Z"></path><path d="M15.6107 13.8791C16.127 12.9878 16.1303 11.9254 15.6172 11.0374L10.4666 2.1175C9.95679 1.21959 9.03585 0.686768 8.00309 0.686768C6.97033 0.686768 6.0494 1.22288 5.53959 2.11421L0.382367 11.044C-0.130724 11.9419 -0.127435 13.0108 0.392235 13.9021C0.905326 14.7836 1.82297 15.3131 2.84915 15.3131H13.1373C14.1668 15.3131 15.091 14.777 15.6107 13.8791ZM14.4924 13.2345C14.2062 13.7278 13.6997 14.0206 13.134 14.0206H2.84586C2.28673 14.0206 1.7835 13.7344 1.50393 13.2509C1.22107 12.7609 1.21779 12.1754 1.50064 11.682L6.65787 2.75558C6.93744 2.26551 7.43737 1.97607 8.00309 1.97607C8.56552 1.97607 9.06874 2.2688 9.34831 2.75887L14.5022 11.6853C14.7785 12.1655 14.7752 12.7444 14.4924 13.2345Z"></path><path d="M7.79592 5.19283C7.40452 5.30466 7.16113 5.65988 7.16113 6.09074C7.18087 6.35058 7.19731 6.6137 7.21705 6.87353C7.27296 7.86354 7.32887 8.83381 7.38479 9.82381C7.40452 10.1593 7.66436 10.4027 7.99984 10.4027C8.33532 10.4027 8.59845 10.1428 8.61489 9.80407C8.61489 9.60015 8.61489 9.41268 8.63463 9.20547C8.67081 8.57068 8.71027 7.9359 8.74645 7.30111C8.76619 6.88998 8.80237 6.47885 8.8221 6.06772C8.8221 5.91971 8.80237 5.78815 8.74645 5.65659C8.57871 5.28821 8.18732 5.10074 7.79592 5.19283Z"></path></symbol><symbol id="qbk-icon-tick" viewBox="0 0 16 16"><path d="M15.2881 2.85506C14.8723 2.43927 14.1981 2.43927 13.7823 2.85505L5.75113 10.8861L2.21746 7.35256C1.80167 6.93678 1.12754 6.93679 0.711753 7.35258C0.295952 7.76838 0.295952 8.44251 0.711753 8.8583L4.99828 13.1448C5.20605 13.3528 5.4787 13.4568 5.75113 13.4568C6.02358 13.4568 6.29623 13.3528 6.50399 13.1448L15.2881 4.36077C15.7038 3.94498 15.7038 3.27085 15.2881 2.85506Z"></path></symbol><symbol id="qbk-icon-close" viewBox="0 0 329 329"><path d="m194.800781 164.769531 128.210938-128.214843c8.34375-8.339844 8.34375-21.824219 0-30.164063-8.339844-8.339844-21.824219-8.339844-30.164063 0l-128.214844 128.214844-128.210937-128.214844c-8.34375-8.339844-21.824219-8.339844-30.164063 0-8.34375 8.339844-8.34375 21.824219 0 30.164063l128.210938 128.214843-128.210938 128.214844c-8.34375 8.339844-8.34375 21.824219 0 30.164063 4.15625 4.160156 9.621094 6.25 15.082032 6.25 5.460937 0 10.921875-2.089844 15.082031-6.25l128.210937-128.214844 128.214844 128.214844c4.160156 4.160156 9.621094 6.25 15.082032 6.25 5.460937 0 10.921874-2.089844 15.082031-6.25 8.34375-8.339844 8.34375-21.824219 0-30.164063zm0 0"></path></symbol><symbol id="qbk-icon-plus" viewBox="0 0 20 20"><path d="M10.75 6.75a.75.75 0 0 0-1.5 0v2.5h-2.5a.75.75 0 0 0 0 1.5h2.5v2.5a.75.75 0 0 0 1.5 0v-2.5h2.5a.75.75 0 0 0 0-1.5h-2.5v-2.5Z"></path></symbol><symbol id="qbk-icon-minus" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M6 10a.75.75 0 0 1 .75-.75h6.5a.75.75 0 0 1 0 1.5h-6.5a.75.75 0 0 1-.75-.75Z"></path></symbol><symbol id="qbk-icon-discount" viewBox="0 0 24 24"><g clip-path="url(#clip0_755_11)"><path opacity="0.55" d="M17.7797 3.09002C17.4497 2.44302 16.7777 2.00002 15.9997 2.00002H10.8347C10.2997 2.00002 9.78872 2.21402 9.41272 2.59302L2.59272 9.48302C2.59272 9.48502 2.59272 9.48602 2.59072 9.48602C2.34672 9.73902 2.17872 10.04 2.09072 10.36L0.73972 8.05502C0.17972 7.10202 0.49972 5.87702 1.45172 5.31802L9.82272 0.425018C10.2827 0.155018 10.8327 0.0800185 11.3497 0.220018L16.3397 1.55702C17.0947 1.76002 17.6327 2.37102 17.7797 3.09002Z" fill="#8E8E8E" fill-opacity="0.55"></path><path d="M10.8347 2H15.9997C17.1047 2 17.9997 2.895 17.9997 4V9.172C17.9997 9.702 17.7897 10.212 17.4137 10.586L10.5957 17.404C9.8187 18.182 8.5597 18.186 7.7757 17.414L2.6097 12.314C1.8237 11.539 1.8157 10.274 2.5897 9.486C2.5917 9.486 2.5927 9.486 2.5927 9.484L9.4127 2.594C9.7897 2.214 10.2997 2 10.8347 2ZM13.4997 8C14.3277 8 14.9997 7.328 14.9997 6.5C14.9997 5.672 14.3277 5 13.4997 5C12.6717 5 11.9997 5.672 11.9997 6.5C11.9997 7.328 12.6717 8 13.4997 8Z" fill="#8E8E8E"></path></g><defs><clipPath id="clip0_755_11"><rect width="18" height="18" fill="white"></rect></clipPath></defs></symbol><symbol id="qbk-icon-next" viewBox="0 0 14 24"><path d="M1.743 24c.466.003.913-.177 1.243-.5l10.505-10.329a1.701 1.701 0 0 0 0-2.427L2.986.414A1.772 1.772 0 0 0 .61.504a1.7 1.7 0 0 0-.092 2.337l9.261 9.108-9.261 9.107a1.7 1.7 0 0 0-.387 1.875A1.751 1.751 0 0 0 1.743 24z" fill-rule="nonzero"></path></symbol><symbol id="qbk-icon-prev" viewBox="0 0 14 24"><path d="M12.257 24a1.766 1.766 0 0 1-1.243-.5L.509 13.172a1.701 1.701 0 0 1 0-2.427L11.014.414a1.772 1.772 0 0 1 2.376.09 1.7 1.7 0 0 1 .092 2.337L4.221 11.95l9.261 9.107a1.7 1.7 0 0 1 .387 1.875A1.751 1.751 0 0 1 12.257 24z" fill-rule="nonzero"></path></symbol><symbol id="qbk-icon-check-circle" viewBox="0 0 512 512"><path xmlns="http://www.w3.org/2000/svg" d="M256 0C114.8 0 0 114.8 0 256s114.8 256 256 256 256-114.8 256-256S397.2 0 256 0z"></path><path xmlns="http://www.w3.org/2000/svg" d="m379.8 169.7c6.2 6.2 6.2 16.4 0 22.6l-150 150c-3.1 3.1-7.2 4.7-11.3 4.7s-8.2-1.6-11.3-4.7l-75-75c-6.2-6.2-6.2-16.4 0-22.6s16.4-6.2 22.6 0l63.7 63.7 138.7-138.7c6.2-6.3 16.4-6.3 22.6 0z" fill="#fff"></path></symbol><symbol id="qbk-icon-gift-box" viewBox="0 0 38 40"><path d="m34.882 13.89-4.117-1.427c1.488-1.171 2.124-3.03 1.668-4.795-.896-3.469-5.337-4.786-8.142-2.423l-2.843 2.393-.562-3.59C20.33.516 16.034-1.184 13.012.922c-1.51 1.052-2.314 2.867-1.958 4.71L7.173 4.285c-1.91-.662-4.03.28-4.725 2.098l-1.68 4.399c-.233.607.096 1.278.734 1.5l19.202 6.656H2.162c-.678 0-1.228.524-1.228 1.17V36.49C.934 38.425 2.587 40 4.62 40h24.573c2.032 0 3.686-1.575 3.686-3.51V23.158l.95.33c.635.22 1.342-.09 1.575-.7l1.68-4.398c.696-1.82-.293-3.838-2.203-4.5zM13.22 37.66h-8.6c-.678 0-1.229-.525-1.229-1.17V21.278h9.83V37.66zm4.915 0h-2.458V21.278h2.458V37.66zm7.783-30.662c1.425-1.2 3.675-.527 4.129 1.23.483 1.871-1.417 3.495-3.319 2.836L22.733 9.68 25.918 7zM14.463 2.81c1.536-1.07 3.711-.202 3.993 1.586l.63 4.019L15.09 7.03c-1.902-.66-2.261-3.082-.628-4.22zm.579 11.675L3.497 10.483l1.26-3.3c.232-.605.939-.919 1.575-.698l10.39 3.601-1.68 4.399zm4.618 1.6-2.309-.8 1.681-4.398 2.31.8-1.682 4.399zM30.421 36.49c0 .645-.551 1.17-1.229 1.17h-8.6V21.278h6.863l2.966 1.028V36.49zm4.354-18.9-1.26 3.298-11.546-4.002 1.681-4.398 10.391 3.601c.637.221.966.894.734 1.5z"></path></symbol><symbol id="qbk-icon-shipping" viewBox="0 0 512 512"><path d="M386.689 304.403c-35.587 0-64.538 28.951-64.538 64.538s28.951 64.538 64.538 64.538c35.593 0 64.538-28.951 64.538-64.538s-28.951-64.538-64.538-64.538zm0 96.807c-17.796 0-32.269-14.473-32.269-32.269s14.473-32.269 32.269-32.269 32.269 14.473 32.269 32.269-14.473 32.269-32.269 32.269zm-220.504-96.807c-35.587 0-64.538 28.951-64.538 64.538s28.951 64.538 64.538 64.538 64.538-28.951 64.538-64.538-28.951-64.538-64.538-64.538zm0 96.807c-17.796 0-32.269-14.473-32.269-32.269s14.473-32.269 32.269-32.269 32.269 14.473 32.269 32.269-14.473 32.269-32.269 32.269zM430.15 119.675c-2.743-5.448-8.32-8.885-14.419-8.885h-84.975v32.269h75.025l43.934 87.384 28.838-14.5-48.403-96.268z"></path><path d="M216.202 353.345h122.084v32.269H216.202zm-98.421 0H61.849c-8.912 0-16.134 7.223-16.134 16.134s7.223 16.134 16.134 16.134h55.933c8.912 0 16.134-7.223 16.134-16.134s-7.223-16.134-16.135-16.134zm390.831-98.636l-31.736-40.874c-3.049-3.937-7.755-6.239-12.741-6.239H346.891V94.655c0-8.912-7.223-16.134-16.134-16.134H61.849c-8.912 0-16.134 7.223-16.134 16.134s7.223 16.134 16.134 16.134h252.773V223.73c0 8.912 7.223 16.134 16.134 16.134h125.478l23.497 30.268v83.211h-44.639c-8.912 0-16.134 7.223-16.134 16.134s7.223 16.134 16.134 16.134h60.773c8.912 0 16.134-7.223 16.135-16.134V264.605c0-3.582-1.194-7.067-3.388-9.896zm-391.906 16.888H42.487c-8.912 0-16.134 7.223-16.134 16.134s7.223 16.134 16.134 16.134h74.218c8.912 0 16.134-7.223 16.134-16.134s-7.222-16.134-16.133-16.134zm37.109-63.463H16.134C7.223 208.134 0 215.357 0 224.269s7.223 16.134 16.134 16.134h137.681c8.912 0 16.134-7.223 16.134-16.134s-7.222-16.135-16.134-16.135zm26.353-63.462H42.487c-8.912 0-16.134 7.223-16.134 16.134s7.223 16.134 16.134 16.134h137.681c8.912 0 16.134-7.223 16.134-16.134s-7.222-16.134-16.134-16.134z"></path></symbol><symbol id="qbk-icon-coupon" viewBox="0 0 30 30"><path d="M21.321 15.719c-3.01.072-3.015 4.484-.006 4.564 3.01-.073 3.014-4.483.006-4.564zm-.785 2.285c.001-1.024 1.558-1.028 1.564-.004-.004 1.021-1.556 1.025-1.564.004zm-5.216-3.723c3.009-.076 3.009-4.488 0-4.564-3.01.077-3.008 4.486 0 4.564zm0-3.063c1.023.004 1.023 1.56 0 1.564-1.023-.005-1.022-1.558 0-1.564zm7.87-1.08c-.293-.294-.77-.295-1.064-.002l-8.69 8.649a.75.75 0 1 0 1.058 1.063l8.691-8.648a.75.75 0 0 0 .005-1.062zm-14.338.399a.75.75 0 0 0-.75.75v1.923a.75.75 0 1 0 1.5 0v-1.923a.75.75 0 0 0-.75-.75zm0 5.504a.75.75 0 0 0-.75.75v1.922a.75.75 0 1 0 1.5 0v-1.922a.75.75 0 0 0-.75-.75zm19.527-3.519a2.6 2.6 0 0 0 1.371-2.3V7.65a2.62 2.62 0 0 0-2.617-2.617H2.867A2.62 2.62 0 0 0 .25 7.65v2.57a2.6 2.6 0 0 0 1.371 2.3c1.369.733 1.885 2.437 1.152 3.806-.262.489-.663.89-1.152 1.152A2.6 2.6 0 0 0 .25 19.78v2.57a2.62 2.62 0 0 0 2.617 2.617h24.266a2.62 2.62 0 0 0 2.617-2.617v-2.57a2.6 2.6 0 0 0-1.371-2.3c-1.964-.983-1.949-3.975 0-4.958zm-2.47 4.512c.401.749 1.015 1.363 1.764 1.764a1.1 1.1 0 0 1 .577.978v2.57a1.12 1.12 0 0 1-1.117 1.117H9.6c-.041-.65.258-1.894-.75-1.919-1.009.024-.709 1.274-.75 1.923H2.867A1.12 1.12 0 0 1 1.75 22.35v-2.57a1.1 1.1 0 0 1 .577-.978 4.31 4.31 0 0 0 1.764-5.836c-.401-.749-1.015-1.363-1.764-1.764a1.1 1.1 0 0 1-.577-.978V7.65a1.12 1.12 0 0 1 1.117-1.117H8.1c.041.651-.26 1.898.75 1.923 1.009-.024.709-1.274.75-1.923h17.533A1.12 1.12 0 0 1 28.25 7.65v2.57a1.1 1.1 0 0 1-.577.978 4.31 4.31 0 0 0-1.764 5.836z"></path></symbol><symbol id="qbk-icon-combo" viewBox="0 0 32 32"><path xmlns="http://www.w3.org/2000/svg" d="M15.75 26a.75.75 0 0 1-.75.75h-3a.75.75 0 1 1 0-1.5h3a.75.75 0 0 1 .75.75zm13.86-8.56a.75.75 0 0 1-.61.31h-1.25V28A1.75 1.75 0 0 1 26 29.75H6A1.75 1.75 0 0 1 4.25 28V17.75H3a.75.75 0 0 1-.71-1l2-6a.75.75 0 0 1 .71-.5h22a.75.75 0 0 1 .71.51l2 6a.75.75 0 0 1-.1.68zM4 16.25h11.46l1.5-4.5H5.54zm2 12h11.25V15.62l-.54 1.62a.75.75 0 0 1-.71.51H5.75V28a.25.25 0 0 0 .25.25zm20.25-10.5H20a.75.75 0 0 1-.71-.51l-.54-1.62v12.63H26a.25.25 0 0 0 .25-.25zm1.75-1.5l-1.5-4.5H19l1.5 4.5zm-12-8.5a.75.75 0 0 0 .75-.75V3a.75.75 0 0 0-1.5 0v4a.75.75 0 0 0 .75.75zm3 .61a.75.75 0 0 0 1-.21l2.2-3.34A.75.75 0 1 0 21 4l-2.2 3.34a.75.75 0 0 0 .2 1.02zm-7.09-.21a.75.75 0 0 0 1.25-.83L11 4a.75.75 0 1 0-1.25.83z"></path></symbol><symbol id="qbk-icon-gift" viewBox="0 0 24 24"><path d="M19.5 6.25h-1.065A2.709 2.709 0 0 0 18.75 5a2.747 2.747 0 0 0-4.876-1.739L12 5.752l-1.881-2.5A2.747 2.747 0 0 0 5.25 5a2.709 2.709 0 0 0 .315 1.25H4.5A2.253 2.253 0 0 0 2.25 8.5V12a.75.75 0 0 0 .75.75h.25V18A3.383 3.383 0 0 0 7 21.75h10A3.383 3.383 0 0 0 20.75 18v-5.25H21a.75.75 0 0 0 .75-.75V8.5a2.253 2.253 0 0 0-2.25-2.25zm.75 2.25v2.75h-7.5v-3.5h6.75a.751.751 0 0 1 .75.75zm-5.211-4.293A1.223 1.223 0 0 1 16 3.75a1.25 1.25 0 0 1 0 2.5h-2.5l1.539-2.043zM6.75 5A1.252 1.252 0 0 1 8 3.75a1.213 1.213 0 0 1 .948.441L10.5 6.25H8A1.252 1.252 0 0 1 6.75 5zm-3 3.5a.751.751 0 0 1 .75-.75h6.75v3.5h-7.5zm1 9.5v-5.25h6.5v7.5H7c-1.577 0-2.25-.673-2.25-2.25zm14.5 0c0 1.577-.673 2.25-2.25 2.25h-4.25v-7.5h6.5z"></path></symbol><symbol id="qbk-icon-percent" viewBox="0 -960 960 960"><path xmlns="http://www.w3.org/2000/svg" d="M300-520q-58 0-99-41t-41-99q0-58 41-99t99-41q58 0 99 41t41 99q0 58-41 99t-99 41Zm0-80q25 0 42.5-17.5T360-660q0-25-17.5-42.5T300-720q-25 0-42.5 17.5T240-660q0 25 17.5 42.5T300-600Zm360 440q-58 0-99-41t-41-99q0-58 41-99t99-41q58 0 99 41t41 99q0 58-41 99t-99 41Zm0-80q25 0 42.5-17.5T720-300q0-25-17.5-42.5T660-360q-25 0-42.5 17.5T600-300q0 25 17.5 42.5T660-240Zm-444 80-56-56 584-584 56 56-584 584Z"></path></symbol><symbol id="qbk-icon-halloween-gift" viewBox="0 0 145 145"><path d="M144.092 59.043c-7.667-23.667-25.667-28.5-39.168-28.5-8.5 0-15.5 1.833-18.167 2.666l-1.166.334-1-.667c-1.667-1-3.5-1.833-5.334-2.333 3.834-16.167 21.667-21.667 21.667-21.667L92.758.209s-5 .5-12.334 6.333c-7.333 6-9.167 21-9.167 21s.167 1 .667 2.5a16.827 16.827 0 0 0-7.667 3l-1 .667-1.166-.5c-.167 0-8.667-3-19.334-3-13.667 0-31.5 5-39.167 28.5-6.5 19.668-2.5 42.501 10.333 60.168 10 13.834 23.334 21.667 36.667 21.667 3.834 0 7.667-.667 11.334-2l1.166-.5 1 .667c6 4.166 14.334 4.333 20.5.333l1-.667 1.167.334c3.334 1 6.834 1.666 10.334 1.666 6.667 0 13.333-2 19.5-5.666 6.334-3.667 12-9.167 17-16 12.834-17.501 16.834-40.334 10.501-59.668ZM99.924 66.71c7.834 0 15.501-13.667 15.501-13.667 0 13.167-6.834 23.5-15.5 23.5-8.668 0-15.5-10.333-15.5-23.5 0 0 7.666 13.667 15.5 13.667Zm-50.5 0c7.833 0 15.5-13.667 15.5-13.667 0 13.167-6.834 23.5-15.5 23.5-8.667 0-15.5-10.333-15.5-23.5 0 0 7.666 13.667 15.5 13.667Zm60 43.334-5.666-6-18.834 12.333-11.167-9.167-11 9.167-19-12.333-5.834 6-18.833-29 18.833 12 5.834-6L62.59 99.376l11-9.167 11 9.167 19.167-12.334 5.833 6 18.834-12-19.001 29.001Z"></path></symbol>', 17)];

    function nh(e, t) {
        return H(), ne("svg", th, oh)
    }
    const rh = Xr(eh, [
        ["render", nh]
    ]);

    function ih(e) {
        return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
    }
    var yc = {
        exports: {}
    };
    (function(e) {
        (function() {
            function t(p, k, G) {
                return p.call.apply(p.bind, arguments)
            }

            function o(p, k, G) {
                if (!p) throw Error();
                if (2 < arguments.length) {
                    var Y = Array.prototype.slice.call(arguments, 2);
                    return function() {
                        var X = Array.prototype.slice.call(arguments);
                        return Array.prototype.unshift.apply(X, Y), p.apply(k, X)
                    }
                }
                return function() {
                    return p.apply(k, arguments)
                }
            }

            function n(p, k, G) {
                return n = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? t : o, n.apply(null, arguments)
            }
            var r = Date.now || function() {
                return +new Date
            };

            function i(p, k) {
                this.a = p, this.o = k || p, this.c = this.o.document
            }
            var a = !!window.FontFace;

            function s(p, k, G, Y) {
                if (k = p.c.createElement(k), G)
                    for (var X in G) G.hasOwnProperty(X) && (X == "style" ? k.style.cssText = G[X] : k.setAttribute(X, G[X]));
                return Y && k.appendChild(p.c.createTextNode(Y)), k
            }

            function c(p, k, G) {
                p = p.c.getElementsByTagName(k)[0], p || (p = document.documentElement), p.insertBefore(G, p.lastChild)
            }

            function l(p) {
                p.parentNode && p.parentNode.removeChild(p)
            }

            function f(p, k, G) {
                k = k || [], G = G || [];
                for (var Y = p.className.split(/\s+/), X = 0; X < k.length; X += 1) {
                    for (var be = !1, Ee = 0; Ee < Y.length; Ee += 1)
                        if (k[X] === Y[Ee]) {
                            be = !0;
                            break
                        }
                    be || Y.push(k[X])
                }
                for (k = [], X = 0; X < Y.length; X += 1) {
                    for (be = !1, Ee = 0; Ee < G.length; Ee += 1)
                        if (Y[X] === G[Ee]) {
                            be = !0;
                            break
                        }
                    be || k.push(Y[X])
                }
                p.className = k.join(" ").replace(/\s+/g, " ").replace(/^\s+|\s+$/, "")
            }

            function u(p, k) {
                for (var G = p.className.split(/\s+/), Y = 0, X = G.length; Y < X; Y++)
                    if (G[Y] == k) return !0;
                return !1
            }

            function d(p) {
                return p.o.location.hostname || p.a.location.hostname
            }

            function _(p, k, G) {
                function Y() {
                    $e && X && be && ($e(Ee), $e = null)
                }
                k = s(p, "link", {
                    rel: "stylesheet",
                    href: k,
                    media: "all"
                });
                var X = !1,
                    be = !0,
                    Ee = null,
                    $e = G || null;
                a ? (k.onload = function() {
                    X = !0, Y()
                }, k.onerror = function() {
                    X = !0, Ee = Error("Stylesheet failed to load"), Y()
                }) : setTimeout(function() {
                    X = !0, Y()
                }, 0), c(p, "head", k)
            }

            function g(p, k, G, Y) {
                var X = p.c.getElementsByTagName("head")[0];
                if (X) {
                    var be = s(p, "script", {
                            src: k
                        }),
                        Ee = !1;
                    return be.onload = be.onreadystatechange = function() {
                        Ee || this.readyState && this.readyState != "loaded" && this.readyState != "complete" || (Ee = !0, G && G(null), be.onload = be.onreadystatechange = null, be.parentNode.tagName == "HEAD" && X.removeChild(be))
                    }, X.appendChild(be), setTimeout(function() {
                        Ee || (Ee = !0, G && G(Error("Script load timeout")))
                    }, Y || 5e3), be
                }
                return null
            }

            function h() {
                this.a = 0, this.c = null
            }

            function O(p) {
                return p.a++,
                    function() {
                        p.a--, C(p)
                    }
            }

            function b(p, k) {
                p.c = k, C(p)
            }

            function C(p) {
                p.a == 0 && p.c && (p.c(), p.c = null)
            }

            function E(p) {
                this.a = p || "-"
            }
            E.prototype.c = function(p) {
                for (var k = [], G = 0; G < arguments.length; G++) k.push(arguments[G].replace(/[\W_]+/g, "").toLowerCase());
                return k.join(this.a)
            };

            function x(p, k) {
                this.c = p, this.f = 4, this.a = "n";
                var G = (k || "n4").match(/^([nio])([1-9])$/i);
                G && (this.a = G[1], this.f = parseInt(G[2], 10))
            }

            function N(p) {
                return P(p) + " " + (p.f + "00") + " 300px " + w(p.c)
            }

            function w(p) {
                var k = [];
                p = p.split(/,\s*/);
                for (var G = 0; G < p.length; G++) {
                    var Y = p[G].replace(/['"]/g, "");
                    Y.indexOf(" ") != -1 || /^\d/.test(Y) ? k.push("'" + Y + "'") : k.push(Y)
                }
                return k.join(",")
            }

            function D(p) {
                return p.a + p.f
            }

            function P(p) {
                var k = "normal";
                return p.a === "o" ? k = "oblique" : p.a === "i" && (k = "italic"), k
            }

            function I(p) {
                var k = 4,
                    G = "n",
                    Y = null;
                return p && ((Y = p.match(/(normal|oblique|italic)/i)) && Y[1] && (G = Y[1].substr(0, 1).toLowerCase()), (Y = p.match(/([1-9]00|normal|bold)/i)) && Y[1] && (/bold/i.test(Y[1]) ? k = 7 : /[1-9]00/.test(Y[1]) && (k = parseInt(Y[1].substr(0, 1), 10)))), G + k
            }

            function $(p, k) {
                this.c = p, this.f = p.o.document.documentElement, this.h = k, this.a = new E("-"), this.j = k.events !== !1, this.g = k.classes !== !1
            }

            function oe(p) {
                p.g && f(p.f, [p.a.c("wf", "loading")]), K(p, "loading")
            }

            function A(p) {
                if (p.g) {
                    var k = u(p.f, p.a.c("wf", "active")),
                        G = [],
                        Y = [p.a.c("wf", "loading")];
                    k || G.push(p.a.c("wf", "inactive")), f(p.f, G, Y)
                }
                K(p, "inactive")
            }

            function K(p, k, G) {
                p.j && p.h[k] && (G ? p.h[k](G.c, D(G)) : p.h[k]())
            }

            function ae() {
                this.c = {}
            }

            function B(p, k, G) {
                var Y = [],
                    X;
                for (X in k)
                    if (k.hasOwnProperty(X)) {
                        var be = p.c[X];
                        be && Y.push(be(k[X], G))
                    }
                return Y
            }

            function re(p, k) {
                this.c = p, this.f = k, this.a = s(this.c, "span", {
                    "aria-hidden": "true"
                }, this.f)
            }

            function R(p) {
                c(p.c, "body", p.a)
            }

            function U(p) {
                return "display:block;position:absolute;top:-9999px;left:-9999px;font-size:300px;width:auto;height:auto;line-height:normal;margin:0;padding:0;font-variant:normal;white-space:nowrap;font-family:" + w(p.c) + ";" + ("font-style:" + P(p) + ";font-weight:" + (p.f + "00") + ";")
            }

            function ie(p, k, G, Y, X, be) {
                this.g = p, this.j = k, this.a = Y, this.c = G, this.f = X || 3e3, this.h = be || void 0
            }
            ie.prototype.start = function() {
                var p = this.c.o.document,
                    k = this,
                    G = r(),
                    Y = new Promise(function(Ee, $e) {
                        function Ke() {
                            r() - G >= k.f ? $e() : p.fonts.load(N(k.a), k.h).then(function(tt) {
                                1 <= tt.length ? Ee() : setTimeout(Ke, 25)
                            }, function() {
                                $e()
                            })
                        }
                        Ke()
                    }),
                    X = null,
                    be = new Promise(function(Ee, $e) {
                        X = setTimeout($e, k.f)
                    });
                Promise.race([be, Y]).then(function() {
                    X && (clearTimeout(X), X = null), k.g(k.a)
                }, function() {
                    k.j(k.a)
                })
            };

            function _e(p, k, G, Y, X, be, Ee) {
                this.v = p, this.B = k, this.c = G, this.a = Y, this.s = Ee || "BESbswy", this.f = {}, this.w = X || 3e3, this.u = be || null, this.m = this.j = this.h = this.g = null, this.g = new re(this.c, this.s), this.h = new re(this.c, this.s), this.j = new re(this.c, this.s), this.m = new re(this.c, this.s), p = new x(this.a.c + ",serif", D(this.a)), p = U(p), this.g.a.style.cssText = p, p = new x(this.a.c + ",sans-serif", D(this.a)), p = U(p), this.h.a.style.cssText = p, p = new x("serif", D(this.a)), p = U(p), this.j.a.style.cssText = p, p = new x("sans-serif", D(this.a)), p = U(p), this.m.a.style.cssText = p, R(this.g), R(this.h), R(this.j), R(this.m)
            }
            var he = {
                    D: "serif",
                    C: "sans-serif"
                },
                Ce = null;

            function we() {
                if (Ce === null) {
                    var p = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent);
                    Ce = !!p && (536 > parseInt(p[1], 10) || parseInt(p[1], 10) === 536 && 11 >= parseInt(p[2], 10))
                }
                return Ce
            }
            _e.prototype.start = function() {
                this.f.serif = this.j.a.offsetWidth, this.f["sans-serif"] = this.m.a.offsetWidth, this.A = r(), Oe(this)
            };

            function ke(p, k, G) {
                for (var Y in he)
                    if (he.hasOwnProperty(Y) && k === p.f[he[Y]] && G === p.f[he[Y]]) return !0;
                return !1
            }

            function Oe(p) {
                var k = p.g.a.offsetWidth,
                    G = p.h.a.offsetWidth,
                    Y;
                (Y = k === p.f.serif && G === p.f["sans-serif"]) || (Y = we() && ke(p, k, G)), Y ? r() - p.A >= p.w ? we() && ke(p, k, G) && (p.u === null || p.u.hasOwnProperty(p.a.c)) ? Ae(p, p.v) : Ae(p, p.B) : Ve(p) : Ae(p, p.v)
            }

            function Ve(p) {
                setTimeout(n(function() {
                    Oe(this)
                }, p), 50)
            }

            function Ae(p, k) {
                setTimeout(n(function() {
                    l(this.g.a), l(this.h.a), l(this.j.a), l(this.m.a), k(this.a)
                }, p), 0)
            }

            function We(p, k, G) {
                this.c = p, this.a = k, this.f = 0, this.m = this.j = !1, this.s = G
            }
            var Je = null;
            We.prototype.g = function(p) {
                var k = this.a;
                k.g && f(k.f, [k.a.c("wf", p.c, D(p).toString(), "active")], [k.a.c("wf", p.c, D(p).toString(), "loading"), k.a.c("wf", p.c, D(p).toString(), "inactive")]), K(k, "fontactive", p), this.m = !0, De(this)
            }, We.prototype.h = function(p) {
                var k = this.a;
                if (k.g) {
                    var G = u(k.f, k.a.c("wf", p.c, D(p).toString(), "active")),
                        Y = [],
                        X = [k.a.c("wf", p.c, D(p).toString(), "loading")];
                    G || Y.push(k.a.c("wf", p.c, D(p).toString(), "inactive")), f(k.f, Y, X)
                }
                K(k, "fontinactive", p), De(this)
            };

            function De(p) {
                --p.f == 0 && p.j && (p.m ? (p = p.a, p.g && f(p.f, [p.a.c("wf", "active")], [p.a.c("wf", "loading"), p.a.c("wf", "inactive")]), K(p, "active")) : A(p.a))
            }

            function Ye(p) {
                this.j = p, this.a = new ae, this.h = 0, this.f = this.g = !0
            }
            Ye.prototype.load = function(p) {
                this.c = new i(this.j, p.context || this.j), this.g = p.events !== !1, this.f = p.classes !== !1, m(this, new $(this.c, p), p)
            };

            function He(p, k, G, Y, X) {
                var be = --p.h == 0;
                (p.f || p.g) && setTimeout(function() {
                    var Ee = X || null,
                        $e = Y || null || {};
                    if (G.length === 0 && be) A(k.a);
                    else {
                        k.f += G.length, be && (k.j = be);
                        var Ke, tt = [];
                        for (Ke = 0; Ke < G.length; Ke++) {
                            var et = G[Ke],
                                it = $e[et.c],
                                It = k.a,
                                Oo = et;
                            if (It.g && f(It.f, [It.a.c("wf", Oo.c, D(Oo).toString(), "loading")]), K(It, "fontloading", Oo), It = null, Je === null)
                                if (window.FontFace) {
                                    var Oo = /Gecko.*Firefox\/(\d+)/.exec(window.navigator.userAgent),
                                        qa = /OS X.*Version\/10\..*Safari/.exec(window.navigator.userAgent) && /Apple/.exec(window.navigator.vendor);
                                    Je = Oo ? 42 < parseInt(Oo[1], 10) : !qa
                                } else Je = !1;
                            Je ? It = new ie(n(k.g, k), n(k.h, k), k.c, et, k.s, it) : It = new _e(n(k.g, k), n(k.h, k), k.c, et, k.s, Ee, it), tt.push(It)
                        }
                        for (Ke = 0; Ke < tt.length; Ke++) tt[Ke].start()
                    }
                }, 0)
            }

            function m(p, k, G) {
                var X = [],
                    Y = G.timeout;
                oe(k);
                var X = B(p.a, G, p.c),
                    be = new We(p.c, k, Y);
                for (p.h = X.length, k = 0, G = X.length; k < G; k++) X[k].load(function(Ee, $e, Ke) {
                    He(p, be, Ee, $e, Ke)
                })
            }

            function y(p, k) {
                this.c = p, this.a = k
            }
            y.prototype.load = function(p) {
                function k() {
                    if (be["__mti_fntLst" + Y]) {
                        var Ee = be["__mti_fntLst" + Y](),
                            $e = [],
                            Ke;
                        if (Ee)
                            for (var tt = 0; tt < Ee.length; tt++) {
                                var et = Ee[tt].fontfamily;
                                Ee[tt].fontStyle != null && Ee[tt].fontWeight != null ? (Ke = Ee[tt].fontStyle + Ee[tt].fontWeight, $e.push(new x(et, Ke))) : $e.push(new x(et))
                            }
                        p($e)
                    } else setTimeout(function() {
                        k()
                    }, 50)
                }
                var G = this,
                    Y = G.a.projectId,
                    X = G.a.version;
                if (Y) {
                    var be = G.c.o;
                    g(this.c, (G.a.api || "https://fast.fonts.net/jsapi") + "/" + Y + ".js" + (X ? "?v=" + X : ""), function(Ee) {
                        Ee ? p([]) : (be["__MonotypeConfiguration__" + Y] = function() {
                            return G.a
                        }, k())
                    }).id = "__MonotypeAPIScript__" + Y
                } else p([])
            };

            function V(p, k) {
                this.c = p, this.a = k
            }
            V.prototype.load = function(p) {
                var k, G, Y = this.a.urls || [],
                    X = this.a.families || [],
                    be = this.a.testStrings || {},
                    Ee = new h;
                for (k = 0, G = Y.length; k < G; k++) _(this.c, Y[k], O(Ee));
                var $e = [];
                for (k = 0, G = X.length; k < G; k++)
                    if (Y = X[k].split(":"), Y[1])
                        for (var Ke = Y[1].split(","), tt = 0; tt < Ke.length; tt += 1) $e.push(new x(Y[0], Ke[tt]));
                    else $e.push(new x(Y[0]));
                b(Ee, function() {
                    p($e, be)
                })
            };

            function Z(p, k) {
                p ? this.c = p : this.c = Q, this.a = [], this.f = [], this.g = k || ""
            }
            var Q = "https://fonts.googleapis.com/css";

            function ee(p, k) {
                for (var G = k.length, Y = 0; Y < G; Y++) {
                    var X = k[Y].split(":");
                    X.length == 3 && p.f.push(X.pop());
                    var be = "";
                    X.length == 2 && X[1] != "" && (be = ":"), p.a.push(X.join(be))
                }
            }

            function j(p) {
                if (p.a.length == 0) throw Error("No fonts to load!");
                if (p.c.indexOf("kit=") != -1) return p.c;
                for (var k = p.a.length, G = [], Y = 0; Y < k; Y++) G.push(p.a[Y].replace(/ /g, "+"));
                return k = p.c + "?family=" + G.join("%7C"), 0 < p.f.length && (k += "&subset=" + p.f.join(",")), 0 < p.g.length && (k += "&text=" + encodeURIComponent(p.g)), k
            }

            function M(p) {
                this.f = p, this.a = [], this.c = {}
            }
            var te = {
                    latin: "BESbswy",
                    "latin-ext": "çöüğş",
                    cyrillic: "йяЖ",
                    greek: "αβΣ",
                    khmer: "កខគ",
                    Hanuman: "កខគ"
                },
                W = {
                    thin: "1",
                    extralight: "2",
                    "extra-light": "2",
                    ultralight: "2",
                    "ultra-light": "2",
                    light: "3",
                    regular: "4",
                    book: "4",
                    medium: "5",
                    "semi-bold": "6",
                    semibold: "6",
                    "demi-bold": "6",
                    demibold: "6",
                    bold: "7",
                    "extra-bold": "8",
                    extrabold: "8",
                    "ultra-bold": "8",
                    ultrabold: "8",
                    black: "9",
                    heavy: "9",
                    l: "3",
                    r: "4",
                    b: "7"
                },
                de = {
                    i: "i",
                    italic: "i",
                    n: "n",
                    normal: "n"
                },
                fe = /^(thin|(?:(?:extra|ultra)-?)?light|regular|book|medium|(?:(?:semi|demi|extra|ultra)-?)?bold|black|heavy|l|r|b|[1-9]00)?(n|i|normal|italic)?$/;

            function ge(p) {
                for (var k = p.f.length, G = 0; G < k; G++) {
                    var Y = p.f[G].split(":"),
                        X = Y[0].replace(/\+/g, " "),
                        be = ["n4"];
                    if (2 <= Y.length) {
                        var Ee, $e = Y[1];
                        if (Ee = [], $e)
                            for (var $e = $e.split(","), Ke = $e.length, tt = 0; tt < Ke; tt++) {
                                var et;
                                if (et = $e[tt], et.match(/^[\w-]+$/)) {
                                    var it = fe.exec(et.toLowerCase());
                                    if (it == null) et = "";
                                    else {
                                        if (et = it[2], et = et == null || et == "" ? "n" : de[et], it = it[1], it == null || it == "") it = "4";
                                        else var It = W[it],
                                            it = It || (isNaN(it) ? "4" : it.substr(0, 1));
                                        et = [et, it].join("")
                                    }
                                } else et = "";
                                et && Ee.push(et)
                            }
                        0 < Ee.length && (be = Ee), Y.length == 3 && (Y = Y[2], Ee = [], Y = Y ? Y.split(",") : Ee, 0 < Y.length && (Y = te[Y[0]]) && (p.c[X] = Y))
                    }
                    for (p.c[X] || (Y = te[X]) && (p.c[X] = Y), Y = 0; Y < be.length; Y += 1) p.a.push(new x(X, be[Y]))
                }
            }

            function ye(p, k) {
                this.c = p, this.a = k
            }
            var z = {
                Arimo: !0,
                Cousine: !0,
                Tinos: !0
            };
            ye.prototype.load = function(p) {
                var k = new h,
                    G = this.c,
                    Y = new Z(this.a.api, this.a.text),
                    X = this.a.families;
                ee(Y, X);
                var be = new M(X);
                ge(be), _(G, j(Y), O(k)), b(k, function() {
                    p(be.a, be.c, z)
                })
            };

            function se(p, k) {
                this.c = p, this.a = k
            }
            se.prototype.load = function(p) {
                var k = this.a.id,
                    G = this.c.o;
                k ? g(this.c, (this.a.api || "https://use.typekit.net") + "/" + k + ".js", function(Y) {
                    if (Y) p([]);
                    else if (G.Typekit && G.Typekit.config && G.Typekit.config.fn) {
                        Y = G.Typekit.config.fn;
                        for (var X = [], be = 0; be < Y.length; be += 2)
                            for (var Ee = Y[be], $e = Y[be + 1], Ke = 0; Ke < $e.length; Ke++) X.push(new x(Ee, $e[Ke]));
                        try {
                            G.Typekit.load({
                                events: !1,
                                classes: !1,
                                async: !0
                            })
                        } catch {}
                        p(X)
                    }
                }, 2e3) : p([])
            };

            function ce(p, k) {
                this.c = p, this.f = k, this.a = []
            }
            ce.prototype.load = function(p) {
                var k = this.f.id,
                    G = this.c.o,
                    Y = this;
                k ? (G.__webfontfontdeckmodule__ || (G.__webfontfontdeckmodule__ = {}), G.__webfontfontdeckmodule__[k] = function(X, be) {
                    for (var Ee = 0, $e = be.fonts.length; Ee < $e; ++Ee) {
                        var Ke = be.fonts[Ee];
                        Y.a.push(new x(Ke.name, I("font-weight:" + Ke.weight + ";font-style:" + Ke.style)))
                    }
                    p(Y.a)
                }, g(this.c, (this.f.api || "https://f.fontdeck.com/s/css/js/") + d(this.c) + "/" + k + ".js", function(X) {
                    X && p([])
                })) : p([])
            };
            var ue = new Ye(window);
            ue.a.c.custom = function(p, k) {
                return new V(k, p)
            }, ue.a.c.fontdeck = function(p, k) {
                return new ce(k, p)
            }, ue.a.c.monotype = function(p, k) {
                return new y(k, p)
            }, ue.a.c.typekit = function(p, k) {
                return new se(k, p)
            }, ue.a.c.google = function(p, k) {
                return new ye(k, p)
            };
            var me = {
                load: n(ue.load, ue)
            };
            e.exports ? e.exports = me : (window.WebFont = me, window.WebFontConfig && ue.load(window.WebFontConfig))
        })()
    })(yc);
    var ah = yc.exports;
    const sh = ih(ah),
        lh = Fe({
            __name: "AppStyles",
            setup(e) {
                const {
                    settings: t,
                    themeSettings: o
                } = ze(), {
                    seasonalTemplate: n
                } = Yr(), r = q(() => {
                    let s = "";
                    const c = { ...t.value,
                            ...n.value
                        },
                        l = c.popup_background_color,
                        f = c.popup_text_primary_color,
                        u = c.highlight_color,
                        d = c.button_primary_bg_color,
                        _ = c.button_primary_text_color,
                        g = c.button_secondary_bg_color,
                        h = c.button_secondary_text_color,
                        {
                            fontSize: O,
                            fontFamily: b
                        } = c.typography || {},
                        C = O ? `--qbk-font-size: ${O}px;` : "",
                        E = b ? `--qbk-font-family: ${b};` : "",
                        x = CSS.supports("color: color-mix(in srgb, red 10%, #fff)") ? "" : `
    --qbk-subdued-highlight: #f1f1f1;
    --qbk-lighten-highlight: #eee;
    --qbk-text-description: currentColor;
    `,
                        N = c.offer_background_img || "none";
                    return s = `
    :root {
      --qbk-popup-background-color: ${l};
      --qbk-popup-text-primary-color: ${f};
      --qbk-highlight-color: ${u};
      --qbk-button-primary-bg-color: ${d};
      --qbk-button-primary-text-color: ${_};
      --qbk-button-secondary-bg-color: ${g};
      --qbk-button-secondary-text-color: ${h};
      --qbk-offer-background-img: ${N};
      ${E}
      ${C}
      ${x}
    }`, s
                }), i = q(() => o.value && o.value.css || ""), a = () => {
                    const {
                        fontFamily: s
                    } = t.value.typography || {};
                    s && sh.load({
                        google: {
                            families: [`${s}:400,700`]
                        }
                    })
                };
                return nt(() => {
                    a()
                }), (s, c) => (H(), Se(Ai("style"), {
                    id: "qbk-styles",
                    innerHTML: `${i.value} ${r.value}`
                }, null, 8, ["innerHTML"]))
            }
        }),
        ch = Fe({
            __name: "RelativeTeleport",
            setup(e) {
                const t = J(null),
                    o = J(!1),
                    n = J(!1),
                    {
                        getConfig: r
                    } = ze(),
                    {
                        isCartEmpty: i
                    } = kt(),
                    a = q(() => r("isRewardBarAlwaysInit")),
                    s = async () => {
                        await L.delay(r("waitForDrawerLoadedTimeout"));
                        const c = r(i.value ? "orderGoalDrawerEmptySelector" : "orderGoalDrawerSelector"),
                            l = r(i.value ? "orderGoalDrawerEmptyPosition" : "orderGoalDrawerPosition"),
                            f = document.querySelector(c);
                        if (!f) return o.value = !1, i.value && !a.value && (n.value = !0), !1;
                        o.value = !0, L.placeElement(f, l, t.value)
                    };
                return nt(() => {
                    s(), document.addEventListener(F.EVENT_LINE_ITEMS_CHANGED, s)
                }), io(() => {
                    document.removeEventListener(F.EVENT_LINE_ITEMS_CHANGED, s)
                }), (c, l) => (H(), ne("div", {
                    class: "qbk-relative-teleport",
                    ref_key: "teleportRef",
                    ref: t
                }, [o.value || a.value ? ht((H(), Se(T(fc), {
                    key: 0,
                    firstKick: n.value
                }, null, 8, ["firstKick"])), [
                    [Rt, o.value]
                ]) : ve("", !0)], 512))
            }
        }),
        uh = {
            class: "qikify-boosterkit"
        },
        dh = Fe({
            __name: "BoosterKit",
            setup(e) {
                const {
                    bkCodes: t,
                    contents: o,
                    init: n,
                    getConfig: r,
                    isFrozenApp: i,
                    isShowPopupOneTime: a,
                    isExtensionAvailableInPlan: s,
                    settings: c,
                    hasActiveFreeGift: l
                } = ze(), {
                    observeCartChanges: f,
                    fetchCartData: u,
                    createCustomCart: d,
                    clearCustomCart: _,
                    clearCartAfterCheckoutByStorefrontAPI: g,
                    customCart: h,
                    cart: O,
                    clearCartAttrs: b,
                    giftChecking: C,
                    appliedDiscounts: E
                } = kt(), {
                    discounts: x,
                    collectDiscounts: N,
                    removeDiscountByDisplayCondition: w
                } = wt(), {
                    setupListener: D,
                    getAtcListener: P,
                    isAllExtensionsEmbedded: I,
                    isOfferEmbed: $,
                    setupTriggerDrawerListener: oe,
                    getVariantInput: A,
                    getQuantityInput: K
                } = Ot(), {
                    setForm: ae
                } = Hr(), {
                    hasActiveRewardBar: B,
                    hasActiveCheckoutOffer: re,
                    hasActiveGiftGoal: R,
                    collectAutoGiftData: U
                } = jr(), {
                    collectProducts: ie
                } = Nt(), {
                    showToast: _e
                } = lc(), {
                    init: he,
                    todayOffersActive: Ce,
                    promotionEntries: we
                } = zn(), {
                    setupPublicAPI: ke
                } = Xl(), Oe = J(null), Ve = J(null), Ae = J(null), {
                    selectedVariantId: We,
                    setupVariantChangeListener: Je
                } = da(Ve), De = q(() => {
                    var y;
                    return s(S.FreeGift) && L.isProductPage() && !$((y = window == null ? void 0 : window.qbkStore) == null ? void 0 : y.handle, S.FreeGift) && l.value
                });
                ot(() => We.value, () => {
                    r("enableResetEventAtc") && He()
                });
                const Ye = async y => {
                        if (a.value) return;
                        const V = async () => {
                                var j;
                                let ee = "";
                                if (x.value && x.value.length > 1) {
                                    if (ee = h.value ? (j = h.value) == null ? void 0 : j.checkoutUrl : "", !ee) try {
                                        ee = (await d(x.value)).checkoutUrl
                                    } catch (M) {
                                        L.log("Cannot create custom cart", M)
                                    }
                                } else _();
                                if (ee) return window.location.href = ee
                            },
                            Z = document.querySelectorAll(r("checkoutSubmitSelector"));
                        L.log("checkoutButtons", Z);
                        const Q = async ee => {
                            Oe.value && await V(), y && await y(), (() => {
                                L.log("show checkout popup"), document.dispatchEvent(new CustomEvent(F.EVENT_OPEN_POPUP, {
                                    detail: {
                                        action: Tt.Checkout,
                                        element: ee
                                    }
                                }))
                            })()
                        };
                        Z.forEach(ee => {
                            D(ee, F.CHECKOUT_LISTENER, () => Q(ee))
                        })
                    },
                    He = () => {
                        var Z;
                        if (a.value || r("ignoreInitPopup")) return;
                        const {
                            form: y,
                            btn: V
                        } = P();
                        if (!(!y || !V) && (ae(y), y.setAttribute(F.FORM_LISTENER, "true"), !I((Z = window == null ? void 0 : window.qbkStore) == null ? void 0 : Z.handle))) {
                            Ve.value = y, Ae.value = V;
                            const Q = r("getVariantId"),
                                ee = A(y),
                                j = l.value && K(y),
                                M = () => {
                                    L.log("show atc popup"), document.dispatchEvent(new CustomEvent(F.EVENT_OPEN_POPUP, {
                                        detail: {
                                            product: {
                                                productId: window.qbkStore.productId,
                                                handle: window.qbkStore.handle,
                                                triggerId: (Q == null ? void 0 : Q()) || (ee == null ? void 0 : ee.value) || window.qbkStore.selectedId,
                                                triggerQuantity: +((j == null ? void 0 : j.value) || 1)
                                            },
                                            action: Tt.AddToCart,
                                            element: V
                                        }
                                    }))
                                };
                            D(V, F.POPUP_LISTENER, M), r("enableResetEventAtc") && Je()
                        }
                    },
                    m = async (y = !1) => {
                        var V, Z, Q, ee, j, M, te, W, de, fe;
                        try {
                            const ge = O.value.item_count || 0,
                                ye = (Q = (Z = (V = O.value) == null ? void 0 : V.items) == null ? void 0 : Z[0]) == null ? void 0 : Q.key,
                                z = E.value,
                                se = await u(),
                                ce = se.item_count || 0,
                                ue = (j = (ee = se == null ? void 0 : se.items) == null ? void 0 : ee[0]) == null ? void 0 : j.key;
                            N(), document.dispatchEvent(new CustomEvent(F.EVENT_DATA_UPDATED)), ce === 0 && (c.value.enable_empty_cart_reward_bar || b(), localStorage.removeItem(F.GIFT_GOAL_STORAGE)), (ge !== ce || ye !== ue) && (re.value && (setTimeout(Ye, r("waitForDrawerLoadedTimeout")), document.querySelector(r("drawerSelector")) && ie(((M = se == null ? void 0 : se.items) == null ? void 0 : M.map(p => String(p.product_id))) || [])), R.value && C(), document.dispatchEvent(new CustomEvent(F.EVENT_LINE_ITEMS_CHANGED)), !r("disableToast") && !y && ((W = (te = E.value) == null ? void 0 : te.all) != null && W.length) && ((fe = (de = E.value) == null ? void 0 : de.all) != null && fe.some(p => {
                                var k, G;
                                return !((k = z.all) != null && k.includes(p)) && ((G = t.value) == null ? void 0 : G.includes(p))
                            })) && _e(o.value.discount_toast_label))
                        } catch (ge) {
                            L.log("App cannot update data", ge)
                        }
                    };
                return Er(() => {
                    n(), Oe.value = r("isUseCustomCart")
                }), nt(async () => {
                    if (!i.value) {
                        ke();
                        try {
                            document.addEventListener(F.EVENT_FILTER_DISCOUNT, y => {
                                var V;
                                return w((V = y.detail) == null ? void 0 : V.callback)
                            }), Oe.value && await g(), await U(), await m(!0), f(), L.isProductPage() && He(), re.value && oe(), document.addEventListener(F.EVENT_CART_CHANGE, () => m()), document.addEventListener(F.EVENT_CHECKOUT_LISTENER, y => {
                                var V;
                                return Ye((V = y == null ? void 0 : y.detail) == null ? void 0 : V.callback)
                            }), document.dispatchEvent(new CustomEvent(F.EVENT_BOOSTERKIT_MOUNTED)), he()
                        } catch (y) {
                            L.log("Cannot set up data", y)
                        }
                    }
                }), io(() => {
                    document.removeEventListener(F.EVENT_CART_CHANGE, () => m()), document.removeEventListener(F.EVENT_CHECKOUT_LISTENER, y => {
                        var V;
                        return Ye((V = y.detail) == null ? void 0 : V.callback)
                    }), document.removeEventListener(F.EVENT_FILTER_DISCOUNT, y => {
                        var V;
                        return w((V = y.detail) == null ? void 0 : V.callback)
                    })
                }), (y, V) => (H(), ne("div", uh, [pe(T(lh)), pe(T(rh)), pe(T(Lb)), T(B) ? (H(), Se(T(ch), {
                    key: 0
                })) : ve("", !0), De.value ? (H(), Se(T(y_), {
                    key: 1,
                    form: Ve.value,
                    to: Ae.value
                }, null, 8, ["form", "to"])) : ve("", !0), pe(T(dm)), T(Ce) && T(we).length ? (H(), Se(T(Om), {
                    key: 2
                })) : ve("", !0), pe(T(Xg))]))
            }
        }),
        fh = Fe({
            __name: "App",
            setup(e) {
                return (t, o) => (H(), Se(dh))
            }
        }),
        ev = "",
        ph = e => (gs("data-v-9e94798f"), e = e(), hs(), e),
        bh = {
            key: 0,
            class: "qbk-design-mode"
        },
        _h = {
            key: 0,
            class: "qbk-empty-state"
        },
        mh = ["src"],
        gh = {
            key: 1,
            class: "qbk-premium-warning-banner"
        },
        hh = ph(() => v("svg", {
            class: "qbk-premium-warning__icon",
            viewBox: "0 0 512 512",
            xmlns: "http://www.w3.org/2000/svg"
        }, [v("path", {
            d: "M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480H40c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24V296c0 13.3 10.7 24 24 24s24-10.7 24-24V184c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"
        })], -1)),
        vh = {
            class: "qbk-premium-warning__message"
        },
        kh = Xr(Fe({
            __name: "InjectOffer.ce",
            setup(e) {
                const t = L.isDesignMode(),
                    o = J(!1),
                    n = J(""),
                    r = wr(),
                    {
                        collectProductData: i
                    } = Nt(),
                    {
                        updateEmbeddedOffers: a
                    } = Ot(),
                    s = q(() => `https://cdn.qikify.com/portal/v2/boosterkit/${r.type}-empty-state.png`);
                return nt(() => {
                    if (t) {
                        if (!(window._BK.entries || []).some(l => l.type === r.type)) {
                            o.value = !0;
                            return
                        }!L.checkValidEntry(r.type) && !cn.isPricingByShopifyPlan() && (n.value = yt(Gt.premiumWarning, {
                            type: `${Gt.entryName[r.type]} offer`
                        }))
                    }
                    a(r.handle, r.type);
                    const c = r.productId;
                    setTimeout(() => {
                        i({
                            id: c
                        })
                    }, 100), Ko(Lp, { ...r
                    }).mount(`#${r.mountId}`)
                }), (c, l) => T(t) ? (H(), ne("div", bh, [o.value ? (H(), ne("div", _h, [v("img", {
                    class: "qbk-empty-state__offer",
                    src: s.value
                }, null, 8, mh)])) : ve("", !0), n.value ? (H(), ne("div", gh, [hh, v("div", vh, [v("span", null, Te(n.value), 1), v("a", {
                    class: "qbk-premium-warning__action",
                    onClick: l[0] || (l[0] = (...f) => T(L).openPricing && T(L).openPricing(...f))
                }, "Upgrade")])])) : ve("", !0)])) : ve("", !0)
            }
        }), [
            ["styles", [`.qbk-empty-state__offer[data-v-9e94798f]{width:100%;height:100%}.qbk-premium-warning-banner[data-v-9e94798f]{display:flex;justify-content:center;align-items:center;gap:5px;color:initial;padding:var(--qbk-space-025) var(--qbk-space-1);font-size:.9em;border-radius:3px;background-color:var(--qbk-error-banner)}.qbk-premium-warning__icon[data-v-9e94798f]{width:2em;height:auto;fill:var(--qbk-text-required);padding:0 10px}.qbk-premium-warning__action[data-v-9e94798f]{padding:0 5px;text-decoration:underline;cursor:pointer;font-weight:700}
`]],
            ["__scopeId", "data-v-9e94798f"]
        ]),
        qc = e => (gs("data-v-fc050d2c"), e = e(), hs(), e),
        yh = {
            key: 0,
            class: "qbk-design-mode"
        },
        qh = {
            key: 0,
            class: "qbk-empty-state"
        },
        Eh = [qc(() => v("img", {
            class: "qbk-empty-state__offer",
            src: "https://cdn.qikify.com/portal/v2/boosterkit/order-goal-empty-state.png"
        }, null, -1))],
        wh = {
            key: 1,
            class: "qbk-premium-warning-banner"
        },
        xh = qc(() => v("svg", {
            class: "qbk-premium-warning__icon",
            viewBox: "0 0 512 512",
            xmlns: "http://www.w3.org/2000/svg"
        }, [v("path", {
            d: "M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480H40c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24V296c0 13.3 10.7 24 24 24s24-10.7 24-24V184c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"
        })], -1)),
        Ch = {
            class: "qbk-premium-warning__message"
        },
        Th = Xr(Fe({
            __name: "InjectOrderGoal.ce",
            setup(e) {
                const t = L.isDesignMode(),
                    o = J(!1),
                    n = J(""),
                    r = wr();
                return nt(() => {
                    if (t) {
                        if (!window._BK) return;
                        const {
                            entries: i
                        } = window._BK, a = Gt.rewardBarEntries.filter(c => i == null ? void 0 : i.some(l => l.type === c)), s = a.filter(c => !L.checkValidEntry(c) && !cn.isPricingByShopifyPlan());
                        if (!a.length) {
                            o.value = !0;
                            return
                        }
                        if (s.length) {
                            const c = a.length === s.length ? "Reward Bar" : s.map(l => Gt.entryName[l]).join(",");
                            n.value = yt(Gt.premiumWarning, {
                                type: c
                            })
                        }
                    }
                    Ko(fc, { ...r
                    }).mount(`#${r.mountId}`)
                }), (i, a) => T(t) ? (H(), ne("div", yh, [o.value ? (H(), ne("div", qh, Eh)) : ve("", !0), n.value ? (H(), ne("div", wh, [xh, v("div", Ch, [v("span", null, Te(n.value), 1), v("a", {
                    class: "qbk-premium-warning__action",
                    onClick: a[0] || (a[0] = (...s) => T(L).openPricing && T(L).openPricing(...s))
                }, "Upgrade")])])) : ve("", !0)])) : ve("", !0)
            }
        }), [
            ["styles", [`.qbk-design-mode[data-v-fc050d2c]{display:flex;justify-content:center;align-items:center}.qbk-empty-state__offer[data-v-fc050d2c]{width:auto;height:auto}.qbk-premium-warning-banner[data-v-fc050d2c]{display:flex;justify-content:center;align-items:center;gap:5px;max-width:760px;color:initial;padding:var(--qbk-space-1);font-size:.9em;border-radius:3px;background-color:var(--qbk-error-banner)}.qbk-premium-warning__icon[data-v-fc050d2c]{width:2em;height:auto;fill:var(--qbk-text-required);padding:0 10px}.qbk-premium-warning__action[data-v-fc050d2c]{padding:0 5px;text-decoration:underline;cursor:pointer;font-weight:700}
`]],
            ["__scopeId", "data-v-fc050d2c"]
        ]),
        Oh = Fe({
            __name: "InjectCartWidget.ce",
            setup(e) {
                const t = wr();
                return nt(() => {
                    Ko(d_, { ...t
                    }).mount(`#${t.mountId}`)
                }), () => {}
            }
        }),
        Nh = Fe({
            __name: "InjectPromotionBadge.ce",
            setup(e) {
                const t = wr();
                return nt(() => {
                    setTimeout(() => {
                        Ko(bc, { ...t
                        }).mount(`#${t.mountId}`)
                    }, 100)
                }), (o, n) => null
            }
        }),
        Ph = Dr(kh),
        Ah = Dr(Oh),
        Ih = Dr(Th),
        Dh = Dr(Nh);
    customElements.define("qbk-inject-offer", Ph), customElements.define("qbk-inject-cart-widget", Ah), customElements.define("qbk-inject-order-goal", Ih), customElements.define("qbk-inject-promotion-badge", Dh), window.BOOSTERKIT_LOADED || (Ko(fh).use(Wf).mount(`#${F.ELEMENT_ID}`), window.BOOSTERKIT_LOADED = !0)
});
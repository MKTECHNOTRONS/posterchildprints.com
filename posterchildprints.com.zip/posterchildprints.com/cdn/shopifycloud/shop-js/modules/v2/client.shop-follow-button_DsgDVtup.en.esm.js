import {
    h as e,
    q as o,
    aq as t,
    am as n,
    x as r,
    T as l,
    as as s,
    i,
    r as a,
    y as c,
    E as d,
    v as u,
    g as p,
    a0 as h,
    u as f,
    o as m,
    J as v,
    _ as g,
    R as w,
    s as N,
    A as b,
    n as _,
    V as O,
    l as y,
    at as x
} from "./chunk.common_Dy4FpwmR.esm.js";
import {
    M as F,
    A as I
} from "./chunk.modal_CSDrTnGs.esm.js";

function L(o) {
    var t;
    const {
        notify: n
    } = a(), [r, l] = e(null), [s, i] = e(!1);
    c((() => {
        (() => {
            d(this, void 0, void 0, (function*() {
                const e = yield function() {
                    return d(this, arguments, void 0, (function*(e = location.origin) {
                        const o = fetch(`${e}/meta.json`);
                        try {
                            const e = yield o;
                            return yield e.json()
                        } catch (e) {
                            return null
                        }
                    }))
                }(o);
                e ? l(e) : n(new Error("Failed to fetch store metadata")), i(!0)
            }))
        })()
    }), [n, o]);
    const u = null !== (t = null == r ? void 0 : r.name) && void 0 !== t ? t : "the store";
    return {
        loaded: s,
        storeId: null == r ? void 0 : r.id,
        storeMetadata: r,
        storeName: u
    }
}

function k({
    anchorElement: e,
    devMode: o,
    onClose: t,
    storefrontOrigin: n
}) {
    var r;
    const {
        trackUserAction: l
    } = u(), {
        translate: s
    } = p(), {
        loaded: a,
        storeId: c,
        storeName: d
    } = L(n), v = c ? `https://shop.app/sid/${c}` : "#";
    if (h()) {
        const e = s("shopFollowButton.followingModal.title", {
                store: d
            }),
            o = s("shopFollowButton.followingModal.subtitle"),
            n = s("shopFollowButton.continueGeneric");
        return f(F, {
            onDismiss: t,
            popupDisabled: !0,
            variant: "follow",
            visible: a,
            children: f("div", {
                className: "m-auto p-6 font-sans",
                children: [f("div", {
                    className: "relative m-auto pb-4 text-center",
                    children: [f("h2", {
                        className: "mb-2 px-6 text-subtitle text-black",
                        children: e
                    }), f("p", {
                        className: "overflow-hidden text-ellipsis whitespace-pre-line text-body-small text-grayscale-d1",
                        children: o
                    })]
                }), f("div", {
                    className: "flex justify-center",
                    children: f("button", {
                        className: "w-full rounded-md bg-purple-primary p-3 leading-6 text-white no-underline",
                        onClick: function() {
                            l({
                                userAction: "FOLLOWING_GET_SHOP_APP_CLICK"
                            }), i.open(v, "_self"), t()
                        },
                        type: "button",
                        children: n
                    })
                })]
            })
        })
    }
    const g = null !== (r = s("shopFollowButton.followingModal.qrAltText")) && void 0 !== r ? r : "";
    let w = c ? `https://shop.app/qr/sid/${c}` : "#";
    return o && (w = "https://shop.app/qr/sid/59659354134"), f(F, {
        anchorTo: e,
        disableMinWidth: !0,
        hideHeader: !0,
        onDismiss: t,
        popupDisabled: !0,
        variant: "follow",
        visible: a,
        children: f("div", {
            className: "m-auto w-55 p-6 font-sans",
            children: [f("div", {
                className: "relative m-auto pb-4 text-center",
                children: f("p", {
                    className: "overflow-hidden text-ellipsis whitespace-pre-line text-grayscale-d1",
                    children: s("shopFollowButton.followingModal.qrHeader", {
                        store: d
                    })
                })
            }), f("div", {
                className: "m-auto w-37 bg-white forced-color-adjust-none",
                children: f("img", {
                    src: w,
                    alt: g
                })
            }), f("div", {
                className: "flex justify-center px-0 pb-0 pt-4 text-purple-primary",
                children: f(m, {
                    className: "h-5"
                })
            })]
        })
    })
}

function C({
    className: e,
    filled: o
}) {
    return f("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 20 20",
        children: f("path", {
            fill: o ? "currentColor" : "none",
            stroke: "currentColor",
            "stroke-linejoin": "round",
            "stroke-width": "1.667",
            d: "m9.14 4.502.86.881.86-.881a3.82 3.82 0 0 1 5.437-.064l.064.064c1.498 1.536 1.518 4.014.062 5.576l-.062.066L10 16.666l-6.36-6.524c-1.52-1.557-1.52-4.083 0-5.641a3.822 3.822 0 0 1 5.5 0Z"
        })
    })
}
const M = ({
        clientId: h,
        devMode: v = !1,
        storefrontOrigin: g
    }) => {
        const {
            trackPageImpression: w,
            trackUserAction: F
        } = u(), {
            translate: L
        } = p(), M = N(), {
            notify: E
        } = a(), S = b(null), T = b(null), [A, P] = function({
            key: r,
            type: l = "localStorage",
            defaultValue: s
        }) {
            const i = `signInWithShop:${r}`,
                [a, c] = e((() => {
                    const e = n(i, {
                        session: "sessionStorage" === l
                    });
                    if (!e) return s;
                    try {
                        return JSON.parse(e)
                    } catch (e) {
                        return s
                    }
                }));
            return [a, o((e => {
                c(e), t(i, JSON.stringify(e), {
                    session: "sessionStorage" === l
                })
            }), [i, l])]
        }({
            key: "following",
            defaultValue: !1
        }), [B, W] = e(!1), [j, D] = e(!1), G = function(e) {
            const {
                recordCounter: o
            } = r();
            return l((() => {
                try {
                    if (e && s(e)) return e
                } catch (e) {
                    e instanceof Error && o("shop_js_invalid_storefront_origin", {
                        attributes: {
                            error: e
                        }
                    })
                }
                return i.location.origin
            }), [e, o])
        }(g), [q, H] = e();
        c((() => {
            w({
                page: A ? "COMPONENT_LOADED_FOLLOWING" : "COMPONENT_LOADED_NOT_FOLLOWING"
            })
        }), [A, w]), c((() => {
            if (!S.current || void 0 === w || !y()) return;
            const e = new IntersectionObserver((o => {
                for (const {
                        isIntersecting: t
                    } of o) t && (null == e || e.disconnect(), w({
                    page: "FOLLOW_BUTTON_SHOWN_IN_VIEWPORT"
                }))
            }));
            return e.observe(S.current), () => {
                e.disconnect()
            }
        }), [w]);
        const z = o((() => {
            var e;
            return A ? (w({
                page: "FOLLOWING_GET_SHOP_APP_CTA"
            }), W(!0)) : (F({
                userAction: "FOLLOW_ON_SHOP_CLICKED"
            }), v ? P(!0) : (D(!0), void(null === (e = T.current) || void 0 === e || e.open("user_button_clicked"))))
        }), [v, A, P, w, F]);
        const V = _("absolute inset-y-0 -z-10 rounded-max bg-purple-primary", A ? "w-9 animate-follow" : "w-full group-hover_bg-purple-d0"),
            U = _("group relative inline-flex h-9 items-center rounded-max bg-transparent", A && "gap-x-1-5"),
            $ = _("cursor-pointer whitespace-nowrap pr-3 font-sans text-button-large transition-colors", A ? "text-black" : "text-white"),
            J = A ? "shopFollowButton.following" : "shopFollowButton.follow",
            {
                authorizeUrl: R
            } = O({
                clientId: h,
                error: q,
                flow: "follow",
                proxy: !0,
                redirectType: "iframe",
                responseType: "code"
            }),
            K = j ? f(I, {
                onClose: () => W(!1),
                onComplete: function(e) {
                    return d(this, arguments, void 0, (function*({
                        loggedIn: e,
                        shouldFinalizeLogin: o,
                        email: t
                    }) {
                        e && o && (yield x(G, (e => {
                            E(new Error(e))
                        }))), M("completed", {
                            loggedIn: e,
                            email: t
                        }), P(!0), D(!1), W(!1)
                    }))
                },
                onError: function({
                    code: e,
                    email: o,
                    message: t
                }) {
                    var n;
                    M("error", {
                        code: e,
                        email: o,
                        message: t
                    }), "retriable_server_error" === e && (q === e && (null === (n = T.current) || void 0 === n || n.reload()), H("retriable_server_error"))
                },
                onLoaded: function() {
                    var e;
                    !A && j && (null === (e = T.current) || void 0 === e || e.open("user_button_clicked"))
                },
                proxy: !0,
                ref: T,
                src: R,
                storefrontOrigin: G,
                variant: "follow"
            }) : null,
            Q = A && B && G ? f(k, {
                anchorElement: S,
                devMode: v,
                onClose: () => W(!1),
                storefrontOrigin: G
            }) : null;
        return f("div", {
            className: "relative z-0",
            children: [f("button", {
                className: U,
                onClick: z,
                type: "button",
                ref: S,
                children: [f("div", {
                    className: V
                }), f("div", {
                    className: "px-2 text-white",
                    children: f(C, {
                        className: "size-5",
                        filled: A
                    })
                }), f("span", {
                    className: $,
                    children: L(J, {
                        shop: f(m, {
                            className: "relative inline-block h-4 w-auto"
                        })
                    })
                })]
            }), K, Q]
        })
    },
    E = e => d(void 0, void 0, void 0, (function*() {
        return {
            shopFollowButton: {
                continueGeneric: "Continue",
                follow: "Follow on {shop}",
                following: "Following on {shop}",
                followingModal: {
                    title: "Visit {store} on Shop",
                    subtitle: "Everything you need to shop, track, and pay—all in one place.",
                    qrHeader: "Scan to visit {store} on the Shop app",
                    qrAltText: "Shop app QR code"
                }
            }
        }
    }));
v((e => {
    var {
        devMode: o,
        element: t
    } = e, n = g(e, ["devMode", "element"]);
    return f(w, {
        devMode: o,
        element: t,
        monorailProps: {
            analyticsContext: "loginWithShopFollow",
            flow: "follow"
        },
        featureName: "ShopFollowButton",
        getFeatureDictionary: E,
        children: f(M, Object.assign({}, n, {
            devMode: o
        }))
    })
}), {
    name: "shop-follow-button",
    props: {
        clientId: "string",
        devMode: "boolean",
        storefrontOrigin: "string"
    },
    shadow: "open"
});
//# sourceMappingURL=client.shop-follow-button_DsgDVtup.en.esm.js.map
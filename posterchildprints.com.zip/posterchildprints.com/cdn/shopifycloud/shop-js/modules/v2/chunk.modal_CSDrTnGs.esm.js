import {
    i as e,
    A as t,
    y as n,
    h as o,
    d as r,
    q as i,
    T as l,
    w as s,
    _ as a,
    a as c,
    u,
    b as d,
    f,
    c as m,
    e as p,
    g as h,
    j as g,
    k as y,
    l as v,
    m as w,
    n as b,
    S as x,
    o as E,
    C as R,
    P as T,
    p as O,
    r as L,
    s as _,
    t as C,
    v as D,
    x as S,
    z as M,
    B as A,
    F as P,
    D as k,
    E as z,
    G as I,
    H as F,
    I as N
} from "./chunk.common_Dy4FpwmR.esm.js";
const j = Math.min,
    H = Math.max,
    V = Math.round,
    W = Math.floor,
    B = e => ({
        x: e,
        y: e
    }),
    q = {
        left: "right",
        right: "left",
        bottom: "top",
        top: "bottom"
    },
    $ = {
        start: "end",
        end: "start"
    };

function U(e, t, n) {
    return H(e, j(t, n))
}

function X(e, t) {
    return "function" == typeof e ? e(t) : e
}

function Y(e) {
    return e.split("-")[0]
}

function Z(e) {
    return e.split("-")[1]
}

function G(e) {
    return "x" === e ? "y" : "x"
}

function J(e) {
    return "y" === e ? "height" : "width"
}

function K(e) {
    return ["top", "bottom"].includes(Y(e)) ? "y" : "x"
}

function Q(e) {
    return G(K(e))
}

function ee(e) {
    return e.replace(/start|end/g, (e => $[e]))
}

function te(e) {
    return e.replace(/left|right|bottom|top/g, (e => q[e]))
}

function ne(e) {
    return "number" != typeof e ? function(e) {
        return {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            ...e
        }
    }(e) : {
        top: e,
        right: e,
        bottom: e,
        left: e
    }
}

function oe(e) {
    const {
        x: t,
        y: n,
        width: o,
        height: r
    } = e;
    return {
        width: o,
        height: r,
        top: n,
        left: t,
        right: t + o,
        bottom: n + r,
        x: t,
        y: n
    }
}

function re(e, t, n) {
    let {
        reference: o,
        floating: r
    } = e;
    const i = K(t),
        l = Q(t),
        s = J(l),
        a = Y(t),
        c = "y" === i,
        u = o.x + o.width / 2 - r.width / 2,
        d = o.y + o.height / 2 - r.height / 2,
        f = o[s] / 2 - r[s] / 2;
    let m;
    switch (a) {
        case "top":
            m = {
                x: u,
                y: o.y - r.height
            };
            break;
        case "bottom":
            m = {
                x: u,
                y: o.y + o.height
            };
            break;
        case "right":
            m = {
                x: o.x + o.width,
                y: d
            };
            break;
        case "left":
            m = {
                x: o.x - r.width,
                y: d
            };
            break;
        default:
            m = {
                x: o.x,
                y: o.y
            }
    }
    switch (Z(t)) {
        case "start":
            m[l] -= f * (n && c ? -1 : 1);
            break;
        case "end":
            m[l] += f * (n && c ? -1 : 1)
    }
    return m
}
async function ie(e, t) {
    var n;
    void 0 === t && (t = {});
    const {
        x: o,
        y: r,
        platform: i,
        rects: l,
        elements: s,
        strategy: a
    } = e, {
        boundary: c = "clippingAncestors",
        rootBoundary: u = "viewport",
        elementContext: d = "floating",
        altBoundary: f = !1,
        padding: m = 0
    } = X(t, e), p = ne(m), h = s[f ? "floating" === d ? "reference" : "floating" : d], g = oe(await i.getClippingRect({
        element: null == (n = await (null == i.isElement ? void 0 : i.isElement(h))) || n ? h : h.contextElement || await (null == i.getDocumentElement ? void 0 : i.getDocumentElement(s.floating)),
        boundary: c,
        rootBoundary: u,
        strategy: a
    })), y = "floating" === d ? {
        x: o,
        y: r,
        width: l.floating.width,
        height: l.floating.height
    } : l.reference, v = await (null == i.getOffsetParent ? void 0 : i.getOffsetParent(s.floating)), w = await (null == i.isElement ? void 0 : i.isElement(v)) && await (null == i.getScale ? void 0 : i.getScale(v)) || {
        x: 1,
        y: 1
    }, b = oe(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
        elements: s,
        rect: y,
        offsetParent: v,
        strategy: a
    }) : y);
    return {
        top: (g.top - b.top + p.top) / w.y,
        bottom: (b.bottom - g.bottom + p.bottom) / w.y,
        left: (g.left - b.left + p.left) / w.x,
        right: (b.right - g.right + p.right) / w.x
    }
}

function le() {
    return "undefined" != typeof window
}

function se(e) {
    return ue(e) ? (e.nodeName || "").toLowerCase() : "#document"
}

function ae(e) {
    var t;
    return (null == e || null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
}

function ce(e) {
    var t;
    return null == (t = (ue(e) ? e.ownerDocument : e.document) || window.document) ? void 0 : t.documentElement
}

function ue(e) {
    return !!le() && (e instanceof Node || e instanceof ae(e).Node)
}

function de(e) {
    return !!le() && (e instanceof Element || e instanceof ae(e).Element)
}

function fe(e) {
    return !!le() && (e instanceof HTMLElement || e instanceof ae(e).HTMLElement)
}

function me(e) {
    return !(!le() || "undefined" == typeof ShadowRoot) && (e instanceof ShadowRoot || e instanceof ae(e).ShadowRoot)
}

function pe(e) {
    const {
        overflow: t,
        overflowX: n,
        overflowY: o,
        display: r
    } = be(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + o + n) && !["inline", "contents"].includes(r)
}

function he(e) {
    return ["table", "td", "th"].includes(se(e))
}

function ge(e) {
    return [":popover-open", ":modal"].some((t => {
        try {
            return e.matches(t)
        } catch (e) {
            return !1
        }
    }))
}

function ye(e) {
    const t = ve(),
        n = de(e) ? be(e) : e;
    return ["transform", "translate", "scale", "rotate", "perspective"].some((e => !!n[e] && "none" !== n[e])) || !!n.containerType && "normal" !== n.containerType || !t && !!n.backdropFilter && "none" !== n.backdropFilter || !t && !!n.filter && "none" !== n.filter || ["transform", "translate", "scale", "rotate", "perspective", "filter"].some((e => (n.willChange || "").includes(e))) || ["paint", "layout", "strict", "content"].some((e => (n.contain || "").includes(e)))
}

function ve() {
    return !("undefined" == typeof CSS || !CSS.supports) && CSS.supports("-webkit-backdrop-filter", "none")
}

function we(e) {
    return ["html", "body", "#document"].includes(se(e))
}

function be(e) {
    return ae(e).getComputedStyle(e)
}

function xe(e) {
    return de(e) ? {
        scrollLeft: e.scrollLeft,
        scrollTop: e.scrollTop
    } : {
        scrollLeft: e.scrollX,
        scrollTop: e.scrollY
    }
}

function Ee(e) {
    if ("html" === se(e)) return e;
    const t = e.assignedSlot || e.parentNode || me(e) && e.host || ce(e);
    return me(t) ? t.host : t
}

function Re(e) {
    const t = Ee(e);
    return we(t) ? e.ownerDocument ? e.ownerDocument.body : e.body : fe(t) && pe(t) ? t : Re(t)
}

function Te(e, t, n) {
    var o;
    void 0 === t && (t = []), void 0 === n && (n = !0);
    const r = Re(e),
        i = r === (null == (o = e.ownerDocument) ? void 0 : o.body),
        l = ae(r);
    if (i) {
        const e = Oe(l);
        return t.concat(l, l.visualViewport || [], pe(r) ? r : [], e && n ? Te(e) : [])
    }
    return t.concat(r, Te(r, [], n))
}

function Oe(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null
}

function Le(e) {
    const t = be(e);
    let n = parseFloat(t.width) || 0,
        o = parseFloat(t.height) || 0;
    const r = fe(e),
        i = r ? e.offsetWidth : n,
        l = r ? e.offsetHeight : o,
        s = V(n) !== i || V(o) !== l;
    return s && (n = i, o = l), {
        width: n,
        height: o,
        $: s
    }
}

function _e(e) {
    return de(e) ? e : e.contextElement
}

function Ce(e) {
    const t = _e(e);
    if (!fe(t)) return B(1);
    const n = t.getBoundingClientRect(),
        {
            width: o,
            height: r,
            $: i
        } = Le(t);
    let l = (i ? V(n.width) : n.width) / o,
        s = (i ? V(n.height) : n.height) / r;
    return l && Number.isFinite(l) || (l = 1), s && Number.isFinite(s) || (s = 1), {
        x: l,
        y: s
    }
}
const De = B(0);

function Se(e) {
    const t = ae(e);
    return ve() && t.visualViewport ? {
        x: t.visualViewport.offsetLeft,
        y: t.visualViewport.offsetTop
    } : De
}

function Me(e, t, n, o) {
    void 0 === t && (t = !1), void 0 === n && (n = !1);
    const r = e.getBoundingClientRect(),
        i = _e(e);
    let l = B(1);
    t && (o ? de(o) && (l = Ce(o)) : l = Ce(e));
    const s = function(e, t, n) {
        return void 0 === t && (t = !1), !(!n || t && n !== ae(e)) && t
    }(i, n, o) ? Se(i) : B(0);
    let a = (r.left + s.x) / l.x,
        c = (r.top + s.y) / l.y,
        u = r.width / l.x,
        d = r.height / l.y;
    if (i) {
        const e = ae(i),
            t = o && de(o) ? ae(o) : o;
        let n = e,
            r = Oe(n);
        for (; r && o && t !== n;) {
            const e = Ce(r),
                t = r.getBoundingClientRect(),
                o = be(r),
                i = t.left + (r.clientLeft + parseFloat(o.paddingLeft)) * e.x,
                l = t.top + (r.clientTop + parseFloat(o.paddingTop)) * e.y;
            a *= e.x, c *= e.y, u *= e.x, d *= e.y, a += i, c += l, n = ae(r), r = Oe(n)
        }
    }
    return oe({
        width: u,
        height: d,
        x: a,
        y: c
    })
}

function Ae(e, t) {
    const n = xe(e).scrollLeft;
    return t ? t.left + n : Me(ce(e)).left + n
}

function Pe(e, t, n) {
    void 0 === n && (n = !1);
    const o = e.getBoundingClientRect();
    return {
        x: o.left + t.scrollLeft - (n ? 0 : Ae(e, o)),
        y: o.top + t.scrollTop
    }
}

function ke(e, t, n) {
    let o;
    if ("viewport" === t) o = function(e, t) {
        const n = ae(e),
            o = ce(e),
            r = n.visualViewport;
        let i = o.clientWidth,
            l = o.clientHeight,
            s = 0,
            a = 0;
        if (r) {
            i = r.width, l = r.height;
            const e = ve();
            (!e || e && "fixed" === t) && (s = r.offsetLeft, a = r.offsetTop)
        }
        return {
            width: i,
            height: l,
            x: s,
            y: a
        }
    }(e, n);
    else if ("document" === t) o = function(e) {
        const t = ce(e),
            n = xe(e),
            o = e.ownerDocument.body,
            r = H(t.scrollWidth, t.clientWidth, o.scrollWidth, o.clientWidth),
            i = H(t.scrollHeight, t.clientHeight, o.scrollHeight, o.clientHeight);
        let l = -n.scrollLeft + Ae(e);
        const s = -n.scrollTop;
        return "rtl" === be(o).direction && (l += H(t.clientWidth, o.clientWidth) - r), {
            width: r,
            height: i,
            x: l,
            y: s
        }
    }(ce(e));
    else if (de(t)) o = function(e, t) {
        const n = Me(e, !0, "fixed" === t),
            o = n.top + e.clientTop,
            r = n.left + e.clientLeft,
            i = fe(e) ? Ce(e) : B(1);
        return {
            width: e.clientWidth * i.x,
            height: e.clientHeight * i.y,
            x: r * i.x,
            y: o * i.y
        }
    }(t, n);
    else {
        const n = Se(e);
        o = {
            x: t.x - n.x,
            y: t.y - n.y,
            width: t.width,
            height: t.height
        }
    }
    return oe(o)
}

function ze(e, t) {
    const n = Ee(e);
    return !(n === t || !de(n) || we(n)) && ("fixed" === be(n).position || ze(n, t))
}

function Ie(e, t, n) {
    const o = fe(t),
        r = ce(t),
        i = "fixed" === n,
        l = Me(e, !0, i, t);
    let s = {
        scrollLeft: 0,
        scrollTop: 0
    };
    const a = B(0);
    if (o || !o && !i)
        if (("body" !== se(t) || pe(r)) && (s = xe(t)), o) {
            const e = Me(t, !0, i, t);
            a.x = e.x + t.clientLeft, a.y = e.y + t.clientTop
        } else r && (a.x = Ae(r));
    const c = !r || o || i ? B(0) : Pe(r, s);
    return {
        x: l.left + s.scrollLeft - a.x - c.x,
        y: l.top + s.scrollTop - a.y - c.y,
        width: l.width,
        height: l.height
    }
}

function Fe(e) {
    return "static" === be(e).position
}

function Ne(e, t) {
    if (!fe(e) || "fixed" === be(e).position) return null;
    if (t) return t(e);
    let n = e.offsetParent;
    return ce(e) === n && (n = n.ownerDocument.body), n
}

function je(e, t) {
    const n = ae(e);
    if (ge(e)) return n;
    if (!fe(e)) {
        let t = Ee(e);
        for (; t && !we(t);) {
            if (de(t) && !Fe(t)) return t;
            t = Ee(t)
        }
        return n
    }
    let o = Ne(e, t);
    for (; o && he(o) && Fe(o);) o = Ne(o, t);
    return o && we(o) && Fe(o) && !ye(o) ? n : o || function(e) {
        let t = Ee(e);
        for (; fe(t) && !we(t);) {
            if (ye(t)) return t;
            if (ge(t)) return null;
            t = Ee(t)
        }
        return null
    }(e) || n
}
const He = {
    convertOffsetParentRelativeRectToViewportRelativeRect: function(e) {
        let {
            elements: t,
            rect: n,
            offsetParent: o,
            strategy: r
        } = e;
        const i = "fixed" === r,
            l = ce(o),
            s = !!t && ge(t.floating);
        if (o === l || s && i) return n;
        let a = {
                scrollLeft: 0,
                scrollTop: 0
            },
            c = B(1);
        const u = B(0),
            d = fe(o);
        if ((d || !d && !i) && (("body" !== se(o) || pe(l)) && (a = xe(o)), fe(o))) {
            const e = Me(o);
            c = Ce(o), u.x = e.x + o.clientLeft, u.y = e.y + o.clientTop
        }
        const f = !l || d || i ? B(0) : Pe(l, a, !0);
        return {
            width: n.width * c.x,
            height: n.height * c.y,
            x: n.x * c.x - a.scrollLeft * c.x + u.x + f.x,
            y: n.y * c.y - a.scrollTop * c.y + u.y + f.y
        }
    },
    getDocumentElement: ce,
    getClippingRect: function(e) {
        let {
            element: t,
            boundary: n,
            rootBoundary: o,
            strategy: r
        } = e;
        const i = [..."clippingAncestors" === n ? ge(t) ? [] : function(e, t) {
                const n = t.get(e);
                if (n) return n;
                let o = Te(e, [], !1).filter((e => de(e) && "body" !== se(e))),
                    r = null;
                const i = "fixed" === be(e).position;
                let l = i ? Ee(e) : e;
                for (; de(l) && !we(l);) {
                    const t = be(l),
                        n = ye(l);
                    n || "fixed" !== t.position || (r = null), (i ? !n && !r : !n && "static" === t.position && r && ["absolute", "fixed"].includes(r.position) || pe(l) && !n && ze(e, l)) ? o = o.filter((e => e !== l)) : r = t, l = Ee(l)
                }
                return t.set(e, o), o
            }(t, this._c) : [].concat(n), o],
            l = i[0],
            s = i.reduce(((e, n) => {
                const o = ke(t, n, r);
                return e.top = H(o.top, e.top), e.right = j(o.right, e.right), e.bottom = j(o.bottom, e.bottom), e.left = H(o.left, e.left), e
            }), ke(t, l, r));
        return {
            width: s.right - s.left,
            height: s.bottom - s.top,
            x: s.left,
            y: s.top
        }
    },
    getOffsetParent: je,
    getElementRects: async function(e) {
        const t = this.getOffsetParent || je,
            n = this.getDimensions,
            o = await n(e.floating);
        return {
            reference: Ie(e.reference, await t(e.floating), e.strategy),
            floating: {
                x: 0,
                y: 0,
                width: o.width,
                height: o.height
            }
        }
    },
    getClientRects: function(e) {
        return Array.from(e.getClientRects())
    },
    getDimensions: function(e) {
        const {
            width: t,
            height: n
        } = Le(e);
        return {
            width: t,
            height: n
        }
    },
    getScale: Ce,
    isElement: de,
    isRTL: function(e) {
        return "rtl" === be(e).direction
    }
};

function Ve(e, t) {
    return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height
}

function We(e, t, n, o) {
    void 0 === o && (o = {});
    const {
        ancestorScroll: r = !0,
        ancestorResize: i = !0,
        elementResize: l = "function" == typeof ResizeObserver,
        layoutShift: s = "function" == typeof IntersectionObserver,
        animationFrame: a = !1
    } = o, c = _e(e), u = r || i ? [...c ? Te(c) : [], ...Te(t)] : [];
    u.forEach((e => {
        r && e.addEventListener("scroll", n, {
            passive: !0
        }), i && e.addEventListener("resize", n)
    }));
    const d = c && s ? function(e, t) {
        let n, o = null;
        const r = ce(e);

        function i() {
            var e;
            clearTimeout(n), null == (e = o) || e.disconnect(), o = null
        }
        return function l(s, a) {
            void 0 === s && (s = !1), void 0 === a && (a = 1), i();
            const c = e.getBoundingClientRect(),
                {
                    left: u,
                    top: d,
                    width: f,
                    height: m
                } = c;
            if (s || t(), !f || !m) return;
            const p = {
                rootMargin: -W(d) + "px " + -W(r.clientWidth - (u + f)) + "px " + -W(r.clientHeight - (d + m)) + "px " + -W(u) + "px",
                threshold: H(0, j(1, a)) || 1
            };
            let h = !0;

            function g(t) {
                const o = t[0].intersectionRatio;
                if (o !== a) {
                    if (!h) return l();
                    o ? l(!1, o) : n = setTimeout((() => {
                        l(!1, 1e-7)
                    }), 1e3)
                }
                1 !== o || Ve(c, e.getBoundingClientRect()) || l(), h = !1
            }
            try {
                o = new IntersectionObserver(g, { ...p,
                    root: r.ownerDocument
                })
            } catch (e) {
                o = new IntersectionObserver(g, p)
            }
            o.observe(e)
        }(!0), i
    }(c, n) : null;
    let f, m = -1,
        p = null;
    l && (p = new ResizeObserver((e => {
        let [o] = e;
        o && o.target === c && p && (p.unobserve(t), cancelAnimationFrame(m), m = requestAnimationFrame((() => {
            var e;
            null == (e = p) || e.observe(t)
        }))), n()
    })), c && !a && p.observe(c), p.observe(t));
    let h = a ? Me(e) : null;
    return a && function t() {
        const o = Me(e);
        h && !Ve(h, o) && n();
        h = o, f = requestAnimationFrame(t)
    }(), n(), () => {
        var e;
        u.forEach((e => {
            r && e.removeEventListener("scroll", n), i && e.removeEventListener("resize", n)
        })), null == d || d(), null == (e = p) || e.disconnect(), p = null, a && cancelAnimationFrame(f)
    }
}
const Be = function(e) {
        return void 0 === e && (e = 0), {
            name: "offset",
            options: e,
            async fn(t) {
                var n, o;
                const {
                    x: r,
                    y: i,
                    placement: l,
                    middlewareData: s
                } = t, a = await async function(e, t) {
                    const {
                        placement: n,
                        platform: o,
                        elements: r
                    } = e, i = await (null == o.isRTL ? void 0 : o.isRTL(r.floating)), l = Y(n), s = Z(n), a = "y" === K(n), c = ["left", "top"].includes(l) ? -1 : 1, u = i && a ? -1 : 1, d = X(t, e);
                    let {
                        mainAxis: f,
                        crossAxis: m,
                        alignmentAxis: p
                    } = "number" == typeof d ? {
                        mainAxis: d,
                        crossAxis: 0,
                        alignmentAxis: null
                    } : {
                        mainAxis: 0,
                        crossAxis: 0,
                        alignmentAxis: null,
                        ...d
                    };
                    return s && "number" == typeof p && (m = "end" === s ? -1 * p : p), a ? {
                        x: m * u,
                        y: f * c
                    } : {
                        x: f * c,
                        y: m * u
                    }
                }(t, e);
                return l === (null == (n = s.offset) ? void 0 : n.placement) && null != (o = s.arrow) && o.alignmentOffset ? {} : {
                    x: r + a.x,
                    y: i + a.y,
                    data: { ...a,
                        placement: l
                    }
                }
            }
        }
    },
    qe = function(e) {
        return void 0 === e && (e = {}), {
            name: "shift",
            options: e,
            async fn(t) {
                const {
                    x: n,
                    y: o,
                    placement: r
                } = t, {
                    mainAxis: i = !0,
                    crossAxis: l = !1,
                    limiter: s = {
                        fn: e => {
                            let {
                                x: t,
                                y: n
                            } = e;
                            return {
                                x: t,
                                y: n
                            }
                        }
                    },
                    ...a
                } = X(e, t), c = {
                    x: n,
                    y: o
                }, u = await ie(t, a), d = K(Y(r)), f = G(d);
                let m = c[f],
                    p = c[d];
                if (i) {
                    const e = "y" === f ? "bottom" : "right";
                    m = U(m + u["y" === f ? "top" : "left"], m, m - u[e])
                }
                if (l) {
                    const e = "y" === d ? "bottom" : "right";
                    p = U(p + u["y" === d ? "top" : "left"], p, p - u[e])
                }
                const h = s.fn({ ...t,
                    [f]: m,
                    [d]: p
                });
                return { ...h,
                    data: {
                        x: h.x - n,
                        y: h.y - o
                    }
                }
            }
        }
    },
    $e = function(e) {
        return void 0 === e && (e = {}), {
            name: "flip",
            options: e,
            async fn(t) {
                var n, o;
                const {
                    placement: r,
                    middlewareData: i,
                    rects: l,
                    initialPlacement: s,
                    platform: a,
                    elements: c
                } = t, {
                    mainAxis: u = !0,
                    crossAxis: d = !0,
                    fallbackPlacements: f,
                    fallbackStrategy: m = "bestFit",
                    fallbackAxisSideDirection: p = "none",
                    flipAlignment: h = !0,
                    ...g
                } = X(e, t);
                if (null != (n = i.arrow) && n.alignmentOffset) return {};
                const y = Y(r),
                    v = K(s),
                    w = Y(s) === s,
                    b = await (null == a.isRTL ? void 0 : a.isRTL(c.floating)),
                    x = f || (w || !h ? [te(s)] : function(e) {
                        const t = te(e);
                        return [ee(e), t, ee(t)]
                    }(s)),
                    E = "none" !== p;
                !f && E && x.push(... function(e, t, n, o) {
                    const r = Z(e);
                    let i = function(e, t, n) {
                        const o = ["left", "right"],
                            r = ["right", "left"],
                            i = ["top", "bottom"],
                            l = ["bottom", "top"];
                        switch (e) {
                            case "top":
                            case "bottom":
                                return n ? t ? r : o : t ? o : r;
                            case "left":
                            case "right":
                                return t ? i : l;
                            default:
                                return []
                        }
                    }(Y(e), "start" === n, o);
                    return r && (i = i.map((e => e + "-" + r)), t && (i = i.concat(i.map(ee)))), i
                }(s, h, p, b));
                const R = [s, ...x],
                    T = await ie(t, g),
                    O = [];
                let L = (null == (o = i.flip) ? void 0 : o.overflows) || [];
                if (u && O.push(T[y]), d) {
                    const e = function(e, t, n) {
                        void 0 === n && (n = !1);
                        const o = Z(e),
                            r = Q(e),
                            i = J(r);
                        let l = "x" === r ? o === (n ? "end" : "start") ? "right" : "left" : "start" === o ? "bottom" : "top";
                        return t.reference[i] > t.floating[i] && (l = te(l)), [l, te(l)]
                    }(r, l, b);
                    O.push(T[e[0]], T[e[1]])
                }
                if (L = [...L, {
                        placement: r,
                        overflows: O
                    }], !O.every((e => e <= 0))) {
                    var _, C;
                    const e = ((null == (_ = i.flip) ? void 0 : _.index) || 0) + 1,
                        t = R[e];
                    if (t) return {
                        data: {
                            index: e,
                            overflows: L
                        },
                        reset: {
                            placement: t
                        }
                    };
                    let n = null == (C = L.filter((e => e.overflows[0] <= 0)).sort(((e, t) => e.overflows[1] - t.overflows[1]))[0]) ? void 0 : C.placement;
                    if (!n) switch (m) {
                        case "bestFit":
                            {
                                var D;
                                const e = null == (D = L.filter((e => {
                                    if (E) {
                                        const t = K(e.placement);
                                        return t === v || "y" === t
                                    }
                                    return !0
                                })).map((e => [e.placement, e.overflows.filter((e => e > 0)).reduce(((e, t) => e + t), 0)])).sort(((e, t) => e[1] - t[1]))[0]) ? void 0 : D[0];e && (n = e);
                                break
                            }
                        case "initialPlacement":
                            n = s
                    }
                    if (r !== n) return {
                        reset: {
                            placement: n
                        }
                    }
                }
                return {}
            }
        }
    },
    Ue = e => ({
        name: "arrow",
        options: e,
        async fn(t) {
            const {
                x: n,
                y: o,
                placement: r,
                rects: i,
                platform: l,
                elements: s,
                middlewareData: a
            } = t, {
                element: c,
                padding: u = 0
            } = X(e, t) || {};
            if (null == c) return {};
            const d = ne(u),
                f = {
                    x: n,
                    y: o
                },
                m = Q(r),
                p = J(m),
                h = await l.getDimensions(c),
                g = "y" === m,
                y = g ? "top" : "left",
                v = g ? "bottom" : "right",
                w = g ? "clientHeight" : "clientWidth",
                b = i.reference[p] + i.reference[m] - f[m] - i.floating[p],
                x = f[m] - i.reference[m],
                E = await (null == l.getOffsetParent ? void 0 : l.getOffsetParent(c));
            let R = E ? E[w] : 0;
            R && await (null == l.isElement ? void 0 : l.isElement(E)) || (R = s.floating[w] || i.floating[p]);
            const T = b / 2 - x / 2,
                O = R / 2 - h[p] / 2 - 1,
                L = j(d[y], O),
                _ = j(d[v], O),
                C = L,
                D = R - h[p] - _,
                S = R / 2 - h[p] / 2 + T,
                M = U(C, S, D),
                A = !a.arrow && null != Z(r) && S !== M && i.reference[p] / 2 - (S < C ? L : _) - h[p] / 2 < 0,
                P = A ? S < C ? S - C : S - D : 0;
            return {
                [m]: f[m] + P,
                data: {
                    [m]: M,
                    centerOffset: S - M - P,
                    ...A && {
                        alignmentOffset: P
                    }
                },
                reset: A
            }
        }
    }),
    Xe = (e, t, n) => {
        const o = new Map,
            r = {
                platform: He,
                ...n
            },
            i = { ...r.platform,
                _c: o
            };
        return (async (e, t, n) => {
            const {
                placement: o = "bottom",
                strategy: r = "absolute",
                middleware: i = [],
                platform: l
            } = n, s = i.filter(Boolean), a = await (null == l.isRTL ? void 0 : l.isRTL(t));
            let c = await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: r
                }),
                {
                    x: u,
                    y: d
                } = re(c, o, a),
                f = o,
                m = {},
                p = 0;
            for (let n = 0; n < s.length; n++) {
                const {
                    name: i,
                    fn: h
                } = s[n], {
                    x: g,
                    y: y,
                    data: v,
                    reset: w
                } = await h({
                    x: u,
                    y: d,
                    initialPlacement: o,
                    placement: f,
                    strategy: r,
                    middlewareData: m,
                    rects: c,
                    platform: l,
                    elements: {
                        reference: e,
                        floating: t
                    }
                });
                u = null != g ? g : u, d = null != y ? y : d, m = { ...m,
                    [i]: { ...m[i],
                        ...v
                    }
                }, w && p <= 50 && (p++, "object" == typeof w && (w.placement && (f = w.placement), w.rects && (c = !0 === w.rects ? await l.getElementRects({
                    reference: e,
                    floating: t,
                    strategy: r
                }) : w.rects), ({
                    x: u,
                    y: d
                } = re(c, f, a))), n = -1)
            }
            return {
                x: u,
                y: d,
                placement: f,
                strategy: r,
                middlewareData: m
            }
        })(e, t, { ...r,
            platform: i
        })
    };

function Ye(t) {
    return (t.ownerDocument.defaultView || e).devicePixelRatio || 1
}

function Ze(e, t) {
    const n = Ye(e);
    return Math.round(t * n) / n
}

function Ge(e) {
    const o = t(e);
    return n((() => {
        o.current = e
    })), o
}
const Je = s(((e, n) => {
        var {
            as: o = "div",
            children: r,
            disabled: i = !1
        } = e, l = a(e, ["as", "children", "disabled"]);
        const s = t(null),
            p = t(null),
            h = t(null);
        c((() => {
            var e;
            i || null === (e = s.current) || void 0 === e || e.focus()
        }), [i]);
        const g = e => {
                const t = s.current;
                if (!t || i) return;
                ((e ? f(t) : m(t)) || t).focus()
            },
            y = i ? -1 : 0,
            v = "absolute -m-px h-px w-px overflow-hidden whitespace-nowrap p-0";
        return u(d, {
            children: [u("div", {
                className: v,
                ref: p,
                onFocus: () => g(!1),
                tabIndex: y
            }), u(o, Object.assign({}, l, {
                ref: e => {
                    s.current = e, "function" == typeof n ? n(e) : n && (n.current = e)
                },
                tabIndex: -1,
                children: r
            })), u("div", {
                className: v,
                ref: h,
                onFocus: () => g(!0),
                tabIndex: y
            })]
        })
    })),
    Ke = ["right", "left", "bottom", "top"],
    Qe = ({
        anchorTo: s,
        children: a,
        headerTitle: c,
        hideHeader: d = !1,
        disableMinWidth: f = !1,
        key: m,
        modalTitle: L = "Sign in with Shop",
        onDismiss: _,
        onModalInViewport: C,
        popupDisabled: D,
        type: S,
        variant: M,
        visible: A
    }) => {
        var P, k, z;
        const {
            dispatch: I,
            modalDismissible: F
        } = p(), {
            translate: N
        } = h(), j = t(null), [H, V] = o(null), W = t(null), B = t(null), q = t(null), [$, U] = o(!1), {
            instanceId: X
        } = g(), Y = t(null), {
            floatingStyles: Z,
            middlewareData: G,
            refs: J,
            update: K
        } = function(e = {}) {
            const {
                placement: s = "bottom",
                strategy: a = "absolute",
                middleware: c = [],
                platform: u,
                elements: {
                    reference: d,
                    floating: f
                } = {},
                transform: m = !0,
                whileElementsMounted: p,
                open: h
            } = e, [g, y] = o({
                x: 0,
                y: 0,
                strategy: a,
                placement: s,
                middlewareData: {},
                isPositioned: !1
            }), [v, w] = o(c);
            r(v, c) || w(c);
            const [b, x] = o(null), [E, R] = o(null), T = i((e => {
                e !== C.current && (C.current = e, x(e))
            }), []), O = i((e => {
                e !== D.current && (D.current = e, R(e))
            }), []), L = d || b, _ = f || E, C = t(null), D = t(null), S = t(g), M = null != p, A = Ge(p), P = Ge(u), k = i((() => {
                if (!C.current || !D.current) return;
                const e = {
                    placement: s,
                    strategy: a,
                    middleware: v
                };
                P.current && (e.platform = P.current), Xe(C.current, D.current, e).then((e => {
                    const t = Object.assign(Object.assign({}, e), {
                        isPositioned: !0
                    });
                    z.current && !r(S.current, t) && (S.current = t, y(t))
                })).catch((e => {
                    console.error("error caught during computePosition", e)
                }))
            }), [v, s, a, P]);
            n((() => {
                !1 === h && S.current.isPositioned && (S.current.isPositioned = !1, y((e => Object.assign(Object.assign({}, e), {
                    isPositioned: !1
                }))))
            }), [h]);
            const z = t(!1);
            n((() => (z.current = !0, () => {
                z.current = !1
            })), []), n((() => {
                if (L && (C.current = L), _ && (D.current = _), L && _) {
                    if (A.current) return A.current(L, _, k);
                    k()
                }
            }), [L, _, k, A, M]);
            const I = l((() => ({
                    reference: C,
                    floating: D,
                    setReference: T,
                    setFloating: O
                })), [T, O]),
                F = l((() => ({
                    reference: L,
                    floating: _
                })), [L, _]),
                N = l((() => {
                    const e = {
                        position: a,
                        left: 0,
                        top: 0
                    };
                    if (!F.floating) return e;
                    const t = Ze(F.floating, g.x),
                        n = Ze(F.floating, g.y);
                    return m ? Object.assign(Object.assign(Object.assign({}, e), {
                        transform: `translate(${t}px, ${n}px)`
                    }), Ye(F.floating) >= 1.5 && {
                        willChange: "transform"
                    }) : {
                        position: a,
                        left: t,
                        top: n
                    }
                }), [a, m, F.floating, g.x, g.y]);
            return l((() => Object.assign(Object.assign({}, g), {
                update: k,
                refs: I,
                elements: F,
                floatingStyles: N
            })), [g, k, I, F, N])
        }({
            middleware: [$e({
                crossAxis: !1,
                fallbackPlacements: Ke.slice(1)
            }), qe({
                padding: 30
            }), Be(30), (Q = {
                element: W,
                padding: 28
            }, {
                name: "arrow",
                options: Q,
                fn(e) {
                    const {
                        element: t,
                        padding: n
                    } = Q;
                    return t && (o = t, {}.hasOwnProperty.call(o, "current")) ? null != t.current ? Ue({
                        element: t.current,
                        padding: n
                    }).fn(e) : {} : t ? Ue({
                        element: t,
                        padding: n
                    }).fn(e) : {};
                    var o
                }
            })],
            placement: Ke[0],
            whileElementsMounted: We
        });
        var Q;
        n((() => {
            if (s) {
                let e;
                e = "string" == typeof s ? y.querySelector(s) : s.current, V(e), J.setReference(e), K()
            }
        }), [s, J, K]), null === Y.current && (Y.current = y.documentElement.style.overflow), !B.current && v() && (B.current = new IntersectionObserver((t => {
            for (const n of t) {
                n.boundingClientRect.top < 0 && e.scrollTo({
                    top: 0,
                    left: 0
                }), n.isIntersecting && (null == C || C())
            }
        }))), !j.current && v() && (j.current = new IntersectionObserver((t => {
            var n;
            for (const o of t) {
                if (o.boundingClientRect.top < 0 && e.scrollTo({
                        top: 0,
                        left: 0
                    }), !o.isIntersecting && o.target.offsetTop) {
                    const t = ((null == H ? void 0 : H.offsetHeight) || 0) + ((null === (n = q.current) || void 0 === n ? void 0 : n.offsetHeight) || 0) / 2 + 30;
                    e.scrollTo({
                        top: o.target.offsetTop - t
                    })
                }
            }
        }))), n((() => () => {
            B.current && B.current.disconnect(), j.current && j.current.disconnect()
        }), []);
        const {
            isDesktop: ee
        } = w(), te = l((() => H && !D && ee ? "dynamic" : "center"), [H, ee, D]);
        n((() => {
            const e = y.documentElement,
                t = null == e ? void 0 : e.style.overflow;
            return () => {
                t && e ? e.style.overflow = t : e.style.removeProperty("overflow")
            }
        }), []);
        const ne = i((e => {
            F && (_(e), y.documentElement.style.overflow = Y.current || "")
        }), [F, _]);
        n((() => {
            function t({
                key: e
            }) {
                "Escape" !== e && "Esc" !== e || ne("keyboard")
            }
            return e.addEventListener("keydown", t), () => {
                e.removeEventListener("keydown", t)
            }
        }), [ne]), n((() => {
            A ? (y.documentElement.style.overflow = "hidden", B.current && q.current && B.current.observe(q.current), j.current && H && j.current.observe(H)) : (B.current && q.current && B.current.unobserve(q.current), j.current && H && j.current.unobserve(H), y.documentElement.style.overflow = Y.current || "")
        }), [H, ne, A]), n((() => {
            var e;
            if (!A) return void U(!1);
            const t = () => {
                U(!0)
            };
            return null === (e = q.current) || void 0 === e || e.addEventListener("transitionend", t, {
                once: !0
            }), () => {
                var e;
                null === (e = q.current) || void 0 === e || e.removeEventListener("transitionend", t)
            }
        }), [A]), n((() => {
            if (A) {
                const e = setTimeout((() => {
                    I({
                        type: "setModalDismissible",
                        payload: !0
                    })
                }), 400);
                return () => {
                    clearTimeout(e)
                }
            }
        }), [I, A]);
        const oe = b("fixed inset-0 z-10 bg-overlay transition-opacity duration-400 ease-cubic-modal motion-reduce_duration-0", A ? "opacity-100" : "opacity-0"),
            re = b("fixed inset-0 z-max overflow-hidden", "center" === te && "flex items-center justify-center", A ? "visible" : "pointer-events-none invisible"),
            ie = b("relative z-50 bg-white transition duration-400 ease-cubic-modal will-change-transform focus_outline-0 motion-reduce_duration-0 sm_absolute sm_inset-x-0 sm_bottom-0 sm_top-auto sm_rounded-b-none", A ? "opacity-100 sm_translate-y-0" : "opacity-0 sm_translate-y-full", "dynamic" === te && A ? "scale-100" : "", "dynamic" !== te || A ? "" : "scale-0 sm_scale-100", !f && ("wide" === S ? "min-w-100" : "min-w-85"), !d && "rounded-lg"),
            le = b("relative overflow-hidden sm_rounded-b-none", !d && "rounded-lg"),
            se = l((() => {
                var e, t, n, o, r, i, l, s;
                if ("center" === te) return null;
                const a = {
                        right: {
                            top: null === (e = G.arrow) || void 0 === e ? void 0 : e.y,
                            left: (null === (t = G.arrow) || void 0 === t ? void 0 : t.x) || "-10px"
                        },
                        left: {
                            top: null === (n = G.arrow) || void 0 === n ? void 0 : n.y,
                            right: (null === (o = G.arrow) || void 0 === o ? void 0 : o.x) || "-10px"
                        },
                        bottom: {
                            top: "-10px",
                            left: (null === (r = G.arrow) || void 0 === r ? void 0 : r.x) || "-10px"
                        },
                        top: {
                            bottom: "-10px",
                            left: (null === (i = G.arrow) || void 0 === i ? void 0 : i.x) || "-10px"
                        }
                    },
                    c = Ke[(null === (s = null === (l = G.flip) || void 0 === l ? void 0 : l.overflows) || void 0 === s ? void 0 : s.length) || 0],
                    d = a[c],
                    f = b("absolute z-30 block size-6 rotate-45 rounded-xs duration-400 ease-cubic-modal sm_hidden", "top" === c ? "bg-grayscale-l4" : "bg-white");
                return u("div", {
                    className: f,
                    "data-testid": "authorize-modal-arrow",
                    ref: W,
                    style: d
                })
            }), [null === (P = G.arrow) || void 0 === P ? void 0 : P.x, null === (k = G.arrow) || void 0 === k ? void 0 : k.y, null === (z = G.flip) || void 0 === z ? void 0 : z.overflows, te]),
            ae = Boolean(c),
            ce = ae ? u(x, {
                className: "size-8 text-purple-primary"
            }) : u(E, {
                className: "h-4-5 text-purple-primary"
            }),
            ue = b("flex w-full items-center justify-between p-4 pb-2", ae && "mb-5 gap-x-4 border-b border-solid border-grayscale-l2l px-5 pb-4"),
            de = "dynamic" === te ? Z : void 0,
            fe = d ? null : u("div", {
                className: ue,
                children: [ce, ae && u("div", {
                    className: "flex-1 font-sans text-body-large",
                    children: c
                }), u("button", {
                    "aria-label": N("button.close", {
                        defaultValue: "Close"
                    }),
                    className: "group relative z-50 flex size-6 cursor-pointer rounded-max",
                    "data-testid": "authorize-modal-close-button",
                    onClick: () => ne("close_button"),
                    type: "button",
                    children: [u(R, {
                        className: "size-6 text-grayscale-l4 transition-colors group-hover_text-grayscale-l2l"
                    }), u("div", {
                        className: "absolute inset-05 -z-10 rounded-max bg-grayscale-primary-light"
                    })]
                })]
            }),
            me = A ? {} : {
                "aria-hidden": !0
            };
        return T(u(O, {
            instanceId: X,
            type: "modal",
            variant: M,
            children: u("div", {
                className: re,
                "data-testid": "authorize-modal-container",
                children: [u("div", Object.assign({}, me, {
                    className: oe,
                    "data-testid": "authorize-modal-overlay",
                    onClick: () => ne("overlay")
                })), u(Je, Object.assign({
                    as: "section",
                    disabled: !$,
                    "aria-modal": "true"
                }, me, {
                    "aria-label": L,
                    className: ie,
                    "data-testid": "authorize-modal",
                    "data-visible": A,
                    part: "modal",
                    ref: e => {
                        q.current = e, H && (J.setFloating(e), K())
                    },
                    role: "dialog",
                    style: de,
                    children: [u("div", {
                        className: le,
                        children: [fe, a]
                    }), se]
                }))]
            })
        }, m), y.body)
    },
    et = () => u(d, {
        children: [u("div", {
            class: "animate-pulse px-4 py-1 pb-6",
            children: [u("div", {
                class: "flex items-center pb-3",
                children: [u("div", {
                    class: "mr-3 size-6 rounded-max bg-grayscale-l2"
                }), u("div", {
                    class: "mr-20 h-3 flex-1 rounded-md bg-grayscale-l2"
                })]
            }), u("div", {
                class: "h-10 rounded-md bg-grayscale-l2"
            })]
        }), u("div", {
            class: "h-10 animate-pulse bg-grayscale-l3"
        })]
    }),
    tt = ({
        children: e
    }) => {
        const {
            loaded: t
        } = p(), n = t ? {} : {
            height: "0"
        };
        return u(d, {
            children: [!t && u(et, {}), u("div", {
                style: n,
                children: e
            })]
        })
    },
    nt = ["captcha_challenge", "retriable_server_error"],
    ot = [/existing customer \d+ on shop \d+ has a conflicting provider subject associated: existing '([^']+)' != incoming '([^']+)'/, /no_prequalification_amount_available/];
const rt = s((({
    activator: e,
    allowAttribute: o,
    anchorTo: r,
    autoOpen: l,
    disableDefaultIframeResizing: s = !1,
    insideModal: a = !0,
    keepModalOpen: c = !1,
    modalHeaderTitle: d,
    modalHeaderVisible: f = !0,
    onComplete: m,
    onCustomFlowSideEffect: h,
    onError: g,
    onLoaded: v,
    onModalVisibleChange: w,
    onResizeIframe: b,
    onPromptChange: x,
    onPromptContinue: E,
    proxy: R,
    scrolling: T,
    src: O,
    storefrontOrigin: j,
    modalType: H,
    variant: V
}, W) => {
    const {
        autoOpened: B,
        dispatch: q,
        loaded: $,
        modalForceHidden: U,
        modalVisible: X,
        sessionDetected: Y
    } = p(), {
        leaveBreadcrumb: Z,
        notify: G
    } = L(), J = _(), {
        clearLoadTimeout: K,
        initLoadTimeout: Q
    } = C(), {
        trackModalStateChange: ee,
        trackPageImpression: te
    } = D(), {
        recordCounter: ne
    } = S(), oe = t(null), re = M(X);
    n((() => {
        $ && (ee({
            currentState: "loaded",
            reason: "event_loaded"
        }), Z("iframe loaded", {}, "state"))
    }), [Z, $, ee]);
    const ie = i((e => {
        q({
            type: "setModalVisible",
            payload: !0
        }), U || ee({
            currentState: "shown",
            reason: e
        })
    }), [q, U, ee]);
    n((() => {
        l && $ && Y && !B && (ie("event_loaded_with_auto_open"), q({
            type: "setAutoOpened",
            payload: !0
        }))
    }), [l, B, q, ie, $, Y]);
    const le = i((({
        dismissMethod: t,
        reason: n
    }) => {
        X && (q({
            type: "setModalVisible",
            payload: !1
        }), (null == e ? void 0 : e.current) && it(e) && e.current.focus(), ee({
            currentState: "hidden",
            dismissMethod: t,
            reason: n
        }))
    }), [e, q, X, ee]);
    n((() => {
        const t = N((function() {
                ie("user_button_clicked")
            }), 150, !0),
            n = e;
        if ((null == n ? void 0 : n.current) && it(n)) return n.current.addEventListener("click", t), () => {
            var e;
            null === (e = n.current) || void 0 === e || e.removeEventListener("click", t)
        }
    }), [e, ie]);
    const se = i((() => {
            k({
                iframe: oe.current,
                src: O
            })
        }), [O]),
        {
            destroy: ae,
            waitForMessage: ce
        } = A({
            includeCore: R,
            onClose: () => le({
                dismissMethod: "auto",
                reason: "event_close_requested"
            }),
            onComplete: e => z(void 0, void 0, void 0, (function*() {
                !c && a && le({
                    dismissMethod: "auto",
                    reason: "event_completed"
                }), yield null == m ? void 0 : m(e)
            })),
            onCustomFlowSideEffect: h,
            onError: e => {
                const {
                    message: t,
                    code: n
                } = e;
                ! function(e, t) {
                    return !(nt.includes(e) || ot.some((e => e.test(t))))
                }(n, t) ? (ne("shop_js_handle_silent_error", {
                    attributes: {
                        errorCode: n
                    }
                }), Z("silent error", {
                    code: n
                }, "state")) : (Z("authorize error", {
                    code: n,
                    message: t
                }, "state"), G(new I(t, "AuthorizeError"))), K(), null == g || g(e)
            },
            onLoaded: e => {
                q({
                    type: "updateState",
                    payload: {
                        loaded: !0,
                        sessionDetected: e.userFound
                    }
                }), null == v || v(e), K()
            },
            onResizeIframe: e => {
                s || oe.current && (oe.current.style.height = `${e.height}px`), null == b || b(e)
            },
            onShopUserMatched: ({
                userCookieExists: e
            }) => {
                J("shopusermatched"), q({
                    type: "setSessionDetected",
                    payload: e
                }), Z("shop user matched", {}, "state")
            },
            onShopUserNotMatched: ({
                apiError: e
            }) => {
                J("shopusernotmatched", e && {
                    apiError: e
                }), q({
                    type: "setSessionDetected",
                    payload: !1
                }), Z("shop user not matched", {}, "state")
            },
            onPromptChange: () => {
                null == x || x()
            },
            onPromptContinue: () => {
                null == E || E()
            },
            source: oe,
            storefrontOrigin: j
        });
    n((() => () => {
        oe.current && ae()
    }), [ae]);
    const ue = i(((e, ...t) => z(void 0, [e, ...t], void 0, (function*(e, {
        afterLoaded: t = !1
    } = {}) {
        var n;
        t && !$ && (yield ce("loaded")), F({
            contentWindow: null === (n = oe.current) || void 0 === n ? void 0 : n.contentWindow,
            event: e
        })
    }))), [$, ce]);
    n((() => {
        var e;
        if (X !== re)
            if (X) {
                try {
                    ue({
                        type: "sheetmodalopened"
                    }, {
                        afterLoaded: !0
                    }), J("modalopened")
                } catch (e) {
                    G(new Error(`Error before calling onModalVisibleChange(true): ${e}`))
                }
                null == w || w(!0)
            } else ue({
                type: "sheetmodalclosed"
            }, {
                afterLoaded: !0
            }), J("modalclosed"), null == w || w(!1), null === (e = y.querySelector("com-1password-notification")) || void 0 === e || e.remove()
    }), [J, X, G, w, ue, re]), P(W, (() => ({
        close: le,
        iframeRef: oe,
        open: ie,
        postMessage: ue,
        reload: se,
        waitForMessage: ce
    })), [le, ie, ue, se, ce]), n((() => {
        Q(), Z("Iframe url updated", {
            src: O
        }, "state")
    }), [Q, Z, O]), n((() => {
        X && te({
            page: "AUTHORIZE_MODAL"
        })
    }), [X, te]), n((() => {
        k({
            iframe: oe.current,
            src: O
        })
    }), [O]);
    const de = u("iframe", {
        allow: o || "publickey-credentials-get *",
        className: "relative z-40 m-auto w-full border-none",
        ref: e => {
            e && (oe.current = e, e.getAttribute("src") || e.setAttribute("src", O))
        },
        tabIndex: 0,
        scrolling: T,
        "data-testid": "authorize-iframe"
    });
    return a ? u(Qe, {
        anchorTo: r,
        headerTitle: d,
        hideHeader: !f,
        onDismiss: e => le({
            dismissMethod: e,
            reason: "user_dismissed"
        }),
        onModalInViewport: () => {
            te({
                page: "AUTHORIZE_MODAL_IN_VIEWPORT",
                allowDuplicates: !0
            }), Z("modal in viewport", {}, "state")
        },
        type: H,
        variant: V,
        visible: X,
        children: u(tt, {
            children: de
        })
    }) : de
}));

function it(e) {
    return Object.prototype.hasOwnProperty.call(e, "current")
}
rt.displayName = "AuthorizeIframe";
export {
    rt as A, Qe as M
};
//# sourceMappingURL=chunk.modal_CSDrTnGs.esm.js.map
const e = "show_sign_in_toast",
    t = "undefined" == typeof document ? {
        activeElement: null,
        addEventListener: () => {},
        appendChild: () => {},
        body: {},
        cookie: "",
        createElement: () => {},
        createTextNode: () => {},
        documentElement: {
            clientHeight: 0,
            clientWidth: 0,
            lang: "",
            style: {
                overflow: "",
                removeProperty: () => {}
            }
        },
        getElementById: () => null,
        head: {
            appendChild: () => {}
        },
        location: void 0,
        querySelector: () => {},
        querySelectorAll: () => [],
        removeEventListener: () => {},
        styleSheets: {}
    } : document,
    n = [];
for (let e = 0; e < 256; ++e) n.push((e + 256).toString(16).slice(1));
let o;
const r = new Uint8Array(16);
var i = {
    randomUUID: "undefined" != typeof crypto && crypto.randomUUID && crypto.randomUUID.bind(crypto)
};

function a(e, t, a) {
    if (i.randomUUID && !t && !e) return i.randomUUID();
    const s = (e = e || {}).random ? ? e.rng ? .() ? ? function() {
        if (!o) {
            if ("undefined" == typeof crypto || !crypto.getRandomValues) throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
            o = crypto.getRandomValues.bind(crypto)
        }
        return o(r)
    }();
    if (s.length < 16) throw new Error("Random bytes length must be >= 16");
    return s[6] = 15 & s[6] | 64, s[8] = 63 & s[8] | 128,
        function(e, t = 0) {
            return (n[e[t + 0]] + n[e[t + 1]] + n[e[t + 2]] + n[e[t + 3]] + "-" + n[e[t + 4]] + n[e[t + 5]] + "-" + n[e[t + 6]] + n[e[t + 7]] + "-" + n[e[t + 8]] + n[e[t + 9]] + "-" + n[e[t + 10]] + n[e[t + 11]] + n[e[t + 12]] + n[e[t + 13]] + n[e[t + 14]] + n[e[t + 15]]).toLowerCase()
        }(s)
}
const s = {
        addEventListener: () => {},
        analytics: {},
        btoa: () => "",
        clearTimeout: () => {},
        CSS: {
            supports: (e, t) => !1
        },
        customElements: {},
        devicePixelRatio: 1,
        getComputedStyle: e => ({}),
        HTMLElement: {},
        innerHeight: 0,
        innerWidth: 0,
        localStorage: {
            getItem() {
                throw new Error("localStorage is not available")
            },
            setItem() {
                throw new Error("localStorage is not available")
            },
            removeItem() {
                throw new Error("localStorage is not available")
            }
        },
        sessionStorage: {
            getItem() {
                throw new Error("sessionStorage is not available")
            },
            setItem() {
                throw new Error("sessionStorage is not available")
            },
            removeItem() {
                throw new Error("sessionStorage is not available")
            }
        },
        location: {
            assign: () => {},
            hostname: "",
            href: "",
            origin: "",
            pathname: "",
            search: ""
        },
        matchMedia: () => ({
            matches: !1
        }),
        open: () => {},
        PublicKeyCredential: {
            isConditionalMediationAvailable: () => Promise.resolve(!1)
        },
        removeEventListener: () => {},
        screen: {
            availWidth: 0,
            height: 0,
            orientation: {
                type: ""
            },
            width: 0
        },
        screenLeft: 0,
        screenTop: 0,
        screenX: 0,
        screenY: 0,
        scrollTo: () => {},
        setTimeout: () => 0,
        Shopify: {},
        ShopifyAnalytics: {},
        top: {
            addEventListener: () => {},
            removeEventListener: () => {}
        },
        trekkie: {},
        URL: URL,
        visualViewport: {}
    },
    c = "undefined" == typeof window ? s : window;

function l(e) {
    const t = e ? "sessionStorage" : "localStorage";
    try {
        const e = c[t],
            n = "__storage_test__";
        return e.setItem(n, n), e.removeItem(n), !0
    } catch (e) {
        return !1
    }
}

function u(e, t, {
    session: n
} = {}) {
    if (!l(n)) return !1;
    return c[n ? "sessionStorage" : "localStorage"].setItem(e, t), !0
}

function d(e, {
    session: t
} = {}) {
    if (!l(t)) return null;
    return c[t ? "sessionStorage" : "localStorage"].getItem(e)
}
const p = "signInWithShop";

function h(e) {
    try {
        return JSON.parse(d(`${p}:${e}`, {
            session: !0
        }))
    } catch (e) {
        return null
    }
}

function f(e) {
    return Object.assign(Object.assign({}, e), {
        id: a()
    })
}

function m(e, t) {
    let n = t;
    t && (n = f(t)), u(`${p}:${e}`, JSON.stringify(n), {
        session: !0
    })
}

function _(e) {
    var t, n, o;
    null === (o = null === (n = null === (t = null == c ? void 0 : c.Shopify) || void 0 === t ? void 0 : t.SignInWithShop) || void 0 === n ? void 0 : n.renderToast) || void 0 === o || o.call(n, f(e))
}

function v(e, t) {
    var n = {};
    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
    if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var r = 0;
        for (o = Object.getOwnPropertySymbols(e); r < o.length; r++) t.indexOf(o[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]])
    }
    return n
}

function g(e, t, n, o) {
    return new(n || (n = Promise))((function(r, i) {
        function a(e) {
            try {
                c(o.next(e))
            } catch (e) {
                i(e)
            }
        }

        function s(e) {
            try {
                c(o.throw(e))
            } catch (e) {
                i(e)
            }
        }

        function c(e) {
            var t;
            e.done ? r(e.value) : (t = e.value, t instanceof n ? t : new n((function(e) {
                e(t)
            }))).then(a, s)
        }
        c((o = o.apply(e, t || [])).next())
    }))
}

function y(e, t, n, o) {
    if ("a" === n && !o) throw new TypeError("Private accessor was defined without a getter");
    if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return "m" === n ? o : "a" === n ? o.call(e) : o ? o.value : t.get(e)
}

function b(e, t, n, o, r) {
    if ("m" === o) throw new TypeError("Private method is not writable");
    if ("a" === o && !r) throw new TypeError("Private accessor was defined without a setter");
    if ("function" == typeof t ? e !== t || !r : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return "a" === o ? r.call(e, n) : r ? r.value = n : t.set(e, n), n
}
"function" == typeof SuppressedError && SuppressedError;
var w, x, k, E, S, C, O, P, M, I, T, j = {},
    A = [],
    N = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
    L = Array.isArray;

function D(e, t) {
    for (var n in t) e[n] = t[n];
    return e
}

function U(e) {
    e && e.parentNode && e.parentNode.removeChild(e)
}

function R(e, t, n) {
    var o, r, i, a = {};
    for (i in t) "key" == i ? o = t[i] : "ref" == i ? r = t[i] : a[i] = t[i];
    if (arguments.length > 2 && (a.children = arguments.length > 3 ? w.call(arguments, 2) : n), "function" == typeof e && null != e.defaultProps)
        for (i in e.defaultProps) void 0 === a[i] && (a[i] = e.defaultProps[i]);
    return z(e, a, o, r, null)
}

function z(e, t, n, o, r) {
    var i = {
        type: e,
        props: t,
        key: n,
        ref: o,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        constructor: void 0,
        __v: null == r ? ++k : r,
        __i: -1,
        __u: 0
    };
    return null == r && null != x.vnode && x.vnode(i), i
}

function F(e) {
    return e.children
}

function $(e, t) {
    this.props = e, this.context = t
}

function V(e, t) {
    if (null == t) return e.__ ? V(e.__, e.__i + 1) : null;
    for (var n; t < e.__k.length; t++)
        if (null != (n = e.__k[t]) && null != n.__e) return n.__e;
    return "function" == typeof e.type ? V(e) : null
}

function H(e) {
    var t, n;
    if (null != (e = e.__) && null != e.__c) {
        for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
            if (null != (n = e.__k[t]) && null != n.__e) {
                e.__e = e.__c.base = n.__e;
                break
            }
        return H(e)
    }
}

function B(e) {
    (!e.__d && (e.__d = !0) && E.push(e) && !W.__r++ || S !== x.debounceRendering) && ((S = x.debounceRendering) || C)(W)
}

function W() {
    var e, t, n, o, r, i, a, s;
    for (E.sort(O); e = E.shift();) e.__d && (t = E.length, o = void 0, i = (r = (n = e).__v).__e, a = [], s = [], n.__P && ((o = D({}, r)).__v = r.__v + 1, x.vnode && x.vnode(o), Q(n.__P, o, r, n.__n, n.__P.namespaceURI, 32 & r.__u ? [i] : null, a, null == i ? V(r) : i, !!(32 & r.__u), s), o.__v = r.__v, o.__.__k[o.__i] = o, ee(a, o, s), o.__e != i && H(o)), E.length > t && E.sort(O));
    W.__r = 0
}

function q(e, t, n, o, r, i, a, s, c, l, u) {
    var d, p, h, f, m, _ = o && o.__k || A,
        v = t.length;
    for (n.__d = c, function(e, t, n) {
            var o, r, i, a, s, c = t.length,
                l = n.length,
                u = l,
                d = 0;
            for (e.__k = [], o = 0; o < c; o++) null != (r = t[o]) && "boolean" != typeof r && "function" != typeof r ? (a = o + d, (r = e.__k[o] = "string" == typeof r || "number" == typeof r || "bigint" == typeof r || r.constructor == String ? z(null, r, null, null, null) : L(r) ? z(F, {
                children: r
            }, null, null, null) : void 0 === r.constructor && r.__b > 0 ? z(r.type, r.props, r.key, r.ref ? r.ref : null, r.__v) : r).__ = e, r.__b = e.__b + 1, i = null, -1 !== (s = r.__i = K(r, n, a, u)) && (u--, (i = n[s]) && (i.__u |= 131072)), null == i || null === i.__v ? (-1 == s && d--, "function" != typeof r.type && (r.__u |= 65536)) : s !== a && (s == a - 1 ? d-- : s == a + 1 ? d++ : (s > a ? d-- : d++, r.__u |= 65536))) : r = e.__k[o] = null;
            if (u)
                for (o = 0; o < l; o++) null != (i = n[o]) && !(131072 & i.__u) && (i.__e == e.__d && (e.__d = V(i)), oe(i, i))
        }(n, t, _), c = n.__d, d = 0; d < v; d++) null != (h = n.__k[d]) && (p = -1 === h.__i ? j : _[h.__i] || j, h.__i = d, Q(e, h, p, r, i, a, s, c, l, u), f = h.__e, h.ref && p.ref != h.ref && (p.ref && ne(p.ref, null, h), u.push(h.ref, h.__c || f, h)), null == m && null != f && (m = f), 65536 & h.__u || p.__k === h.__k ? c = X(h, c, e) : "function" == typeof h.type && void 0 !== h.__d ? c = h.__d : f && (c = f.nextSibling), h.__d = void 0, h.__u &= -196609);
    n.__d = c, n.__e = m
}

function X(e, t, n) {
    var o, r;
    if ("function" == typeof e.type) {
        for (o = e.__k, r = 0; o && r < o.length; r++) o[r] && (o[r].__ = e, t = X(o[r], t, n));
        return t
    }
    e.__e != t && (t && e.type && !n.contains(t) && (t = V(e)), n.insertBefore(e.__e, t || null), t = e.__e);
    do {
        t = t && t.nextSibling
    } while (null != t && 8 === t.nodeType);
    return t
}

function Y(e, t) {
    return t = t || [], null == e || "boolean" == typeof e || (L(e) ? e.some((function(e) {
        Y(e, t)
    })) : t.push(e)), t
}

function K(e, t, n, o) {
    var r = e.key,
        i = e.type,
        a = n - 1,
        s = n + 1,
        c = t[n];
    if (null === c || c && r == c.key && i === c.type && !(131072 & c.__u)) return n;
    if (o > (null == c || 131072 & c.__u ? 0 : 1))
        for (; a >= 0 || s < t.length;) {
            if (a >= 0) {
                if ((c = t[a]) && !(131072 & c.__u) && r == c.key && i === c.type) return a;
                a--
            }
            if (s < t.length) {
                if ((c = t[s]) && !(131072 & c.__u) && r == c.key && i === c.type) return s;
                s++
            }
        }
    return -1
}

function J(e, t, n) {
    "-" === t[0] ? e.setProperty(t, null == n ? "" : n) : e[t] = null == n ? "" : "number" != typeof n || N.test(t) ? n : n + "px"
}

function Z(e, t, n, o, r) {
    var i;
    e: if ("style" === t)
        if ("string" == typeof n) e.style.cssText = n;
        else {
            if ("string" == typeof o && (e.style.cssText = o = ""), o)
                for (t in o) n && t in n || J(e.style, t, "");
            if (n)
                for (t in n) o && n[t] === o[t] || J(e.style, t, n[t])
        }
    else if ("o" === t[0] && "n" === t[1]) i = t !== (t = t.replace(/(PointerCapture)$|Capture$/i, "$1")), t = t.toLowerCase() in e || "onFocusOut" === t || "onFocusIn" === t ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + i] = n, n ? o ? n.u = o.u : (n.u = P, e.addEventListener(t, i ? I : M, i)) : e.removeEventListener(t, i ? I : M, i);
    else {
        if ("http://www.w3.org/2000/svg" == r) t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if ("width" != t && "height" != t && "href" != t && "list" != t && "form" != t && "tabIndex" != t && "download" != t && "rowSpan" != t && "colSpan" != t && "role" != t && "popover" != t && t in e) try {
            e[t] = null == n ? "" : n;
            break e
        } catch (e) {}
        "function" == typeof n || (null == n || !1 === n && "-" !== t[4] ? e.removeAttribute(t) : e.setAttribute(t, "popover" == t && 1 == n ? "" : n))
    }
}

function G(e) {
    return function(t) {
        if (this.l) {
            var n = this.l[t.type + e];
            if (null == t.t) t.t = P++;
            else if (t.t < n.u) return;
            return n(x.event ? x.event(t) : t)
        }
    }
}

function Q(e, t, n, o, r, i, a, s, c, l) {
    var u, d, p, h, f, m, _, v, g, y, b, w, k, E, S, C, O = t.type;
    if (void 0 !== t.constructor) return null;
    128 & n.__u && (c = !!(32 & n.__u), i = [s = t.__e = n.__e]), (u = x.__b) && u(t);
    e: if ("function" == typeof O) try {
        if (v = t.props, g = "prototype" in O && O.prototype.render, y = (u = O.contextType) && o[u.__c], b = u ? y ? y.props.value : u.__ : o, n.__c ? _ = (d = t.__c = n.__c).__ = d.__E : (g ? t.__c = d = new O(v, b) : (t.__c = d = new $(v, b), d.constructor = O, d.render = re), y && y.sub(d), d.props = v, d.state || (d.state = {}), d.context = b, d.__n = o, p = d.__d = !0, d.__h = [], d._sb = []), g && null == d.__s && (d.__s = d.state), g && null != O.getDerivedStateFromProps && (d.__s == d.state && (d.__s = D({}, d.__s)), D(d.__s, O.getDerivedStateFromProps(v, d.__s))), h = d.props, f = d.state, d.__v = t, p) g && null == O.getDerivedStateFromProps && null != d.componentWillMount && d.componentWillMount(), g && null != d.componentDidMount && d.__h.push(d.componentDidMount);
        else {
            if (g && null == O.getDerivedStateFromProps && v !== h && null != d.componentWillReceiveProps && d.componentWillReceiveProps(v, b), !d.__e && (null != d.shouldComponentUpdate && !1 === d.shouldComponentUpdate(v, d.__s, b) || t.__v === n.__v)) {
                for (t.__v !== n.__v && (d.props = v, d.state = d.__s, d.__d = !1), t.__e = n.__e, t.__k = n.__k, t.__k.some((function(e) {
                        e && (e.__ = t)
                    })), w = 0; w < d._sb.length; w++) d.__h.push(d._sb[w]);
                d._sb = [], d.__h.length && a.push(d);
                break e
            }
            null != d.componentWillUpdate && d.componentWillUpdate(v, d.__s, b), g && null != d.componentDidUpdate && d.__h.push((function() {
                d.componentDidUpdate(h, f, m)
            }))
        }
        if (d.context = b, d.props = v, d.__P = e, d.__e = !1, k = x.__r, E = 0, g) {
            for (d.state = d.__s, d.__d = !1, k && k(t), u = d.render(d.props, d.state, d.context), S = 0; S < d._sb.length; S++) d.__h.push(d._sb[S]);
            d._sb = []
        } else
            do {
                d.__d = !1, k && k(t), u = d.render(d.props, d.state, d.context), d.state = d.__s
            } while (d.__d && ++E < 25);
        d.state = d.__s, null != d.getChildContext && (o = D(D({}, o), d.getChildContext())), g && !p && null != d.getSnapshotBeforeUpdate && (m = d.getSnapshotBeforeUpdate(h, f)), q(e, L(C = null != u && u.type === F && null == u.key ? u.props.children : u) ? C : [C], t, n, o, r, i, a, s, c, l), d.base = t.__e, t.__u &= -161, d.__h.length && a.push(d), _ && (d.__E = d.__ = null)
    } catch (e) {
        if (t.__v = null, c || null != i) {
            for (t.__u |= c ? 160 : 128; s && 8 === s.nodeType && s.nextSibling;) s = s.nextSibling;
            i[i.indexOf(s)] = null, t.__e = s
        } else t.__e = n.__e, t.__k = n.__k;
        x.__e(e, t, n)
    } else null == i && t.__v === n.__v ? (t.__k = n.__k, t.__e = n.__e) : t.__e = te(n.__e, t, n, o, r, i, a, c, l);
    (u = x.diffed) && u(t)
}

function ee(e, t, n) {
    t.__d = void 0;
    for (var o = 0; o < n.length; o++) ne(n[o], n[++o], n[++o]);
    x.__c && x.__c(t, e), e.some((function(t) {
        try {
            e = t.__h, t.__h = [], e.some((function(e) {
                e.call(t)
            }))
        } catch (e) {
            x.__e(e, t.__v)
        }
    }))
}

function te(e, t, n, o, r, i, a, s, c) {
    var l, u, d, p, h, f, m, _ = n.props,
        v = t.props,
        g = t.type;
    if ("svg" === g ? r = "http://www.w3.org/2000/svg" : "math" === g ? r = "http://www.w3.org/1998/Math/MathML" : r || (r = "http://www.w3.org/1999/xhtml"), null != i)
        for (l = 0; l < i.length; l++)
            if ((h = i[l]) && "setAttribute" in h == !!g && (g ? h.localName === g : 3 === h.nodeType)) {
                e = h, i[l] = null;
                break
            }
    if (null == e) {
        if (null === g) return document.createTextNode(v);
        e = document.createElementNS(r, g, v.is && v), s && (x.__m && x.__m(t, i), s = !1), i = null
    }
    if (null === g) _ === v || s && e.data === v || (e.data = v);
    else {
        if (i = i && w.call(e.childNodes), _ = n.props || j, !s && null != i)
            for (_ = {}, l = 0; l < e.attributes.length; l++) _[(h = e.attributes[l]).name] = h.value;
        for (l in _)
            if (h = _[l], "children" == l);
            else if ("dangerouslySetInnerHTML" == l) d = h;
        else if (!(l in v)) {
            if ("value" == l && "defaultValue" in v || "checked" == l && "defaultChecked" in v) continue;
            Z(e, l, null, h, r)
        }
        for (l in v) h = v[l], "children" == l ? p = h : "dangerouslySetInnerHTML" == l ? u = h : "value" == l ? f = h : "checked" == l ? m = h : s && "function" != typeof h || _[l] === h || Z(e, l, h, _[l], r);
        if (u) s || d && (u.__html === d.__html || u.__html === e.innerHTML) || (e.innerHTML = u.__html), t.__k = [];
        else if (d && (e.innerHTML = ""), q(e, L(p) ? p : [p], t, n, o, "foreignObject" === g ? "http://www.w3.org/1999/xhtml" : r, i, a, i ? i[0] : n.__k && V(n, 0), s, c), null != i)
            for (l = i.length; l--;) U(i[l]);
        s || (l = "value", "progress" === g && null == f ? e.removeAttribute("value") : void 0 !== f && (f !== e[l] || "progress" === g && !f || "option" === g && f !== _[l]) && Z(e, l, f, _[l], r), l = "checked", void 0 !== m && m !== e[l] && Z(e, l, m, _[l], r))
    }
    return e
}

function ne(e, t, n) {
    try {
        if ("function" == typeof e) {
            var o = "function" == typeof e.__u;
            o && e.__u(), o && null == t || (e.__u = e(t))
        } else e.current = t
    } catch (e) {
        x.__e(e, n)
    }
}

function oe(e, t, n) {
    var o, r;
    if (x.unmount && x.unmount(e), (o = e.ref) && (o.current && o.current !== e.__e || ne(o, null, t)), null != (o = e.__c)) {
        if (o.componentWillUnmount) try {
            o.componentWillUnmount()
        } catch (e) {
            x.__e(e, t)
        }
        o.base = o.__P = null
    }
    if (o = e.__k)
        for (r = 0; r < o.length; r++) o[r] && oe(o[r], t, n || "function" != typeof e.type);
    n || U(e.__e), e.__c = e.__ = e.__e = e.__d = void 0
}

function re(e, t, n) {
    return this.constructor(e, n)
}

function ie(e, t, n) {
    var o, r, i, a;
    x.__ && x.__(e, t), r = (o = "function" == typeof n) ? null : t.__k, i = [], a = [], Q(t, e = (!o && n || t).__k = R(F, null, [e]), r || j, j, t.namespaceURI, !o && n ? [n] : r ? null : t.firstChild ? w.call(t.childNodes) : null, i, !o && n ? n : r ? r.__e : t.firstChild, o, a), ee(i, e, a)
}

function ae(e, t, n) {
    var o, r, i, a, s = D({}, e.props);
    for (i in e.type && e.type.defaultProps && (a = e.type.defaultProps), t) "key" == i ? o = t[i] : "ref" == i ? r = t[i] : s[i] = void 0 === t[i] && void 0 !== a ? a[i] : t[i];
    return arguments.length > 2 && (s.children = arguments.length > 3 ? w.call(arguments, 2) : n), z(e.type, s, o || e.key, r || e.ref, null)
}

function se(e, t) {
    var n = {
        __c: t = "__cC" + T++,
        __: e,
        Consumer: function(e, t) {
            return e.children(t)
        },
        Provider: function(e) {
            var n, o;
            return this.getChildContext || (n = new Set, (o = {})[t] = this, this.getChildContext = function() {
                return o
            }, this.componentWillUnmount = function() {
                n = null
            }, this.shouldComponentUpdate = function(e) {
                this.props.value !== e.value && n.forEach((function(e) {
                    e.__e = !0, B(e)
                }))
            }, this.sub = function(e) {
                n.add(e);
                var t = e.componentWillUnmount;
                e.componentWillUnmount = function() {
                    n && n.delete(e), t && t.call(e)
                }
            }), e.children
        }
    };
    return n.Provider.__ = n.Consumer.contextType = n
}
w = A.slice, x = {
    __e: function(e, t, n, o) {
        for (var r, i, a; t = t.__;)
            if ((r = t.__c) && !r.__) try {
                if ((i = r.constructor) && null != i.getDerivedStateFromError && (r.setState(i.getDerivedStateFromError(e)), a = r.__d), null != r.componentDidCatch && (r.componentDidCatch(e, o || {}), a = r.__d), a) return r.__E = r
            } catch (t) {
                e = t
            }
        throw e
    }
}, k = 0, $.prototype.setState = function(e, t) {
    var n;
    n = null != this.__s && this.__s !== this.state ? this.__s : this.__s = D({}, this.state), "function" == typeof e && (e = e(D({}, n), this.props)), e && D(n, e), null != e && this.__v && (t && this._sb.push(t), B(this))
}, $.prototype.forceUpdate = function(e) {
    this.__v && (this.__e = !0, e && this.__h.push(e), B(this))
}, $.prototype.render = F, E = [], C = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, O = function(e, t) {
    return e.__v.__b - t.__v.__b
}, W.__r = 0, P = 0, M = G(!1), I = G(!0), T = 0;
var ce = 0;

function le(e, t, n, o, r, i) {
    t || (t = {});
    var a, s, c = t;
    "ref" in t && (a = t.ref, delete t.ref);
    var l = {
        type: e,
        props: c,
        key: n,
        ref: a,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        constructor: void 0,
        __v: --ce,
        __i: -1,
        __u: 0,
        __source: r,
        __self: i
    };
    if ("function" == typeof e && (a = e.defaultProps))
        for (s in a) void 0 === c[s] && (c[s] = a[s]);
    return x.vnode && x.vnode(l), l
}
var ue, de, pe, he, fe = 0,
    me = [],
    _e = x,
    ve = _e.__b,
    ge = _e.__r,
    ye = _e.diffed,
    be = _e.__c,
    we = _e.unmount,
    xe = _e.__;

function ke(e, t) {
    _e.__h && _e.__h(de, e, fe || t), fe = 0;
    var n = de.__H || (de.__H = {
        __: [],
        __h: []
    });
    return e >= n.__.length && n.__.push({}), n.__[e]
}

function Ee(e) {
    return fe = 1, Se(ze, e)
}

function Se(e, t, n) {
    var o = ke(ue++, 2);
    if (o.t = e, !o.__c && (o.__ = [n ? n(t) : ze(void 0, t), function(e) {
            var t = o.__N ? o.__N[0] : o.__[0],
                n = o.t(t, e);
            t !== n && (o.__N = [n, o.__[1]], o.__c.setState({}))
        }], o.__c = de, !de.u)) {
        var r = function(e, t, n) {
            if (!o.__c.__H) return !0;
            var r = o.__c.__H.__.filter((function(e) {
                return !!e.__c
            }));
            if (r.every((function(e) {
                    return !e.__N
                }))) return !i || i.call(this, e, t, n);
            var a = !1;
            return r.forEach((function(e) {
                if (e.__N) {
                    var t = e.__[0];
                    e.__ = e.__N, e.__N = void 0, t !== e.__[0] && (a = !0)
                }
            })), !(!a && o.__c.props === e) && (!i || i.call(this, e, t, n))
        };
        de.u = !0;
        var i = de.shouldComponentUpdate,
            a = de.componentWillUpdate;
        de.componentWillUpdate = function(e, t, n) {
            if (this.__e) {
                var o = i;
                i = void 0, r(e, t, n), i = o
            }
            a && a.call(this, e, t, n)
        }, de.shouldComponentUpdate = r
    }
    return o.__N || o.__
}

function Ce(e, t) {
    var n = ke(ue++, 3);
    !_e.__s && Re(n.__H, t) && (n.__ = e, n.i = t, de.__H.__h.push(n))
}

function Oe(e, t) {
    var n = ke(ue++, 4);
    !_e.__s && Re(n.__H, t) && (n.__ = e, n.i = t, de.__h.push(n))
}

function Pe(e) {
    return fe = 5, Ie((function() {
        return {
            current: e
        }
    }), [])
}

function Me(e, t, n) {
    fe = 6, Oe((function() {
        return "function" == typeof e ? (e(t()), function() {
            return e(null)
        }) : e ? (e.current = t(), function() {
            return e.current = null
        }) : void 0
    }), null == n ? n : n.concat(e))
}

function Ie(e, t) {
    var n = ke(ue++, 7);
    return Re(n.__H, t) && (n.__ = e(), n.__H = t, n.__h = e), n.__
}

function Te(e, t) {
    return fe = 8, Ie((function() {
        return e
    }), t)
}

function je(e) {
    var t = de.context[e.__c],
        n = ke(ue++, 9);
    return n.c = e, t ? (null == n.__ && (n.__ = !0, t.sub(de)), t.props.value) : e.__
}

function Ae() {
    for (var e; e = me.shift();)
        if (e.__P && e.__H) try {
            e.__H.__h.forEach(De), e.__H.__h.forEach(Ue), e.__H.__h = []
        } catch (t) {
            e.__H.__h = [], _e.__e(t, e.__v)
        }
}
_e.__b = function(e) {
    de = null, ve && ve(e)
}, _e.__ = function(e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m), xe && xe(e, t)
}, _e.__r = function(e) {
    ge && ge(e), ue = 0;
    var t = (de = e.__c).__H;
    t && (pe === de ? (t.__h = [], de.__h = [], t.__.forEach((function(e) {
        e.__N && (e.__ = e.__N), e.i = e.__N = void 0
    }))) : (t.__h.forEach(De), t.__h.forEach(Ue), t.__h = [], ue = 0)), pe = de
}, _e.diffed = function(e) {
    ye && ye(e);
    var t = e.__c;
    t && t.__H && (t.__H.__h.length && (1 !== me.push(t) && he === _e.requestAnimationFrame || ((he = _e.requestAnimationFrame) || Le)(Ae)), t.__H.__.forEach((function(e) {
        e.i && (e.__H = e.i), e.i = void 0
    }))), pe = de = null
}, _e.__c = function(e, t) {
    t.some((function(e) {
        try {
            e.__h.forEach(De), e.__h = e.__h.filter((function(e) {
                return !e.__ || Ue(e)
            }))
        } catch (n) {
            t.some((function(e) {
                e.__h && (e.__h = [])
            })), t = [], _e.__e(n, e.__v)
        }
    })), be && be(e, t)
}, _e.unmount = function(e) {
    we && we(e);
    var t, n = e.__c;
    n && n.__H && (n.__H.__.forEach((function(e) {
        try {
            De(e)
        } catch (e) {
            t = e
        }
    })), n.__H = void 0, t && _e.__e(t, n.__v))
};
var Ne = "function" == typeof requestAnimationFrame;

function Le(e) {
    var t, n = function() {
            clearTimeout(o), Ne && cancelAnimationFrame(t), setTimeout(e)
        },
        o = setTimeout(n, 100);
    Ne && (t = requestAnimationFrame(n))
}

function De(e) {
    var t = de,
        n = e.__c;
    "function" == typeof n && (e.__c = void 0, n()), de = t
}

function Ue(e) {
    var t = de;
    e.__c = e.__(), de = t
}

function Re(e, t) {
    return !e || e.length !== t.length || t.some((function(t, n) {
        return t !== e[n]
    }))
}

function ze(e, t) {
    return "function" == typeof t ? t(e) : t
}

function Fe(e, t) {
    for (var n in e)
        if ("__source" !== n && !(n in t)) return !0;
    for (var o in t)
        if ("__source" !== o && e[o] !== t[o]) return !0;
    return !1
}

function $e(e, t) {
    this.props = e, this.context = t
}($e.prototype = new $).isPureReactComponent = !0, $e.prototype.shouldComponentUpdate = function(e, t) {
    return Fe(this.props, e) || Fe(this.state, t)
};
var Ve = x.__b;
x.__b = function(e) {
    e.type && e.type.__f && e.ref && (e.props.ref = e.ref, e.ref = null), Ve && Ve(e)
};
var He = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.forward_ref") || 3911;

function Be(e) {
    function t(t) {
        if (!("ref" in t)) return e(t, null);
        var n = t.ref;
        delete t.ref;
        var o = e(t, n);
        return t.ref = n, o
    }
    return t.$$typeof = He, t.render = t, t.prototype.isReactComponent = t.__f = !0, t.displayName = "ForwardRef(" + (e.displayName || e.name) + ")", t
}
var We = x.__e;
x.__e = function(e, t, n, o) {
    if (e.then)
        for (var r, i = t; i = i.__;)
            if ((r = i.__c) && r.__c) return null == t.__e && (t.__e = n.__e, t.__k = n.__k), r.__c(e, t);
    We(e, t, n, o)
};
var qe = x.unmount;

function Xe(e, t, n) {
    return e && (e.__c && e.__c.__H && (e.__c.__H.__.forEach((function(e) {
        "function" == typeof e.__c && e.__c()
    })), e.__c.__H = null), null != (e = function(e, t) {
        for (var n in t) e[n] = t[n];
        return e
    }({}, e)).__c && (e.__c.__P === n && (e.__c.__P = t), e.__c = null), e.__k = e.__k && e.__k.map((function(e) {
        return Xe(e, t, n)
    }))), e
}

function Ye(e, t, n) {
    return e && n && (e.__v = null, e.__k = e.__k && e.__k.map((function(e) {
        return Ye(e, t, n)
    })), e.__c && e.__c.__P === t && (e.__e && n.appendChild(e.__e), e.__c.__e = !0, e.__c.__P = n)), e
}

function Ke() {
    this.__u = 0, this.t = null, this.__b = null
}

function Je(e) {
    var t = e.__.__c;
    return t && t.__a && t.__a(e)
}

function Ze() {
    this.u = null, this.o = null
}
x.unmount = function(e) {
    var t = e.__c;
    t && t.__R && t.__R(), t && 32 & e.__u && (e.type = null), qe && qe(e)
}, (Ke.prototype = new $).__c = function(e, t) {
    var n = t.__c,
        o = this;
    null == o.t && (o.t = []), o.t.push(n);
    var r = Je(o.__v),
        i = !1,
        a = function() {
            i || (i = !0, n.__R = null, r ? r(s) : s())
        };
    n.__R = a;
    var s = function() {
        if (!--o.__u) {
            if (o.state.__a) {
                var e = o.state.__a;
                o.__v.__k[0] = Ye(e, e.__c.__P, e.__c.__O)
            }
            var t;
            for (o.setState({
                    __a: o.__b = null
                }); t = o.t.pop();) t.forceUpdate()
        }
    };
    o.__u++ || 32 & t.__u || o.setState({
        __a: o.__b = o.__v.__k[0]
    }), e.then(a, a)
}, Ke.prototype.componentWillUnmount = function() {
    this.t = []
}, Ke.prototype.render = function(e, t) {
    if (this.__b) {
        if (this.__v.__k) {
            var n = document.createElement("div"),
                o = this.__v.__k[0].__c;
            this.__v.__k[0] = Xe(this.__b, n, o.__O = o.__P)
        }
        this.__b = null
    }
    var r = t.__a && R(F, null, e.fallback);
    return r && (r.__u &= -33), [R(F, null, t.__a ? null : e.children), r]
};
var Ge = function(e, t, n) {
    if (++n[1] === n[0] && e.o.delete(t), e.props.revealOrder && ("t" !== e.props.revealOrder[0] || !e.o.size))
        for (n = e.u; n;) {
            for (; n.length > 3;) n.pop()();
            if (n[1] < n[0]) break;
            e.u = n = n[2]
        }
};

function Qe(e) {
    return this.getChildContext = function() {
        return e.context
    }, e.children
}

function et(e) {
    var t = this,
        n = e.i;
    t.componentWillUnmount = function() {
        ie(null, t.l), t.l = null, t.i = null
    }, t.i && t.i !== n && t.componentWillUnmount(), t.l || (t.i = n, t.l = {
        nodeType: 1,
        parentNode: n,
        childNodes: [],
        contains: function() {
            return !0
        },
        appendChild: function(e) {
            this.childNodes.push(e), t.i.appendChild(e)
        },
        insertBefore: function(e, n) {
            this.childNodes.push(e), t.i.appendChild(e)
        },
        removeChild: function(e) {
            this.childNodes.splice(this.childNodes.indexOf(e) >>> 1, 1), t.i.removeChild(e)
        }
    }), ie(R(Qe, {
        context: t.context
    }, e.__v), t.l)
}

function tt(e, t) {
    var n = R(et, {
        __v: e,
        i: t
    });
    return n.containerInfo = t, n
}(Ze.prototype = new $).__a = function(e) {
    var t = this,
        n = Je(t.__v),
        o = t.o.get(e);
    return o[0]++,
        function(r) {
            var i = function() {
                t.props.revealOrder ? (o.push(r), Ge(t, e, o)) : r()
            };
            n ? n(i) : i()
        }
}, Ze.prototype.render = function(e) {
    this.u = null, this.o = new Map;
    var t = Y(e.children);
    e.revealOrder && "b" === e.revealOrder[0] && t.reverse();
    for (var n = t.length; n--;) this.o.set(t[n], this.u = [1, 0, this.u]);
    return e.children
}, Ze.prototype.componentDidUpdate = Ze.prototype.componentDidMount = function() {
    var e = this;
    this.o.forEach((function(t, n) {
        Ge(e, n, t)
    }))
};
var nt = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103,
    ot = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,
    rt = /^on(Ani|Tra|Tou|BeforeInp|Compo)/,
    it = /[A-Z0-9]/g,
    at = "undefined" != typeof document,
    st = function(e) {
        return ("undefined" != typeof Symbol && "symbol" == typeof Symbol() ? /fil|che|rad/ : /fil|che|ra/).test(e)
    };
$.prototype.isReactComponent = {}, ["componentWillMount", "componentWillReceiveProps", "componentWillUpdate"].forEach((function(e) {
    Object.defineProperty($.prototype, e, {
        configurable: !0,
        get: function() {
            return this["UNSAFE_" + e]
        },
        set: function(t) {
            Object.defineProperty(this, e, {
                configurable: !0,
                writable: !0,
                value: t
            })
        }
    })
}));
var ct = x.event;

function lt() {}

function ut() {
    return this.cancelBubble
}

function dt() {
    return this.defaultPrevented
}
x.event = function(e) {
    return ct && (e = ct(e)), e.persist = lt, e.isPropagationStopped = ut, e.isDefaultPrevented = dt, e.nativeEvent = e
};
var pt = {
        enumerable: !1,
        configurable: !0,
        get: function() {
            return this.class
        }
    },
    ht = x.vnode;
x.vnode = function(e) {
    "string" == typeof e.type && function(e) {
        var t = e.props,
            n = e.type,
            o = {},
            r = -1 === n.indexOf("-");
        for (var i in t) {
            var a = t[i];
            if (!("value" === i && "defaultValue" in t && null == a || at && "children" === i && "noscript" === n || "class" === i || "className" === i)) {
                var s = i.toLowerCase();
                "defaultValue" === i && "value" in t && null == t.value ? i = "value" : "download" === i && !0 === a ? a = "" : "translate" === s && "no" === a ? a = !1 : "o" === s[0] && "n" === s[1] ? "ondoubleclick" === s ? i = "ondblclick" : "onchange" !== s || "input" !== n && "textarea" !== n || st(t.type) ? "onfocus" === s ? i = "onfocusin" : "onblur" === s ? i = "onfocusout" : rt.test(i) && (i = s) : s = i = "oninput" : r && ot.test(i) ? i = i.replace(it, "-$&").toLowerCase() : null === a && (a = void 0), "oninput" === s && o[i = s] && (i = "oninputCapture"), o[i] = a
            }
        }
        "select" == n && o.multiple && Array.isArray(o.value) && (o.value = Y(t.children).forEach((function(e) {
            e.props.selected = -1 != o.value.indexOf(e.props.value)
        }))), "select" == n && null != o.defaultValue && (o.value = Y(t.children).forEach((function(e) {
            e.props.selected = o.multiple ? -1 != o.defaultValue.indexOf(e.props.value) : o.defaultValue == e.props.value
        }))), t.class && !t.className ? (o.class = t.class, Object.defineProperty(o, "className", pt)) : (t.className && !t.class || t.class && t.className) && (o.class = o.className = t.className), e.props = o
    }(e), e.$$typeof = nt, ht && ht(e)
};
var ft = x.__r;
x.__r = function(e) {
    ft && ft(e), e.__c
};
var mt = x.diffed;
x.diffed = function(e) {
        mt && mt(e);
        var t = e.props,
            n = e.__e;
        null != n && "textarea" === e.type && "value" in t && t.value !== n.value && (n.value = null == t.value ? "" : t.value)
    },
    function() {
        if ("undefined" != typeof document && !("adoptedStyleSheets" in document)) {
            var e = "ShadyCSS" in window && !ShadyCSS.nativeShadow,
                t = document.implementation.createHTMLDocument(""),
                n = new WeakMap,
                o = "object" == typeof DOMException ? Error : DOMException,
                r = Object.defineProperty,
                i = Array.prototype.forEach,
                a = /@import.+?;?$/gm,
                s = CSSStyleSheet.prototype;
            s.replace = function() {
                return Promise.reject(new o("Can't call replace on non-constructed CSSStyleSheets."))
            }, s.replaceSync = function() {
                throw new o("Failed to execute 'replaceSync' on 'CSSStyleSheet': Can't call replaceSync on non-constructed CSSStyleSheets.")
            };
            var c = new WeakMap,
                l = new WeakMap,
                u = new WeakMap,
                d = new WeakMap,
                p = O.prototype;
            p.replace = function(e) {
                try {
                    return this.replaceSync(e), Promise.resolve(this)
                } catch (e) {
                    return Promise.reject(e)
                }
            }, p.replaceSync = function(e) {
                if (C(this), "string" == typeof e) {
                    var t = this;
                    c.get(t).textContent = function(e) {
                        var t = e.replace(a, "");
                        return t !== e && console.warn("@import rules are not allowed here. See https://github.com/WICG/construct-stylesheets/issues/119#issuecomment-588352418"), t.trim()
                    }(e), d.set(t, []), l.get(t).forEach((function(e) {
                        e.isConnected() && S(t, E(t, e))
                    }))
                }
            }, r(p, "cssRules", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return C(this), c.get(this).sheet.cssRules
                }
            }), r(p, "media", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return C(this), c.get(this).sheet.media
                }
            }), ["addRule", "deleteRule", "insertRule", "removeRule"].forEach((function(e) {
                p[e] = function() {
                    var t = this;
                    C(t);
                    var n = arguments;
                    d.get(t).push({
                        method: e,
                        args: n
                    }), l.get(t).forEach((function(o) {
                        if (o.isConnected()) {
                            var r = E(t, o).sheet;
                            r[e].apply(r, n)
                        }
                    }));
                    var o = c.get(t).sheet;
                    return o[e].apply(o, n)
                }
            })), r(O, Symbol.hasInstance, {
                configurable: !0,
                value: x
            });
            var h = {
                    childList: !0,
                    subtree: !0
                },
                f = new WeakMap,
                m = new WeakMap,
                _ = new WeakMap,
                v = new WeakMap;
            if (A.prototype = {
                    isConnected: function() {
                        var e = m.get(this);
                        return e instanceof Document ? "loading" !== e.readyState : function(e) {
                            return "isConnected" in e ? e.isConnected : document.contains(e)
                        }(e.host)
                    },
                    connect: function() {
                        var e = T(this);
                        v.get(this).observe(e, h), _.get(this).length > 0 && j(this), I(e, (function(e) {
                            P(e).connect()
                        }))
                    },
                    disconnect: function() {
                        v.get(this).disconnect()
                    },
                    update: function(e) {
                        var t = this,
                            n = m.get(t) === document ? "Document" : "ShadowRoot";
                        if (!Array.isArray(e)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Iterator getter is not callable.");
                        if (!e.every(x)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Failed to convert value to 'CSSStyleSheet'");
                        if (e.some(k)) throw new TypeError("Failed to set the 'adoptedStyleSheets' property on " + n + ": Can't adopt non-constructed stylesheets");
                        t.sheets = e;
                        var o, r, i = _.get(t),
                            a = (o = e).filter((function(e, t) {
                                return o.indexOf(e) === t
                            }));
                        (r = a, i.filter((function(e) {
                            return -1 === r.indexOf(e)
                        }))).forEach((function(e) {
                            var n;
                            (n = E(e, t)).parentNode.removeChild(n),
                                function(e, t) {
                                    u.get(e).delete(t), l.set(e, l.get(e).filter((function(e) {
                                        return e !== t
                                    })))
                                }(e, t)
                        })), _.set(t, a), t.isConnected() && a.length > 0 && j(t)
                    }
                }, window.CSSStyleSheet = O, M(Document), "ShadowRoot" in window) {
                M(ShadowRoot);
                var g = Element.prototype,
                    y = g.attachShadow;
                g.attachShadow = function(e) {
                    var t = y.call(this, e);
                    return "closed" === e.mode && n.set(this, t), t
                }
            }
            var b = P(document);
            b.isConnected() ? b.connect() : document.addEventListener("DOMContentLoaded", b.connect.bind(b))
        }

        function w(e) {
            return e.shadowRoot || n.get(e)
        }

        function x(e) {
            return "object" == typeof e && (p.isPrototypeOf(e) || s.isPrototypeOf(e))
        }

        function k(e) {
            return "object" == typeof e && s.isPrototypeOf(e)
        }

        function E(e, t) {
            return u.get(e).get(t)
        }

        function S(e, t) {
            requestAnimationFrame((function() {
                t.textContent = c.get(e).textContent, d.get(e).forEach((function(e) {
                    return t.sheet[e.method].apply(t.sheet, e.args)
                }))
            }))
        }

        function C(e) {
            if (!c.has(e)) throw new TypeError("Illegal invocation")
        }

        function O() {
            var e = this,
                n = document.createElement("style");
            t.body.appendChild(n), c.set(e, n), l.set(e, []), u.set(e, new WeakMap), d.set(e, [])
        }

        function P(e) {
            var t = f.get(e);
            return t || (t = new A(e), f.set(e, t)), t
        }

        function M(e) {
            r(e.prototype, "adoptedStyleSheets", {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return P(this).sheets
                },
                set: function(e) {
                    P(this).update(e)
                }
            })
        }

        function I(e, t) {
            for (var n = document.createNodeIterator(e, NodeFilter.SHOW_ELEMENT, (function(e) {
                    return w(e) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
                }), null, !1), o = void 0; o = n.nextNode();) t(w(o))
        }

        function T(e) {
            var t = m.get(e);
            return t instanceof Document ? t.body : t
        }

        function j(e) {
            var t = document.createDocumentFragment(),
                n = _.get(e),
                o = v.get(e),
                r = T(e);
            o.disconnect(), n.forEach((function(n) {
                t.appendChild(E(n, e) || function(e, t) {
                    var n = document.createElement("style");
                    return u.get(e).set(t, n), l.get(e).push(t), n
                }(n, e))
            })), r.insertBefore(t, null), o.observe(r, h), n.forEach((function(t) {
                S(t, E(t, e))
            }))
        }

        function A(t) {
            var n = this;
            n.sheets = [], m.set(n, t), _.set(n, []), v.set(n, new MutationObserver((function(t, o) {
                document ? t.forEach((function(t) {
                    e || i.call(t.addedNodes, (function(e) {
                        e instanceof Element && I(e, (function(e) {
                            P(e).connect()
                        }))
                    })), i.call(t.removedNodes, (function(t) {
                        t instanceof Element && (function(e, t) {
                            return t instanceof HTMLStyleElement && _.get(e).some((function(t) {
                                return E(t, e)
                            }))
                        }(n, t) && j(n), e || I(t, (function(e) {
                            P(e).disconnect()
                        })))
                    }))
                })) : o.disconnect()
            })))
        }
    }();
const _t = se({
        client: void 0,
        leaveBreadcrumb: () => {
            throw new Error("Invalid attempt to call leaveBreadcrumb outside of context.")
        },
        notify: () => {
            throw new Error("Invalid attempt to call notify outside of context.")
        }
    }),
    vt = () => {
        const e = je(_t);
        if (!e) throw new Error("Invalid attempt to use useBugsnag outside of BugsnagProvider.");
        return e
    };
var gt = '*,::backdrop,:after,:before{--tw-border-spacing-x:0;--tw-border-spacing-y:0;--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-pan-x: ;--tw-pan-y: ;--tw-pinch-zoom: ;--tw-scroll-snap-strictness:proximity;--tw-gradient-from-position: ;--tw-gradient-via-position: ;--tw-gradient-to-position: ;--tw-ordinal: ;--tw-slashed-zero: ;--tw-numeric-figure: ;--tw-numeric-spacing: ;--tw-numeric-fraction: ;--tw-ring-inset: ;--tw-ring-offset-width:0px;--tw-ring-offset-color:#fff;--tw-ring-color:#3b82f680;--tw-ring-offset-shadow:0 0 #0000;--tw-ring-shadow:0 0 #0000;--tw-shadow:0 0 #0000;--tw-shadow-colored:0 0 #0000;--tw-blur: ;--tw-brightness: ;--tw-contrast: ;--tw-grayscale: ;--tw-hue-rotate: ;--tw-invert: ;--tw-saturate: ;--tw-sepia: ;--tw-drop-shadow: ;--tw-backdrop-blur: ;--tw-backdrop-brightness: ;--tw-backdrop-contrast: ;--tw-backdrop-grayscale: ;--tw-backdrop-hue-rotate: ;--tw-backdrop-invert: ;--tw-backdrop-opacity: ;--tw-backdrop-saturate: ;--tw-backdrop-sepia: ;--tw-contain-size: ;--tw-contain-layout: ;--tw-contain-paint: ;--tw-contain-style: }/*! tailwindcss v3.4.14 | MIT License | https://tailwindcss.com*/*,:after,:before{border:0 solid;box-sizing:border-box}:after,:before{--tw-content:""}:host,html{-webkit-text-size-adjust:100%;font-feature-settings:normal;-webkit-tap-highlight-color:transparent;font-family:SuisseIntl,sans-serif;font-variation-settings:normal;line-height:1.5;tab-size:4}body{line-height:inherit;margin:0}hr{border-top-width:1px;color:inherit;height:0}abbr:where([title]){-webkit-text-decoration:underline dotted;text-decoration:underline dotted}h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}a{color:inherit;text-decoration:inherit}b,strong{font-weight:bolder}code,kbd,pre,samp{font-feature-settings:normal;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:1em;font-variation-settings:normal}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:initial}sub{bottom:-.25em}sup{top:-.5em}table{border-collapse:collapse;border-color:inherit;text-indent:0}button,input,optgroup,select,textarea{font-feature-settings:inherit;color:inherit;font-family:inherit;font-size:100%;font-variation-settings:inherit;font-weight:inherit;letter-spacing:inherit;line-height:inherit;margin:0;padding:0}button,select{text-transform:none}button,input:where([type=button]),input:where([type=reset]),input:where([type=submit]){-webkit-appearance:button;background-color:initial;background-image:none}:-moz-focusring{outline:auto}:-moz-ui-invalid{box-shadow:none}progress{vertical-align:initial}::-webkit-inner-spin-button,::-webkit-outer-spin-button{height:auto}[type=search]{-webkit-appearance:textfield;outline-offset:-2px}::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}summary{display:list-item}blockquote,dd,dl,figure,h1,h2,h3,h4,h5,h6,hr,p,pre{margin:0}fieldset{margin:0}fieldset,legend{padding:0}menu,ol,ul{list-style:none;margin:0;padding:0}dialog{padding:0}textarea{resize:vertical}input::placeholder,textarea::placeholder{color:#9ca3af;opacity:1}[role=button],button{cursor:pointer}:disabled{cursor:default}audio,canvas,embed,iframe,img,object,svg,video{display:block;vertical-align:middle}img,video{height:auto;max-width:100%}[hidden]:where(:not([hidden=until-found])){display:none}:host{font-family:SuisseIntl,sans-serif}:host([data-nametag=shop-portal-provider]){all:initial!important}:host(shopify-payment-terms){font-family:inherit}.container{width:100%}@media (min-width:768px){.container{max-width:768px}}@media (min-width:1024px){.container{max-width:1024px}}@media (min-width:1280px){.container{max-width:1280px}}@media (min-width:1536px){.container{max-width:1536px}}.sr-only{clip:rect(0,0,0,0);border-width:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px}.pointer-events-none{pointer-events:none}.\\!visible{visibility:visible!important}.visible{visibility:visible}.invisible{visibility:hidden}.fixed{position:fixed}.absolute{position:absolute}.relative{position:relative}.inset-0{inset:0}.inset-05{inset:2px}.inset-x-0{left:0;right:0}.inset-y-0{bottom:0;top:0}.bottom-8{bottom:32px}.bottom-\\[15\\%\\]{bottom:15%}.-z-10{z-index:-10}.z-0{z-index:0}.z-10{z-index:10}.z-30{z-index:30}.z-40{z-index:40}.z-50{z-index:50}.z-\\[800\\]{z-index:800}.z-max{z-index:2147483647}.float-right{float:right}.-m-px{margin:-1px}.m-0{margin:0}.m-\\[1em\\]{margin:1em}.m-auto{margin:auto}.mx-auto{margin-left:auto;margin-right:auto}.my-1{margin-bottom:4px;margin-top:4px}.my-5{margin-bottom:20px;margin-top:20px}.-ml-1{margin-left:-4px}.mb-2{margin-bottom:8px}.mb-3{margin-bottom:12px}.mb-4{margin-bottom:16px}.mb-5{margin-bottom:20px}.mb-7{margin-bottom:28px}.ml-1{margin-left:4px}.ml-auto{margin-left:auto}.mr-0\\.5{margin-right:.125rem}.mr-20{margin-right:5rem}.mr-3{margin-right:12px}.mt-4{margin-top:16px}.mt-5{margin-top:20px}.mt-8{margin-top:32px}.box-content{box-sizing:initial}.block{display:block}.inline-block{display:inline-block}.inline{display:inline}.flex{display:flex}.inline-flex{display:inline-flex}.hidden{display:none}.size-0{height:0;width:0}.size-5{height:20px;width:20px}.size-6{height:24px;width:24px}.size-8{height:32px;width:32px}.size-full{height:100%;width:100%}.h-10{height:40px}.h-3{height:12px}.h-4{height:16px}.h-4-5{height:18px}.h-5{height:20px}.h-8{height:32px}.h-9{height:36px}.h-\\[14px\\]{height:14px}.h-auto{height:auto}.h-full{height:100%}.h-px{height:1px}.max-h-\\[80vh\\]{max-height:80vh}.w-22{width:88px}.w-37{width:148px}.w-55{width:220px}.w-6{width:24px}.w-85{width:340px}.w-9{width:36px}.w-\\[432px\\]{width:432px}.w-\\[59px\\]{width:59px}.w-auto{width:auto}.w-fit{width:fit-content}.w-full{width:100%}.w-pay-button{width:var(--shop-pay-button-width,260px)}.w-px{width:1px}.min-w-100{min-width:400px}.min-w-85{min-width:340px}.min-w-max{min-width:max-content}.max-w-\\[40\\%\\]{max-width:40%}.max-w-full{max-width:100%}.flex-1{flex:1 1 0%}.flex-none{flex:none}.flex-shrink-0{flex-shrink:0}.translate-y-0{--tw-translate-y:0px}.translate-y-0,.translate-y-94{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.translate-y-94{--tw-translate-y:376px}.translate-y-full{--tw-translate-y:100%}.rotate-45,.translate-y-full{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.rotate-45{--tw-rotate:45deg}.scale-0{--tw-scale-x:0;--tw-scale-y:0}.scale-0,.scale-100{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.scale-100{--tw-scale-x:1;--tw-scale-y:1}.transform{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.animate-fade-in{animation:fadeIn 1s}@keyframes fadeOut{0%{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(100%)}}.animate-fade-out{animation:fadeOut .3s ease-out}@keyframes follow{0%{transform:scaleY(1);width:100%}25%{transform:scaleY(1)}50%{transform:scaleY(1.2)}to{transform:scaleY(1);width:36px}}.animate-follow{animation:follow .3s cubic-bezier(.45,0,.15,1)}@keyframes pulse{50%{opacity:.5}}.animate-pulse{animation:pulse 2s cubic-bezier(.4,0,.6,1) infinite}@keyframes reveal{to{stroke-dashoffset:408}}.animate-reveal{animation:reveal 1.3s ease-in-out 0s infinite reverse}@keyframes slideUp{0%,20%{opacity:0;transform:translateY(100%)}to{opacity:1;transform:translateY(0)}}.animate-slide-up{animation:slideUp .3s ease-in}@keyframes spin{to{transform:rotate(1turn)}}.animate-spin{animation:spin 1.3s linear infinite}.cursor-pointer{cursor:pointer}.resize{resize:both}.list-none{list-style-type:none}.flex-row{flex-direction:row}.flex-col{flex-direction:column}.flex-nowrap{flex-wrap:nowrap}.content-center{align-content:center}.items-end{align-items:flex-end}.items-center{align-items:center}.justify-start{justify-content:flex-start}.justify-center{justify-content:center}.justify-between{justify-content:space-between}.gap-0\\.5{gap:.125rem}.gap-1{gap:4px}.gap-2{gap:8px}.gap-3{gap:12px}.gap-4{gap:16px}.gap-x-1{column-gap:4px}.gap-x-1-5{column-gap:6px}.gap-x-3{column-gap:12px}.gap-x-4{column-gap:16px}.space-y-2\\.5>:not([hidden])~:not([hidden]){--tw-space-y-reverse:0;margin-bottom:calc(.625rem*var(--tw-space-y-reverse));margin-top:calc(.625rem*(1 - var(--tw-space-y-reverse)))}.overflow-hidden{overflow:hidden}.overflow-visible{overflow:visible}.truncate{overflow:hidden;white-space:nowrap}.text-ellipsis,.truncate{text-overflow:ellipsis}.whitespace-nowrap{white-space:nowrap}.whitespace-pre-line{white-space:pre-line}.rounded-lg{border-radius:16px}.rounded-login-button{border-radius:var(--buttons-radius,var(--shop-pay-button-border-radius,12px))}.rounded-max{border-radius:999px}.rounded-md{border-radius:12px}.rounded-sm100{border-radius:10px}.rounded-xs{border-radius:4px}.border{border-width:1px}.border-0{border-width:0}.border-\\[0\\.5px\\]{border-width:.5px}.border-b{border-bottom-width:1px}.border-solid{border-style:solid}.border-none{border-style:none}.border-grayscale-l2{--tw-border-opacity:1;border-color:rgb(203 203 202/var(--tw-border-opacity))}.border-grayscale-l2l{--tw-border-opacity:1;border-color:rgb(227 227 227/var(--tw-border-opacity))}.bg-grayscale-l2{--tw-bg-opacity:1;background-color:rgb(203 203 202/var(--tw-bg-opacity))}.bg-grayscale-l3{--tw-bg-opacity:1;background-color:rgb(240 240 240/var(--tw-bg-opacity))}.bg-grayscale-l4{--tw-bg-opacity:1;background-color:rgb(242 244 245/var(--tw-bg-opacity))}.bg-grayscale-primary-light{--tw-bg-opacity:1;background-color:rgb(112 112 112/var(--tw-bg-opacity))}.bg-overlay{background-color:#0006}.bg-poppy-d1{--tw-bg-opacity:1;background-color:rgb(217 42 15/var(--tw-bg-opacity))}.bg-poppy-l2{--tw-bg-opacity:1;background-color:rgb(255 236 233/var(--tw-bg-opacity))}.bg-purple-primary{--tw-bg-opacity:1;background-color:rgb(84 51 235/var(--tw-bg-opacity))}.bg-transparent{background-color:initial}.bg-white{--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.bg-gradient-to-b{background-image:linear-gradient(to bottom,var(--tw-gradient-stops))}.from-black\\/95{--tw-gradient-from:#000000f2 var(--tw-gradient-from-position);--tw-gradient-to:#0000 var(--tw-gradient-to-position);--tw-gradient-stops:var(--tw-gradient-from),var(--tw-gradient-to)}.to-black\\/60{--tw-gradient-to:#0009 var(--tw-gradient-to-position)}.fill-purple-primary{fill:#5433eb}.stroke-white{stroke:#fff}.p-0{padding:0}.p-3{padding:12px}.p-4{padding:16px}.p-6{padding:24px}.p-8{padding:32px}.px-0{padding-left:0;padding-right:0}.px-11{padding-left:44px;padding-right:44px}.px-2{padding-left:8px;padding-right:8px}.px-3{padding-left:12px;padding-right:12px}.px-4{padding-left:16px;padding-right:16px}.px-5{padding-left:20px;padding-right:20px}.px-6{padding-left:24px;padding-right:24px}.py-1{padding-bottom:4px;padding-top:4px}.py-2-5{padding-bottom:10px;padding-top:10px}.py-2\\.5{padding-bottom:.625rem;padding-top:.625rem}.py-3{padding-bottom:12px;padding-top:12px}.py-4{padding-bottom:16px;padding-top:16px}.pb-0{padding-bottom:0}.pb-2{padding-bottom:8px}.pb-3{padding-bottom:12px}.pb-4{padding-bottom:16px}.pb-6{padding-bottom:24px}.pr-1\\.5{padding-right:.375rem}.pr-3{padding-right:12px}.pt-0{padding-top:0}.pt-4{padding-top:16px}.text-center{text-align:center}.align-middle{vertical-align:middle}.font-inherit{font-family:inherit}.font-sans{font-family:SuisseIntl,sans-serif}.font-system{font-family:ui-sans-serif,system-ui,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}.text-body-large{font-size:16px;font-weight:450;letter-spacing:.15px;line-height:20px}.text-body-small{font-weight:450}.text-body-small,.text-body-title-small{font-size:14px;letter-spacing:.15px;line-height:18px}.text-body-title-small{font-weight:500}.text-button-large{font-size:16px;font-weight:500;letter-spacing:.15px;line-height:18px}.text-button-medium{font-size:14px;font-weight:500;letter-spacing:.15px;line-height:16px}.text-caption{font-size:12px;font-weight:450;letter-spacing:.15px;line-height:14px}.text-subtitle{font-size:18px;font-weight:500;letter-spacing:.15px;line-height:20px}.font-bold{font-weight:700}.font-light{font-weight:300}.font-medium{font-weight:500}.font-normal{font-weight:400}.font-semibold{font-weight:600}.uppercase{text-transform:uppercase}.leading-6{line-height:1.5rem}.leading-normal{line-height:1.5}.leading-snug{line-height:1.375}.tracking-wider{letter-spacing:.05em}.text-black{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.text-grayscale-d0{--tw-text-opacity:1;color:rgb(102 102 102/var(--tw-text-opacity))}.text-grayscale-d1{--tw-text-opacity:1;color:rgb(64 64 64/var(--tw-text-opacity))}.text-grayscale-d2\\/70{color:#121212b3}.text-grayscale-l4{--tw-text-opacity:1;color:rgb(242 244 245/var(--tw-text-opacity))}.text-grayscale-primary-light{--tw-text-opacity:1;color:rgb(112 112 112/var(--tw-text-opacity))}.text-poppy-d1{--tw-text-opacity:1;color:rgb(217 42 15/var(--tw-text-opacity))}.text-purple-primary{--tw-text-opacity:1;color:rgb(84 51 235/var(--tw-text-opacity))}.text-white{--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity))}.underline{text-decoration-line:underline}.no-underline{text-decoration-line:none}.opacity-0{opacity:0}.opacity-100{opacity:1}.shadow-lg{--tw-shadow:0px 8px 30px 0px #0006;--tw-shadow-colored:0px 8px 30px 0px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow,0 0 #0000),var(--tw-ring-shadow,0 0 #0000),var(--tw-shadow)}.blur{--tw-blur:blur(8px)}.blur,.filter{filter:var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)}.transition{transition-duration:.15s;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke,opacity,box-shadow,transform,filter,backdrop-filter;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-all{transition-duration:.15s;transition-property:all;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-colors{transition-duration:.15s;transition-property:color,background-color,border-color,text-decoration-color,fill,stroke;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-opacity{transition-duration:.15s;transition-property:opacity;transition-timing-function:cubic-bezier(.4,0,.2,1)}.transition-transform{transition-duration:.15s;transition-property:transform;transition-timing-function:cubic-bezier(.4,0,.2,1)}.duration-300{transition-duration:.3s}.duration-400{transition-duration:.4s}.ease-cubic-modal{transition-timing-function:cubic-bezier(.32,.72,0,1)}.ease-in-out{transition-timing-function:cubic-bezier(.4,0,.2,1)}.will-change-transform{will-change:transform}.forced-color-adjust-none{forced-color-adjust:none}.stroke-dasharray-reveal{stroke-dasharray:136}.first_pt-0:first-child{padding-top:0}.last_border-b-0:last-child{border-bottom-width:0}.last_pb-0:last-child{padding-bottom:0}.hover_text-black:hover{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.hover_text-grayscale-l2l:hover{--tw-text-opacity:1;color:rgb(227 227 227/var(--tw-text-opacity))}.focus_text-black:focus{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.focus_outline-none:focus{outline:2px solid #0000;outline-offset:2px}.focus_outline-0:focus{outline-width:0}.active_text-black:active{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.hover_enabled_bg-purple-d0:enabled:hover{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.hover_enabled_bg-transparent:enabled:hover{background-color:initial}.focus-visible_enabled_outline-none:enabled:focus-visible{outline:2px solid #0000;outline-offset:2px}.focus-visible_enabled_ring:enabled:focus-visible{--tw-ring-offset-shadow:var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);--tw-ring-shadow:var(--tw-ring-inset) 0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);box-shadow:var(--tw-ring-offset-shadow),var(--tw-ring-shadow),var(--tw-shadow,0 0 #0000)}.focus-visible_enabled_ring-purple-primary-light:enabled:focus-visible{--tw-ring-opacity:1;--tw-ring-color:rgb(219 209 255/var(--tw-ring-opacity))}.disabled_opacity-50:disabled{opacity:.5}.group:hover .group-hover_bg-purple-d0{--tw-bg-opacity:1;background-color:rgb(69 36 219/var(--tw-bg-opacity))}.group:hover .group-hover_text-grayscale-l2l{--tw-text-opacity:1;color:rgb(227 227 227/var(--tw-text-opacity))}@media (prefers-reduced-motion:reduce){.motion-reduce_duration-0{transition-duration:0s}}@media (max-width:448px){.sm_absolute{position:absolute}.sm_inset-x-0{left:0;right:0}.sm_bottom-0{bottom:0}.sm_top-auto{top:auto}.sm_hidden{display:none}.sm_max-w-none{max-width:none}.sm_translate-y-0{--tw-translate-y:0px}.sm_translate-y-0,.sm_translate-y-full{transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm_translate-y-full{--tw-translate-y:100%}.sm_scale-100{--tw-scale-x:1;--tw-scale-y:1;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))}.sm_rounded-none{border-radius:0}.sm_rounded-b-none{border-bottom-left-radius:0;border-bottom-right-radius:0}}';

function yt({
    children: e,
    instanceId: t,
    type: n,
    variant: o
}) {
    const r = Pe(null),
        [i, a] = Ee(null),
        {
            notify: s
        } = vt();
    return Oe((() => {
        a(r.current.attachShadow({
            mode: "open"
        }))
    }), []), Oe((() => {
        if (i) {
            const e = new CSSStyleSheet;
            e.replace(gt).then((() => {
                i.adoptedStyleSheets = [e]
            })).catch((e => {
                s(new Error(`Failed to adopt stylesheets for portal provider: ${e}`))
            }))
        }
    }), [i, s]), le("div", {
        "data-nametag": "shop-portal-provider",
        "data-portal-instance-id": t,
        "data-type": n,
        "data-variant": o,
        ref: r,
        children: i && tt(e, i)
    })
}
const bt = se({
        analyticsData: {
            analyticsTraceId: ""
        },
        getTrekkieAttributes: () => g(void 0, void 0, void 0, (function*() {
            return Promise.resolve({})
        })),
        produceMonorailEvent: () => {
            throw new Error("Invalid attempt to call produceMonorailEvent outside of context.")
        },
        trackModalStateChange: () => {
            throw new Error("Invalid attempt to call trackModalStateChange outside of context.")
        },
        trackPageImpression: () => g(void 0, void 0, void 0, (function*() {
            throw new Error("Invalid attempt to call trackPageImpression outside of context.")
        })),
        trackUserAction: () => {
            throw new Error("Invalid attempt to call trackUserAction outside of context.")
        }
    }),
    wt = () => je(bt),
    xt = se({
        log: () => {
            throw new Error("Invalid attempt to call log outside of context.")
        },
        recordCounter: () => {
            throw new Error("Invalid attempt to call recordCounter outside of context.")
        },
        recordGauge: () => {
            throw new Error("Invalid attempt to call recordGauge outside of context.")
        },
        recordHistogram: () => {
            throw new Error("Invalid attempt to call recordHistogram outside of context.")
        },
        client: void 0
    }),
    kt = () => je(xt),
    Et = se({
        devMode: !1,
        element: null,
        instanceId: ""
    }),
    St = () => je(Et),
    Ct = se({
        autoOpened: !1,
        dispatch: () => {
            throw new Error("Invalid attempt to call dispatch outside of AuthorizeStateProvider")
        },
        loaded: !1,
        modalDismissible: !1,
        modalForceHidden: !1,
        modalVisible: !1,
        sessionDetected: !1
    });

function Ot(e, t) {
    switch (t.type) {
        case "setAutoOpened":
            return Object.assign(Object.assign({}, e), {
                autoOpened: t.payload
            });
        case "setLoaded":
            return Object.assign(Object.assign({}, e), {
                loaded: t.payload
            });
        case "setModalDismissible":
            return Object.assign(Object.assign({}, e), {
                modalDismissible: t.payload
            });
        case "setModalForceHidden":
            return Object.assign(Object.assign({}, e), {
                modalForceHidden: t.payload
            });
        case "setModalVisible":
            return Object.assign(Object.assign(Object.assign({}, e), {
                modalVisible: t.payload
            }), t.payload && {
                modalDismissible: !1
            });
        case "setSessionDetected":
            return Object.assign(Object.assign({}, e), {
                sessionDetected: t.payload
            });
        case "updateState":
            {
                let n = t.payload.modalDismissible ? t.payload.modalDismissible : e.modalDismissible;
                return t.payload.modalVisible && (n = !1),
                Object.assign(Object.assign(Object.assign({}, e), t.payload), {
                    modalDismissible: n
                })
            }
        default:
            return e
    }
}
const Pt = ({
    children: e
}) => {
    const [t, n] = Se(Ot, {
        autoOpened: !1,
        loaded: !1,
        modalDismissible: !1,
        modalForceHidden: !1,
        modalVisible: !1,
        sessionDetected: !1
    }), o = Ie((() => {
        const {
            autoOpened: e,
            loaded: o,
            modalDismissible: r,
            modalForceHidden: i,
            modalVisible: a,
            sessionDetected: s
        } = t;
        return {
            autoOpened: e,
            dispatch: n,
            loaded: o,
            modalDismissible: r,
            modalForceHidden: i,
            modalVisible: a && !i,
            sessionDetected: s
        }
    }), [n, t]);
    return le(Ct.Provider, {
        value: o,
        children: e
    })
};

function Mt(e) {
    return It(e).map((e => e instanceof Error ? e : new Tt(`[${typeof e}] ${function(e){if("string"!=typeof e)try{return JSON.stringify(e)??typeof e}catch{}return`
        $ {
            e
        }
        `}(e).slice(0,10240)}`)))
}

function It(e, t = 0) {
    return t >= 20 ? [e, "Truncated cause stack"] : e instanceof Error && e.cause ? [e, ...It(e.cause, t + 1)] : [e]
}
var Tt = class extends Error {
        name = "BugsnagInvalidError"
    },
    jt = /^\s*at .*(\S+:\d+|\(native\))/m,
    At = /^(eval@)?(\[native code])?$/;

function Nt(e) {
    return e.stack ? e.stack.match(jt) ? function(e) {
        return e.stack.split("\n").filter((e => !!e.match(jt))).map((e => {
            let t = e.replace(/^\s+/, "").replace(/^.*?\s+/, ""),
                n = t.match(/ (\(.+\)$)/);
            t = n ? t.replace(n[0], "") : t;
            let o = Lt(n ? n[1] : t);
            return {
                method: n && t || void 0,
                file: ["eval", "<anonymous>"].indexOf(o[0]) > -1 ? void 0 : o[0],
                lineNumber: o[1],
                columnNumber: o[2]
            }
        }))
    }(e) : function(e) {
        return e.stack.split("\n").filter((e => !e.match(At))).map((e => {
            if (-1 === e.indexOf("@") && -1 === e.indexOf(":")) return {
                method: e
            };
            let t = /((.*".+"[^@]*)?[^@]*)(?:@)/,
                n = e.match(t),
                o = n && n[1] ? n[1] : void 0,
                r = Lt(e.replace(t, ""));
            return {
                method: o,
                file: r[0],
                lineNumber: r[1],
                columnNumber: r[2]
            }
        }))
    }(e) : []
}

function Lt(e) {
    if (-1 === e.indexOf(":")) return [e];
    let t = /(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/[()]/g, ""));
    return [t[1], t[2] ? Number(t[2]) : void 0, t[3] ? Number(t[3]) : void 0]
}
var Dt = class {
    breadcrumbs = [];
    apiKey;
    plugins;
    appId;
    appType;
    appVersion;
    releaseStage;
    locale;
    userAgent;
    metadata;
    persistedMetadata;
    onError;
    onPostErrorListeners = [];
    endpoints;
    constructor(e) {
        this.apiKey = e.apiKey, this.appType = e.appType, this.appId = e.appId, this.appVersion = e.appVersion, this.releaseStage = e.releaseStage, this.locale = e.locale, this.userAgent = e.userAgent, this.metadata = e.metadata, this.onError = e.onError, this.persistedMetadata = {}, this.endpoints = e.endpoints ? ? {
            notify: "https://notify.bugsnag.com/",
            sessions: "https://sessions.bugsnag.com"
        }, this.plugins = e.plugins ? ? [], this.plugins.forEach((e => e.load(this))), this.leaveBreadcrumb("Bugsnag started", void 0, "state")
    }
    addMetadata(e) {
        for (let t of Object.keys(e)) this.persistedMetadata[t] = e[t]
    }
    leaveBreadcrumb(e, t, n = "manual") {
        this.breadcrumbs.push({
            name: e,
            metaData: t,
            type: n,
            timestamp: (new Date).toISOString()
        })
    }
    notify(e, {
        errorClass: t,
        severity: n,
        severityType: o,
        handled: r = !0,
        metadata: i,
        context: a,
        groupingHash: s
    } = {}) {
        let c = Mt(e),
            l = { ...this.metadata,
                ...this.persistedMetadata,
                ...i
            },
            u = this.buildBugsnagEvent(c, {
                errorClass: t,
                severityType: o,
                handled: r,
                severity: n,
                metadata: l,
                context: a,
                groupingHash: s
            });
        if ((this.onError ? .(u, e) ? ? 1) && "development" !== this.releaseStage) {
            let e = this.sendToBugsnag(u);
            return this.onPostErrorListeners.forEach((e => e(u))), e
        }
        return Promise.resolve()
    }
    addOnPostError(e) {
        this.onPostErrorListeners.push(e)
    }
    buildBugsnagEvent(e, {
        errorClass: t,
        severity: n = "error",
        severityType: o = "handledException",
        handled: r,
        metadata: i = {},
        context: a,
        groupingHash: s
    }) {
        let c = (new Date).toISOString(),
            {
                breadcrumbs: l,
                appId: u,
                appType: d,
                appVersion: p,
                releaseStage: h,
                locale: f,
                userAgent: m
            } = this,
            _ = e.map(((e, n) => ({
                errorClass: 0 === n ? t ? ? e.name : e.name,
                stacktrace: Ut(u, e),
                message: e.message
            })));
        return {
            payloadVersion: "5",
            exceptions: _,
            severity: n,
            severityReason: {
                type: o
            },
            unhandled: !r,
            app: {
                id: u,
                type: d,
                version: p,
                releaseStage: h
            },
            device: {
                time: c,
                locale: f,
                userAgent: m
            },
            breadcrumbs: l,
            context: a,
            metaData: i,
            groupingHash: s
        }
    }
    async sendToBugsnag(e) {
        let {
            apiKey: t
        } = this, n = {
            apiKey: t,
            notifier: {
                name: "Bugsnag JavaScript",
                version: "7.22.2",
                url: "https://github.com/bugsnag/bugsnag-js"
            },
            events: [e]
        };
        try {
            await fetch(this.endpoints.notify, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Bugsnag-Api-Key": t,
                    "Bugsnag-Payload-Version": "5",
                    "Bugsnag-Sent-At": e.device.time
                },
                body: JSON.stringify(n)
            })
        } catch (e) {
            console.warn("[bugsnag-light] failed to send an event"), console.warn(e)
        }
    }
};

function Ut(e, t) {
    let n = Nt(t).map((t => {
        let n = t.file ? .includes(e);
        return {
            method: t.method ? ? "",
            file: t.file ? ? "",
            lineNumber: t.lineNumber ? ? 0,
            columnNumber: t.columnNumber,
            inProject: n
        }
    }));
    if (t instanceof Tt) {
        let e = n.findIndex((e => e.method.endsWith("notify")));
        e > -1 && (n = n.slice(e + 1))
    }
    return n
}
const Rt = "undefined" == typeof navigator ? {
    languages: [],
    userAgent: "",
    userLanguage: "",
    credentials: {}
} : navigator;
var zt = "e35d7136cee78d344ccffdbd5ca710fa";

function Ft(e, t) {
    if (!{}.hasOwnProperty.call(e, t)) throw new TypeError("attempted to use private field on non-instance");
    return e
}
var $t = 0;

function Vt(e) {
    return "__private_" + $t++ + "_" + e
}

function Ht(e) {
    return Object.entries(e).map((([e, t]) => ({
        key: e,
        value: {
            stringValue: String(t)
        }
    })))
}

function Bt(e) {
    if (Array.isArray(e)) return {
        arrayValue: {
            values: e.map((e => Bt(e)))
        }
    };
    switch (typeof e) {
        case "boolean":
            return {
                boolValue: Boolean(e)
            };
        case "number":
            return {
                doubleValue: Number(e)
            };
        default:
            return {
                stringValue: String(e)
            }
    }
}
const Wt = function(e, t, n) {
    const o = [0];
    for (let r = 0; r < n; r++) {
        const n = Math.floor(e * t ** r);
        o.push(n)
    }
    return o
}(5, 2, 12);
var qt = Vt("exporter"),
    Xt = Vt("attributes"),
    Yt = Vt("metrics"),
    Kt = Vt("logs");
class Jt {
    constructor({
        exporter: e,
        attributes: t
    }) {
        Object.defineProperty(this, qt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Xt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Yt, {
            writable: !0,
            value: []
        }), Object.defineProperty(this, Kt, {
            writable: !0,
            value: []
        }), Ft(this, qt)[qt] = e, Ft(this, Xt)[Xt] = null != t ? t : {}
    }
    addAttributes(e) {
        Ft(this, Xt)[Xt] = { ...Ft(this, Xt)[Xt],
            ...e
        }
    }
    histogram({
        name: e,
        value: t,
        unit: n,
        bounds: o,
        attributes: r,
        scale: i
    }) {
        const a = 1e6 * Date.now();
        o ? Ft(this, Yt)[Yt].push({
            name: e,
            type: "histogram",
            value: t,
            unit: n,
            timeUnixNano: a,
            attributes: r,
            bounds: o
        }) : Ft(this, Yt)[Yt].push({
            name: e,
            type: "exponential_histogram",
            value: t,
            unit: n,
            timeUnixNano: a,
            attributes: r,
            scale: i
        })
    }
    counter({
        name: e,
        value: t,
        unit: n,
        attributes: o
    }) {
        const r = 1e6 * Date.now();
        Ft(this, Yt)[Yt].push({
            name: e,
            type: "counter",
            value: t,
            unit: n,
            timeUnixNano: r,
            attributes: o
        })
    }
    gauge({
        name: e,
        value: t,
        unit: n,
        attributes: o
    }) {
        const r = 1e6 * Date.now();
        Ft(this, Yt)[Yt].push({
            name: e,
            type: "gauge",
            value: t,
            unit: n,
            timeUnixNano: r,
            attributes: o
        })
    }
    log({
        body: e,
        attributes: t
    }) {
        const n = 1e6 * Date.now();
        Ft(this, Kt)[Kt].push({
            timeUnixNano: n,
            body: e,
            attributes: t
        })
    }
    async exportMetrics() {
        const e = {};
        Ft(this, Yt)[Yt].forEach((t => {
            switch (t.attributes = { ...Ft(this, Xt)[Xt],
                ...t.attributes
            }, t.type) {
                case "histogram":
                    ! function(e, t) {
                        var n;
                        const {
                            name: o,
                            value: r,
                            unit: i,
                            timeUnixNano: a,
                            attributes: s
                        } = t, c = null !== (n = t.bounds) && void 0 !== n ? n : Wt, l = new Array(c.length + 1).fill(0);
                        e[o] || = {
                            name: o,
                            unit: i || "1",
                            histogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        };
                        for (let e = 0; e < l.length; e++) {
                            const t = c[e];
                            if (void 0 === t) l[e] = 1;
                            else if (r <= t) {
                                l[e] = 1;
                                break
                            }
                        }
                        e[o].histogram.dataPoints.push({
                            startTimeUnixNano: a,
                            timeUnixNano: a,
                            count: 1,
                            sum: r,
                            min: r,
                            max: r,
                            bucketCounts: l,
                            explicitBounds: c,
                            attributes: Ht(null != s ? s : {})
                        })
                    }(e, t);
                    break;
                case "exponential_histogram":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a,
                            scale: s
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            exponentialHistogram: {
                                aggregationTemporality: 1,
                                dataPoints: []
                            }
                        };
                        const c = o <= 0 ? 0 : o,
                            l = s || 3,
                            u = 2 ** l / Math.log(2),
                            d = Math.ceil(Math.log(o) * u) - 1,
                            p = o <= 0 ? 1 : 0,
                            h = {
                                offset: 0,
                                bucketCounts: []
                            },
                            f = {
                                offset: o > 0 ? d : 0,
                                bucketCounts: o > 0 ? [1] : []
                            };
                        e[n].exponentialHistogram.dataPoints.push({
                            attributes: Ht(null != a ? a : {}),
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            count: 1,
                            sum: c,
                            scale: l,
                            zeroCount: p,
                            positive: f,
                            negative: h,
                            min: c,
                            max: c,
                            zeroThreshold: 0
                        })
                    }(e, t);
                    break;
                case "counter":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            sum: {
                                aggregationTemporality: 1,
                                isMonotonic: !0,
                                dataPoints: []
                            }
                        }, e[n].sum.dataPoints.push({
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            asDouble: o,
                            attributes: Ht(null != a ? a : {})
                        })
                    }(e, t);
                    break;
                case "gauge":
                    ! function(e, t) {
                        const {
                            name: n,
                            value: o,
                            unit: r,
                            timeUnixNano: i,
                            attributes: a
                        } = t;
                        e[n] || = {
                            name: n,
                            unit: r || "1",
                            gauge: {
                                dataPoints: []
                            }
                        }, e[n].gauge.dataPoints.push({
                            startTimeUnixNano: i,
                            timeUnixNano: i,
                            asDouble: o,
                            attributes: Ht(null != a ? a : {})
                        })
                    }(e, t)
            }
        }));
        const t = Object.values(e);
        0 !== t.length && (Ft(this, Yt)[Yt] = [], await Ft(this, qt)[qt].exportMetrics(t))
    }
    async exportLogs() {
        const e = Ft(this, Kt)[Kt].map((e => {
            const t = {
                timeUnixNano: e.timeUnixNano,
                observedTimeUnixNano: e.timeUnixNano,
                attributes: (n = { ...Ft(this, Xt)[Xt],
                    ...e.attributes
                }, Object.entries(n).map((([e, t]) => ({
                    key: e,
                    value: Bt(t)
                }))))
            };
            var n;
            return e.body && (t.body = {
                stringValue: e.body
            }), t
        }));
        0 !== e.length && (Ft(this, Kt)[Kt] = [], await Ft(this, qt)[qt].exportLogs(e))
    }
}
var Zt, Gt = Vt("url"),
    Qt = Vt("serviceName"),
    en = Vt("logger"),
    tn = Vt("fetchFn");
class nn {
    constructor(e, t, n) {
        Object.defineProperty(this, Gt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, Qt, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, en, {
            writable: !0,
            value: void 0
        }), Object.defineProperty(this, tn, {
            writable: !0,
            value: void 0
        }), Ft(this, Gt)[Gt] = e.replace(/\/v1\/(logs|metrics|traces)\/?$/, ""), Ft(this, Qt)[Qt] = t, Ft(this, en)[en] = null == n ? void 0 : n.logger, Ft(this, tn)[tn] = null == n ? void 0 : n.fetchFn
    }
    async exportMetrics(e) {
        const t = {
            resourceMetrics: [{
                resource: {
                    attributes: [{
                        key: "service.name",
                        value: {
                            stringValue: Ft(this, Qt)[Qt]
                        }
                    }]
                },
                scopeMetrics: [{
                    scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: []
                    },
                    metrics: e
                }]
            }]
        };
        await this.exportTo(t, "/v1/metrics")
    }
    async exportLogs(e) {
        const t = {
            resourceLogs: [{
                resource: {
                    attributes: [{
                        key: "service.name",
                        value: {
                            stringValue: Ft(this, Qt)[Qt]
                        }
                    }]
                },
                scopeLogs: [{
                    scope: {
                        name: "open-telemetry-mini-client",
                        version: "1.1.0",
                        attributes: []
                    },
                    logRecords: e
                }]
            }]
        };
        await this.exportTo(t, "/v1/logs")
    }
    async exportTo(e, t) {
        var n;
        const o = await this.exporterFetch()(`${Ft(this,Gt)[Gt]}${t}`, {
            method: "POST",
            keepalive: !0,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(e)
        });
        if (null === (n = Ft(this, en)[en]) || void 0 === n || n.log({
                status: o.status
            }), !o.ok) {
            if (400 === o.status) {
                const e = await o.text();
                throw new on(`Invalid OpenTelemetry Data: ${e}`)
            }
            if (429 === o.status || 503 === o.status) {
                const t = await o.text(),
                    n = o.headers.get("Retry-After"),
                    r = n ? {
                        seconds: Number(n)
                    } : void 0;
                throw new on("Server did not accept data", {
                    errorData: t,
                    retryAfter: r,
                    body: e
                })
            }
            throw new on(`Server responded with ${o.status}`)
        }
    }
    exporterFetch() {
        return Ft(this, tn)[tn] || fetch
    }
}
class on extends Error {
    constructor(e, t) {
        super(e), this.metadata = void 0, this.name = "OpenTelemetryClientError", this.metadata = t
    }
}
class rn extends Jt {
    counter(e) {
        super.counter(e), this.exportMetrics()
    }
    histogram(e) {
        super.histogram(e), this.exportMetrics()
    }
    gauge(e) {
        super.gauge(e), this.exportMetrics()
    }
}
class an {
    constructor(e) {
        Zt.set(this, void 0), b(this, Zt, e, "f")
    }
    exportMetrics(e) {
        return g(this, void 0, void 0, (function*() {
            var t;
            try {
                yield y(this, Zt, "f").exportMetrics(e)
            } catch (n) {
                if (n instanceof on) {
                    const o = null === (t = n.metadata) || void 0 === t ? void 0 : t.retryAfter;
                    if (o) return void(yield new Promise((t => {
                        setTimeout((() => this.exportMetrics(e).finally(t)), 1e3 * o.seconds)
                    })))
                }
                throw n
            }
        }))
    }
    exportLogs(e) {
        return g(this, void 0, void 0, (function*() {
            var t;
            try {
                yield y(this, Zt, "f").exportLogs(e)
            } catch (n) {
                if (n instanceof on) {
                    const o = null === (t = n.metadata) || void 0 === t ? void 0 : t.retryAfter;
                    if (o) return void(yield new Promise((t => {
                        setTimeout((() => this.exportLogs(e).finally(t)), 1e3 * o.seconds)
                    })))
                }
                throw n
            }
        }))
    }
}
Zt = new WeakMap;
const sn = {
    blockedRequest: "Blocked Request",
    emptyeEventCreatedAtMs: "event_created_at_ms metadata field cannot be empty",
    errorParsingCreatedAtMs: "Error parsing: X-Monorail-Edge-Event-Created-At-Ms",
    failedToReadRequestBody: "Failed to read request body",
    incorrectContentType: "Incorrect Content-Type. Expected: application/json or text/plain",
    methodNotAllowed: "Method Not Allowed",
    noPermissionToGetURL: "Your client does not have permission to get URL",
    noResponseFromEdge: "No response from edge",
    schemaValidationError: "Schema validation error"
};

function cn() {
    {
        const e = new nn("https://otlp-http-production.shopifysvc.com/v1/metrics", "shop-js");
        return new an(e)
    }
}
const ln = ["Load failed", "Failed to fetch", "when attempting to fetch resource"],
    un = ["NotFoundError", "NotSupportedError", "ReferenceError", "SyntaxError", "TypeError"],
    dn = ["development", "spin"].includes("production");

function pn({
    metadata: e,
    onNetworkError: n
}) {
    return {
        apiKey: zt,
        appId: "shop-js",
        appVersion: "1.0.32-beta",
        onError: o => {
            var r, i, a, s, l, u;
            const d = o.exceptions[0];
            if (!d) return !1;
            const {
                errorClass: p,
                message: h
            } = d, f = "NetworkError" === p || ln.some((e => null == h ? void 0 : h.includes(e))) || (m = h, Boolean((null == m ? void 0 : m.includes("A network failure may have prevented the request from completing")) || (null == m ? void 0 : m.includes("Backpressure applied"))));
            var m;
            const _ = d.stacktrace.some((e => e.inProject));
            if (f) return n(), !1;
            if (!_) return !1;
            if (un.includes(p)) return !1;
            const v = null === (i = null === (r = c.Shopify) || void 0 === r ? void 0 : r.featureAssets) || void 0 === i ? void 0 : i["shop-js"],
                g = Boolean(v && Object.keys(v).length > 0),
                y = Array.from(t.querySelectorAll('script[src*="/shop-js/"]')).map((e => e.src));
            o.device = {
                locale: Rt.userLanguage || Rt.language,
                userAgent: Rt.userAgent,
                orientation: null === (s = null === (a = c.screen) || void 0 === a ? void 0 : a.orientation) || void 0 === s ? void 0 : s.type,
                time: (new Date).toISOString()
            }, o.metaData = Object.assign(Object.assign(Object.assign({}, o.metaData), e), {
                custom: Object.assign(Object.assign(Object.assign({}, null === (l = o.metaData) || void 0 === l ? void 0 : l.custom), e.custom), {
                    beta: !0,
                    bundleLocale: "en",
                    compactUX: !0,
                    domain: null === (u = null == c ? void 0 : c.location) || void 0 === u ? void 0 : u.hostname,
                    shopJsUrls: y,
                    shopJsFeatureAssetsExist: g
                })
            }), o.request = {
                url: c.location.href
            }
        },
        releaseStage: "production"
    }
}
class hn {
    constructor(e) {
        this.opentelClient = new rn({
            exporter: cn()
        });
        const t = pn({
            metadata: {
                custom: {
                    feature: e
                }
            },
            onNetworkError: this.handleNetworkError.bind(this)
        });
        this.client = new Dt(t), this.feature = e || "", this.leaveBreadcrumb = this.leaveBreadcrumb.bind(this), this.notify = this.notify.bind(this)
    }
    leaveBreadcrumb(e, t, n) {
        this.client ? dn ? console.log("[Bugsnag leaveBreadcrumb called]", e, t, n) : this.client.leaveBreadcrumb(e, t, n) : console.log("Bugsnag.leaveBreadcrumb() called before client creation.")
    }
    notify(e, t) {
        return g(this, void 0, void 0, (function*() {
            var n;
            this.client ? dn ? console.log("[Bugsnag notify called]", e) : this.client.notify(e, t) : null === (n = console.warn) || void 0 === n || n.call(console, "Bugsnag.notify() called before client creation.")
        }))
    }
    handleNetworkError() {
        this.opentelClient.counter({
            attributes: {
                beta: !0,
                feature: this.feature,
                error: "NetworkError"
            },
            name: "shop_js_network_error",
            value: 1
        })
    }
}
const fn = ({
    children: e
}) => {
    const {
        featureName: t
    } = St(), n = Ie((() => {
        var e;
        t || ["development", "spin"].includes("production") && (null === (e = console.warn) || void 0 === e || e.call(console, "BugsnagProvider created without a feature name."));
        const {
            client: n,
            leaveBreadcrumb: o,
            notify: r
        } = new hn(t);
        return {
            client: n,
            leaveBreadcrumb: o,
            notify: r
        }
    }), [t]);
    return le(_t.Provider, {
        value: n,
        children: e
    })
};

function mn(e) {
    return e.replace(/[-:_]([a-z])/g, ((e, t) => `${t.toUpperCase()}`))
}

function _n(e) {
    return e.replace(/([a-z0-9])([A-Z])/g, ((e, t, n) => `${t}-${n.toLowerCase()}`)).replace(/[\s_]+/g, "-")
}
class vn extends Error {
    constructor(e, t, n = a()) {
        super(e), this.name = t, this.analyticsTraceId = n;
        const o = t.replace(/[A-Z]/g, (e => `_${e.toLowerCase()}`)).replace(/^_/, "");
        this.analyticsTraceId = n, this.code = o, this.name = t
    }
}

function gn({
    children: e
}) {
    const [t] = function(e) {
        var t = ke(ue++, 10),
            n = Ee();
        return t.__ = e, de.componentDidCatch || (de.componentDidCatch = function(e, o) {
            t.__ && t.__(e, o), n[1](e)
        }), [n[0], function() {
            n[1](void 0)
        }]
    }(), {
        notify: n
    } = vt();
    return Ce((() => {
        t && n(t instanceof Error ? t : new vn(t, "UnhandledError"), {
            context: "Error in Preact tree"
        })
    }), [t, n]), le(F, {
        children: e
    })
}

function yn(e, t, n = !1) {
    let o;
    return function(...r) {
        const i = n && !o;
        "number" == typeof o && clearTimeout(o), o = setTimeout((() => {
            o = void 0, n || e.apply(this, r)
        }), t), i && e.apply(this, r)
    }
}

function bn(e) {
    return g(this, arguments, void 0, (function*(e, {
        maxRetries: t = 3,
        retryDelay: n = 1e3,
        signal: o
    } = {}) {
        const r = e => g(this, [e], void 0, (function*({
            retryCount: e = 0,
            importPromise: i,
            retryImportPath: a
        }) {
            var s;
            if (!(null == o ? void 0 : o.aborted)) try {
                return i ? yield i(): yield(s = a || "",
                    import (s))
            } catch (i) {
                if (!(i instanceof Error) || (null == o ? void 0 : o.aborted)) return;
                const a = (e => {
                    try {
                        return new c.URL(e)
                    } catch (e) {
                        return null
                    }
                })(i.message.replace("Failed to fetch dynamically imported module: ", "").trim());
                if (!a) throw i;
                if (a.searchParams.set("t", `${Number(new Date)}`), e < t - 1) {
                    if (yield new Promise((e => setTimeout(e, n))), null == o ? void 0 : o.aborted) return;
                    return r({
                        retryCount: e + 1,
                        retryImportPath: a.href
                    })
                }
                throw i
            }
        }));
        return r({
            importPromise: e
        })
    }))
}
const wn = ["en", "bg-BG", "cs", "da", "de", "el", "es", "fi", "fr", "hi", "hr-HR", "hu", "id", "it", "ja", "ko", "lt-LT", "ms", "nb", "nl", "pl", "pt-BR", "pt-PT", "ro-RO", "ru", "sk-SK", "sl-SI", "sv", "th", "tr", "vi", "zh-CN", "zh-TW"],
    xn = se({
        loading: void 0,
        locale: "en",
        translations: void 0
    });

function kn(e) {
    return wn.includes(e)
}
const En = [],
    Sn = [],
    Cn = new Map;
const On = yn((function(e) {
    let t = {};
    const n = Cn.get(e);
    Sn.forEach((e => {
        t = Object.assign(Object.assign({}, t), e)
    })), Cn.set(e, Object.assign(Object.assign({}, n), t)), En.forEach((e => e())), En.splice(0, En.length), Sn.splice(0, Sn.length)
}), 250);

function Pn({
    children: e,
    getFeatureDictionary: n,
    overrideLocale: o
}) {
    const {
        notify: r
    } = vt(), [i, a] = Ee("en"), {
        featureName: s
    } = St(), [l, u] = Ee(), d = Te((() => {
        var e;
        const n = Object.freeze([o, t.documentElement.lang, null === (e = c.Shopify) || void 0 === e ? void 0 : e.locale, ...Rt.languages].filter((e => e)));
        let r;
        for (const e of n) {
            if (kn(e)) {
                r = e;
                break
            }
            try {
                const t = new Intl.Locale(e);
                if (t.language && kn(t.language)) {
                    r = t.language;
                    break
                }
                console.error(`Unsupported locale: "${e}"`)
            } catch (t) {
                console.error(`Invalid locale: "${e}"`)
            }
        }
        return r || "en"
    }), [o]), p = Te((() => g(this, void 0, void 0, (function*() {
        if (kn(i)) {
            if (!Cn.has(i)) {
                u(!0);
                try {
                    const e = yield bn((() => g(this, void 0, void 0, (function*() {
                        return {
                            button: {
                                close: "Close"
                            }
                        }
                    }))), {
                        maxRetries: 5,
                        retryDelay: 1e3
                    });
                    Cn.set(i, e)
                } catch (e) {
                    r(new vn(`Failed to fetch translations for locale ${i}: ${e}`, "TranslationFetchError"))
                }
            }
            if (s && n) {
                u(!0);
                const e = n ? yield n(i): {};
                Sn.push(e)
            }
            En.push((() => u(!1))), On(i)
        }
    }))), [s, n, i, r]);
    Ce((() => {
        const e = d();
        a(e)
    }), [d]), Ce((() => {
        try {
            p()
        } catch (e) {
            e instanceof Error && r(e)
        }
    }), [p, i, r]);
    const h = Ie((() => ({
        loading: l,
        locale: i,
        translations: Cn
    })), [l, i]);
    return le(xn.Provider, {
        value: h,
        children: !1 === l && e
    })
}

function Mn(e, t = 200, n = !1) {
    const o = Pe(),
        r = Pe(e);
    return r.current = e, Te(((...e) => {
        var i;
        const a = n && !o.current;
        "number" == typeof o.current && clearTimeout(o.current), o.current = setTimeout(((...e) => {
            var t;
            o.current = void 0, n || null === (t = r.current) || void 0 === t || t.call(r, ...e)
        }), t, ...e), a && (null === (i = r.current) || void 0 === i || i.call(r, ...e))
    }), [t, n])
}

function In(e, t, n) {
    return (t = function(e) {
        var t = function(e, t) {
            if ("object" != typeof e || !e) return e;
            var n = e[Symbol.toPrimitive];
            if (void 0 !== n) {
                var o = n.call(e, t);
                if ("object" != typeof o) return o;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === t ? String : Number)(e)
        }(e, "string");
        return "symbol" == typeof t ? t : t + ""
    }(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function Tn(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        t && (o = o.filter((function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        }))), n.push.apply(n, o)
    }
    return n
}

function jn(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? Tn(Object(n), !0).forEach((function(t) {
            In(e, t, n[t])
        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Tn(Object(n)).forEach((function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
        }))
    }
    return e
}
const An = "http://localhost:8082",
    Nn = "https://monorail-edge.shopifysvc.com",
    Ln = "/v1/produce";

function Dn(e) {
    return void 0 !== e.schemaId
}
class Un {
    constructor(e) {
        this.producer = e
    }
    do(e, t) {
        return Dn(e) ? this.producer.produce(e) : this.producer.produceBatch(e)
    }
}

function Rn() {
    if ("undefined" != typeof crypto && crypto && "function" == typeof crypto.randomUUID) return crypto.randomUUID();
    const e = new Array(36);
    for (let t = 0; t < 36; t++) e[t] = Math.floor(16 * Math.random());
    return e[14] = 4, e[19] = e[19] &= -5, e[19] = e[19] |= 8, e[8] = e[13] = e[18] = e[23] = "-", e.map((e => e.toString(16))).join("")
}

function zn(e) {
    if (e.metadata || e.consent) return jn(jn({}, e.metadata), e.consent && {
        consent: e.consent,
        consent_provider: e.consent_provider,
        consent_version: e.consent_version
    })
}

function Fn(e, t = !0) {
    return e && Object.keys(e).length && t ? Object.keys(e).map((t => ({
        [$n(t)]: e[t]
    }))).reduce(((e, t) => jn(jn({}, e), t))) : e
}

function $n(e) {
    return e.split(/(?=[A-Z])/).join("_").toLowerCase()
}

function Vn(e) {
    return e.events.map((e => {
        let t = !0,
            n = !0;
        e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (t = Boolean(e.options.convertEventCase)), e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertMetaDataCase") && (n = Boolean(e.options.convertMetaDataCase));
        const o = zn(e);
        return jn({
            schema_id: e.schemaId,
            payload: Fn(e.payload, t)
        }, o && {
            metadata: Fn(o, n)
        })
    }))
}
class Hn extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), In(this, "name", "MonorailUnableToProduceError"), this.response = e, Object.setPrototypeOf(this, Hn.prototype)
    }
}
class Bn extends Error {
    constructor(e) {
        super(`Response not from Monorail Edge. Response received: ${JSON.stringify(e)}`), In(this, "name", "MonorailInterceptedProduceError"), this.response = e, Object.setPrototypeOf(this, Bn.prototype)
    }
}
class Wn extends Error {
    constructor(e) {
        super(`Error producing to the Monorail Edge. Response received: ${JSON.stringify(e)}`), In(this, "name", "MonorailBatchProduceError"), Object.setPrototypeOf(this, Wn.prototype), this.response = e
    }
}
class qn extends Error {
    constructor(e, t) {
        super(`Error completing request. A network failure may have prevented the request from completing. Error: ${e}. Schemas: ${Array.from(new Set(t)).join(", ")}`), In(this, "name", "MonorailRequestError"), Object.setPrototypeOf(this, qn.prototype)
    }
}
class Xn {
    static withEndpoint(e) {
        return new Xn(`https://${new URL(e).hostname}`)
    }
    constructor(e = An, t = {}) {
        var n, o;
        if (this.edgeDomain = e, this.optionsOrKeepalive = t, "boolean" == typeof t) return this.keepalive = t, void(this.detectInterceptedErrorEnabled = !1);
        this.keepalive = null !== (n = t.keepalive) && void 0 !== n && n, this.detectInterceptedErrorEnabled = null !== (o = t.detectInterceptedErrorEnabled) && void 0 !== o && o
    }
    async produceBatch(e) {
        const t = {
            events: Vn(e),
            metadata: Fn(e.metadata)
        };
        let n;
        try {
            n = await fetch(this.produceBatchEndpoint(), {
                method: "post",
                headers: Yn(e.metadata),
                body: JSON.stringify(t),
                keepalive: this.keepalive
            })
        } catch (t) {
            throw new qn(t, e.events.map((e => e.schemaId)))
        }
        if (207 === n.status) {
            const e = await n.json();
            throw new Wn(e)
        }
        if (!n.ok) {
            if (!Boolean(n.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new Bn({
                status: n.status,
                message: await n.text()
            });
            throw new Hn({
                status: n.status,
                message: await n.text()
            })
        }
        return {
            status: n.status
        }
    }
    async produce(e) {
        let t, n = !0;
        e && e.options && Object.prototype.hasOwnProperty.call(e.options, "convertEventCase") && (n = Boolean(e.options.convertEventCase));
        try {
            t = await async function({
                endpoint: e,
                event: t,
                keepalive: n
            }) {
                var o, r;
                const i = t.metadata ? {
                        clientMessageId: null === (o = t.metadata) || void 0 === o ? void 0 : o.clientMessageId,
                        eventCreatedAtMs: null === (r = t.metadata) || void 0 === r ? void 0 : r.eventCreatedAtMs
                    } : {},
                    a = zn(jn(jn({}, t), {}, {
                        metadata: i
                    }));
                return fetch(null != e ? e : Nn + Ln, {
                    method: "post",
                    headers: Yn(t.metadata),
                    body: JSON.stringify(jn({
                        schema_id: t.schemaId,
                        payload: t.payload
                    }, a && {
                        metadata: Fn(a, !0)
                    })),
                    keepalive: n
                })
            }({
                endpoint: this.produceEndpoint(),
                keepalive: this.keepalive,
                event: jn(jn({}, e), {}, {
                    payload: Fn(e.payload, n)
                })
            })
        } catch (t) {
            throw new qn(t, [e.schemaId])
        }
        if (!t) throw new Hn({
            message: "No response from edge"
        });
        if (!t.ok) {
            if (!Boolean(t.headers.get("x-request-id")) && this.detectInterceptedErrorEnabled) throw new Bn({
                status: t.status,
                message: await t.text()
            });
            throw new Hn({
                status: t.status,
                message: await t.text()
            })
        }
        return {
            status: t.status
        }
    }
    produceBatchEndpoint() {
        return this.edgeDomain + "/unstable/produce_batch"
    }
    produceEndpoint() {
        return this.edgeDomain + Ln
    }
}

function Yn(e) {
    const t = {
        "Content-Type": "application/json; charset=utf-8",
        "X-Monorail-Edge-Event-Created-At-Ms": (e && e.eventCreatedAtMs || Date.now()).toString(),
        "X-Monorail-Edge-Event-Sent-At-Ms": Date.now().toString(),
        "X-Monorail-Edge-Client-Message-Id": (e && e.clientMessageId || Rn()).toString()
    };
    return e && e.userAgent && (t["User-Agent"] = e.userAgent), e && e.remoteIp && (t["X-Forwarded-For"] = e.remoteIp), e && e.deviceInstallId && (t["X-Monorail-Edge-Device-Install-Id"] = e.deviceInstallId), e && e.client && (t["X-Monorail-Edge-Client"] = e.client), e && e.clientOs && (t["X-Monorail-Edge-Client-OS"] = e.clientOs), t
}
class Kn {
    static printWelcomeMessage(e) {
        console.log(`%c👋 from Monorail%c\n\nWe've noticed that you're${e?"":" not"} running in debug mode. As such, we will ${e?"produce":"not produce"} Monorail events to the console. \n\nIf you want Monorail events to ${e?"stop":"start"} appearing here, %cset debugMode=${(!e).toString()}%c, for the Monorail Log Producer in your code.`, "font-size: large;", "font-size: normal;", "font-weight: bold;", "font-weight: normal;")
    }
    constructor(e) {
        this.sendToConsole = e, e && Kn.printWelcomeMessage(e)
    }
    async produce(e) {
        return this.sendToConsole && console.log("Monorail event produced", e), new Promise((t => {
            t(e)
        }))
    }
    produceBatch(e) {
        return this.sendToConsole && console.log("Monorail Batch event produced", e), new Promise((t => {
            t(e)
        }))
    }
}
class Jn {
    constructor(e) {
        this.version = e.version
    }
}
class Zn {
    constructor(e) {
        if ((null == e ? void 0 : e.provider) instanceof Jn == !1) throw new Gn("ConsentTrackingMiddleware requires an instance of ConsentTrackingProvider");
        this.provider = e.provider
    }
    async do(e, t) {
        if (Dn(e)) return t(await this.provider.annotateEvent(e));
        const n = await Promise.all(e.events.map((e => this.provider.annotateEvent(e))));
        return t(jn(jn({}, e), {}, {
            events: n
        }))
    }
}
class Gn extends Error {
    constructor(e) {
        super(e), Object.setPrototypeOf(this, Gn.prototype)
    }
}

function Qn(e, t) {
    var n, o, r;
    if (e === t) return !0;
    if (typeof e != typeof t) return !1;
    if ("function" == typeof e && void 0 !== (null === (n = e.toString) || void 0 === n ? void 0 : n.call(e)) && (null === (o = e.toString) || void 0 === o ? void 0 : o.call(e)) === (null === (r = t.toString) || void 0 === r ? void 0 : r.call(t))) return !0;
    if (e && t && "object" == typeof e && "object" == typeof t) {
        if (e.constructor !== t.constructor) return !1;
        let n, o;
        const r = Object.keys(e);
        if (Array.isArray(e)) {
            if (n = e.length, n !== t.length) return !1;
            for (o = n; 0 != o--;)
                if (!Qn(e[o], t[o])) return !1;
            return !0
        }
        if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === t.valueOf();
        if (e.toString !== Object.prototype.toString) return e.toString() === t.toString();
        if (n = r.length, n !== Object.keys(t).length) return !1;
        for (o = n; 0 != o--;)
            if (!Object.prototype.hasOwnProperty.call(t, r[o])) return !1;
        for (o = n; 0 != o--;) {
            const n = r[o];
            if (!Qn(e[n], t[n])) return !1
        }
        return !0
    }
    return e != e && t != t
}
const eo = "",
    to = "1",
    no = "0",
    oo = "p",
    ro = "a",
    io = "m",
    ao = "t",
    so = "m",
    co = "a",
    lo = "p",
    uo = "s";

function po(e) {
    try {
        return decodeURIComponent(e)
    } catch (e) {
        return ""
    }
}

function ho(e, t = !1) {
    const n = document.cookie ? document.cookie.split("; ") : [];
    for (let t = 0; t < n.length; t++) {
        const [o, r] = n[t].split("=");
        if (e === po(o)) {
            return po(r)
        }
    }
    if (t && "_tracking_consent" === e && !window.localStorage.getItem("tracking_consent_fetched")) {
        if ("undefined" != typeof __CtaTestEnv__ && "true" === __CtaTestEnv__) return;
        return console.debug("_tracking_consent missing"),
            function(e = "/") {
                const t = new XMLHttpRequest;
                t.open("HEAD", e, !1), t.withCredentials = !0, t.send()
            }(), window.localStorage.setItem("tracking_consent_fetched", "true"), ho(e, !1)
    }
}

function fo() {
    const e = new URLSearchParams(window.location.search).get("_cs") || ho("_tracking_consent");
    if (void 0 !== e) return function(e) {
        const t = e.slice(0, 1);
        if ("{" == t) return function(e) {
            var t;
            let n;
            try {
                n = JSON.parse(e)
            } catch {
                return
            }
            if ("2.1" !== n.v) return;
            if (null === (t = n.con) || void 0 === t || !t.CMP) return;
            return n
        }(e);
        if ("3" == t) return function(e) {
            const t = e.slice(1).split("_"),
                [n, o, r, i, a] = t;
            let s, c;
            try {
                s = t[5] ? JSON.parse(t.slice(5).join("_")) : void 0
            } catch {}
            if (a) {
                const e = a.replace(/\*/g, "/").replace(/-/g, "+"),
                    t = Array.from(atob(e)).map((e => e.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                c = [8, 13, 18, 23].reduce(((e, t) => e.slice(0, t) + "-" + e.slice(t)), t)
            }

            function l(e) {
                const t = n.split(".")[0];
                return t.includes(e.toLowerCase()) ? no : t.includes(e.toUpperCase()) ? to : eo
            }

            function u(e) {
                return n.includes(e.replace("t", "s").toUpperCase())
            }
            return {
                v: "3",
                con: {
                    CMP: {
                        [co]: l(co),
                        [lo]: l(lo),
                        [so]: l(so),
                        [uo]: l(uo)
                    }
                },
                region: o || "",
                cus: s,
                purposes: {
                    [ro]: u(ro),
                    [oo]: u(oo),
                    [io]: u(io),
                    [ao]: u(ao)
                },
                sale_of_data_region: "t" == i,
                display_banner: "t" == r,
                consent_id: c
            }
        }(e);
        return
    }(e)
}

function mo(e) {
    const t = fo();
    if (!t || !t.purposes) return !0;
    const n = t.purposes[e];
    return "boolean" != typeof n || n
}

function _o() {
    return mo(ro)
}

function vo() {
    return mo(oo)
}

function go() {
    return mo(io)
}

function yo() {
    return mo(ao)
}

function bo() {
    const e = [];
    return _o() && e.push("analytics"), go() && e.push("marketing"), yo() && e.push("sale_of_data"), vo() && e.push("preferences"), e
}
class wo extends Jn {
    async annotateEvent(e) {
        return Promise.resolve(function(e, t) {
            if ("v1" === t) {
                const n = bo();
                return { ...e,
                    metadata: { ...null == e ? void 0 : e.metadata,
                        consent: n,
                        consent_provider: "consent-tracking-api",
                        consent_version: t
                    }
                }
            }
            throw new xo(t || "unknown")
        }(e, this.version))
    }
}
class xo extends Error {
    constructor(e) {
        super(`Version ${e} is not supported by the consent-tracking-api provider`), this.name = "MonorailConsentTrackingApiProviderVersionError", Object.setPrototypeOf(this, xo.prototype)
    }
}

function ko() {
    var e;
    const n = null === (e = t.querySelector("script#shop-js-analytics")) || void 0 === e ? void 0 : e.innerHTML;
    return n ? JSON.parse(n) : {}
}

function Eo() {
    return g(this, void 0, void 0, (function*() {
        let e;
        return Promise.race([new Promise((t => e = setTimeout((() => t({})), 1e4))), new Promise((e => {
            var t, n, o;
            const r = (null === (n = null === (t = c.ShopifyAnalytics) || void 0 === t ? void 0 : t.lib) || void 0 === n ? void 0 : n.ready) || (null === (o = c.analytics) || void 0 === o ? void 0 : o.ready);
            null == r || r((() => {
                var t, n, o;
                const r = (null === (n = null === (t = c.ShopifyAnalytics) || void 0 === t ? void 0 : t.lib) || void 0 === n ? void 0 : n.trekkie) || (null === (o = c.analytics) || void 0 === o ? void 0 : o.trekkie);
                e(r.defaultAttributes)
            }))
        }))]).finally((() => clearTimeout(e)))
    }))
}

function So(...e) {
    return g(this, void 0, void 0, (function*() {
        var t;
        if (!c.ShopifyAnalytics && !c.analytics) return {};
        let n;
        Boolean(null === (t = c.trekkie) || void 0 === t ? void 0 : t.ready) ? n = Eo() : (c.trekkie = c.trekkie || [], n = new Promise((e => {
            c.trekkie.push(["ready", () => {
                e(Eo())
            }])
        })));
        const o = yield n;
        return e.reduce(((e, t) => {
            const n = o[t];
            return void 0 !== n && (e[t] = n), e
        }), {})
    }))
}
var Co;
const Oo = "unspecified",
    Po = function() {
        const e = new wo({
            version: "v1"
        });
        return [new Zn({
            provider: e
        })]
    }(),
    Mo = class e {
        static createLogProducer(t) {
            return new e(new Kn(t.debugMode), t.middleware || [])
        }
        static createHttpProducerWithEndpoint(t, n = []) {
            return new e(Xn.withEndpoint(t), n)
        }
        static createHttpProducer(t) {
            return new e(t.production ? new Xn(Nn, t.options) : new Xn(An, t.options), t.middleware || [])
        }
        static buildMiddlewareChain(e, t = 0) {
            return t === e.length ? this.identityFn : n => e[t].do(n, this.buildMiddlewareChain(e, t + 1))
        }
        constructor(t, n) {
            this.producer = t, this.middleware = n, this.executeChain = e.buildMiddlewareChain(this.middleware.concat(new Un(t)))
        }
        produce(e) {
            return e.metadata = jn({
                eventCreatedAtMs: Date.now(),
                clientMessageId: Rn()
            }, e.metadata), this.executeChain(e)
        }
        produceBatch(e) {
            return this.executeChain(e)
        }
    }.createHttpProducer({
        production: !0,
        middleware: Po
    });
class Io {
    constructor({
        analyticsData: e,
        devMode: t = !1,
        notify: n,
        recordCounter: o
    }) {
        var r;
        Co.set(this, void 0), this.featureInitializationEventAlreadyEmitted = !1, this.trackedPageImpressions = new Set, b(this, Co, Object.assign(Object.assign({}, e), {
            flowVersion: null !== (r = e.flowVersion) && void 0 !== r ? r : Oo
        }), "f"), this.devMode = t, this.notify = n, this.recordCounter = o, this.clearTrackedPageImpressions = this.clearTrackedPageImpressions.bind(this), this.produceMonorailEvent = this.produceMonorailEvent.bind(this), this.trackFeatureInitialization = this.trackFeatureInitialization.bind(this), this.trackModalStateChange = this.trackModalStateChange.bind(this), this.trackPageImpression = this.trackPageImpression.bind(this), this.trackUserAction = this.trackUserAction.bind(this)
    }
    get analyticsData() {
        return y(this, Co, "f")
    }
    set analyticsData(e) {
        const t = Object.assign(Object.assign({}, y(this, Co, "f")), e);
        Qn(t, y(this, Co, "f")) || b(this, Co, t, "f")
    }
    clearTrackedPageImpressions() {
        this.trackedPageImpressions.clear()
    }
    produceMonorailEvent({
        event: e,
        onError: t,
        trekkieAttributes: n
    }) {
        this.devMode || (!n || Object.keys(n).length ? (e.payload = Object.assign(e.payload, n), Mo.produce(e).catch((e => {
            var n;
            if (null == t || t(e), function(e) {
                    var t, n, o, r, i;
                    return !(e instanceof qn || e instanceof Hn || (null === (t = null == e ? void 0 : e.message) || void 0 === t ? void 0 : t.includes("Invalid agent:")) || (null === (n = null == e ? void 0 : e.message) || void 0 === n ? void 0 : n.includes(".text is not a function")) || (null === (o = null == e ? void 0 : e.message) || void 0 === o ? void 0 : o.match(/Cannot read properties of (null|undefined) \(reading 'status'\)/)) || (null === (r = null == e ? void 0 : e.message) || void 0 === r ? void 0 : r.match(/(null|undefined) is not an object \(evaluating '[a-zA-Z]+\.status'\)/)) || (null === (i = null == e ? void 0 : e.message) || void 0 === i ? void 0 : i.match(/[a-zA-Z]+ is (null|undefined)/)))
                }(e)) {
                const t = e instanceof Error ? e : new vn(String(e), "MonorailProducerError");
                if (null === (n = this.notify) || void 0 === n || n.call(this, t), this.recordCounter) {
                    const e = function(e) {
                        const t = Object.values(sn).find((([t, n]) => e.message.includes(n)));
                        return (null == t ? void 0 : t[0]) || "otherErrors"
                    }(t);
                    this.recordCounter("shop_js_monorail_producer_error", {
                        attributes: {
                            error: e
                        }
                    })
                }
            }
        }))) : null == t || t({
            message: "trekkie attributes are empty"
        }))
    }
    trackFeatureInitialization() {
        return g(this, void 0, void 0, (function*() {
            var e, t, n, o;
            const {
                analyticsTraceId: r,
                apiKey: i,
                checkoutToken: a,
                flow: s,
                flowVersion: l = Oo,
                shopId: u,
                source: d = "unspecified",
                uxMode: p
            } = this.analyticsData;
            if (!s) return;
            this.featureInitializationEventAlreadyEmitted && (null === (e = this.notify) || void 0 === e || e.call(this, new vn(`Feature Initialize Event already emitted once for the feature ${s}`, "MonorailLogicError", r)));
            const h = ko(),
                f = null !== (t = null == h ? void 0 : h.pageType) && void 0 !== t ? t : "",
                m = yield So("customerId", "isPersistentCookie", "path", "uniqToken", "visitToken"), _ = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, i && {
                    apiKey: i
                }), a && {
                    checkoutToken: a
                }), u && {
                    shopId: u
                }), m), {
                    analyticsTraceId: r,
                    flow: s,
                    flowVersion: l,
                    sdkVersion: "1.0.32-beta",
                    shopPermanentDomain: null !== (o = null === (n = c.Shopify) || void 0 === n ? void 0 : n.shop) && void 0 !== o ? o : "",
                    source: d,
                    storefrontPageType: f,
                    uxMode: p
                });
            this.featureInitializationEventAlreadyEmitted = !0, this.produceMonorailEvent({
                event: {
                    schemaId: "shopify_pay_login_with_shop_sdk_feature_initialize/1.1",
                    payload: _
                }
            })
        }))
    }
    trackModalStateChange({
        currentState: e,
        dismissMethod: t,
        reason: n
    }) {
        var o;
        const {
            analyticsTraceId: r,
            checkoutToken: i,
            flow: a,
            flowVersion: s = "unspecified"
        } = this.analyticsData;
        a && (this.produceMonorailEvent({
            event: {
                schemaId: "shop_identity_modal_state_change/1.4",
                payload: {
                    analyticsTraceId: r,
                    checkoutToken: i,
                    currentState: e,
                    dismissMethod: t,
                    flow: a,
                    flowVersion: s,
                    previousState: this.previousModalState,
                    reason: n,
                    zoom: `${null===(o=c.visualViewport)||void 0===o?void 0:o.scale}`
                }
            }
        }), this.previousModalState = e)
    }
    trackPageImpression(e) {
        return g(this, arguments, void 0, (function*({
            allowDuplicates: e = !1,
            analyticsTraceId: t = this.analyticsData.analyticsTraceId,
            flow: n = this.analyticsData.flow,
            page: o,
            shopAccountUuid: r
        }) {
            var i, a, s;
            if (!e && this.trackedPageImpressions.has(o)) return;
            const {
                apiKey: l,
                checkoutToken: u,
                flowVersion: d = Oo
            } = this.analyticsData;
            if (!n) return;
            this.trackedPageImpressions.add(o);
            const p = ko(),
                h = null !== (i = null == p ? void 0 : p.pageType) && void 0 !== i ? i : "",
                f = yield So("customerId", "isPersistentCookie", "path", "uniqToken", "visitToken"), m = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, l && {
                    apiKey: l
                }), u && {
                    checkoutToken: u
                }), r && {
                    shopAccountUuid: r
                }), f), {
                    analyticsTraceId: t,
                    flow: n,
                    flowVersion: d,
                    pageName: o,
                    sdkVersion: "1.0.32-beta",
                    shopPermanentDomain: null !== (s = null === (a = c.Shopify) || void 0 === a ? void 0 : a.shop) && void 0 !== s ? s : "",
                    storefrontPageType: h
                });
            this.produceMonorailEvent({
                event: {
                    payload: m,
                    schemaId: "shopify_pay_login_with_shop_sdk_page_impressions/3.3"
                },
                onError: () => {
                    this.trackedPageImpressions.delete(o)
                },
                trekkieAttributes: f
            })
        }))
    }
    trackUserAction({
        userAction: e
    }) {
        var t, n;
        const {
            analyticsTraceId: o,
            apiKey: r,
            checkoutToken: i,
            checkoutVersion: a,
            flow: s,
            flowVersion: l = Oo,
            shopId: u
        } = this.analyticsData;
        if (!s) return;
        const d = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, r && {
            apiKey: r
        }), i && {
            checkoutToken: i
        }), a && {
            checkoutVersion: a
        }), u && {
            shopId: u
        }), {
            analyticsTraceId: o,
            flow: s,
            flowVersion: l,
            sdkVersion: "1.0.32-beta",
            shopPermanentDomain: null !== (n = null === (t = c.Shopify) || void 0 === t ? void 0 : t.shop) && void 0 !== n ? n : "",
            userAction: e
        });
        this.produceMonorailEvent({
            event: {
                schemaId: "shopify_pay_login_with_shop_sdk_user_actions/2.2",
                payload: d
            }
        })
    }
}
Co = new WeakMap;
const To = ({
    analyticsContext: e = "loginWithShop",
    apiKey: t,
    checkoutVersion: n,
    checkoutToken: o,
    children: r,
    flow: i,
    flowVersion: a,
    shopId: s = 0,
    shopPermanentDomain: c,
    source: l,
    uxMode: u
}) => {
    const {
        notify: d
    } = vt(), {
        recordCounter: p
    } = kt(), {
        devMode: h,
        instanceId: f
    } = St(), m = Pe({
        analyticsContext: e,
        analyticsTraceId: f,
        apiKey: t,
        checkoutVersion: n,
        checkoutToken: o,
        flow: i,
        flowVersion: a,
        shopId: s,
        shopPermanentDomain: c,
        source: l,
        uxMode: u
    }), _ = Ie((() => new Io({
        analyticsData: m.current,
        devMode: h,
        notify: d,
        recordCounter: p
    })), [h, d, p]);
    _.analyticsData = Object.assign(Object.assign({}, m.current), {
        analyticsTraceId: f,
        analyticsContext: e,
        apiKey: t,
        checkoutVersion: n,
        checkoutToken: o,
        flow: i,
        flowVersion: a,
        shopId: s,
        shopPermanentDomain: c,
        source: l,
        uxMode: u
    }), Ce((() => () => {
        _.clearTrackedPageImpressions()
    }), [_]);
    const v = Mn((() => {
        _.trackFeatureInitialization()
    }), 100);
    Ce((() => {
        v()
    }), [v]);
    const g = Ie((() => ({
        analyticsData: _.analyticsData,
        getTrekkieAttributes: So,
        produceMonorailEvent: _.produceMonorailEvent,
        trackModalStateChange: _.trackModalStateChange,
        trackPageImpression: _.trackPageImpression,
        trackUserAction: _.trackUserAction
    })), [_.analyticsData, _.produceMonorailEvent, _.trackModalStateChange, _.trackPageImpression, _.trackUserAction]);
    return le(bt.Provider, {
        value: g,
        children: r
    })
};

function jo({
    children: e
}) {
    const {
        featureName: t
    } = St(), n = Ie((() => new rn({
        exporter: cn()
    })), []), o = Te((({
        body: e,
        attributes: o
    }) => {
        n.log({
            body: e,
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, o)
        })
    }), [n, t]), r = Te(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1
        } = o;
        n.counter({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), i = Te(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1
        } = o;
        n.gauge({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), a = Te(((e, o = {}) => {
        const {
            attributes: r,
            unit: i,
            value: a = 1,
            bounds: s
        } = o;
        n.histogram({
            attributes: Object.assign({
                beta: !0,
                feature: t
            }, r),
            bounds: s,
            name: e,
            value: a,
            unit: i
        })
    }), [n, t]), s = Ie((() => ({
        client: n,
        log: o,
        recordCounter: r,
        recordGauge: i,
        recordHistogram: a
    })), [n, o, r, i, a]);
    return le(xt.Provider, {
        value: s,
        children: e
    })
}
const Ao = ({
    children: e,
    devMode: n = !1,
    element: o,
    featureName: r,
    getFeatureDictionary: i,
    metricsEnabled: s = !0,
    monorailProps: c,
    overrideLocale: l
}) => {
    Ce((() => {
        if (t.querySelector('style[data-description="shop-js-font-faces"]')) return;
        const e = t.createElement("style");
        e.dataset.description = "shop-js-font-faces", e.appendChild(t.createTextNode("\n@font-face {\n  font-family: 'SuisseIntl';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/SuisseIntl-Book.otf')\n    format('opentype');\n  font-style: normal;\n  font-weight: 450;\n  font-display: fallback;\n}\n\n@font-face {\n  font-family: 'SuisseIntl';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/SuisseIntl-Medium.otf')\n    format('opentype');\n  font-style: normal;\n  font-weight: 500;\n  font-display: fallback;\n}\n\n@font-face {\n  font-family: 'SuisseIntl';\n  src: url('https://cdn.shopify.com/shop-assets/static_uploads/shoplift/SuisseIntl-SemiBold.otf')\n    format('opentype');\n  font-style: normal;\n  font-weight: 600;\n  font-display: fallback;\n}")), t.head.appendChild(e)
    }), []);
    const u = Ie((() => a()), []);
    Ce((() => {
        o && o.setAttribute("data-instance-id", u)
    }), [o, u]);
    const d = Ie((() => ({
        devMode: n,
        element: o,
        featureName: r,
        instanceId: u
    })), [n, o, r, u]);
    return le(Et.Provider, {
        value: d,
        children: le(No, {
            enabled: s,
            monorailProps: c,
            children: le(Pn, {
                getFeatureDictionary: i,
                overrideLocale: l,
                children: le(Pt, {
                    children: e
                })
            })
        })
    })
};

function No({
    children: e,
    enabled: t = !0,
    monorailProps: n
}) {
    return t ? le(fn, {
        children: le(gn, {
            children: le(jo, {
                children: le(To, Object.assign({}, n, {
                    children: e
                }))
            })
        })
    }) : le(F, {
        children: e
    })
}
const Lo = () => je(xn),
    Do = ["string", void 0],
    Uo = () => {
        const {
            locale: e,
            translations: t
        } = Lo();
        return {
            locale: e,
            translate: (n, o) => {
                const r = n.split(".");
                if (!t) throw new ReferenceError;
                const i = o || {},
                    {
                        count: a,
                        defaultValue: s
                    } = i,
                    c = v(i, ["count", "defaultValue"]);
                let l = t.get(e);
                if (!l && (null == o ? void 0 : o.defaultValue)) return o.defaultValue;
                try {
                    for (const e of r) switch (typeof l) {
                        case "object":
                            l = l[e];
                            break;
                        case "string":
                        case "undefined":
                            throw new ReferenceError
                    }
                    if (void 0 === l) throw new ReferenceError;
                    if ("string" != typeof t && a) {
                        let e = 1 === a ? "one" : "other";
                        0 === a && "string" != typeof t && "zero" in t && (e = "zero"), l = l[e]
                    }
                    if ("string" != typeof l) throw new ReferenceError;
                    let e = !1;
                    const n = Object.keys(c),
                        o = l.split(new RegExp(`({${n.join("}|{")}})`, "g"));
                    return n.forEach((t => {
                        e || Do.includes(typeof c[t]) || (e = !0), o.forEach(((e, n) => {
                            e === `{${t}}` && (o[n] = c[t])
                        }))
                    })), e ? le(F, {
                        children: o
                    }) : o.join("")
                } catch (e) {
                    return s || n
                }
            }
        }
    };

function Ro(e) {
    const {
        element: t
    } = St(), {
        loading: n
    } = Lo();
    Ce((() => {
        if (t && !1 === n) return Object.entries(e).forEach((([e, n]) => {
            t.addEventListener(e, n)
        })), null == t || t._eventListenerReadyPromiseResolve(), () => {
            Object.entries(e).forEach((([e, n]) => {
                null == t || t.removeEventListener(e, n)
            }))
        }
    }), [t, n, e])
}
const zo = c.HTMLElement,
    Fo = e => {
        const t = c.HTMLElement;
        c.HTMLElement = zo;
        const n = e();
        return c.HTMLElement = t, n
    },
    $o = e => Fo((() => t.createElement(e))),
    Vo = {
        boolean: {
            stringify: e => "" === e ? "true" : e ? /^[ty1-9]/i.test(e).toString() : "false",
            parse: (e, t, n) => "" === e || (e ? /^[ty1-9]/i.test(e) : n.hasAttribute(t) && null === e)
        },
        function: {
            stringify: e => "function" == typeof e ? e.name.replace("bound ", "") : "string" == typeof e ? e.replace("bound ", "") : e,
            parse: (e, t, n) => {
                if (!e) return null;
                const o = "undefined" != typeof window ? window[e] : "undefined" != typeof global ? global[e] : void 0;
                return "function" == typeof o ? o.bind(n) : void 0
            }
        },
        number: {
            stringify: e => `${e}`,
            parse: e => {
                if (e) return parseFloat(e)
            }
        },
        string: {
            stringify: e => e,
            parse: e => {
                if (e) return e
            }
        }
    };

function Ho(e, {
    methods: t,
    name: n,
    props: o,
    shadow: r
}) {
    var i;
    if ("undefined" == typeof window) return;
    const {
        notify: a
    } = new hn(n);

    function s() {
        const t = (e => Fo((() => Reflect.construct(HTMLElement, [], e))))(s);
        if (t._eventListenerReadyPromise = new Promise((e => {
                t._eventListenerReadyPromiseResolve = e
            })), t._vdomComponent = e, t._root = r ? t.attachShadow({
                mode: r
            }) : t, r) {
            const e = new CSSStyleSheet;
            e.replace(gt), t._root.adoptedStyleSheets = [e]
        }
        return t
    }
    const c = new Map;
    Object.entries(o || {}).forEach((([e, t]) => {
        const n = _n(e);
        c.set(n, {
            attribute: n,
            preactProp: e,
            type: t
        })
    }));
    const l = Array.from(c.values()).map((({
        attribute: e
    }) => e));

    function u(e) {
        this.getChildContext = () => e.context;
        const {
            context: t,
            children: n
        } = e;
        return ae(n, v(e, ["context", "children"]))
    }

    function d(e) {
        return R("slot", Object.assign({}, e))
    }

    function p(e, t) {
        if (3 === e.nodeType) return e.data;
        if (1 !== e.nodeType) return null;
        const n = {},
            o = [],
            {
                childNodes: r
            } = e;
        c.forEach((({
            attribute: t,
            preactProp: o,
            type: r
        }) => {
            const i = Vo[r],
                a = e.getAttribute(t);
            let s = a;
            ("boolean" === r || a) && (s = i.parse(a, t, e)), null !== s && (n[t] = s, n[o] = s)
        }));
        for (const e of r) {
            const t = p(e, null);
            o.push(t)
        }
        const i = t ? R(d, null, o) : o;
        return R(t, n, i)
    }
    s.prototype = Object.create(HTMLElement.prototype), s.prototype.constructor = s, s.observedAttributes = l, s.prototype.attributeChangedCallback = function(e, t, n) {
        if (!this._vdom) return;
        const o = c.get(e);
        if (!o) return;
        const {
            preactProp: r,
            type: i
        } = o, a = Vo[i], s = {};
        if (n || "boolean" !== i) {
            if (i && n) {
                const t = a.parse(n, e, this);
                s[e] = t, s[r] = t
            }
        } else {
            const t = a.parse(n, e, this);
            s[e] = t, s[r] = t
        }
        this._vdom = ae(this._vdom, s), ie(this._vdom, this._root)
    }, s.prototype.connectedCallback = function() {
        const e = new CustomEvent("_preact", {
            detail: {},
            bubbles: !0,
            cancelable: !0
        });
        this.dispatchEvent(e);
        const t = e.detail.context;
        this._vdom = R(u, Object.assign(Object.assign({}, this._props), {
            context: t,
            element: this
        }), p(this, this._vdomComponent)), ie(this._vdom, this._root)
    }, null == t || t.forEach((e => {
        s.prototype[e] = function(t) {
            this._eventListenerReadyPromise.then((() => {
                this.dispatchEvent(new CustomEvent(e, {
                    detail: t
                }))
            })).catch((() => {
                a(new vn(`Custom element ${n}: Error listening for methods`, "CustomElementMethodListenerError"))
            }))
        }
    })), s.prototype.disconnectedCallback = function() {
        ie(this._vdom = null, this._root)
    }, c.forEach((({
        attribute: e,
        type: t
    }) => {
        const n = Vo[t];
        Object.defineProperty(s.prototype, e, {
            get() {
                return this._vdom && this._vdom.props ? this._vdom.props[e] : null
            },
            set(o) {
                let r = o;
                this._vdom ? this.attributeChangedCallback(e, null, o) : (("boolean" === t || o) && (r = n.parse(o, e, this)), this._props || (this._props = {}), this._props[e] = r, this.connectedCallback()), this.setAttribute(e, n.stringify(r))
            }
        })
    }));
    const h = customElements.get(n);
    if (!h) return null === (i = Reflect.defineProperty) || void 0 === i || i.call(Reflect, s, "componentVersion", {
        value: "preact"
    }), ((e, t) => {
        Fo((() => {
            customElements.define(e, t)
        }))
    })(n, s); {
        const e = h.componentVersion;
        e && "preact" !== e && a(new vn(`Custom element ${n} already registered by ${e}`, "CustomElementAlreadyDefinedError"))
    }
}

function Bo(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}
var Wo, qo = {
    exports: {}
};
/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
var Xo, Yo = (Wo || (Wo = 1, Xo = qo, function() {
        var e = {}.hasOwnProperty;

        function t() {
            for (var e = "", t = 0; t < arguments.length; t++) {
                var r = arguments[t];
                r && (e = o(e, n(r)))
            }
            return e
        }

        function n(n) {
            if ("string" == typeof n || "number" == typeof n) return n;
            if ("object" != typeof n) return "";
            if (Array.isArray(n)) return t.apply(null, n);
            if (n.toString !== Object.prototype.toString && !n.toString.toString().includes("[native code]")) return n.toString();
            var r = "";
            for (var i in n) e.call(n, i) && n[i] && (r = o(r, i));
            return r
        }

        function o(e, t) {
            return t ? e ? e + " " + t : e + t : e
        }
        Xo.exports ? (t.default = t, Xo.exports = t) : window.classNames = t
    }()), qo.exports),
    Ko = Bo(Yo);

function Jo({
    className: e
}) {
    return le("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 50 50",
        children: [le("path", {
            fill: "currentColor",
            d: "M50 12.5C50 5.597 44.403 0 37.5 0h-25C5.597 0 0 5.597 0 12.5v25C0 44.403 5.597 50 12.5 50h25C44.403 50 50 44.403 50 37.5v-25z"
        }), le("path", {
            fill: "#fff",
            d: "M14.551 17.49v12.2a.09.09 0 0 0 .092.092h2.249a.091.091 0 0 0 .091-.091v-5.203c0-1.007.676-1.726 1.761-1.726 1.189 0 1.484.969 1.484 1.96v4.969a.09.09 0 0 0 .027.065.09.09 0 0 0 .066.026h2.24a.092.092 0 0 0 .09-.091v-5.266c0-.18-.007-.357-.022-.53a4.681 4.681 0 0 0-.416-1.628c-.52-1.084-1.505-1.785-2.989-1.785a2.989 2.989 0 0 0-2.336 1.195l-.056.066V17.49a.092.092 0 0 0-.091-.092h-2.098a.092.092 0 0 0-.092.092zm-3.441 6.862s-1.088-.256-1.489-.357c-.4-.102-1.101-.328-1.101-.848 0-.544.562-.696 1.138-.696.576 0 1.21.137 1.261.771a.09.09 0 0 0 .09.08l2.108-.008a.091.091 0 0 0 .086-.06.092.092 0 0 0 .005-.036c-.13-2.027-1.915-2.752-3.563-2.752-1.953 0-3.377 1.28-3.377 2.698 0 1.03.294 2 2.597 2.673.402.118.954.27 1.433.4.577.16.884.4.884.784 0 .443-.652.75-1.277.75-.916 0-1.567-.338-1.62-.946a.09.09 0 0 0-.09-.08l-2.104.01a.09.09 0 0 0-.066.028.092.092 0 0 0-.025.066c.096 1.914 1.951 2.945 3.68 2.945 2.57 0 3.74-1.45 3.74-2.796.003-.628-.143-2.075-2.31-2.627zm25.703-2.588V20.54a.088.088 0 0 0-.026-.064.09.09 0 0 0-.065-.027h-2.1a.09.09 0 0 0-.09.09v11.994a.088.088 0 0 0 .026.064.089.089 0 0 0 .065.026h2.249a.09.09 0 0 0 .09-.09v-3.937h.034c.356.542 1.334 1.192 2.608 1.192 2.401 0 4.397-1.98 4.397-4.66 0-2.569-1.984-4.651-4.51-4.651-1.125 0-2.069.62-2.677 1.369v-.082zm2.468 5.747c-1.292 0-2.32-1.072-2.32-2.38 0-1.308 1.027-2.368 2.32-2.368 1.294 0 2.33 1.06 2.33 2.368 0 1.308-1.036 2.38-2.33 2.38zm-11.406-7.554c-2.096 0-3.142.708-3.983 1.28l-.024.016a.205.205 0 0 0-.063.275l.867 1.487a.213.213 0 0 0 .322.056l.065-.054c.432-.36 1.086-.905 2.761-1.04.933-.074 1.74.176 2.33.72.653.601 1.044 1.57 1.044 2.594 0 1.88-1.114 3.064-2.902 3.088-1.474-.008-2.466-.774-2.466-1.906 0-.599.237-1.04.77-1.43a.207.207 0 0 0 .061-.263l-.744-1.402a.215.215 0 0 0-.297-.083c-.836.493-1.822 1.446-1.767 3.182.067 2.21 1.912 3.896 4.31 3.965h.273c2.85-.092 4.907-2.198 4.907-5.048 0-2.637-1.914-5.437-5.463-5.437z"
        })]
    })
}
const Zo = () => je(Ct);
const Go = function(e) {
        const t = function(e) {
            if (e.match(/\.shop\.dev$/)) return "shop.dev";
            const t = e.match(/([^.]*[.]){2}(eu|us|asia).spin.dev/);
            return t && t.length ? t[0] : void 0
        }(e.hostname);
        return t ? {
            coreAuthDomain: `https://shop1.my.${t}`,
            payAuthDomain: `https://shop-server.${t}`,
            payAuthDomainAlt: `https://pay-shopify-com.${t}`
        } : {
            coreAuthDomain: e.origin,
            payAuthDomain: "https://shop.app",
            payAuthDomainAlt: "https://pay.shopify.com"
        }
    }(c.location),
    Qo = Go.coreAuthDomain,
    er = Go.payAuthDomain,
    tr = Go.payAuthDomainAlt;

function nr() {
    const {
        notify: e
    } = vt(), {
        element: t
    } = St();
    return Te(((n, o, r = !1) => {
        t ? t.dispatchEvent(new CustomEvent(n, {
            bubbles: r,
            cancelable: !1,
            composed: !0,
            detail: o
        })) : e(new Error("dispatchEvent called without a reference to the custom element."))
    }), [t, e])
}

function or(e, t) {
    try {
        const n = new c.URL(e).host.split(".").reverse(),
            o = new c.URL(t).host.split(".").reverse();
        for (let e = 0; e < Math.min(n.length, o.length); e++)
            if (n[e] !== o[e]) return !1;
        return !0
    } catch (e) {
        return !1
    }
}

function rr(e) {
    return !("string" != typeof e || !e) && RegExp(/^[^@]+@[^@]+\.[^@]{2,}$/i).test(e)
}

function ir(e) {
    const t = new c.URL(e);
    if (("localhost" === t.hostname || "127.0.0.1" === t.hostname) && "https:" !== t.protocol) throw new Error("using_localhost");
    if ("https:" !== t.protocol) throw new Error("not_using_https");
    if ("/" !== t.pathname) throw new Error("has_path");
    if (t.hash) throw new Error("has_hash");
    if (t.search) throw new Error("has_search");
    return !0
}

function ar({
    allowedOrigins: e,
    destination: t = c,
    handler: n,
    source: o
}) {
    const r = Ie((() => new Set), []);
    Ce((() => (r.add(n), () => {
        r.delete(n)
    })), [n, r]);
    const i = Te((e => {
            r.forEach((t => t(e)))
        }), [r]),
        a = Te((t => {
            const n = o.current instanceof HTMLIFrameElement ? o.current.contentWindow : o.current;
            (function(e, t) {
                return e.source === t
            })(t, n || null) && (e.some((e => or(e, t.origin))) ? i(t.data) : console.error("Origin mismatch for message event", t))
        }), [e, i, o]),
        s = Te((() => {
            t.removeEventListener("message", a, !1)
        }), [t, a]);
    Ce((() => (t.addEventListener("message", a, !1), () => {
        s()
    })), [t, s, a]);
    const l = Te(((e, t) => g(this, void 0, void 0, (function*() {
        let n;
        return new Promise(((o, i) => {
            function a() {
                i(new vn("Abort signal received", "AbortSignalReceivedError"))
            }(null == t ? void 0 : t.aborted) && a(), n = n => {
                n.type === e && (null == t || t.removeEventListener("abort", a), o(n))
            }, r.add(n), null == t || t.addEventListener("abort", a)
        })).finally((() => {
            r.delete(n)
        }))
    }))), [r]);
    return {
        destroy: s,
        waitForMessage: l
    }
}

function sr(e) {
    var {
        includeCore: t,
        source: n,
        storefrontOrigin: o
    } = e, r = v(e, ["includeCore", "source", "storefrontOrigin"]);
    const i = nr(),
        a = Te((e => g(this, void 0, void 0, (function*() {
            const {
                onAuthorizeStepChanged: t,
                onClose: n,
                onComplete: o,
                onConfirmSuccess: a,
                onContinueToCheckout: s,
                onCustomFlowSideEffect: c,
                onDiscountSaved: l,
                onEmailChangeRequested: u,
                onError: d,
                onLeadCaptureLoaded: p,
                onLoaded: h,
                onModalOpened: f,
                onPopUpOpened: m,
                onPrequalError: _,
                onPrequalMissingInformation: v,
                onPrequalReady: g,
                onPrequalSuccess: y,
                onProcessingStatusUpdated: b,
                onResizeIframe: w,
                onRestarted: x,
                onShopUserMatched: k,
                onShopUserNotMatched: E,
                onUserVerified: S,
                onVerificationStepChanged: C,
                onPromptChange: O,
                onPromptContinue: P
            } = r;
            switch (e.type) {
                case "authorize_step_changed":
                    null == t || t(e);
                    break;
                case "close":
                case "close_requested":
                    null == n || n();
                    break;
                case "completed":
                    {
                        const {
                            avatar: t,
                            email: n,
                            givenName: r,
                            loggedIn: a,
                            shouldFinalizeLogin: s
                        } = e;o && (yield o(e)),
                        i("completed", e),
                        a && s && i("storefront:signincompleted", {
                            avatar: (() => {
                                const e = $o("shop-user-avatar"),
                                    o = (null == r ? void 0 : r[0]) || (null == n ? void 0 : n[0]) || "";
                                return e.setAttribute("src", t || ""), e.setAttribute("initial", o), e
                            })()
                        }, !0);
                        break
                    }
                case "confirm_success":
                    null == a || a();
                    break;
                case "continue_to_checkout":
                    null == s || s();
                    break;
                case "custom_flow_side_effect":
                    null == c || c(e);
                    break;
                case "discount_saved":
                    null == l || l();
                    break;
                case "email_change_requested":
                    null == u || u();
                    break;
                case "error":
                    null == d || d(e), i("error", {
                        code: e.code,
                        message: e.message,
                        email: e.email
                    });
                    break;
                case "loaded":
                    i("loaded", e), "loginTitle" in e ? null == p || p(e) : null == h || h(e);
                    break;
                case "modalopened":
                    null == f || f();
                    break;
                case "pop_up_opened":
                    null == m || m(e), i("popuploading", e);
                    break;
                case "processing_status_updated":
                    null == b || b();
                    break;
                case "prequal_error":
                    null == _ || _();
                    break;
                case "prequal_missing_information":
                    null == v || v();
                    break;
                case "prequal_ready":
                    null == g || g();
                    break;
                case "prequal_success":
                    null == y || y();
                    break;
                case "resize_iframe":
                    null == w || w(e);
                    break;
                case "restarted":
                    null == x || x(), i("restarted");
                    break;
                case "shop_user_matched":
                    null == k || k(e);
                    break;
                case "shop_user_not_matched":
                    null == E || E(e);
                    break;
                case "user_verified":
                    null == S || S(e);
                    break;
                case "verification_step_changed":
                    null == C || C(e);
                    break;
                case "prompt_change":
                    null == O || O();
                    break;
                case "prompt_continue":
                    null == P || P()
            }
        }))), [i, r]);
    return ar({
        allowedOrigins: Ie((() => [er, tr, ...t ? [Qo] : [], ...o ? [o] : []]), [t, o]),
        handler: a,
        source: n
    })
}
const cr = "temporarily_unavailable",
    lr = "Shop login is temporarily unavailable";

function ur() {
    const e = nr(),
        t = Pe(null),
        n = Te((() => {
            t.current && (clearTimeout(t.current), t.current = null)
        }), []);
    return {
        initLoadTimeout: Te((() => {
            n(), t.current = setTimeout((() => {
                e("error", {
                    message: lr,
                    code: cr
                }), n()
            }), 1e4)
        }), [n, e]),
        clearLoadTimeout: n
    }
}

function dr(e) {
    const t = Pe(e);
    return Ce((() => {
        t.current = e
    })), t.current
}

function pr({
    contentWindow: e,
    event: t
}) {
    if (!e) return;
    [er, tr].forEach((n => {
        e.postMessage(t, n)
    }))
}
class hr {
    constructor(e) {
        this._source = e
    }
    isSourceOf(e) {
        return e.source === this._source.contentWindow
    }
}
const fr = ({
        iframe: e,
        src: t
    }) => {
        const n = null == e ? void 0 : e.parentNode;
        n && e && (n.removeChild(e), e.setAttribute("src", ""), e.setAttribute("src", t), n.appendChild(e))
    },
    mr = {
        mobile: ["max-width: 448px"],
        tablet: ["min-width: 449px", "max-width: 1000px", "max-height: 920px"]
    };

function _r() {
    const e = mr.mobile.every((e => c.matchMedia(`(${e})`).matches)),
        t = !e && mr.tablet.every((e => c.matchMedia(`(${e})`).matches));
    return {
        isMobile: e,
        isTablet: t,
        isDesktop: !e && !t
    }
}

function vr() {
    return Boolean(Rt.userAgent) && /(android|iphone|ipad|mobile|phone)/i.test(Rt.userAgent) || function() {
        const e = Rt.userAgent.toLowerCase();
        return e.includes("fban/fbios") || e.includes("fb_iab/fb4a")
    }() || Rt.userAgent.toLowerCase().includes("instagram") || Rt.userAgent.toLowerCase().includes("messenger") || function() {
        const e = Rt.userAgent;
        return RegExp(br).test(e) || RegExp(wr).test(e)
    }() || /Mozilla\/5.0 \([^)]*Android[^)]*; wv\).+Chrome\//.test(Rt.userAgent)
}

function gr(e) {
    return "/" === e ? e : e.endsWith("/") ? e.slice(0, -1) : e
}

function yr() {
    return Boolean("undefined" != typeof IntersectionObserver && IntersectionObserver)
}
const br = "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|).* AppleNews",
    wr = "(iPod|iPod touch|iPhone|iPad);.*CPU.*OS[ +](\\d+)_(\\d+)(?:_(\\d+)|)(?!.*Version).*Mobile(?!.*Safari)";

function xr({
    className: e
}) {
    return le("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 20 20",
        children: le("path", {
            fill: "currentColor",
            "fill-rule": "evenodd",
            d: "M0 10C0 4.477 4.477 0 10 0s10 4.477 10 10-4.477 10-10 10S0 15.523 0 10Zm7.707-3.707a1 1 0 0 0-1.414 1.414L8.586 10l-2.293 2.293a1 1 0 1 0 1.414 1.414L10 11.414l2.293 2.293a1 1 0 0 0 1.414-1.414L11.414 10l2.293-2.293a1 1 0 0 0-1.414-1.414L10 8.586 7.707 6.293Z",
            "clip-rule": "evenodd"
        })
    })
}
const kr = '\n  a[href],\n  area[href],\n  input:not([type="hidden"]):not([disabled]):not([tabindex="-1"]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]):not([tabindex="-1"]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls]';

function Er(e) {
    return e.querySelector(kr)
}

function Sr(e) {
    const t = e.querySelectorAll(kr);
    return t[t.length - 1]
}

function Cr({
    className: e
}) {
    return le("svg", {
        className: e,
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 60 25",
        role: "img",
        children: [le("title", {
            children: "Shop"
        }), le("path", {
            fill: "currentColor",
            d: "M7.74 11.067c-2.35-.509-3.396-.708-3.396-1.612 0-.85.708-1.274 2.125-1.274 1.246 0 2.157.544 2.828 1.609.05.082.155.11.24.066l2.644-1.334a.186.186 0 0 0 .076-.259c-1.098-1.9-3.125-2.94-5.794-2.94-3.507 0-5.686 1.727-5.686 4.47 0 2.914 2.653 3.65 5.006 4.16 2.353.509 3.403.708 3.403 1.612 0 .904-.765 1.33-2.293 1.33-1.41 0-2.457-.644-3.09-1.896a.185.185 0 0 0-.25-.082L.916 16.222a.188.188 0 0 0-.082.253c1.046 2.102 3.194 3.284 6.062 3.284 3.653 0 5.86-1.697 5.86-4.526 0-2.83-2.666-3.65-5.015-4.16v-.006ZM21.909 5.324c-1.5 0-2.824.53-3.776 1.476a.093.093 0 0 1-.158-.067V.7a.185.185 0 0 0-.187-.186H14.48a.185.185 0 0 0-.187.186v18.728c0 .105.083.187.187.187h3.308a.185.185 0 0 0 .187-.187v-8.215c0-1.586 1.217-2.803 2.859-2.803 1.641 0 2.83 1.191 2.83 2.803v8.215c0 .105.082.187.187.187h3.308a.185.185 0 0 0 .186-.187v-8.215c0-3.451-2.264-5.888-5.436-5.888ZM34.056 4.786c-1.796 0-3.478.55-4.687 1.344a.187.187 0 0 0-.06.25l1.458 2.487c.054.089.168.12.256.066a5.812 5.812 0 0 1 3.04-.834c2.887 0 5.01 2.035 5.01 4.725 0 2.292-1.7 3.99-3.853 3.99-1.755 0-2.973-1.022-2.973-2.463 0-.825.351-1.501 1.265-1.979a.183.183 0 0 0 .073-.259L32.21 9.787a.186.186 0 0 0-.224-.08c-1.844.683-3.137 2.327-3.137 4.533 0 3.338 2.66 5.829 6.369 5.829 4.333 0 7.448-3 7.448-7.302 0-4.611-3.624-7.98-8.609-7.98ZM52.342 5.295c-1.673 0-3.169.62-4.26 1.707a.092.092 0 0 1-.158-.066V5.627a.185.185 0 0 0-.186-.186h-3.223a.185.185 0 0 0-.187.186v18.7c0 .104.082.186.187.186h3.308a.185.185 0 0 0 .187-.187v-6.131c0-.083.098-.124.158-.07 1.088 1.012 2.527 1.602 4.174 1.602 3.88 0 6.907-3.138 6.907-7.216 0-4.077-3.03-7.216-6.907-7.216Zm-.626 11.265c-2.207 0-3.88-1.754-3.88-4.074s1.67-4.074 3.88-4.074 3.877 1.726 3.877 4.074c0 2.349-1.644 4.074-3.88 4.074h.003Z"
        })]
    })
}
const Or = Be((({
    children: e,
    className: t,
    disabled: n,
    href: o,
    onClick: r
}, i) => le("button", {
    className: Ko("relative m-0 flex w-auto items-center overflow-visible rounded-login-button border-none bg-purple-primary p-0 transition-all hover_enabled_bg-purple-d0 focus-visible_enabled_outline-none focus-visible_enabled_ring focus-visible_enabled_ring-purple-primary-light disabled_opacity-50", t),
    disabled: n,
    href: o,
    ref: i,
    type: "button",
    onClick: r,
    children: e
})));
Or.displayName = "Button";
const Pr = ({
        defaultUxMode: e,
        uxMode: t
    }) => Ie((() => {
        const n = vr();
        return "windoid" === t && n ? e : t
    }), [e, t]),
    Mr = e => {
        if (void 0 !== e) return !1 === e ? "false" : "true"
    };

function Ir(e) {
    if (!e.proxy && void 0 === (null == e ? void 0 : e.clientId)) return "";
    const t = function({
        analyticsContext: e,
        analyticsTraceId: t,
        apiKey: n,
        avoidSdkSession: o,
        checkoutRedirectUrl: r,
        checkoutToken: i,
        checkoutVersion: a,
        clientId: s,
        codeChallenge: l,
        codeChallengeMethod: u,
        consentChallenge: d,
        disableSignUp: p,
        error: h,
        experiments: f,
        flow: m,
        flowVersion: _,
        hideCopy: v,
        isCompactLayout: g = !0,
        isFullView: y,
        locale: b,
        loginStart: w,
        modalCustomized: x,
        orderId: k,
        origin: E,
        personalizeAds: S,
        prompt: C,
        placement: O,
        popUpFeatures: P,
        popUpName: M,
        redirectType: I,
        redirectUri: T,
        requireVerification: j,
        responseMode: A,
        responseType: N,
        returnUri: L,
        scope: D,
        shopId: U,
        state: R,
        storefrontDomain: z,
        transactionParams: F,
        uxMode: $,
        uxRole: V,
        hideButtons: H,
        hideHeader: B,
        accentColor: W,
        darkMode: q
    }) {
        const X = void 0 === p ? void 0 : !1 === p,
            Y = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({
                analytics_context: e,
                analytics_trace_id: t,
                avoid_sdk_session: Mr(o),
                api_key: n,
                checkout_redirect_url: r,
                checkout_token: i,
                checkout_version: a,
                client_id: s,
                code_challenge: l,
                code_challenge_method: u,
                compact_layout: Mr(g),
                consent_challenge: Mr(d),
                "customize-modal": Mr(x)
            }, h && {
                error: h
            }), f && {
                experiments: f
            }), {
                flow: m ? m.toString() : void 0,
                flow_version: _,
                full_view: Mr(y),
                hide_copy: Mr(v),
                locale: b
            }), w && {
                login_start: w
            }), {
                order_id: k ? k.toString() : void 0,
                origin: E,
                personalize_ads: Mr(S),
                hide_buttons: Mr(H),
                hide_header: Mr(B),
                accent_color: W,
                dark_mode: Mr(q),
                placement: O,
                pop_up_features: "pop_up" === I ? P : void 0,
                pop_up_name: "pop_up" === I ? M : void 0,
                preact: "true",
                prompt: C,
                redirect_type: I,
                redirect_uri: T || c.location.origin,
                require_verification: Mr(j),
                response_mode: A || "web_message",
                response_type: N || "id_token"
            }), L && {
                return_uri: L
            }), {
                scope: D || "openid email profile",
                sign_up_enabled: Mr(X),
                shop_id: U ? U.toString() : void 0,
                state: R,
                storefront_domain: z,
                target_origin: c.location.origin,
                transaction_params: F,
                ux_mode: $,
                ux_role: V
            });
        return Object.keys(Y).forEach((e => void 0 === Y[e] && delete Y[e])), new URLSearchParams(Y)
    }(e);
    if (e.proxy) return `${Qo}/services/login_with_shop/authorize?${t}`;
    if (function(e) {
            return "loginWithShopSelfServe" === e.analyticsContext && "iframe" !== e.uxMode && "prompt" !== e.uxRole
        }(e)) return `${er}/oauth/authorize?${t}`;
    const n = e.avoidPayAltDomain ? "/pay/sdk-authorize" : "/pay/sdk-session";
    return `${er}${n}?${t}`
}

function Tr(e) {
    var {
        analyticsContext: t,
        avoidPayAltDomain: n = !1,
        avoidSdkSession: o = !1,
        disableSignUp: r = !1,
        flow: i = "default",
        flowVersion: a = "unspecified",
        error: s,
        prompt: c = "login",
        responseMode: l
    } = e, u = v(e, ["analyticsContext", "avoidPayAltDomain", "avoidSdkSession", "disableSignUp", "flow", "flowVersion", "error", "prompt", "responseMode"]);
    const {
        locale: d
    } = Lo(), {
        instanceId: p
    } = St(), h = Te((e => {
        const h = function(e, t) {
                if ("redirect" === t) return "query";
                if ("windoid" === t) return "web_message";
                return e
            }(l, u.uxMode),
            f = function(e, t) {
                if ("redirect" === t && "loginWithShop" === e) return "loginWithShopClassicCustomerAccounts";
                return e
            }(t, u.uxMode);
        return Ir(Object.assign(Object.assign(Object.assign({
            analyticsContext: f,
            analyticsTraceId: p,
            avoidPayAltDomain: n,
            avoidSdkSession: o,
            disableSignUp: r,
            error: s,
            flow: i,
            flowVersion: a,
            locale: d,
            prompt: c
        }, h && {
            responseMode: h
        }), u), e))
    }), [t, n, o, r, s, i, a, p, d, c, u, l]);
    return {
        authorizeUrl: Ie((() => h()), [h]),
        getAuthorizeUrl: h
    }
}

function jr(e = c.location.origin, t) {
    const n = `${e}/services/login_with_shop/finalize`;
    return fetch(n).catch(t)
}
const Ar = ({
    storefrontOrigin: e
}) => {
    const {
        notify: t
    } = vt();
    return Te((n => g(void 0, [n], void 0, (function*({
        loggedIn: n,
        shouldFinalizeLogin: o,
        redirectUri: r
    }) {
        n && o && (yield jr(e, t)), r && (c.location.href = r)
    }))), [t, e])
};

function Nr() {
    if (! function() {
            const e = Rt.userAgent,
                t = Boolean(e.match(/iPad/i)) || Boolean(e.match(/iPhone/i)),
                n = Boolean(e.match(/WebKit/i));
            return t && n && !e.match(/CriOS/i)
        }()) return;
    const e = "shop-pay-safari-unzoom",
        n = t.getElementById(e);
    if (n) return n.focus();
    const o = t.createElement("input");
    o.id = e, o.style.fontSize = "16px", o.style.width = "1px", o.style.height = "1px", o.style.position = "fixed", o.style.bottom = "-1000px", o.style.right = "-1000px", o.style.transform = "translate(1000px, 1000px)", o.setAttribute("aria-hidden", "true"), t.body.appendChild(o), o.focus({
        preventScroll: !0
    })
}

function Lr({
    autoOpen: e,
    email: n,
    emailInputSelector: o,
    hideChange: r,
    iframeRef: i,
    shouldListen: a = !0
}) {
    const {
        autoOpened: s,
        loaded: c,
        modalVisible: l,
        sessionDetected: u
    } = Zo(), {
        leaveBreadcrumb: d,
        notify: p
    } = vt(), {
        trackUserAction: h
    } = wt(), {
        isFilledWithPasswordManager: f
    } = function({
        emailInputSelector: e
    }) {
        const [n, o] = Ee(), [r, i] = Ee();
        return Ce((() => {
            var n;

            function r(e) {
                "password" === this.type ? i(e.timeStamp) : o(e.timeStamp)
            }
            if (e) {
                const o = t.querySelector(e);
                if (o) {
                    o.addEventListener("input", r);
                    const e = null === (n = o.form) || void 0 === n ? void 0 : n.querySelector('input[type="password"]');
                    return e && e instanceof HTMLInputElement && e.addEventListener("input", r), () => {
                        o.removeEventListener("input", r), e && e.removeEventListener("input", r)
                    }
                }
            }
        }), [e]), {
            isFilledWithPasswordManager: Ie((() => void 0 !== n && void 0 !== r && Math.abs(n - r) < 100), [n, r])
        }
    }({
        emailInputSelector: o
    }), m = Pe(null), [_, v] = Ee(), [y, b] = Ee(), [w, x] = Ee(), k = Pe(null), E = Pe(""), S = Ie((() => new Set), []), C = Te(((t, ...n) => g(this, [t, ...n], void 0, (function*(t, n = "", o = "") {
        var a, _;
        const y = rr(t);
        if (f && !S.has("PASSWORD_MANAGER_AUTOFILL_DETECTED") && (S.add("PASSWORD_MANAGER_AUTOFILL_DETECTED"), h({
                userAction: "PASSWORD_MANAGER_AUTOFILL_DETECTED"
            })), y && !S.has("EMAIL_ENTERED") && (S.add("EMAIL_ENTERED"), h({
                userAction: "EMAIL_ENTERED"
            })), d("email entered", {}, "state"), !i.current || l) return;
        if (c && u && e && !s) return;
        const b = y ? t : "";
        m.current && !(null === (a = m.current) || void 0 === a ? void 0 : a.signal.aborted) && m.current.abort(), m.current = new AbortController;
        try {
            const {
                open: e,
                postMessage: t,
                waitForMessage: a
            } = i.current;
            E.current = b, t({
                firstName: n,
                lastName: o,
                type: "namesubmitted"
            }), t({
                email: b,
                hideChange: void 0 === r ? b.length > 0 : r,
                type: "emailsubmitted"
            }), d("email submitted", {
                email: b ? "redacted" : ""
            }, "state");
            const s = a("shop_user_matched", m.current.signal),
                c = new Promise(((e, t) => {
                    const n = () => g(this, void 0, void 0, (function*() {
                        try {
                            const t = yield a("error", m.current.signal);
                            "error" === t.type && "captcha_challenge" === t.code ? e(void 0) : n()
                        } catch (e) {
                            t(e)
                        }
                    }));
                    n()
                }));
            yield Promise.race([s, c]), e("event_shop_user_matched"), null === (_ = null == k ? void 0 : k.current) || void 0 === _ || _.blur(), Nr(), m.current.abort(), v(void 0)
        } catch (e) {
            if (e instanceof vn && "AbortSignalReceivedError" === e.name) return;
            e instanceof Error && p(new Error(`Error updating user info: ${e.name} - ${e.message}`))
        }
    }))), [e, s, r, i, f, d, c, l, p, u, h, S]), O = Mn(((e, t, n) => {
        C(e, t, n)
    }), 200);
    Ce((() => {
        void 0 !== _ && c && O(_, y, w)
    }), [O, _, c, y, w]), Ce((() => {
        if (!o) return;
        const e = t.querySelector(o);
        if (!e) return;
        k.current = e;
        const n = () => {
            e && v(e.value)
        };
        if ((null == e ? void 0 : e.value) && n(), a) return null == e || e.addEventListener("input", n), () => {
            null == e || e.removeEventListener("input", n)
        };
        null == e || e.removeEventListener("input", n)
    }), [o, a]), Ce((() => {
        void 0 !== n && v(n)
    }), [n]);
    return {
        getSubmittedEmail: () => E.current,
        updateEmailToPost: e => v(e || ""),
        updateNamesToPost: (e, t) => ((e = "", t = "") => {
            b(e), x(t)
        })(e, t)
    }
}
const Dr = ({
        handleComplete: e,
        handleError: t,
        windoidRef: n
    }) => {
        const o = nr();
        return Te((r => g(void 0, void 0, void 0, (function*() {
            var i, a;
            switch (r.data.type) {
                case "completed":
                    e(r.data), o("completed", r.data, !0), null === (i = n.current) || void 0 === i || i.close();
                    break;
                case "error":
                    null == t || t(r.data), o("error", r.data), null === (a = n.current) || void 0 === a || a.close();
                    break;
                case "windoidopened":
                    o("windoidopened")
            }
        }))), [o, e, t, n])
    },
    Ur = ({
        getAuthorizeUrl: e,
        getEmail: t,
        iframeRef: n,
        openWindoid: o
    }) => {
        const {
            trackUserAction: r
        } = wt();
        return Te((() => {
            var i;
            r({
                userAction: "SIGN_IN_WITH_SHOP_PROMPT_CONTINUE_CLICK"
            }), null === (i = null == n ? void 0 : n.current) || void 0 === i || i.close({
                dismissMethod: "windoid_continue",
                reason: "user_prompt_continue_clicked"
            });
            const a = t(),
                s = e(Object.assign(Object.assign({}, a && {
                    loginStart: a
                }), {
                    origin: "preauth_prompt",
                    prompt: void 0
                }));
            o(s)
        }), [e, t, n, o, r])
    },
    Rr = {},
    zr = (e, n, o = "SignInWithShop") => {
        var r;
        const i = ((e, n) => {
            const o = void 0 === c.screenLeft ? c.screenX : c.screenLeft,
                r = void 0 === c.screenTop ? c.screenY : c.screenTop;
            let i, a;
            i = c.innerWidth ? c.innerWidth : t.documentElement.clientWidth ? t.documentElement.clientWidth : screen.width, a = c.innerHeight ? c.innerHeight : t.documentElement.clientHeight ? t.documentElement.clientHeight : screen.height;
            const s = Math.max(1, i / c.screen.availWidth);
            return {
                height: n / s,
                left: (i - e) / 2 / s + o,
                top: (a - n) / 2 / s + r,
                width: e / s
            }
        })(365, 554);
        null === (r = Rr[o]) || void 0 === r || r.call(Rr);
        const a = c.open(e, "SignInWithShop", `popup,width=${i.width},height=${i.height},top=${i.top},left=${i.left}`),
            s = () => (e => {
                null == e || e.close()
            })(a);
        return n(new MessageEvent("message", {
            data: {
                type: "windoidopened"
            }
        })), ["beforeunload", "unload", "pagehide"].forEach((e => {
            c.addEventListener(e, s, {
                once: !0
            })
        })), c.addEventListener("message", n), Rr[o] = () => {
            ["beforeunload", "unload", "pagehide"].forEach((e => {
                c.removeEventListener(e, s)
            })), c.removeEventListener("message", n)
        }, a
    },
    Fr = new Error("Operation aborted");

function $r(e) {
    return g(this, arguments, void 0, (function*(e, t = {}, {
        maxRetries: n = 3,
        retryDelay: o = 1e3,
        signal: r
    } = {}) {
        try {
            if (null == r ? void 0 : r.aborted) return Promise.reject(Fr);
            const n = yield fetch(e, t);
            if (!n.ok) throw new Error(`HTTP error! status: ${n.status}`);
            return n
        } catch (i) {
            if (null == r ? void 0 : r.aborted) return Promise.reject(Fr);
            if (n - 1 > 0) return yield new Promise((e => setTimeout(e, o))), (null == r ? void 0 : r.aborted) ? Promise.reject(Fr) : $r(e, t, {
                maxRetries: n - 1,
                retryDelay: o,
                signal: r
            });
            throw i
        }
    }))
}
const Vr = e => {
    const t = e || c.location.origin;
    try {
        return new c.URL(t).hostname
    } catch (e) {
        return console.error(`[Shop Pay] Store URL (${t}) is not valid`, e), null
    }
};

function Hr({
    channel: e,
    paymentOption: t,
    source: n,
    sourceToken: o,
    storeUrl: r,
    variants: i
}) {
    const a = Vr(r);
    if (!a) return "#";
    let s = new c.URL(`https://${a}/checkout`);
    if (i) {
        const e = i.split(",").map((e => {
                const [t, n] = e.split(":"), o = n ? Number(n) : 1;
                return {
                    id: Number(t),
                    quantity: isNaN(o) ? 1 : o
                }
            })),
            t = e.map((e => `${e.id}:${e.quantity}`)).join(",");
        s = new c.URL(`https://${a}/cart/${t}`)
    }
    const l = new URLSearchParams(s.search);
    return l.append("payment", t || "shop_pay"), n && l.append("source", n), o && l.append("source_token", o), e && l.append("channel", e), `${s.href}?${l}`
}

function Br(e, t) {
    Boolean(c.customElements) && (c.Shopify || (c.Shopify = {}), c.Shopify.SignInWithShop || (c.Shopify.SignInWithShop = {}), c.Shopify.SignInWithShop[e] = t)
}

function Wr() {
    var e;
    const n = null === (e = t.querySelector("script#shop-js-features")) || void 0 === e ? void 0 : e.innerHTML;
    return n ? JSON.parse(n) : {}
}
class qr extends Error {
    constructor() {
        super("FedCM is not supported")
    }
}
class Xr extends Error {
    constructor() {
        super("FedCM was cancelled")
    }
}
const Yr = e => g(void 0, void 0, void 0, (function*() {
    if (!("IdentityCredential" in c)) throw new qr;
    const {
        mediation: t = "optional",
        analyticsTraceId: n,
        monorailTracker: o,
        signal: r
    } = e, i = yield function(e) {
        return g(this, void 0, void 0, (function*() {
            let t = "/services/login_with_shop/fedcm/provider";
            e && (t += `?analytics_trace_id=${encodeURIComponent(e)}`);
            try {
                const e = yield $r(t, {
                    method: "GET"
                }, {
                    maxRetries: 5,
                    retryDelay: 1e3
                }), n = yield e.json();
                return {
                    configURL: n.configURL,
                    clientId: n.clientId,
                    nonce: n.nonce,
                    state: n.state
                }
            } catch (e) {
                throw new vn("Failed to fetch FedCM Provider", "FetchFedCMProviderError")
            }
        }))
    }(n);
    if (!i) return;
    const a = yield function(e, t, n) {
        return Rt.credentials.get({
            identity: {
                providers: [t]
            },
            mediation: e,
            signal: n
        })
    }(t, i, r);
    if (!a) throw null == o || o.trackUserAction({
        userAction: "FEDCM_CANCELLED"
    }), new Xr;
    return function(e, t, n) {
        return g(this, void 0, void 0, (function*() {
            try {
                const o = yield $r("/services/login_with_shop/fedcm/callback", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: new URLSearchParams({
                        raw_id_token: e,
                        state: t
                    }).toString()
                }, {
                    maxRetries: 5,
                    retryDelay: 1e3
                });
                return null == n || n.trackUserAction({
                    userAction: "FEDCM_COMPLETED"
                }), o
            } catch (e) {
                throw new vn("Failed to fetch FedCM Callback", "FetchFedCMPCallbackError")
            }
        }))
    }(null == a ? void 0 : a.token, i.state, o)
}));

function Kr({
    onElementFound: e,
    selector: n
}) {
    const o = new WeakSet,
        r = new MutationObserver((e => {
            let t = !1;
            for (const n of e)
                if (n.addedNodes.length > 0) {
                    t = !0;
                    break
                }
            t && i()
        }));

    function i() {
        t.querySelectorAll(n).forEach((t => {
            o.has(t) || (e(t), o.add(t))
        }))
    }
    return function() {
        g(this, void 0, void 0, (function*() {
            yield function() {
                if (t.body) return Promise.resolve();
                return new Promise((e => {
                    c.addEventListener("DOMContentLoaded", (() => e()))
                }))
            }(), i(), r.observe(t.body || t.documentElement, {
                childList: !0,
                subtree: !0
            })
        }))
    }(), r
}

function Jr({
    onFallback: e,
    onVisible: t
}) {
    const n = new IntersectionObserver((r => {
        for (const i of r) {
            const {
                isIntersecting: r,
                target: a
            } = i;
            r && (o(a) ? t(a) : e(a), n.unobserve(a))
        }
    }), {
        threshold: 1
    });

    function o(e) {
        let t = e;
        for (; t;) {
            if (!["", "1"].includes(getComputedStyle(t).opacity)) return !1;
            t = t.parentElement
        }
        return !0
    }
    return n
}
var Zr, Gr;
class Qr {
    constructor(e, t) {
        Zr.set(this, void 0), Gr.set(this, void 0), e && (b(this, Zr, e, "f"), b(this, Gr, (e => {
            t(e.target.value)
        }), "f"), y(this, Zr, "f").addEventListener("input", y(this, Gr, "f")))
    }
    destroy() {
        y(this, Zr, "f") && y(this, Gr, "f") && y(this, Zr, "f").removeEventListener("input", y(this, Gr, "f"))
    }
}
Zr = new WeakMap, Gr = new WeakMap;
const ei = "shop-toast-manager";

function ti(e) {
    let n = t.querySelector(ei);
    n || (n = t.createElement(ei), t.body.appendChild(n)), customElements.whenDefined(ei).then((() => {
        n.renderToast(e)
    })).catch((() => {}))
}
Br("renderToast", ti);
export {
    Or as $, Pe as A, sr as B, xr as C, fr as D, g as E, Me as F, vn as G, pr as H, yn as I, Ho as J, Pr as K, Lr as L, Ro as M, Ar as N, _ as O, tt as P, m as Q, Ao as R, Jo as S, Ie as T, e as U, Tr as V, Dr as W, zr as X, Mn as Y, Ur as Z, v as _, Oe as a, vr as a0, h as a1, Ir as a2, a as a3, Br as a4, tr as a5, hn as a6, er as a7, or as a8, hr as a9, mn as aA, Hr as aB, Mr as aC, rn as aa, cn as ab, Io as ac, So as ad, Rt as ae, $o as af, Wr as ag, rr as ah, Yr as ai, Jr as aj, Kr as ak, Qr as al, d as am, gr as an, qr as ao, Xr as ap, u as aq, _n as ar, ir as as, jr as at, se as au, je as av, Qo as aw, ar as ax, Vr as ay, $r as az, F as b, Sr as c, Qn as d, Zo as e, Er as f, Uo as g, Ee as h, c as i, St as j, t as k, yr as l, _r as m, Ko as n, Cr as o, yt as p, Te as q, vt as r, nr as s, ur as t, le as u, wt as v, Be as w, kt as x, Ce as y, dr as z
};
//# sourceMappingURL=chunk.common_Dy4FpwmR.esm.js.map
import '../sass/model-viewer-ui.scss';
import '../sprite';

import ModelViewerUI from './model-viewer-ui';

window.Shopify = window.Shopify || {};
window.Shopify.ModelViewerUI = ModelViewerUI;
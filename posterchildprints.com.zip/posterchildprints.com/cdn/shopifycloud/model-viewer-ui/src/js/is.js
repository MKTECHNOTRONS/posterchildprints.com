// Borrowed partially from Plyr.js v3.5.4 (https://github.com/sampotts/plyr/blob/master/src/js/utils/is.js)
// MIT Licensed

const getConstructor = (input) => {
    return input !== null && typeof input !== 'undefined' ?
        input.constructor : null;
};

const instanceOf = (input, constructor) => {
    return Boolean(input && constructor && input instanceof constructor);
};

const isObject = (input) => getConstructor(input) === Object;
const isBoolean = (input) => getConstructor(input) === Boolean;
const isString = (input) => getConstructor(input) === String;
const isNodeList = (input) => instanceOf(input, NodeList);
const isArray = (input) => Array.isArray(input);
const isNullOrUndefined = (input) => {
    return input === null || typeof input === 'undefined';
};
const isElement = (input) => instanceOf(input, Element);
const isEmpty = (input) =>
    isNullOrUndefined(input) ||
    ((isString(input) || isArray(input) || isNodeList(input)) && !input.length) ||
    (isObject(input) && !Object.keys(input).length);
// eslint-disable-next-line no-undef
const isJQueryObject = (input) => window.jQuery && input instanceof jQuery;

const is = {
    string: isString,
    nodeList: isNodeList,
    array: isArray,
    nullOrUndefined: isNullOrUndefined,
    element: isElement,
    object: isObject,
    boolean: isBoolean,
    empty: isEmpty,
    jqueryObject: isJQueryObject,
};

export default is;
! function() {
    "use strict";

    function e(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function t(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
        }
    }

    function n(e, n, i) {
        return n && t(e.prototype, n), i && t(e, i), e
    }

    function i(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function o(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var i = Object.getOwnPropertySymbols(e);
            t && (i = i.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), n.push.apply(n, i)
        }
        return n
    }

    function r(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = null != arguments[t] ? arguments[t] : {};
            t % 2 ? o(Object(n), !0).forEach((function(t) {
                i(e, t, n[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
            }))
        }
        return e
    }

    function a(e, t) {
        return function(e) {
            if (Array.isArray(e)) return e
        }(e) || function(e, t) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
            var n = [],
                i = !0,
                o = !1,
                r = void 0;
            try {
                for (var a, s = e[Symbol.iterator](); !(i = (a = s.next()).done) && (n.push(a.value), !t || n.length !== t); i = !0);
            } catch (e) {
                o = !0, r = e
            } finally {
                try {
                    i || null == s.return || s.return()
                } finally {
                    if (o) throw r
                }
            }
            return n
        }(e, t) || function(e, t) {
            if (!e) return;
            if ("string" == typeof e) return s(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            "Object" === n && e.constructor && (n = e.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(e);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return s(e, t)
        }(e, t) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function s(e, t) {
        (null == t || t > e.length) && (t = e.length);
        for (var n = 0, i = new Array(t); n < t; n++) i[n] = e[n];
        return i
    }
    var l = function(e) {
            return null != e ? e.constructor : null
        },
        u = function(e, t) {
            return Boolean(e && t && e instanceof t)
        },
        c = function(e) {
            return l(e) === Object
        },
        d = function(e) {
            return l(e) === String
        },
        f = function(e) {
            return u(e, NodeList)
        },
        h = function(e) {
            return Array.isArray(e)
        },
        m = function(e) {
            return null == e
        },
        p = d,
        v = f,
        y = h,
        g = m,
        b = function(e) {
            return u(e, Element)
        },
        w = c,
        A = function(e) {
            return l(e) === Boolean
        },
        T = function(e) {
            return m(e) || (d(e) || h(e) || f(e)) && !e.length || c(e) && !Object.keys(e).length
        },
        E = function(e) {
            return window.jQuery && e instanceof jQuery
        },
        L = function() {
            function t() {
                e(this, t), this.cache = []
            }
            return n(t, [{
                key: "cacheInstance",
                value: function(e) {
                    this.cache.push({
                        viewer: e.viewer,
                        instance: e
                    })
                }
            }, {
                key: "getCachedInstance",
                value: function(e) {
                    var t = this.cache.find((function(t) {
                        var n = t.viewer;
                        return e === n
                    }));
                    return t ? t.instance : null
                }
            }, {
                key: "removeFromCache",
                value: function(e) {
                    var t = this.cache.find((function(t) {
                        var n = t.viewer;
                        return e === n
                    }));
                    if (!t) return null;
                    var n = this.cache.indexOf(t);
                    return this.cache.splice(n, 1)[0]
                }
            }]), t
        }();

    function k(e, t) {
        var n = e.length ? e : [e];
        Array.from(n).reverse().forEach((function(e, n) {
            var i = n > 0 ? t.cloneNode(!0) : t,
                o = e.parentNode,
                r = e.nextSibling;
            i.appendChild(e), r ? o.insertBefore(i, r) : o.appendChild(i)
        }))
    }

    function S(e, t, n) {
        var i = document.createElement(e);
        return w(t) && function(e, t) {
            b(e) && !T(t) && Object.entries(t).filter((function(e) {
                var t = a(e, 2)[1];
                return !g(t)
            })).forEach((function(t) {
                var n = a(t, 2),
                    i = n[0],
                    o = n[1];
                return e.setAttribute(i, o)
            }))
        }(i, t), p(n) && (i.innerText = n), i
    }

    function _(e) {
        v(e) || y(e) ? Array.from(e).forEach(_) : b(e) && b(e.parentNode) && e.parentNode.removeChild(e)
    }

    function x(e, t) {
        if (b(e)) {
            var n = t;
            A(n) || (n = !e.hidden), e.hidden = n
        }
    }

    function O(e, t, n) {
        if (v(e)) return Array.from(e).map((function(e) {
            return O(e, t, n)
        }));
        if (b(e)) {
            var i = "toggle";
            return void 0 !== n && (i = n ? "add" : "remove"), e.classList[i](t), e.classList.contains(t)
        }
        return !1
    }
    var M = {
        config: {
            controls: ["zoom-in", "zoom-out", "fullscreen"],
            iconUrl: "https://cdn.shopify.com/shopifycloud/model-viewer-ui/".concat("assets/v1.0/sprites.svg"),
            focusOnPlay: !0
        }
    };
    "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self && self;
    var C = function(e, t) {
        return e(t = {
            exports: {}
        }, t.exports), t.exports
    }((function(e, t) {
        /*! @license DOMPurify | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/2.0.8/LICENSE */
        e.exports = function() {
            var e = Object.hasOwnProperty,
                t = Object.setPrototypeOf,
                n = Object.isFrozen,
                i = Object.keys,
                o = Object.freeze,
                r = Object.seal,
                a = Object.create,
                s = "undefined" != typeof Reflect && Reflect,
                l = s.apply,
                u = s.construct;
            l || (l = function(e, t, n) {
                return e.apply(t, n)
            }), o || (o = function(e) {
                return e
            }), r || (r = function(e) {
                return e
            }), u || (u = function(e, t) {
                return new(Function.prototype.bind.apply(e, [null].concat(function(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                        return n
                    }
                    return Array.from(e)
                }(t))))
            });
            var c = L(Array.prototype.forEach),
                d = L(Array.prototype.indexOf),
                f = L(Array.prototype.join),
                h = L(Array.prototype.pop),
                m = L(Array.prototype.push),
                p = L(Array.prototype.slice),
                v = L(String.prototype.toLowerCase),
                y = L(String.prototype.match),
                g = L(String.prototype.replace),
                b = L(String.prototype.indexOf),
                w = L(String.prototype.trim),
                A = L(RegExp.prototype.test),
                T = k(RegExp),
                E = k(TypeError);

            function L(e) {
                return function(t) {
                    for (var n = arguments.length, i = Array(n > 1 ? n - 1 : 0), o = 1; o < n; o++) i[o - 1] = arguments[o];
                    return l(e, t, i)
                }
            }

            function k(e) {
                return function() {
                    for (var t = arguments.length, n = Array(t), i = 0; i < t; i++) n[i] = arguments[i];
                    return u(e, n)
                }
            }

            function S(e, i) {
                t && t(e, null);
                for (var o = i.length; o--;) {
                    var r = i[o];
                    if ("string" == typeof r) {
                        var a = v(r);
                        a !== r && (n(i) || (i[o] = a), r = a)
                    }
                    e[r] = !0
                }
                return e
            }

            function _(t) {
                var n = a(null),
                    i = void 0;
                for (i in t) l(e, t, [i]) && (n[i] = t[i]);
                return n
            }
            var x = o(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]),
                O = o(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "audio", "canvas", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "video", "view", "vkern"]),
                M = o(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]),
                C = o(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover"]),
                F = o(["#text"]),
                D = o(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "xmlns"]),
                N = o(["accent-height", "accumulate", "additive", "alignment-baseline", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "targetx", "targety", "transform", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]),
                P = o(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]),
                z = o(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]),
                I = r(/\{\{[\s\S]*|[\s\S]*\}\}/gm),
                R = r(/<%[\s\S]*|[\s\S]*%>/gm),
                j = r(/^data-[\-\w.\u00B7-\uFFFF]/),
                B = r(/^aria-[\-\w]+$/),
                U = r(/^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i),
                H = r(/^(?:\w+script|data):/i),
                V = r(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
                q = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                };

            function Z(e) {
                if (Array.isArray(e)) {
                    for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                    return n
                }
                return Array.from(e)
            }
            var G = function() {
                    return "undefined" == typeof window ? null : window
                },
                W = function(e, t) {
                    if ("object" !== (void 0 === e ? "undefined" : q(e)) || "function" != typeof e.createPolicy) return null;
                    var n = null;
                    t.currentScript && t.currentScript.hasAttribute("data-tt-policy-suffix") && (n = t.currentScript.getAttribute("data-tt-policy-suffix"));
                    var i = "dompurify" + (n ? "#" + n : "");
                    try {
                        return e.createPolicy(i, {
                            createHTML: function(e) {
                                return e
                            }
                        })
                    } catch (e) {
                        return console.warn("TrustedTypes policy " + i + " could not be created."), null
                    }
                };
            return function e() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : G(),
                    n = function(t) {
                        return e(t)
                    };
                if (n.version = "2.0.17", n.removed = [], !t || !t.document || 9 !== t.document.nodeType) return n.isSupported = !1, n;
                var r = t.document,
                    a = !1,
                    s = t.document,
                    l = t.DocumentFragment,
                    u = t.HTMLTemplateElement,
                    L = t.Node,
                    k = t.NodeFilter,
                    Y = t.NamedNodeMap,
                    K = void 0 === Y ? t.NamedNodeMap || t.MozNamedAttrMap : Y,
                    X = t.Text,
                    Q = t.Comment,
                    $ = t.DOMParser,
                    J = t.trustedTypes;
                if ("function" == typeof u) {
                    var ee = s.createElement("template");
                    ee.content && ee.content.ownerDocument && (s = ee.content.ownerDocument)
                }
                var te = W(J, r),
                    ne = te && Pe ? te.createHTML("") : "",
                    ie = s,
                    oe = ie.implementation,
                    re = ie.createNodeIterator,
                    ae = ie.getElementsByTagName,
                    se = ie.createDocumentFragment,
                    le = r.importNode,
                    ue = {};
                try {
                    ue = _(s).documentMode ? s.documentMode : {}
                } catch (e) {}
                var ce = {};
                n.isSupported = oe && void 0 !== oe.createHTMLDocument && 9 !== ue;
                var de = I,
                    fe = R,
                    he = j,
                    me = B,
                    pe = H,
                    ve = V,
                    ye = U,
                    ge = null,
                    be = S({}, [].concat(Z(x), Z(O), Z(M), Z(C), Z(F))),
                    we = null,
                    Ae = S({}, [].concat(Z(D), Z(N), Z(P), Z(z))),
                    Te = null,
                    Ee = null,
                    Le = !0,
                    ke = !0,
                    Se = !1,
                    _e = !1,
                    xe = !1,
                    Oe = !1,
                    Me = !1,
                    Ce = !1,
                    Fe = !1,
                    De = !1,
                    Ne = !1,
                    Pe = !1,
                    ze = !0,
                    Ie = !0,
                    Re = !1,
                    je = {},
                    Be = S({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]),
                    Ue = null,
                    He = S({}, ["audio", "video", "img", "source", "image", "track"]),
                    Ve = null,
                    qe = S({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "summary", "title", "value", "style", "xmlns"]),
                    Ze = null,
                    Ge = s.createElement("form"),
                    We = function(e) {
                        Ze && Ze === e || (e && "object" === (void 0 === e ? "undefined" : q(e)) || (e = {}), e = _(e), ge = "ALLOWED_TAGS" in e ? S({}, e.ALLOWED_TAGS) : be, we = "ALLOWED_ATTR" in e ? S({}, e.ALLOWED_ATTR) : Ae, Ve = "ADD_URI_SAFE_ATTR" in e ? S(_(qe), e.ADD_URI_SAFE_ATTR) : qe, Ue = "ADD_DATA_URI_TAGS" in e ? S(_(He), e.ADD_DATA_URI_TAGS) : He, Te = "FORBID_TAGS" in e ? S({}, e.FORBID_TAGS) : {}, Ee = "FORBID_ATTR" in e ? S({}, e.FORBID_ATTR) : {}, je = "USE_PROFILES" in e && e.USE_PROFILES, Le = !1 !== e.ALLOW_ARIA_ATTR, ke = !1 !== e.ALLOW_DATA_ATTR, Se = e.ALLOW_UNKNOWN_PROTOCOLS || !1, _e = e.SAFE_FOR_JQUERY || !1, xe = e.SAFE_FOR_TEMPLATES || !1, Oe = e.WHOLE_DOCUMENT || !1, Fe = e.RETURN_DOM || !1, De = e.RETURN_DOM_FRAGMENT || !1, Ne = e.RETURN_DOM_IMPORT || !1, Pe = e.RETURN_TRUSTED_TYPE || !1, Ce = e.FORCE_BODY || !1, ze = !1 !== e.SANITIZE_DOM, Ie = !1 !== e.KEEP_CONTENT, Re = e.IN_PLACE || !1, ye = e.ALLOWED_URI_REGEXP || ye, xe && (ke = !1), De && (Fe = !0), je && (ge = S({}, [].concat(Z(F))), we = [], !0 === je.html && (S(ge, x), S(we, D)), !0 === je.svg && (S(ge, O), S(we, N), S(we, z)), !0 === je.svgFilters && (S(ge, M), S(we, N), S(we, z)), !0 === je.mathMl && (S(ge, C), S(we, P), S(we, z))), e.ADD_TAGS && (ge === be && (ge = _(ge)), S(ge, e.ADD_TAGS)), e.ADD_ATTR && (we === Ae && (we = _(we)), S(we, e.ADD_ATTR)), e.ADD_URI_SAFE_ATTR && S(Ve, e.ADD_URI_SAFE_ATTR), Ie && (ge["#text"] = !0), Oe && S(ge, ["html", "head", "body"]), ge.table && (S(ge, ["tbody"]), delete Te.tbody), o && o(e), Ze = e)
                    },
                    Ye = function(e) {
                        m(n.removed, {
                            element: e
                        });
                        try {
                            e.parentNode.removeChild(e)
                        } catch (t) {
                            e.outerHTML = ne
                        }
                    },
                    Ke = function(e, t) {
                        try {
                            m(n.removed, {
                                attribute: t.getAttributeNode(e),
                                from: t
                            })
                        } catch (e) {
                            m(n.removed, {
                                attribute: null,
                                from: t
                            })
                        }
                        t.removeAttribute(e)
                    },
                    Xe = function(e) {
                        var t = void 0,
                            n = void 0;
                        if (Ce) e = "<remove></remove>" + e;
                        else {
                            var i = y(e, /^[\r\n\t ]+/);
                            n = i && i[0]
                        }
                        var o = te ? te.createHTML(e) : e;
                        try {
                            t = (new $).parseFromString(o, "text/html")
                        } catch (e) {}
                        if (a && S(Te, ["title"]), !t || !t.documentElement) {
                            var r = (t = oe.createHTMLDocument("")).body;
                            r.parentNode.removeChild(r.parentNode.firstElementChild), r.outerHTML = o
                        }
                        return e && n && t.body.insertBefore(s.createTextNode(n), t.body.childNodes[0] || null), ae.call(t, Oe ? "html" : "body")[0]
                    };
                n.isSupported && function() {
                    try {
                        var e = Xe("<x/><title>&lt;/title&gt;&lt;img&gt;");
                        A(/<\/title/, e.querySelector("title").innerHTML) && (a = !0)
                    } catch (e) {}
                }();
                var Qe = function(e) {
                        return re.call(e.ownerDocument || e, e, k.SHOW_ELEMENT | k.SHOW_COMMENT | k.SHOW_TEXT, (function() {
                            return k.FILTER_ACCEPT
                        }), !1)
                    },
                    $e = function(e) {
                        return !(e instanceof X || e instanceof Q || "string" == typeof e.nodeName && "string" == typeof e.textContent && "function" == typeof e.removeChild && e.attributes instanceof K && "function" == typeof e.removeAttribute && "function" == typeof e.setAttribute && "string" == typeof e.namespaceURI)
                    },
                    Je = function(e) {
                        return "object" === (void 0 === L ? "undefined" : q(L)) ? e instanceof L : e && "object" === (void 0 === e ? "undefined" : q(e)) && "number" == typeof e.nodeType && "string" == typeof e.nodeName
                    },
                    et = function(e, t, i) {
                        ce[e] && c(ce[e], (function(e) {
                            e.call(n, t, i, Ze)
                        }))
                    },
                    tt = function(e) {
                        var t = void 0;
                        if (et("beforeSanitizeElements", e, null), $e(e)) return Ye(e), !0;
                        if (y(e.nodeName, /[\u0080-\uFFFF]/)) return Ye(e), !0;
                        var i = v(e.nodeName);
                        if (et("uponSanitizeElement", e, {
                                tagName: i,
                                allowedTags: ge
                            }), ("svg" === i || "math" === i) && 0 !== e.querySelectorAll("p, br, form, table").length) return Ye(e), !0;
                        if (!ge[i] || Te[i]) {
                            if (Ie && !Be[i] && "function" == typeof e.insertAdjacentHTML) try {
                                var o = e.innerHTML;
                                e.insertAdjacentHTML("AfterEnd", te ? te.createHTML(o) : o)
                            } catch (e) {}
                            return Ye(e), !0
                        }
                        return "noscript" === i && A(/<\/noscript/i, e.innerHTML) || "noembed" === i && A(/<\/noembed/i, e.innerHTML) ? (Ye(e), !0) : (!_e || Je(e.firstElementChild) || Je(e.content) && Je(e.content.firstElementChild) || !A(/</g, e.textContent) || (m(n.removed, {
                            element: e.cloneNode()
                        }), e.innerHTML ? e.innerHTML = g(e.innerHTML, /</g, "&lt;") : e.innerHTML = g(e.textContent, /</g, "&lt;")), xe && 3 === e.nodeType && (t = e.textContent, t = g(t, de, " "), t = g(t, fe, " "), e.textContent !== t && (m(n.removed, {
                            element: e.cloneNode()
                        }), e.textContent = t)), et("afterSanitizeElements", e, null), !1)
                    },
                    nt = function(e, t, n) {
                        if (ze && ("id" === t || "name" === t) && (n in s || n in Ge)) return !1;
                        if (ke && A(he, t));
                        else if (Le && A(me, t));
                        else {
                            if (!we[t] || Ee[t]) return !1;
                            if (Ve[t]);
                            else if (A(ye, g(n, ve, "")));
                            else if ("src" !== t && "xlink:href" !== t && "href" !== t || "script" === e || 0 !== b(n, "data:") || !Ue[e])
                                if (Se && !A(pe, g(n, ve, "")));
                                else if (n) return !1
                        }
                        return !0
                    },
                    it = function(e) {
                        var t = void 0,
                            o = void 0,
                            r = void 0,
                            a = void 0,
                            s = void 0;
                        et("beforeSanitizeAttributes", e, null);
                        var l = e.attributes;
                        if (l) {
                            var u = {
                                attrName: "",
                                attrValue: "",
                                keepAttr: !0,
                                allowedAttributes: we
                            };
                            for (s = l.length; s--;) {
                                var c = t = l[s],
                                    m = c.name,
                                    y = c.namespaceURI;
                                if (o = w(t.value), r = v(m), u.attrName = r, u.attrValue = o, u.keepAttr = !0, u.forceKeepAttr = void 0, et("uponSanitizeAttribute", e, u), o = u.attrValue, !u.forceKeepAttr) {
                                    if ("name" === r && "IMG" === e.nodeName && l.id) a = l.id, l = p(l, []), Ke("id", e), Ke(m, e), d(l, a) > s && e.setAttribute("id", a.value);
                                    else {
                                        if ("INPUT" === e.nodeName && "type" === r && "file" === o && u.keepAttr && (we[r] || !Ee[r])) continue;
                                        "id" === m && e.setAttribute(m, ""), Ke(m, e)
                                    }
                                    if (u.keepAttr)
                                        if (_e && A(/\/>/i, o)) Ke(m, e);
                                        else if (A(/svg|math/i, e.namespaceURI) && A(T("</(" + f(i(Be), "|") + ")", "i"), o)) Ke(m, e);
                                    else {
                                        xe && (o = g(o, de, " "), o = g(o, fe, " "));
                                        var b = e.nodeName.toLowerCase();
                                        if (nt(b, r, o)) try {
                                            y ? e.setAttributeNS(y, m, o) : e.setAttribute(m, o), h(n.removed)
                                        } catch (e) {}
                                    }
                                }
                            }
                            et("afterSanitizeAttributes", e, null)
                        }
                    },
                    ot = function e(t) {
                        var n = void 0,
                            i = Qe(t);
                        for (et("beforeSanitizeShadowDOM", t, null); n = i.nextNode();) et("uponSanitizeShadowNode", n, null), tt(n) || (n.content instanceof l && e(n.content), it(n));
                        et("afterSanitizeShadowDOM", t, null)
                    };
                return n.sanitize = function(e, i) {
                    var o = void 0,
                        a = void 0,
                        s = void 0,
                        u = void 0,
                        c = void 0;
                    if (e || (e = "\x3c!--\x3e"), "string" != typeof e && !Je(e)) {
                        if ("function" != typeof e.toString) throw E("toString is not a function");
                        if ("string" != typeof(e = e.toString())) throw E("dirty is not a string, aborting")
                    }
                    if (!n.isSupported) {
                        if ("object" === q(t.toStaticHTML) || "function" == typeof t.toStaticHTML) {
                            if ("string" == typeof e) return t.toStaticHTML(e);
                            if (Je(e)) return t.toStaticHTML(e.outerHTML)
                        }
                        return e
                    }
                    if (Me || We(i), n.removed = [], "string" == typeof e && (Re = !1), Re);
                    else if (e instanceof L) 1 === (a = (o = Xe("\x3c!--\x3e")).ownerDocument.importNode(e, !0)).nodeType && "BODY" === a.nodeName || "HTML" === a.nodeName ? o = a : o.appendChild(a);
                    else {
                        if (!Fe && !xe && !Oe && -1 === e.indexOf("<")) return te && Pe ? te.createHTML(e) : e;
                        if (!(o = Xe(e))) return Fe ? null : ne
                    }
                    o && Ce && Ye(o.firstChild);
                    for (var d = Qe(Re ? e : o); s = d.nextNode();) 3 === s.nodeType && s === u || tt(s) || (s.content instanceof l && ot(s.content), it(s), u = s);
                    if (u = null, Re) return e;
                    if (Fe) {
                        if (De)
                            for (c = se.call(o.ownerDocument); o.firstChild;) c.appendChild(o.firstChild);
                        else c = o;
                        return Ne && (c = le.call(r, c, !0)), c
                    }
                    var f = Oe ? o.outerHTML : o.innerHTML;
                    return xe && (f = g(f, de, " "), f = g(f, fe, " ")), te && Pe ? te.createHTML(f) : f
                }, n.setConfig = function(e) {
                    We(e), Me = !0
                }, n.clearConfig = function() {
                    Ze = null, Me = !1
                }, n.isValidAttribute = function(e, t, n) {
                    Ze || We({});
                    var i = v(e),
                        o = v(t);
                    return nt(i, o, n)
                }, n.addHook = function(e, t) {
                    "function" == typeof t && (ce[e] = ce[e] || [], m(ce[e], t))
                }, n.removeHook = function(e) {
                    ce[e] && h(ce[e])
                }, n.removeHooks = function(e) {
                    ce[e] && (ce[e] = [])
                }, n.removeAllHooks = function() {
                    ce = {}
                }, n
            }()
        }()
    }));

    function F(e, t) {
        return new Promise((function(n, i) {
            if (p(t) && null !== document.getElementById(t)) n();
            else {
                var o = S("div", {
                    hidden: "",
                    id: t
                });
                (function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "text";
                    return new Promise((function(n, i) {
                        try {
                            var o = new XMLHttpRequest;
                            if (!("withCredentials" in o)) return;
                            o.addEventListener("load", (function() {
                                if ("text" === t) try {
                                    n(JSON.parse(o.responseText))
                                } catch (e) {
                                    n(o.responseText)
                                } else n(o.response)
                            })), o.addEventListener("error", (function() {
                                throw new Error(o.status)
                            })), o.open("GET", e, !0), o.responseType = t, o.send()
                        } catch (e) {
                            i(e)
                        }
                    }))
                })(e).then((function(e) {
                    T(e) && n(), o.innerHTML = C.sanitize(e), document.body.insertBefore(o, document.body.firstChild), n(o)
                })).catch((function(e) {
                    i(e)
                }))
            }
        }))
    }
    var D = ["zoom-in", "zoom-out", "fullscreen"];

    function N(e) {
        var t = e.iconName,
            n = e.classList,
            i = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        i.setAttribute("focusable", !1), i.setAttribute("class", n.join(" "));
        var o = document.createElementNS("http://www.w3.org/2000/svg", "use");
        return o.setAttributeNS("http://www.w3.org/1999/xlink", "path", "#".concat(t)), o.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", "#".concat(t)), i.appendChild(o), i
    }
    var P = {
        build: function(e) {
            var t = e.viewer,
                n = e.elements,
                i = e.container,
                o = e.config,
                r = o.controls,
                a = o.iconUrl,
                s = S("div", {
                    class: "shopify-model-viewer-ui__sr-only",
                    "data-shopify-model-viewer-ui-sr-only": "",
                    role: "status"
                }),
                l = S("div", {
                    class: "shopify-model-viewer-ui__controls-overlay"
                });
            if (i.insertBefore(s, t), i.appendChild(l), this.buildControlButton(e, l), r && Array.isArray(r) && r.length) {
                var u = r.filter((function(e) {
                    return !D.includes(e)
                }));
                if (u.length > 0) throw Error("Unrecognized controls passed to ModelViewerUI: ".concat(u.join(", ")));
                F(a, "sprites-mvui").then((function(e) {
                    n.sprites = e
                })).catch((function() {
                    throw Error("Failed to load sprite from URL")
                })), n.zoomLevel = s, this.buildControlList(e, l)
            }
        },
        buildControlList: function(e, t) {
            var n = e.config.controls,
                i = S("div", {
                    class: "shopify-model-viewer-ui__controls-area"
                });
            t.appendChild(i), n.forEach((function(t) {
                var n = S("button", {
                    class: "shopify-model-viewer-ui__button shopify-model-viewer-ui__button--control shopify-model-viewer-ui__button--".concat(t)
                });
                switch (t) {
                    case "zoom-in":
                        n.setAttribute("aria-label", "Zoom In"), n.appendChild(N({
                            iconName: "zoom-in-icon",
                            classList: ["shopify-model-viewer-ui__control-icon"]
                        }));
                        break;
                    case "zoom-out":
                        n.setAttribute("aria-label", "Zoom Out"), n.appendChild(N({
                            iconName: "zoom-out-icon",
                            classList: ["shopify-model-viewer-ui__control-icon"]
                        }));
                        break;
                    case "fullscreen":
                        n.setAttribute("aria-label", "Enter Fullscreen"), n.appendChild(N({
                            iconName: "enter-fullscreen-icon",
                            classList: ["shopify-model-viewer-ui__control-icon", "shopify-model-viewer-ui__control-icon--enter-fullscreen"]
                        })), n.appendChild(N({
                            iconName: "exit-fullscreen-icon",
                            classList: ["shopify-model-viewer-ui__control-icon", "shopify-model-viewer-ui__control-icon--exit-fullscreen"]
                        }))
                }
                e.elements.buttons[t] = n, i.appendChild(n)
            })), e.elements.controlArea = i
        },
        buildControlButton: function(e, t) {
            var n = e.elements,
                i = S("button", {
                    class: "shopify-model-viewer-ui__button shopify-model-viewer-ui__button--poster"
                });
            i.setAttribute("aria-label", "Play 3D Viewer"), i.appendChild(N({
                iconName: "threed-icon-button-control",
                classList: ["shopify-model-viewer-ui__poster-control-icon"]
            })), n.controlButton = i, t.appendChild(i)
        }
    };

    function z() {
        return document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement
    }

    function I(e, t) {
        for (var n = 0; n < e.length; n++) {
            if (e[n].identifier === t) return n
        }
        return -1
    }
    var R = {
            isDragging: !1,
            cursorStartPosition: null
        },
        j = function() {
            function t(n) {
                e(this, t), this.mvui = n, this.state = r({}, R), this.onMouseDown = this.onMouseDown.bind(this), this.onMouseMove = this.onMouseMove.bind(this), this.onMouseUp = this.onMouseUp.bind(this), this.resetState = this.resetState.bind(this)
            }
            return n(t, [{
                key: "add",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : R,
                        t = this.mvui.container;
                    this.state = r({}, e), t.addEventListener("mousedown", this.onMouseDown), t.addEventListener("mousemove", this.onMouseMove), t.addEventListener("mouseup", this.onMouseUp)
                }
            }, {
                key: "remove",
                value: function() {
                    var e = this.mvui.container;
                    e.removeEventListener("mousedown", this.onMouseDown), e.removeEventListener("mousemove", this.onMouseMove), e.removeEventListener("mouseup", this.onMouseUp)
                }
            }, {
                key: "onMouseDown",
                value: function(e) {
                    this.resetState(), this.state.cursorStartPosition = {
                        x: e.pageX,
                        y: e.pageY
                    }
                }
            }, {
                key: "onMouseMove",
                value: function(e) {
                    var t, n, i = this.state.cursorStartPosition;
                    g(i) || (t = i, n = {
                        x: e.pageX,
                        y: e.pageY
                    }, (Math.abs(t.x - n.x) > 4 || Math.abs(t.y - n.y) > 4) && (this.state.isDragging = !0))
                }
            }, {
                key: "onMouseUp",
                value: function(e) {
                    var t = this.mvui,
                        n = t.interacting,
                        i = t.elements,
                        o = t.toggleable,
                        r = i.controlArea,
                        a = this.state.isDragging;
                    r.contains(e.target) || (n || a ? o && n && !a && t.pause() : t.play()), this.resetState()
                }
            }, {
                key: "resetState",
                value: function() {
                    this.state = r({}, R)
                }
            }]), t
        }();
    var B = {
            isDragging: !1,
            isPinchZooming: !1,
            ongoingTouches: [],
            touchStartPositions: []
        },
        U = function() {
            function t(n) {
                e(this, t), this.mvui = n, this.state = r({}, B), this.onTouchStart = this.onTouchStart.bind(this), this.onTouchMove = this.onTouchMove.bind(this), this.onTouchEnd = this.onTouchEnd.bind(this), this.resetState = this.resetState.bind(this)
            }
            return n(t, [{
                key: "add",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : B,
                        t = this.mvui.container;
                    this.state = r({}, e), t.addEventListener("touchstart", this.onTouchStart), t.addEventListener("touchmove", this.onTouchMove), t.addEventListener("touchend", this.onTouchEnd)
                }
            }, {
                key: "remove",
                value: function() {
                    var e = this.mvui.container;
                    e.removeEventListener("touchstart", this.onTouchStart), e.removeEventListener("touchmove", this.onTouchMove), e.removeEventListener("touchend", this.onTouchEnd)
                }
            }, {
                key: "onTouchStart",
                value: function(e) {
                    for (var t, n = this.state, i = n.ongoingTouches, o = n.touchStartPositions, r = e.changedTouches, a = 0; a < r.length; a++) {
                        var s = {
                            identifier: (t = r[a]).identifier,
                            pageX: t.pageX,
                            pageY: t.pageY
                        };
                        i.push(s), o.push({
                            x: s.pageX,
                            y: s.pageY
                        })
                    }
                }
            }, {
                key: "onTouchMove",
                value: function(e) {
                    var t, n, i = e.changedTouches,
                        o = this.state,
                        r = o.ongoingTouches,
                        a = o.touchStartPositions;
                    r.length >= 2 && (this.state.isPinchZooming = !0);
                    for (var s = 0; s < i.length; s++) {
                        var l = i[s],
                            u = l.pageX,
                            c = l.pageY,
                            d = I(r, l.identifier);
                        if (-1 !== d) {
                            var f = a[d];
                            t = f, n = {
                                x: u,
                                y: c
                            }, (Math.abs(t.x - n.x) > 10 || Math.abs(t.y - n.y) > 10) && (this.state.isDragging = !0)
                        }
                    }
                }
            }, {
                key: "onTouchEnd",
                value: function(e) {
                    for (var t = e.changedTouches, n = e.target, i = this.mvui, o = i.interacting, r = i.elements, a = i.toggleable, s = r.controlArea, l = this.state, u = l.isDragging, c = l.isPinchZooming, d = l.ongoingTouches, f = l.touchStartPositions, h = 0; h < t.length; h++) {
                        var m = I(d, t[h].identifier); - 1 !== m && (d.splice(m, 1), f.splice(m, 1))
                    }
                    0 === d.length && this.resetState(), s.contains(n) || (o || u || c ? a && o && !u && !c && i.pause() : i.play())
                }
            }, {
                key: "resetState",
                value: function() {
                    this.state = r({}, B)
                }
            }]), t
        }(),
        H = function() {
            function t(n) {
                e(this, t), this.mvui = n, "ontouchstart" in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0 ? this.touchListeners = new U(n) : this.mouseListeners = new j(n), this.onModelVisibilityChanged = this.onModelVisibilityChanged.bind(this), this.onViewerKeyPress = this.onViewerKeyPress.bind(this), this.onControlButtonClick = this.onControlButtonClick.bind(this), this.onFullscreenChange = this.onFullscreenChange.bind(this), this.onUIButtonFocus = this.onUIButtonFocus.bind(this), this.onUIButtonBlur = this.onUIButtonBlur.bind(this), this.onZoomOut = this.onZoomOut.bind(this), this.onZoomIn = this.onZoomIn.bind(this), this.onFullscreen = this.onFullscreen.bind(this)
            }
            return n(t, [{
                key: "add",
                value: function() {
                    var e = this,
                        t = this.mvui,
                        n = t.viewer,
                        i = t.elements,
                        o = i.buttons,
                        r = i.controlButton;
                    for (var a in n.addEventListener("model-visibility", this.onModelVisibilityChanged), n.addEventListener("keypress", this.onViewerKeyPress), r.addEventListener("click", this.onControlButtonClick), ["fullscreenchange", "mozfullscreenchange", "webkitfullscreenchange"].forEach((function(t) {
                            document.addEventListener(t, e.onFullscreenChange, !1)
                        })), o) Object.prototype.hasOwnProperty.call(o, a) && (o[a].addEventListener("focus", this.onUIButtonFocus), o[a].addEventListener("blur", this.onUIButtonBlur));
                    var s = o["zoom-in"];
                    s && s.addEventListener("click", this.onZoomIn);
                    var l = o["zoom-out"];
                    l && l.addEventListener("click", this.onZoomOut);
                    var u = o.fullscreen;
                    u && u.addEventListener("click", this.onFullscreen), this.mouseListeners && this.mouseListeners.add(), this.touchListeners && this.touchListeners.add()
                }
            }, {
                key: "remove",
                value: function() {
                    var e = this,
                        t = this.mvui,
                        n = t.viewer,
                        i = t.elements,
                        o = i.buttons,
                        r = i.controlButton;
                    for (var a in n.removeEventListener("model-visibility", this.onModelVisibilityChanged), n.removeEventListener("keypress", this.onViewerKeyPress), r.removeEventListener("click", this.onControlButtonClick), ["fullscreenchange", "mozfullscreenchange", "webkitfullscreenchange"].forEach((function(t) {
                            document.removeEventListener(t, e.onFullscreenChange, !1)
                        })), o) Object.prototype.hasOwnProperty.call(o, a) && (o[a].removeEventListener("focus", this.onUIButtonFocus), o[a].removeEventListener("blur", this.onUIButtonBlur));
                    this.mouseEventListeners && this.mouseListeners.remove(), this.touchListeners && this.touchListeners.remove()
                }
            }, {
                key: "onModelVisibilityChanged",
                value: function(e) {
                    var t = this.mvui,
                        n = t.viewer,
                        i = e.target,
                        o = e.detail;
                    i === n && (t.modelIsVisible = o.visible)
                }
            }, {
                key: "onViewerKeyPress",
                value: function(e) {
                    var t = this.mvui;
                    if (t.interacting) {
                        var n = e.which || e.keyCode;
                        switch (String.fromCharCode(n)) {
                            case "-":
                                t.zoom(8);
                                break;
                            case "+":
                                t.zoom(-8);
                                break;
                            case "f":
                                t.toggleFullscreen()
                        }
                    }
                }
            }, {
                key: "onControlButtonClick",
                value: function() {
                    var e = this.mvui;
                    e.interacting || e.play()
                }
            }, {
                key: "onFullscreenChange",
                value: function() {
                    var e = this.mvui.container;
                    z() ? e.classList.add("shopify-model-viewer-ui--fullscreen") : e.classList.remove("shopify-model-viewer-ui--fullscreen")
                }
            }, {
                key: "onUIButtonFocus",
                value: function() {
                    this.mvui.container.classList.add("shopify-model-viewer-ui--child-focused")
                }
            }, {
                key: "onUIButtonBlur",
                value: function() {
                    this.mvui.container.classList.remove("shopify-model-viewer-ui--child-focused")
                }
            }, {
                key: "onZoomOut",
                value: function(e) {
                    e.stopPropagation(), this.mvui.zoom(8)
                }
            }, {
                key: "onZoomIn",
                value: function(e) {
                    e.stopPropagation(), this.mvui.zoom(-8)
                }
            }, {
                key: "onFullscreen",
                value: function(e) {
                    e.stopPropagation(), this.mvui.toggleFullscreen()
                }
            }]), t
        }(),
        V = function(e) {
            var t = e.state.listeners;
            t || ((t = new H(e)).add(), e.state.listeners = t)
        },
        q = function(e) {
            e.state.listeners.remove()
        },
        Z = new L;

    function G(e) {
        var t = e;
        if (p(t) && (t = document.querySelector(t)), E(t) && (t = t[0]), y(t) || v(t)) throw Error("Use static setup method when using an array or nodeList of elements");
        if (g(t) || !b(t)) throw Error("Please pass in a query selector, element, or jQuery instance");
        return t
    }

    function W() {
        return void 0 !== window.orientation || -1 !== navigator.userAgent.indexOf("IEMobile")
    }
    var Y = function() {
        function t(n) {
            var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            e(this, t), this.config = r(r({}, M.config), i);
            var o = G(n),
                a = Z.getCachedInstance(o);
            if (a) return a;
            var s = o.getAttribute("reveal"),
                l = Boolean(o.getAttribute("toggleable"));
            if (this.state = {
                    elements: {
                        original: o.cloneNode(!0),
                        buttons: {},
                        container: null,
                        controlButton: null,
                        controlArea: null,
                        zoomLevel: null,
                        sprites: null
                    },
                    viewerProperties: {
                        reveal: s,
                        interaction: o.getAttribute("interaction"),
                        orbit: o.cameraOrbit,
                        fov: o.fieldOfView,
                        zoomLevelTimeout: null
                    },
                    viewer: o,
                    interacting: "interaction" !== s,
                    toggleable: !!A(l) && l,
                    modelIsVisible: !1
                }, this.defineProperties(), !b(this.container)) {
                var u = S("div", {
                    class: "shopify-model-viewer-ui"
                });
                W() || u.classList.add("shopify-model-viewer-ui--desktop"), k(this.viewer, u), this.container = u
            }
            Z.cacheInstance(this), P.build(this), V(this), this.interacting ? x(this.elements.controlButton, !0) : (x(this.elements.controlButton, !1), O(o, "shopify-model-viewer-ui__disabled", !0), o.setAttribute("tabindex", "-1"))
        }
        return n(t, [{
            key: "destroy",
            value: function() {
                if (this.state) {
                    var e, t, n = this.state.elements,
                        i = n.sprites,
                        o = n.original;
                    i && _(i), e = o, t = this.container, b(t) && b(t.parentNode) && b(e) && t.parentNode.replaceChild(e, t), q(this), Z.removeFromCache(this.viewer), this.state = null
                }
            }
        }, {
            key: "zoom",
            value: function(e) {
                var t = this.viewer,
                    n = this.elements,
                    i = this.viewerProperties,
                    o = t.getFieldOfView();
                o += e;
                var r = Math.min(Math.max(o, 10), 45);
                t.fieldOfView = "".concat(r, "deg");
                var a = 100 * (r - 45) / -35;
                n.zoomLevel.innerText = "".concat(Math.round(a), "% ").concat("Zoomed", "."), clearTimeout(i.zoomLevelTimeout), i.zoomLevelTimeout = setTimeout((function() {
                    n.zoomLevel.innerText = ""
                }), 5e3)
            }
        }, {
            key: "toggleFullscreen",
            value: function() {
                var e = this.container,
                    t = this.elements.buttons.fullscreen;
                z() ? (t.setAttribute("aria-label", "Enter Fullscreen"), document.cancelFullScreen ? document.cancelFullScreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen && document.webkitCancelFullScreen()) : (t.setAttribute("aria-label", "Exit Fullscreen"), e.requestFullscreen ? e.requestFullscreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.webkitRequestFullscreen && e.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT))
            }
        }, {
            key: "play",
            value: function() {
                var e = this.elements,
                    t = this.viewer,
                    n = this.modelIsVisible,
                    i = e.controlButton,
                    o = e.controlArea;
                "interaction" === t.getAttribute("reveal") && t.setAttribute("reveal", "auto"), x(i, !0), t.dispatchEvent(new CustomEvent("shopify_model_viewer_ui_toggle_play", {
                    detail: {
                        modelViewerUI: this
                    }
                })), O(t, "shopify-model-viewer-ui__disabled", !1), t.setAttribute("tabindex", "0"), this.config.focusOnPlay && t.focus(), n && O(o, "shopify-model-viewer-ui__controls-area--playing", !0), this.interacting = !0
            }
        }, {
            key: "pause",
            value: function() {
                var e = this.elements,
                    t = this.viewer,
                    n = this.viewerProperties,
                    i = e.controlButton,
                    o = e.controlArea,
                    r = n.orbit,
                    a = n.fov;
                x(i, !1), t.dispatchEvent(new CustomEvent("shopify_model_viewer_ui_toggle_pause", {
                    detail: {
                        modelViewerUI: this
                    }
                })), O(t, "shopify-model-viewer-ui__disabled", !0), O(o, "shopify-model-viewer-ui__controls-area--playing", !1), t.setAttribute("tabindex", "-1"), t.blur(), t.cameraOrbit = r, t.fieldOfView = a, t.pause(), this.interacting = !1
            }
        }, {
            key: "defineProperties",
            value: function() {
                Object.defineProperty(this, "elements", {
                    value: this.state.elements,
                    writable: !1
                }), Object.defineProperty(this, "viewer", {
                    value: this.state.viewer,
                    writable: !1
                }), Object.defineProperty(this, "viewerProperties", {
                    value: this.state.viewerProperties,
                    writable: !1
                }), Object.defineProperty(this, "toggleable", {
                    value: this.state.toggleable,
                    writable: !1
                }), Object.defineProperty(this, "interacting", {
                    value: this.state.interacting,
                    writable: !0
                }), Object.defineProperty(this, "container", {
                    value: this.elements.container,
                    writable: !0
                })
            }
        }, {
            key: "modelIsVisible",
            get: function() {
                return this.state.modelIsVisible
            },
            set: function(e) {
                this.state.modelIsVisible = e;
                var t = this.elements,
                    n = t.controlArea,
                    i = t.controlButton;
                e && !g(n) && (x(i, !0), O(n, "shopify-model-viewer-ui__controls-area--playing", !0))
            }
        }], [{
            key: "setup",
            value: function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    i = null;
                return p(e) ? i = Array.from(document.querySelectorAll(e)) : v(e) ? i = Array.from(e) : y(e) && (i = e.filter(b)), T(i) ? null : i.map((function(e) {
                    return new t(e, n)
                }))
            }
        }]), t
    }();
    window.Shopify = window.Shopify || {}, window.Shopify.ModelViewerUI = Y
}();
//# sourceMappingURL=model-viewer-ui.en.js.map